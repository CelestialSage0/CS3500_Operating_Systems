
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00009117          	auipc	sp,0x9
    80000004:	a6010113          	addi	sp,sp,-1440 # 80008a60 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	078000ef          	jal	ra,8000008e <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
// at timervec in kernelvec.S,
// which turns them into software interrupts for
// devintr() in trap.c.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
// which hart (core) is this?
static inline uint64
r_mhartid()
{
  uint64 x;
  asm volatile("csrr %0, mhartid" : "=r"(x));
    80000022:	f14027f3          	csrr	a5,mhartid
  // each CPU has a separate source of timer interrupts.
  int id = r_mhartid();
    80000026:	0007869b          	sext.w	a3,a5

  // ask the CLINT for a timer interrupt.
  int interval = 1000000; // cycles; about 1/10th second in qemu.
  *(uint64*)CLINT_MTIMECMP(id) = *(uint64*)CLINT_MTIME + interval;
    8000002a:	0037979b          	slliw	a5,a5,0x3
    8000002e:	02004737          	lui	a4,0x2004
    80000032:	97ba                	add	a5,a5,a4
    80000034:	0200c737          	lui	a4,0x200c
    80000038:	ff873583          	ld	a1,-8(a4) # 200bff8 <_entry-0x7dff4008>
    8000003c:	000f4637          	lui	a2,0xf4
    80000040:	24060613          	addi	a2,a2,576 # f4240 <_entry-0x7ff0bdc0>
    80000044:	95b2                	add	a1,a1,a2
    80000046:	e38c                	sd	a1,0(a5)

  // prepare information in scratch[] for timervec.
  // scratch[0..2] : space for timervec to save registers.
  // scratch[3] : address of CLINT MTIMECMP register.
  // scratch[4] : desired interval (in cycles) between timer interrupts.
  uint64 *scratch = &timer_scratch[id][0];
    80000048:	00269713          	slli	a4,a3,0x2
    8000004c:	9736                	add	a4,a4,a3
    8000004e:	00371693          	slli	a3,a4,0x3
    80000052:	00009717          	auipc	a4,0x9
    80000056:	8ce70713          	addi	a4,a4,-1842 # 80008920 <timer_scratch>
    8000005a:	9736                	add	a4,a4,a3
  scratch[3] = CLINT_MTIMECMP(id);
    8000005c:	ef1c                	sd	a5,24(a4)
  scratch[4] = interval;
    8000005e:	f310                	sd	a2,32(a4)
}

static inline void
w_mscratch(uint64 x)
{
  asm volatile("csrw mscratch, %0" : : "r"(x));
    80000060:	34071073          	csrw	mscratch,a4
  asm volatile("csrw mtvec, %0" : : "r"(x));
    80000064:	00006797          	auipc	a5,0x6
    80000068:	e0c78793          	addi	a5,a5,-500 # 80005e70 <timervec>
    8000006c:	30579073          	csrw	mtvec,a5
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000070:	300027f3          	csrr	a5,mstatus

  // set the machine-mode trap handler.
  w_mtvec((uint64)timervec);

  // enable machine-mode interrupts.
  w_mstatus(r_mstatus() | MSTATUS_MIE);
    80000074:	0087e793          	ori	a5,a5,8
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000078:	30079073          	csrw	mstatus,a5
  asm volatile("csrr %0, mie" : "=r"(x));
    8000007c:	304027f3          	csrr	a5,mie

  // enable machine-mode timer interrupts.
  w_mie(r_mie() | MIE_MTIE);
    80000080:	0807e793          	ori	a5,a5,128
  asm volatile("csrw mie, %0" : : "r"(x));
    80000084:	30479073          	csrw	mie,a5
}
    80000088:	6422                	ld	s0,8(sp)
    8000008a:	0141                	addi	sp,sp,16
    8000008c:	8082                	ret

000000008000008e <start>:
{
    8000008e:	1141                	addi	sp,sp,-16
    80000090:	e406                	sd	ra,8(sp)
    80000092:	e022                	sd	s0,0(sp)
    80000094:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000096:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000009a:	7779                	lui	a4,0xffffe
    8000009c:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7fdbca57>
    800000a0:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    800000a2:	6705                	lui	a4,0x1
    800000a4:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    800000a8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    800000aa:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    800000ae:	00001797          	auipc	a5,0x1
    800000b2:	f2478793          	addi	a5,a5,-220 # 80000fd2 <main>
    800000b6:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    800000ba:	4781                	li	a5,0
    800000bc:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    800000c0:	67c1                	lui	a5,0x10
    800000c2:	17fd                	addi	a5,a5,-1
    800000c4:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    800000c8:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    800000cc:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    800000d0:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r"(x));
    800000d4:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    800000d8:	57fd                	li	a5,-1
    800000da:	83a9                	srli	a5,a5,0xa
    800000dc:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000e0:	47bd                	li	a5,15
    800000e2:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000e6:	00000097          	auipc	ra,0x0
    800000ea:	f36080e7          	jalr	-202(ra) # 8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000ee:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000f2:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000f4:	823e                	mv	tp,a5
  asm volatile("mret");
    800000f6:	30200073          	mret
}
    800000fa:	60a2                	ld	ra,8(sp)
    800000fc:	6402                	ld	s0,0(sp)
    800000fe:	0141                	addi	sp,sp,16
    80000100:	8082                	ret

0000000080000102 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80000102:	715d                	addi	sp,sp,-80
    80000104:	e486                	sd	ra,72(sp)
    80000106:	e0a2                	sd	s0,64(sp)
    80000108:	fc26                	sd	s1,56(sp)
    8000010a:	f84a                	sd	s2,48(sp)
    8000010c:	f44e                	sd	s3,40(sp)
    8000010e:	f052                	sd	s4,32(sp)
    80000110:	ec56                	sd	s5,24(sp)
    80000112:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80000114:	04c05663          	blez	a2,80000160 <consolewrite+0x5e>
    80000118:	8a2a                	mv	s4,a0
    8000011a:	84ae                	mv	s1,a1
    8000011c:	89b2                	mv	s3,a2
    8000011e:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80000120:	5afd                	li	s5,-1
    80000122:	4685                	li	a3,1
    80000124:	8626                	mv	a2,s1
    80000126:	85d2                	mv	a1,s4
    80000128:	fbf40513          	addi	a0,s0,-65
    8000012c:	00002097          	auipc	ra,0x2
    80000130:	610080e7          	jalr	1552(ra) # 8000273c <either_copyin>
    80000134:	01550c63          	beq	a0,s5,8000014c <consolewrite+0x4a>
      break;
    uartputc(c);
    80000138:	fbf44503          	lbu	a0,-65(s0)
    8000013c:	00000097          	auipc	ra,0x0
    80000140:	780080e7          	jalr	1920(ra) # 800008bc <uartputc>
  for(i = 0; i < n; i++){
    80000144:	2905                	addiw	s2,s2,1
    80000146:	0485                	addi	s1,s1,1
    80000148:	fd299de3          	bne	s3,s2,80000122 <consolewrite+0x20>
  }

  return i;
}
    8000014c:	854a                	mv	a0,s2
    8000014e:	60a6                	ld	ra,72(sp)
    80000150:	6406                	ld	s0,64(sp)
    80000152:	74e2                	ld	s1,56(sp)
    80000154:	7942                	ld	s2,48(sp)
    80000156:	79a2                	ld	s3,40(sp)
    80000158:	7a02                	ld	s4,32(sp)
    8000015a:	6ae2                	ld	s5,24(sp)
    8000015c:	6161                	addi	sp,sp,80
    8000015e:	8082                	ret
  for(i = 0; i < n; i++){
    80000160:	4901                	li	s2,0
    80000162:	b7ed                	j	8000014c <consolewrite+0x4a>

0000000080000164 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000164:	7159                	addi	sp,sp,-112
    80000166:	f486                	sd	ra,104(sp)
    80000168:	f0a2                	sd	s0,96(sp)
    8000016a:	eca6                	sd	s1,88(sp)
    8000016c:	e8ca                	sd	s2,80(sp)
    8000016e:	e4ce                	sd	s3,72(sp)
    80000170:	e0d2                	sd	s4,64(sp)
    80000172:	fc56                	sd	s5,56(sp)
    80000174:	f85a                	sd	s6,48(sp)
    80000176:	f45e                	sd	s7,40(sp)
    80000178:	f062                	sd	s8,32(sp)
    8000017a:	ec66                	sd	s9,24(sp)
    8000017c:	e86a                	sd	s10,16(sp)
    8000017e:	1880                	addi	s0,sp,112
    80000180:	8aaa                	mv	s5,a0
    80000182:	8a2e                	mv	s4,a1
    80000184:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000186:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018a:	00011517          	auipc	a0,0x11
    8000018e:	8d650513          	addi	a0,a0,-1834 # 80010a60 <cons>
    80000192:	00001097          	auipc	ra,0x1
    80000196:	b9e080e7          	jalr	-1122(ra) # 80000d30 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019a:	00011497          	auipc	s1,0x11
    8000019e:	8c648493          	addi	s1,s1,-1850 # 80010a60 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a2:	00011917          	auipc	s2,0x11
    800001a6:	95690913          	addi	s2,s2,-1706 # 80010af8 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    800001aa:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001ac:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    800001ae:	4ca9                	li	s9,10
  while(n > 0){
    800001b0:	07305b63          	blez	s3,80000226 <consoleread+0xc2>
    while(cons.r == cons.w){
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	02f71763          	bne	a4,a5,800001ea <consoleread+0x86>
      if(killed(myproc())){
    800001c0:	00002097          	auipc	ra,0x2
    800001c4:	a72080e7          	jalr	-1422(ra) # 80001c32 <myproc>
    800001c8:	00002097          	auipc	ra,0x2
    800001cc:	3be080e7          	jalr	958(ra) # 80002586 <killed>
    800001d0:	e535                	bnez	a0,8000023c <consoleread+0xd8>
      sleep(&cons.r, &cons.lock);
    800001d2:	85a6                	mv	a1,s1
    800001d4:	854a                	mv	a0,s2
    800001d6:	00002097          	auipc	ra,0x2
    800001da:	108080e7          	jalr	264(ra) # 800022de <sleep>
    while(cons.r == cons.w){
    800001de:	0984a783          	lw	a5,152(s1)
    800001e2:	09c4a703          	lw	a4,156(s1)
    800001e6:	fcf70de3          	beq	a4,a5,800001c0 <consoleread+0x5c>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ea:	0017871b          	addiw	a4,a5,1
    800001ee:	08e4ac23          	sw	a4,152(s1)
    800001f2:	07f7f713          	andi	a4,a5,127
    800001f6:	9726                	add	a4,a4,s1
    800001f8:	01874703          	lbu	a4,24(a4)
    800001fc:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    80000200:	077d0563          	beq	s10,s7,8000026a <consoleread+0x106>
    cbuf = c;
    80000204:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000208:	4685                	li	a3,1
    8000020a:	f9f40613          	addi	a2,s0,-97
    8000020e:	85d2                	mv	a1,s4
    80000210:	8556                	mv	a0,s5
    80000212:	00002097          	auipc	ra,0x2
    80000216:	4d4080e7          	jalr	1236(ra) # 800026e6 <either_copyout>
    8000021a:	01850663          	beq	a0,s8,80000226 <consoleread+0xc2>
    dst++;
    8000021e:	0a05                	addi	s4,s4,1
    --n;
    80000220:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    80000222:	f99d17e3          	bne	s10,s9,800001b0 <consoleread+0x4c>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    80000226:	00011517          	auipc	a0,0x11
    8000022a:	83a50513          	addi	a0,a0,-1990 # 80010a60 <cons>
    8000022e:	00001097          	auipc	ra,0x1
    80000232:	bb6080e7          	jalr	-1098(ra) # 80000de4 <release>

  return target - n;
    80000236:	413b053b          	subw	a0,s6,s3
    8000023a:	a811                	j	8000024e <consoleread+0xea>
        release(&cons.lock);
    8000023c:	00011517          	auipc	a0,0x11
    80000240:	82450513          	addi	a0,a0,-2012 # 80010a60 <cons>
    80000244:	00001097          	auipc	ra,0x1
    80000248:	ba0080e7          	jalr	-1120(ra) # 80000de4 <release>
        return -1;
    8000024c:	557d                	li	a0,-1
}
    8000024e:	70a6                	ld	ra,104(sp)
    80000250:	7406                	ld	s0,96(sp)
    80000252:	64e6                	ld	s1,88(sp)
    80000254:	6946                	ld	s2,80(sp)
    80000256:	69a6                	ld	s3,72(sp)
    80000258:	6a06                	ld	s4,64(sp)
    8000025a:	7ae2                	ld	s5,56(sp)
    8000025c:	7b42                	ld	s6,48(sp)
    8000025e:	7ba2                	ld	s7,40(sp)
    80000260:	7c02                	ld	s8,32(sp)
    80000262:	6ce2                	ld	s9,24(sp)
    80000264:	6d42                	ld	s10,16(sp)
    80000266:	6165                	addi	sp,sp,112
    80000268:	8082                	ret
      if(n < target){
    8000026a:	0009871b          	sext.w	a4,s3
    8000026e:	fb677ce3          	bgeu	a4,s6,80000226 <consoleread+0xc2>
        cons.r--;
    80000272:	00011717          	auipc	a4,0x11
    80000276:	88f72323          	sw	a5,-1914(a4) # 80010af8 <cons+0x98>
    8000027a:	b775                	j	80000226 <consoleread+0xc2>

000000008000027c <consputc>:
{
    8000027c:	1141                	addi	sp,sp,-16
    8000027e:	e406                	sd	ra,8(sp)
    80000280:	e022                	sd	s0,0(sp)
    80000282:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000284:	10000793          	li	a5,256
    80000288:	00f50a63          	beq	a0,a5,8000029c <consputc+0x20>
    uartputc_sync(c);
    8000028c:	00000097          	auipc	ra,0x0
    80000290:	55e080e7          	jalr	1374(ra) # 800007ea <uartputc_sync>
}
    80000294:	60a2                	ld	ra,8(sp)
    80000296:	6402                	ld	s0,0(sp)
    80000298:	0141                	addi	sp,sp,16
    8000029a:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000029c:	4521                	li	a0,8
    8000029e:	00000097          	auipc	ra,0x0
    800002a2:	54c080e7          	jalr	1356(ra) # 800007ea <uartputc_sync>
    800002a6:	02000513          	li	a0,32
    800002aa:	00000097          	auipc	ra,0x0
    800002ae:	540080e7          	jalr	1344(ra) # 800007ea <uartputc_sync>
    800002b2:	4521                	li	a0,8
    800002b4:	00000097          	auipc	ra,0x0
    800002b8:	536080e7          	jalr	1334(ra) # 800007ea <uartputc_sync>
    800002bc:	bfe1                	j	80000294 <consputc+0x18>

00000000800002be <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002be:	1101                	addi	sp,sp,-32
    800002c0:	ec06                	sd	ra,24(sp)
    800002c2:	e822                	sd	s0,16(sp)
    800002c4:	e426                	sd	s1,8(sp)
    800002c6:	e04a                	sd	s2,0(sp)
    800002c8:	1000                	addi	s0,sp,32
    800002ca:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002cc:	00010517          	auipc	a0,0x10
    800002d0:	79450513          	addi	a0,a0,1940 # 80010a60 <cons>
    800002d4:	00001097          	auipc	ra,0x1
    800002d8:	a5c080e7          	jalr	-1444(ra) # 80000d30 <acquire>

  switch(c){
    800002dc:	47d5                	li	a5,21
    800002de:	0af48663          	beq	s1,a5,8000038a <consoleintr+0xcc>
    800002e2:	0297ca63          	blt	a5,s1,80000316 <consoleintr+0x58>
    800002e6:	47a1                	li	a5,8
    800002e8:	0ef48763          	beq	s1,a5,800003d6 <consoleintr+0x118>
    800002ec:	47c1                	li	a5,16
    800002ee:	10f49a63          	bne	s1,a5,80000402 <consoleintr+0x144>
  case C('P'):  // Print process list.
    procdump();
    800002f2:	00002097          	auipc	ra,0x2
    800002f6:	4a0080e7          	jalr	1184(ra) # 80002792 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002fa:	00010517          	auipc	a0,0x10
    800002fe:	76650513          	addi	a0,a0,1894 # 80010a60 <cons>
    80000302:	00001097          	auipc	ra,0x1
    80000306:	ae2080e7          	jalr	-1310(ra) # 80000de4 <release>
}
    8000030a:	60e2                	ld	ra,24(sp)
    8000030c:	6442                	ld	s0,16(sp)
    8000030e:	64a2                	ld	s1,8(sp)
    80000310:	6902                	ld	s2,0(sp)
    80000312:	6105                	addi	sp,sp,32
    80000314:	8082                	ret
  switch(c){
    80000316:	07f00793          	li	a5,127
    8000031a:	0af48e63          	beq	s1,a5,800003d6 <consoleintr+0x118>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    8000031e:	00010717          	auipc	a4,0x10
    80000322:	74270713          	addi	a4,a4,1858 # 80010a60 <cons>
    80000326:	0a072783          	lw	a5,160(a4)
    8000032a:	09872703          	lw	a4,152(a4)
    8000032e:	9f99                	subw	a5,a5,a4
    80000330:	07f00713          	li	a4,127
    80000334:	fcf763e3          	bltu	a4,a5,800002fa <consoleintr+0x3c>
      c = (c == '\r') ? '\n' : c;
    80000338:	47b5                	li	a5,13
    8000033a:	0cf48763          	beq	s1,a5,80000408 <consoleintr+0x14a>
      consputc(c);
    8000033e:	8526                	mv	a0,s1
    80000340:	00000097          	auipc	ra,0x0
    80000344:	f3c080e7          	jalr	-196(ra) # 8000027c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000348:	00010797          	auipc	a5,0x10
    8000034c:	71878793          	addi	a5,a5,1816 # 80010a60 <cons>
    80000350:	0a07a683          	lw	a3,160(a5)
    80000354:	0016871b          	addiw	a4,a3,1
    80000358:	0007061b          	sext.w	a2,a4
    8000035c:	0ae7a023          	sw	a4,160(a5)
    80000360:	07f6f693          	andi	a3,a3,127
    80000364:	97b6                	add	a5,a5,a3
    80000366:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    8000036a:	47a9                	li	a5,10
    8000036c:	0cf48563          	beq	s1,a5,80000436 <consoleintr+0x178>
    80000370:	4791                	li	a5,4
    80000372:	0cf48263          	beq	s1,a5,80000436 <consoleintr+0x178>
    80000376:	00010797          	auipc	a5,0x10
    8000037a:	7827a783          	lw	a5,1922(a5) # 80010af8 <cons+0x98>
    8000037e:	9f1d                	subw	a4,a4,a5
    80000380:	08000793          	li	a5,128
    80000384:	f6f71be3          	bne	a4,a5,800002fa <consoleintr+0x3c>
    80000388:	a07d                	j	80000436 <consoleintr+0x178>
    while(cons.e != cons.w &&
    8000038a:	00010717          	auipc	a4,0x10
    8000038e:	6d670713          	addi	a4,a4,1750 # 80010a60 <cons>
    80000392:	0a072783          	lw	a5,160(a4)
    80000396:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000039a:	00010497          	auipc	s1,0x10
    8000039e:	6c648493          	addi	s1,s1,1734 # 80010a60 <cons>
    while(cons.e != cons.w &&
    800003a2:	4929                	li	s2,10
    800003a4:	f4f70be3          	beq	a4,a5,800002fa <consoleintr+0x3c>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800003a8:	37fd                	addiw	a5,a5,-1
    800003aa:	07f7f713          	andi	a4,a5,127
    800003ae:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    800003b0:	01874703          	lbu	a4,24(a4)
    800003b4:	f52703e3          	beq	a4,s2,800002fa <consoleintr+0x3c>
      cons.e--;
    800003b8:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003bc:	10000513          	li	a0,256
    800003c0:	00000097          	auipc	ra,0x0
    800003c4:	ebc080e7          	jalr	-324(ra) # 8000027c <consputc>
    while(cons.e != cons.w &&
    800003c8:	0a04a783          	lw	a5,160(s1)
    800003cc:	09c4a703          	lw	a4,156(s1)
    800003d0:	fcf71ce3          	bne	a4,a5,800003a8 <consoleintr+0xea>
    800003d4:	b71d                	j	800002fa <consoleintr+0x3c>
    if(cons.e != cons.w){
    800003d6:	00010717          	auipc	a4,0x10
    800003da:	68a70713          	addi	a4,a4,1674 # 80010a60 <cons>
    800003de:	0a072783          	lw	a5,160(a4)
    800003e2:	09c72703          	lw	a4,156(a4)
    800003e6:	f0f70ae3          	beq	a4,a5,800002fa <consoleintr+0x3c>
      cons.e--;
    800003ea:	37fd                	addiw	a5,a5,-1
    800003ec:	00010717          	auipc	a4,0x10
    800003f0:	70f72a23          	sw	a5,1812(a4) # 80010b00 <cons+0xa0>
      consputc(BACKSPACE);
    800003f4:	10000513          	li	a0,256
    800003f8:	00000097          	auipc	ra,0x0
    800003fc:	e84080e7          	jalr	-380(ra) # 8000027c <consputc>
    80000400:	bded                	j	800002fa <consoleintr+0x3c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000402:	ee048ce3          	beqz	s1,800002fa <consoleintr+0x3c>
    80000406:	bf21                	j	8000031e <consoleintr+0x60>
      consputc(c);
    80000408:	4529                	li	a0,10
    8000040a:	00000097          	auipc	ra,0x0
    8000040e:	e72080e7          	jalr	-398(ra) # 8000027c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000412:	00010797          	auipc	a5,0x10
    80000416:	64e78793          	addi	a5,a5,1614 # 80010a60 <cons>
    8000041a:	0a07a703          	lw	a4,160(a5)
    8000041e:	0017069b          	addiw	a3,a4,1
    80000422:	0006861b          	sext.w	a2,a3
    80000426:	0ad7a023          	sw	a3,160(a5)
    8000042a:	07f77713          	andi	a4,a4,127
    8000042e:	97ba                	add	a5,a5,a4
    80000430:	4729                	li	a4,10
    80000432:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000436:	00010797          	auipc	a5,0x10
    8000043a:	6cc7a323          	sw	a2,1734(a5) # 80010afc <cons+0x9c>
        wakeup(&cons.r);
    8000043e:	00010517          	auipc	a0,0x10
    80000442:	6ba50513          	addi	a0,a0,1722 # 80010af8 <cons+0x98>
    80000446:	00002097          	auipc	ra,0x2
    8000044a:	efc080e7          	jalr	-260(ra) # 80002342 <wakeup>
    8000044e:	b575                	j	800002fa <consoleintr+0x3c>

0000000080000450 <consoleinit>:

void
consoleinit(void)
{
    80000450:	1141                	addi	sp,sp,-16
    80000452:	e406                	sd	ra,8(sp)
    80000454:	e022                	sd	s0,0(sp)
    80000456:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000458:	00008597          	auipc	a1,0x8
    8000045c:	bb858593          	addi	a1,a1,-1096 # 80008010 <etext+0x10>
    80000460:	00010517          	auipc	a0,0x10
    80000464:	60050513          	addi	a0,a0,1536 # 80010a60 <cons>
    80000468:	00001097          	auipc	ra,0x1
    8000046c:	838080e7          	jalr	-1992(ra) # 80000ca0 <initlock>

  uartinit();
    80000470:	00000097          	auipc	ra,0x0
    80000474:	32a080e7          	jalr	810(ra) # 8000079a <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000478:	00240797          	auipc	a5,0x240
    8000047c:	79878793          	addi	a5,a5,1944 # 80240c10 <devsw>
    80000480:	00000717          	auipc	a4,0x0
    80000484:	ce470713          	addi	a4,a4,-796 # 80000164 <consoleread>
    80000488:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000048a:	00000717          	auipc	a4,0x0
    8000048e:	c7870713          	addi	a4,a4,-904 # 80000102 <consolewrite>
    80000492:	ef98                	sd	a4,24(a5)
}
    80000494:	60a2                	ld	ra,8(sp)
    80000496:	6402                	ld	s0,0(sp)
    80000498:	0141                	addi	sp,sp,16
    8000049a:	8082                	ret

000000008000049c <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(int xx, int base, int sign)
{
    8000049c:	7179                	addi	sp,sp,-48
    8000049e:	f406                	sd	ra,40(sp)
    800004a0:	f022                	sd	s0,32(sp)
    800004a2:	ec26                	sd	s1,24(sp)
    800004a4:	e84a                	sd	s2,16(sp)
    800004a6:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    800004a8:	c219                	beqz	a2,800004ae <printint+0x12>
    800004aa:	08054663          	bltz	a0,80000536 <printint+0x9a>
    x = -xx;
  else
    x = xx;
    800004ae:	2501                	sext.w	a0,a0
    800004b0:	4881                	li	a7,0
    800004b2:	fd040693          	addi	a3,s0,-48

  i = 0;
    800004b6:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    800004b8:	2581                	sext.w	a1,a1
    800004ba:	00008617          	auipc	a2,0x8
    800004be:	b8660613          	addi	a2,a2,-1146 # 80008040 <digits>
    800004c2:	883a                	mv	a6,a4
    800004c4:	2705                	addiw	a4,a4,1
    800004c6:	02b577bb          	remuw	a5,a0,a1
    800004ca:	1782                	slli	a5,a5,0x20
    800004cc:	9381                	srli	a5,a5,0x20
    800004ce:	97b2                	add	a5,a5,a2
    800004d0:	0007c783          	lbu	a5,0(a5)
    800004d4:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    800004d8:	0005079b          	sext.w	a5,a0
    800004dc:	02b5553b          	divuw	a0,a0,a1
    800004e0:	0685                	addi	a3,a3,1
    800004e2:	feb7f0e3          	bgeu	a5,a1,800004c2 <printint+0x26>

  if(sign)
    800004e6:	00088b63          	beqz	a7,800004fc <printint+0x60>
    buf[i++] = '-';
    800004ea:	fe040793          	addi	a5,s0,-32
    800004ee:	973e                	add	a4,a4,a5
    800004f0:	02d00793          	li	a5,45
    800004f4:	fef70823          	sb	a5,-16(a4)
    800004f8:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
    800004fc:	02e05763          	blez	a4,8000052a <printint+0x8e>
    80000500:	fd040793          	addi	a5,s0,-48
    80000504:	00e784b3          	add	s1,a5,a4
    80000508:	fff78913          	addi	s2,a5,-1
    8000050c:	993a                	add	s2,s2,a4
    8000050e:	377d                	addiw	a4,a4,-1
    80000510:	1702                	slli	a4,a4,0x20
    80000512:	9301                	srli	a4,a4,0x20
    80000514:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    80000518:	fff4c503          	lbu	a0,-1(s1)
    8000051c:	00000097          	auipc	ra,0x0
    80000520:	d60080e7          	jalr	-672(ra) # 8000027c <consputc>
  while(--i >= 0)
    80000524:	14fd                	addi	s1,s1,-1
    80000526:	ff2499e3          	bne	s1,s2,80000518 <printint+0x7c>
}
    8000052a:	70a2                	ld	ra,40(sp)
    8000052c:	7402                	ld	s0,32(sp)
    8000052e:	64e2                	ld	s1,24(sp)
    80000530:	6942                	ld	s2,16(sp)
    80000532:	6145                	addi	sp,sp,48
    80000534:	8082                	ret
    x = -xx;
    80000536:	40a0053b          	negw	a0,a0
  if(sign && (sign = xx < 0))
    8000053a:	4885                	li	a7,1
    x = -xx;
    8000053c:	bf9d                	j	800004b2 <printint+0x16>

000000008000053e <panic>:
    release(&pr.lock);
}

void
panic(char *s)
{
    8000053e:	1101                	addi	sp,sp,-32
    80000540:	ec06                	sd	ra,24(sp)
    80000542:	e822                	sd	s0,16(sp)
    80000544:	e426                	sd	s1,8(sp)
    80000546:	1000                	addi	s0,sp,32
    80000548:	84aa                	mv	s1,a0
  pr.locking = 0;
    8000054a:	00010797          	auipc	a5,0x10
    8000054e:	5c07ab23          	sw	zero,1494(a5) # 80010b20 <pr+0x18>
  printf("panic: ");
    80000552:	00008517          	auipc	a0,0x8
    80000556:	ac650513          	addi	a0,a0,-1338 # 80008018 <etext+0x18>
    8000055a:	00000097          	auipc	ra,0x0
    8000055e:	02e080e7          	jalr	46(ra) # 80000588 <printf>
  printf(s);
    80000562:	8526                	mv	a0,s1
    80000564:	00000097          	auipc	ra,0x0
    80000568:	024080e7          	jalr	36(ra) # 80000588 <printf>
  printf("\n");
    8000056c:	00008517          	auipc	a0,0x8
    80000570:	b6450513          	addi	a0,a0,-1180 # 800080d0 <digits+0x90>
    80000574:	00000097          	auipc	ra,0x0
    80000578:	014080e7          	jalr	20(ra) # 80000588 <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000057c:	4785                	li	a5,1
    8000057e:	00008717          	auipc	a4,0x8
    80000582:	36f72123          	sw	a5,866(a4) # 800088e0 <panicked>
  for(;;)
    80000586:	a001                	j	80000586 <panic+0x48>

0000000080000588 <printf>:
{
    80000588:	7131                	addi	sp,sp,-192
    8000058a:	fc86                	sd	ra,120(sp)
    8000058c:	f8a2                	sd	s0,112(sp)
    8000058e:	f4a6                	sd	s1,104(sp)
    80000590:	f0ca                	sd	s2,96(sp)
    80000592:	ecce                	sd	s3,88(sp)
    80000594:	e8d2                	sd	s4,80(sp)
    80000596:	e4d6                	sd	s5,72(sp)
    80000598:	e0da                	sd	s6,64(sp)
    8000059a:	fc5e                	sd	s7,56(sp)
    8000059c:	f862                	sd	s8,48(sp)
    8000059e:	f466                	sd	s9,40(sp)
    800005a0:	f06a                	sd	s10,32(sp)
    800005a2:	ec6e                	sd	s11,24(sp)
    800005a4:	0100                	addi	s0,sp,128
    800005a6:	8a2a                	mv	s4,a0
    800005a8:	e40c                	sd	a1,8(s0)
    800005aa:	e810                	sd	a2,16(s0)
    800005ac:	ec14                	sd	a3,24(s0)
    800005ae:	f018                	sd	a4,32(s0)
    800005b0:	f41c                	sd	a5,40(s0)
    800005b2:	03043823          	sd	a6,48(s0)
    800005b6:	03143c23          	sd	a7,56(s0)
  locking = pr.locking;
    800005ba:	00010d97          	auipc	s11,0x10
    800005be:	566dad83          	lw	s11,1382(s11) # 80010b20 <pr+0x18>
  if(locking)
    800005c2:	020d9b63          	bnez	s11,800005f8 <printf+0x70>
  if (fmt == 0)
    800005c6:	040a0263          	beqz	s4,8000060a <printf+0x82>
  va_start(ap, fmt);
    800005ca:	00840793          	addi	a5,s0,8
    800005ce:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    800005d2:	000a4503          	lbu	a0,0(s4)
    800005d6:	14050f63          	beqz	a0,80000734 <printf+0x1ac>
    800005da:	4981                	li	s3,0
    if(c != '%'){
    800005dc:	02500a93          	li	s5,37
    switch(c){
    800005e0:	07000b93          	li	s7,112
  consputc('x');
    800005e4:	4d41                	li	s10,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800005e6:	00008b17          	auipc	s6,0x8
    800005ea:	a5ab0b13          	addi	s6,s6,-1446 # 80008040 <digits>
    switch(c){
    800005ee:	07300c93          	li	s9,115
    800005f2:	06400c13          	li	s8,100
    800005f6:	a82d                	j	80000630 <printf+0xa8>
    acquire(&pr.lock);
    800005f8:	00010517          	auipc	a0,0x10
    800005fc:	51050513          	addi	a0,a0,1296 # 80010b08 <pr>
    80000600:	00000097          	auipc	ra,0x0
    80000604:	730080e7          	jalr	1840(ra) # 80000d30 <acquire>
    80000608:	bf7d                	j	800005c6 <printf+0x3e>
    panic("null fmt");
    8000060a:	00008517          	auipc	a0,0x8
    8000060e:	a1e50513          	addi	a0,a0,-1506 # 80008028 <etext+0x28>
    80000612:	00000097          	auipc	ra,0x0
    80000616:	f2c080e7          	jalr	-212(ra) # 8000053e <panic>
      consputc(c);
    8000061a:	00000097          	auipc	ra,0x0
    8000061e:	c62080e7          	jalr	-926(ra) # 8000027c <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    80000622:	2985                	addiw	s3,s3,1
    80000624:	013a07b3          	add	a5,s4,s3
    80000628:	0007c503          	lbu	a0,0(a5)
    8000062c:	10050463          	beqz	a0,80000734 <printf+0x1ac>
    if(c != '%'){
    80000630:	ff5515e3          	bne	a0,s5,8000061a <printf+0x92>
    c = fmt[++i] & 0xff;
    80000634:	2985                	addiw	s3,s3,1
    80000636:	013a07b3          	add	a5,s4,s3
    8000063a:	0007c783          	lbu	a5,0(a5)
    8000063e:	0007849b          	sext.w	s1,a5
    if(c == 0)
    80000642:	cbed                	beqz	a5,80000734 <printf+0x1ac>
    switch(c){
    80000644:	05778a63          	beq	a5,s7,80000698 <printf+0x110>
    80000648:	02fbf663          	bgeu	s7,a5,80000674 <printf+0xec>
    8000064c:	09978863          	beq	a5,s9,800006dc <printf+0x154>
    80000650:	07800713          	li	a4,120
    80000654:	0ce79563          	bne	a5,a4,8000071e <printf+0x196>
      printint(va_arg(ap, int), 16, 1);
    80000658:	f8843783          	ld	a5,-120(s0)
    8000065c:	00878713          	addi	a4,a5,8
    80000660:	f8e43423          	sd	a4,-120(s0)
    80000664:	4605                	li	a2,1
    80000666:	85ea                	mv	a1,s10
    80000668:	4388                	lw	a0,0(a5)
    8000066a:	00000097          	auipc	ra,0x0
    8000066e:	e32080e7          	jalr	-462(ra) # 8000049c <printint>
      break;
    80000672:	bf45                	j	80000622 <printf+0x9a>
    switch(c){
    80000674:	09578f63          	beq	a5,s5,80000712 <printf+0x18a>
    80000678:	0b879363          	bne	a5,s8,8000071e <printf+0x196>
      printint(va_arg(ap, int), 10, 1);
    8000067c:	f8843783          	ld	a5,-120(s0)
    80000680:	00878713          	addi	a4,a5,8
    80000684:	f8e43423          	sd	a4,-120(s0)
    80000688:	4605                	li	a2,1
    8000068a:	45a9                	li	a1,10
    8000068c:	4388                	lw	a0,0(a5)
    8000068e:	00000097          	auipc	ra,0x0
    80000692:	e0e080e7          	jalr	-498(ra) # 8000049c <printint>
      break;
    80000696:	b771                	j	80000622 <printf+0x9a>
      printptr(va_arg(ap, uint64));
    80000698:	f8843783          	ld	a5,-120(s0)
    8000069c:	00878713          	addi	a4,a5,8
    800006a0:	f8e43423          	sd	a4,-120(s0)
    800006a4:	0007b903          	ld	s2,0(a5)
  consputc('0');
    800006a8:	03000513          	li	a0,48
    800006ac:	00000097          	auipc	ra,0x0
    800006b0:	bd0080e7          	jalr	-1072(ra) # 8000027c <consputc>
  consputc('x');
    800006b4:	07800513          	li	a0,120
    800006b8:	00000097          	auipc	ra,0x0
    800006bc:	bc4080e7          	jalr	-1084(ra) # 8000027c <consputc>
    800006c0:	84ea                	mv	s1,s10
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006c2:	03c95793          	srli	a5,s2,0x3c
    800006c6:	97da                	add	a5,a5,s6
    800006c8:	0007c503          	lbu	a0,0(a5)
    800006cc:	00000097          	auipc	ra,0x0
    800006d0:	bb0080e7          	jalr	-1104(ra) # 8000027c <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006d4:	0912                	slli	s2,s2,0x4
    800006d6:	34fd                	addiw	s1,s1,-1
    800006d8:	f4ed                	bnez	s1,800006c2 <printf+0x13a>
    800006da:	b7a1                	j	80000622 <printf+0x9a>
      if((s = va_arg(ap, char*)) == 0)
    800006dc:	f8843783          	ld	a5,-120(s0)
    800006e0:	00878713          	addi	a4,a5,8
    800006e4:	f8e43423          	sd	a4,-120(s0)
    800006e8:	6384                	ld	s1,0(a5)
    800006ea:	cc89                	beqz	s1,80000704 <printf+0x17c>
      for(; *s; s++)
    800006ec:	0004c503          	lbu	a0,0(s1)
    800006f0:	d90d                	beqz	a0,80000622 <printf+0x9a>
        consputc(*s);
    800006f2:	00000097          	auipc	ra,0x0
    800006f6:	b8a080e7          	jalr	-1142(ra) # 8000027c <consputc>
      for(; *s; s++)
    800006fa:	0485                	addi	s1,s1,1
    800006fc:	0004c503          	lbu	a0,0(s1)
    80000700:	f96d                	bnez	a0,800006f2 <printf+0x16a>
    80000702:	b705                	j	80000622 <printf+0x9a>
        s = "(null)";
    80000704:	00008497          	auipc	s1,0x8
    80000708:	91c48493          	addi	s1,s1,-1764 # 80008020 <etext+0x20>
      for(; *s; s++)
    8000070c:	02800513          	li	a0,40
    80000710:	b7cd                	j	800006f2 <printf+0x16a>
      consputc('%');
    80000712:	8556                	mv	a0,s5
    80000714:	00000097          	auipc	ra,0x0
    80000718:	b68080e7          	jalr	-1176(ra) # 8000027c <consputc>
      break;
    8000071c:	b719                	j	80000622 <printf+0x9a>
      consputc('%');
    8000071e:	8556                	mv	a0,s5
    80000720:	00000097          	auipc	ra,0x0
    80000724:	b5c080e7          	jalr	-1188(ra) # 8000027c <consputc>
      consputc(c);
    80000728:	8526                	mv	a0,s1
    8000072a:	00000097          	auipc	ra,0x0
    8000072e:	b52080e7          	jalr	-1198(ra) # 8000027c <consputc>
      break;
    80000732:	bdc5                	j	80000622 <printf+0x9a>
  if(locking)
    80000734:	020d9163          	bnez	s11,80000756 <printf+0x1ce>
}
    80000738:	70e6                	ld	ra,120(sp)
    8000073a:	7446                	ld	s0,112(sp)
    8000073c:	74a6                	ld	s1,104(sp)
    8000073e:	7906                	ld	s2,96(sp)
    80000740:	69e6                	ld	s3,88(sp)
    80000742:	6a46                	ld	s4,80(sp)
    80000744:	6aa6                	ld	s5,72(sp)
    80000746:	6b06                	ld	s6,64(sp)
    80000748:	7be2                	ld	s7,56(sp)
    8000074a:	7c42                	ld	s8,48(sp)
    8000074c:	7ca2                	ld	s9,40(sp)
    8000074e:	7d02                	ld	s10,32(sp)
    80000750:	6de2                	ld	s11,24(sp)
    80000752:	6129                	addi	sp,sp,192
    80000754:	8082                	ret
    release(&pr.lock);
    80000756:	00010517          	auipc	a0,0x10
    8000075a:	3b250513          	addi	a0,a0,946 # 80010b08 <pr>
    8000075e:	00000097          	auipc	ra,0x0
    80000762:	686080e7          	jalr	1670(ra) # 80000de4 <release>
}
    80000766:	bfc9                	j	80000738 <printf+0x1b0>

0000000080000768 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000768:	1101                	addi	sp,sp,-32
    8000076a:	ec06                	sd	ra,24(sp)
    8000076c:	e822                	sd	s0,16(sp)
    8000076e:	e426                	sd	s1,8(sp)
    80000770:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    80000772:	00010497          	auipc	s1,0x10
    80000776:	39648493          	addi	s1,s1,918 # 80010b08 <pr>
    8000077a:	00008597          	auipc	a1,0x8
    8000077e:	8be58593          	addi	a1,a1,-1858 # 80008038 <etext+0x38>
    80000782:	8526                	mv	a0,s1
    80000784:	00000097          	auipc	ra,0x0
    80000788:	51c080e7          	jalr	1308(ra) # 80000ca0 <initlock>
  pr.locking = 1;
    8000078c:	4785                	li	a5,1
    8000078e:	cc9c                	sw	a5,24(s1)
}
    80000790:	60e2                	ld	ra,24(sp)
    80000792:	6442                	ld	s0,16(sp)
    80000794:	64a2                	ld	s1,8(sp)
    80000796:	6105                	addi	sp,sp,32
    80000798:	8082                	ret

000000008000079a <uartinit>:

void uartstart();

void
uartinit(void)
{
    8000079a:	1141                	addi	sp,sp,-16
    8000079c:	e406                	sd	ra,8(sp)
    8000079e:	e022                	sd	s0,0(sp)
    800007a0:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007a2:	100007b7          	lui	a5,0x10000
    800007a6:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007aa:	f8000713          	li	a4,-128
    800007ae:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800007b2:	470d                	li	a4,3
    800007b4:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800007b8:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800007bc:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800007c0:	469d                	li	a3,7
    800007c2:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800007c6:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    800007ca:	00008597          	auipc	a1,0x8
    800007ce:	88e58593          	addi	a1,a1,-1906 # 80008058 <digits+0x18>
    800007d2:	00010517          	auipc	a0,0x10
    800007d6:	35650513          	addi	a0,a0,854 # 80010b28 <uart_tx_lock>
    800007da:	00000097          	auipc	ra,0x0
    800007de:	4c6080e7          	jalr	1222(ra) # 80000ca0 <initlock>
}
    800007e2:	60a2                	ld	ra,8(sp)
    800007e4:	6402                	ld	s0,0(sp)
    800007e6:	0141                	addi	sp,sp,16
    800007e8:	8082                	ret

00000000800007ea <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800007ea:	1101                	addi	sp,sp,-32
    800007ec:	ec06                	sd	ra,24(sp)
    800007ee:	e822                	sd	s0,16(sp)
    800007f0:	e426                	sd	s1,8(sp)
    800007f2:	1000                	addi	s0,sp,32
    800007f4:	84aa                	mv	s1,a0
  push_off();
    800007f6:	00000097          	auipc	ra,0x0
    800007fa:	4ee080e7          	jalr	1262(ra) # 80000ce4 <push_off>

  if(panicked){
    800007fe:	00008797          	auipc	a5,0x8
    80000802:	0e27a783          	lw	a5,226(a5) # 800088e0 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000806:	10000737          	lui	a4,0x10000
  if(panicked){
    8000080a:	c391                	beqz	a5,8000080e <uartputc_sync+0x24>
    for(;;)
    8000080c:	a001                	j	8000080c <uartputc_sync+0x22>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000080e:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80000812:	0207f793          	andi	a5,a5,32
    80000816:	dfe5                	beqz	a5,8000080e <uartputc_sync+0x24>
    ;
  WriteReg(THR, c);
    80000818:	0ff4f513          	zext.b	a0,s1
    8000081c:	100007b7          	lui	a5,0x10000
    80000820:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80000824:	00000097          	auipc	ra,0x0
    80000828:	560080e7          	jalr	1376(ra) # 80000d84 <pop_off>
}
    8000082c:	60e2                	ld	ra,24(sp)
    8000082e:	6442                	ld	s0,16(sp)
    80000830:	64a2                	ld	s1,8(sp)
    80000832:	6105                	addi	sp,sp,32
    80000834:	8082                	ret

0000000080000836 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80000836:	00008797          	auipc	a5,0x8
    8000083a:	0b27b783          	ld	a5,178(a5) # 800088e8 <uart_tx_r>
    8000083e:	00008717          	auipc	a4,0x8
    80000842:	0b273703          	ld	a4,178(a4) # 800088f0 <uart_tx_w>
    80000846:	06f70a63          	beq	a4,a5,800008ba <uartstart+0x84>
{
    8000084a:	7139                	addi	sp,sp,-64
    8000084c:	fc06                	sd	ra,56(sp)
    8000084e:	f822                	sd	s0,48(sp)
    80000850:	f426                	sd	s1,40(sp)
    80000852:	f04a                	sd	s2,32(sp)
    80000854:	ec4e                	sd	s3,24(sp)
    80000856:	e852                	sd	s4,16(sp)
    80000858:	e456                	sd	s5,8(sp)
    8000085a:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000085c:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000860:	00010a17          	auipc	s4,0x10
    80000864:	2c8a0a13          	addi	s4,s4,712 # 80010b28 <uart_tx_lock>
    uart_tx_r += 1;
    80000868:	00008497          	auipc	s1,0x8
    8000086c:	08048493          	addi	s1,s1,128 # 800088e8 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80000870:	00008997          	auipc	s3,0x8
    80000874:	08098993          	addi	s3,s3,128 # 800088f0 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80000878:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    8000087c:	02077713          	andi	a4,a4,32
    80000880:	c705                	beqz	a4,800008a8 <uartstart+0x72>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000882:	01f7f713          	andi	a4,a5,31
    80000886:	9752                	add	a4,a4,s4
    80000888:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    8000088c:	0785                	addi	a5,a5,1
    8000088e:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80000890:	8526                	mv	a0,s1
    80000892:	00002097          	auipc	ra,0x2
    80000896:	ab0080e7          	jalr	-1360(ra) # 80002342 <wakeup>
    
    WriteReg(THR, c);
    8000089a:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    8000089e:	609c                	ld	a5,0(s1)
    800008a0:	0009b703          	ld	a4,0(s3)
    800008a4:	fcf71ae3          	bne	a4,a5,80000878 <uartstart+0x42>
  }
}
    800008a8:	70e2                	ld	ra,56(sp)
    800008aa:	7442                	ld	s0,48(sp)
    800008ac:	74a2                	ld	s1,40(sp)
    800008ae:	7902                	ld	s2,32(sp)
    800008b0:	69e2                	ld	s3,24(sp)
    800008b2:	6a42                	ld	s4,16(sp)
    800008b4:	6aa2                	ld	s5,8(sp)
    800008b6:	6121                	addi	sp,sp,64
    800008b8:	8082                	ret
    800008ba:	8082                	ret

00000000800008bc <uartputc>:
{
    800008bc:	7179                	addi	sp,sp,-48
    800008be:	f406                	sd	ra,40(sp)
    800008c0:	f022                	sd	s0,32(sp)
    800008c2:	ec26                	sd	s1,24(sp)
    800008c4:	e84a                	sd	s2,16(sp)
    800008c6:	e44e                	sd	s3,8(sp)
    800008c8:	e052                	sd	s4,0(sp)
    800008ca:	1800                	addi	s0,sp,48
    800008cc:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800008ce:	00010517          	auipc	a0,0x10
    800008d2:	25a50513          	addi	a0,a0,602 # 80010b28 <uart_tx_lock>
    800008d6:	00000097          	auipc	ra,0x0
    800008da:	45a080e7          	jalr	1114(ra) # 80000d30 <acquire>
  if(panicked){
    800008de:	00008797          	auipc	a5,0x8
    800008e2:	0027a783          	lw	a5,2(a5) # 800088e0 <panicked>
    800008e6:	e7c9                	bnez	a5,80000970 <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800008e8:	00008717          	auipc	a4,0x8
    800008ec:	00873703          	ld	a4,8(a4) # 800088f0 <uart_tx_w>
    800008f0:	00008797          	auipc	a5,0x8
    800008f4:	ff87b783          	ld	a5,-8(a5) # 800088e8 <uart_tx_r>
    800008f8:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800008fc:	00010997          	auipc	s3,0x10
    80000900:	22c98993          	addi	s3,s3,556 # 80010b28 <uart_tx_lock>
    80000904:	00008497          	auipc	s1,0x8
    80000908:	fe448493          	addi	s1,s1,-28 # 800088e8 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000090c:	00008917          	auipc	s2,0x8
    80000910:	fe490913          	addi	s2,s2,-28 # 800088f0 <uart_tx_w>
    80000914:	00e79f63          	bne	a5,a4,80000932 <uartputc+0x76>
    sleep(&uart_tx_r, &uart_tx_lock);
    80000918:	85ce                	mv	a1,s3
    8000091a:	8526                	mv	a0,s1
    8000091c:	00002097          	auipc	ra,0x2
    80000920:	9c2080e7          	jalr	-1598(ra) # 800022de <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000924:	00093703          	ld	a4,0(s2)
    80000928:	609c                	ld	a5,0(s1)
    8000092a:	02078793          	addi	a5,a5,32
    8000092e:	fee785e3          	beq	a5,a4,80000918 <uartputc+0x5c>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    80000932:	00010497          	auipc	s1,0x10
    80000936:	1f648493          	addi	s1,s1,502 # 80010b28 <uart_tx_lock>
    8000093a:	01f77793          	andi	a5,a4,31
    8000093e:	97a6                	add	a5,a5,s1
    80000940:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80000944:	0705                	addi	a4,a4,1
    80000946:	00008797          	auipc	a5,0x8
    8000094a:	fae7b523          	sd	a4,-86(a5) # 800088f0 <uart_tx_w>
  uartstart();
    8000094e:	00000097          	auipc	ra,0x0
    80000952:	ee8080e7          	jalr	-280(ra) # 80000836 <uartstart>
  release(&uart_tx_lock);
    80000956:	8526                	mv	a0,s1
    80000958:	00000097          	auipc	ra,0x0
    8000095c:	48c080e7          	jalr	1164(ra) # 80000de4 <release>
}
    80000960:	70a2                	ld	ra,40(sp)
    80000962:	7402                	ld	s0,32(sp)
    80000964:	64e2                	ld	s1,24(sp)
    80000966:	6942                	ld	s2,16(sp)
    80000968:	69a2                	ld	s3,8(sp)
    8000096a:	6a02                	ld	s4,0(sp)
    8000096c:	6145                	addi	sp,sp,48
    8000096e:	8082                	ret
    for(;;)
    80000970:	a001                	j	80000970 <uartputc+0xb4>

0000000080000972 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000972:	1141                	addi	sp,sp,-16
    80000974:	e422                	sd	s0,8(sp)
    80000976:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80000978:	100007b7          	lui	a5,0x10000
    8000097c:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000980:	8b85                	andi	a5,a5,1
    80000982:	cb91                	beqz	a5,80000996 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80000984:	100007b7          	lui	a5,0x10000
    80000988:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    8000098c:	0ff57513          	zext.b	a0,a0
  } else {
    return -1;
  }
}
    80000990:	6422                	ld	s0,8(sp)
    80000992:	0141                	addi	sp,sp,16
    80000994:	8082                	ret
    return -1;
    80000996:	557d                	li	a0,-1
    80000998:	bfe5                	j	80000990 <uartgetc+0x1e>

000000008000099a <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000099a:	1101                	addi	sp,sp,-32
    8000099c:	ec06                	sd	ra,24(sp)
    8000099e:	e822                	sd	s0,16(sp)
    800009a0:	e426                	sd	s1,8(sp)
    800009a2:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009a4:	54fd                	li	s1,-1
    800009a6:	a029                	j	800009b0 <uartintr+0x16>
      break;
    consoleintr(c);
    800009a8:	00000097          	auipc	ra,0x0
    800009ac:	916080e7          	jalr	-1770(ra) # 800002be <consoleintr>
    int c = uartgetc();
    800009b0:	00000097          	auipc	ra,0x0
    800009b4:	fc2080e7          	jalr	-62(ra) # 80000972 <uartgetc>
    if(c == -1)
    800009b8:	fe9518e3          	bne	a0,s1,800009a8 <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    800009bc:	00010497          	auipc	s1,0x10
    800009c0:	16c48493          	addi	s1,s1,364 # 80010b28 <uart_tx_lock>
    800009c4:	8526                	mv	a0,s1
    800009c6:	00000097          	auipc	ra,0x0
    800009ca:	36a080e7          	jalr	874(ra) # 80000d30 <acquire>
  uartstart();
    800009ce:	00000097          	auipc	ra,0x0
    800009d2:	e68080e7          	jalr	-408(ra) # 80000836 <uartstart>
  release(&uart_tx_lock);
    800009d6:	8526                	mv	a0,s1
    800009d8:	00000097          	auipc	ra,0x0
    800009dc:	40c080e7          	jalr	1036(ra) # 80000de4 <release>
}
    800009e0:	60e2                	ld	ra,24(sp)
    800009e2:	6442                	ld	s0,16(sp)
    800009e4:	64a2                	ld	s1,8(sp)
    800009e6:	6105                	addi	sp,sp,32
    800009e8:	8082                	ret

00000000800009ea <refcnt_init>:
  int refcnt[PHYSTOP / PGSIZE]; // Reference count array
} pageref;

// Initialize reference counting in kalloc.c
void refcnt_init()
{
    800009ea:	1141                	addi	sp,sp,-16
    800009ec:	e406                	sd	ra,8(sp)
    800009ee:	e022                	sd	s0,0(sp)
    800009f0:	0800                	addi	s0,sp,16
  initlock(&pageref.lock, "pageref");
    800009f2:	00007597          	auipc	a1,0x7
    800009f6:	66e58593          	addi	a1,a1,1646 # 80008060 <digits+0x20>
    800009fa:	00010517          	auipc	a0,0x10
    800009fe:	18650513          	addi	a0,a0,390 # 80010b80 <pageref>
    80000a02:	00000097          	auipc	ra,0x0
    80000a06:	29e080e7          	jalr	670(ra) # 80000ca0 <initlock>
  int i;
  for (i = 0; i < PHYSTOP / PGSIZE; i++)
    80000a0a:	00010797          	auipc	a5,0x10
    80000a0e:	18e78793          	addi	a5,a5,398 # 80010b98 <pageref+0x18>
    80000a12:	00230717          	auipc	a4,0x230
    80000a16:	18670713          	addi	a4,a4,390 # 80230b98 <pid_lock>
    pageref.refcnt[i] = 0;
    80000a1a:	0007a023          	sw	zero,0(a5)
  for (i = 0; i < PHYSTOP / PGSIZE; i++)
    80000a1e:	0791                	addi	a5,a5,4
    80000a20:	fee79de3          	bne	a5,a4,80000a1a <refcnt_init+0x30>
}
    80000a24:	60a2                	ld	ra,8(sp)
    80000a26:	6402                	ld	s0,0(sp)
    80000a28:	0141                	addi	sp,sp,16
    80000a2a:	8082                	ret

0000000080000a2c <get_refcnt>:
  refcnt_init();
  freerange(end, (void *)PHYSTOP);
}

int get_refcnt(uint64 pa)
{
    80000a2c:	1141                	addi	sp,sp,-16
    80000a2e:	e422                	sd	s0,8(sp)
    80000a30:	0800                	addi	s0,sp,16
  if (pa >= PHYSTOP)
    80000a32:	47c5                	li	a5,17
    80000a34:	07ee                	slli	a5,a5,0x1b
    80000a36:	00f57e63          	bgeu	a0,a5,80000a52 <get_refcnt+0x26>
    return 0;
  return pageref.refcnt[pa / PGSIZE];
    80000a3a:	8131                	srli	a0,a0,0xc
    80000a3c:	0511                	addi	a0,a0,4
    80000a3e:	050a                	slli	a0,a0,0x2
    80000a40:	00010797          	auipc	a5,0x10
    80000a44:	14078793          	addi	a5,a5,320 # 80010b80 <pageref>
    80000a48:	953e                	add	a0,a0,a5
    80000a4a:	4508                	lw	a0,8(a0)
}
    80000a4c:	6422                	ld	s0,8(sp)
    80000a4e:	0141                	addi	sp,sp,16
    80000a50:	8082                	ret
    return 0;
    80000a52:	4501                	li	a0,0
    80000a54:	bfe5                	j	80000a4c <get_refcnt+0x20>

0000000080000a56 <inc_refcnt>:

// Increment reference count
void inc_refcnt(uint64 pa)
{
  if (pa >= PHYSTOP)
    80000a56:	47c5                	li	a5,17
    80000a58:	07ee                	slli	a5,a5,0x1b
    80000a5a:	00f56363          	bltu	a0,a5,80000a60 <inc_refcnt+0xa>
    80000a5e:	8082                	ret
{
    80000a60:	1101                	addi	sp,sp,-32
    80000a62:	ec06                	sd	ra,24(sp)
    80000a64:	e822                	sd	s0,16(sp)
    80000a66:	e426                	sd	s1,8(sp)
    80000a68:	1000                	addi	s0,sp,32
    80000a6a:	84aa                	mv	s1,a0
    return;
  acquire(&pageref.lock);
    80000a6c:	00010517          	auipc	a0,0x10
    80000a70:	11450513          	addi	a0,a0,276 # 80010b80 <pageref>
    80000a74:	00000097          	auipc	ra,0x0
    80000a78:	2bc080e7          	jalr	700(ra) # 80000d30 <acquire>
  pageref.refcnt[pa / PGSIZE]++;
    80000a7c:	80b1                	srli	s1,s1,0xc
    80000a7e:	00010517          	auipc	a0,0x10
    80000a82:	10250513          	addi	a0,a0,258 # 80010b80 <pageref>
    80000a86:	0491                	addi	s1,s1,4
    80000a88:	048a                	slli	s1,s1,0x2
    80000a8a:	94aa                	add	s1,s1,a0
    80000a8c:	449c                	lw	a5,8(s1)
    80000a8e:	2785                	addiw	a5,a5,1
    80000a90:	c49c                	sw	a5,8(s1)
  release(&pageref.lock);
    80000a92:	00000097          	auipc	ra,0x0
    80000a96:	352080e7          	jalr	850(ra) # 80000de4 <release>
}
    80000a9a:	60e2                	ld	ra,24(sp)
    80000a9c:	6442                	ld	s0,16(sp)
    80000a9e:	64a2                	ld	s1,8(sp)
    80000aa0:	6105                	addi	sp,sp,32
    80000aa2:	8082                	ret

0000000080000aa4 <dec_refcnt>:

// Decrement reference count and return new count
int dec_refcnt(uint64 pa)
{
    80000aa4:	1101                	addi	sp,sp,-32
    80000aa6:	ec06                	sd	ra,24(sp)
    80000aa8:	e822                	sd	s0,16(sp)
    80000aaa:	e426                	sd	s1,8(sp)
    80000aac:	e04a                	sd	s2,0(sp)
    80000aae:	1000                	addi	s0,sp,32
  if (pa >= PHYSTOP)
    80000ab0:	47c5                	li	a5,17
    80000ab2:	07ee                	slli	a5,a5,0x1b
    return 0;
    80000ab4:	4901                	li	s2,0
  if (pa >= PHYSTOP)
    80000ab6:	00f56963          	bltu	a0,a5,80000ac8 <dec_refcnt+0x24>
  acquire(&pageref.lock);
  int cnt = --pageref.refcnt[pa / PGSIZE];
  release(&pageref.lock);
  return cnt;
}
    80000aba:	854a                	mv	a0,s2
    80000abc:	60e2                	ld	ra,24(sp)
    80000abe:	6442                	ld	s0,16(sp)
    80000ac0:	64a2                	ld	s1,8(sp)
    80000ac2:	6902                	ld	s2,0(sp)
    80000ac4:	6105                	addi	sp,sp,32
    80000ac6:	8082                	ret
    80000ac8:	84aa                	mv	s1,a0
  acquire(&pageref.lock);
    80000aca:	00010517          	auipc	a0,0x10
    80000ace:	0b650513          	addi	a0,a0,182 # 80010b80 <pageref>
    80000ad2:	00000097          	auipc	ra,0x0
    80000ad6:	25e080e7          	jalr	606(ra) # 80000d30 <acquire>
  int cnt = --pageref.refcnt[pa / PGSIZE];
    80000ada:	80b1                	srli	s1,s1,0xc
    80000adc:	00010517          	auipc	a0,0x10
    80000ae0:	0a450513          	addi	a0,a0,164 # 80010b80 <pageref>
    80000ae4:	0491                	addi	s1,s1,4
    80000ae6:	048a                	slli	s1,s1,0x2
    80000ae8:	94aa                	add	s1,s1,a0
    80000aea:	449c                	lw	a5,8(s1)
    80000aec:	37fd                	addiw	a5,a5,-1
    80000aee:	0007891b          	sext.w	s2,a5
    80000af2:	c49c                	sw	a5,8(s1)
  release(&pageref.lock);
    80000af4:	00000097          	auipc	ra,0x0
    80000af8:	2f0080e7          	jalr	752(ra) # 80000de4 <release>
  return cnt;
    80000afc:	bf7d                	j	80000aba <dec_refcnt+0x16>

0000000080000afe <kfree>:
// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void kfree(void *pa)
{
    80000afe:	1101                	addi	sp,sp,-32
    80000b00:	ec06                	sd	ra,24(sp)
    80000b02:	e822                	sd	s0,16(sp)
    80000b04:	e426                	sd	s1,8(sp)
    80000b06:	e04a                	sd	s2,0(sp)
    80000b08:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000b0a:	03451793          	slli	a5,a0,0x34
    80000b0e:	eb85                	bnez	a5,80000b3e <kfree+0x40>
    80000b10:	84aa                	mv	s1,a0
    80000b12:	00241797          	auipc	a5,0x241
    80000b16:	29678793          	addi	a5,a5,662 # 80241da8 <end>
    80000b1a:	02f56263          	bltu	a0,a5,80000b3e <kfree+0x40>
    80000b1e:	47c5                	li	a5,17
    80000b20:	07ee                	slli	a5,a5,0x1b
    80000b22:	00f57e63          	bgeu	a0,a5,80000b3e <kfree+0x40>
    panic("kfree");

  // Only free if reference count becomes 0
  if (dec_refcnt((uint64)pa) > 0)
    80000b26:	00000097          	auipc	ra,0x0
    80000b2a:	f7e080e7          	jalr	-130(ra) # 80000aa4 <dec_refcnt>
    80000b2e:	02a05063          	blez	a0,80000b4e <kfree+0x50>

  acquire(&kmem.lock);
  r->next = kmem.freelist;
  kmem.freelist = r;
  release(&kmem.lock);
}
    80000b32:	60e2                	ld	ra,24(sp)
    80000b34:	6442                	ld	s0,16(sp)
    80000b36:	64a2                	ld	s1,8(sp)
    80000b38:	6902                	ld	s2,0(sp)
    80000b3a:	6105                	addi	sp,sp,32
    80000b3c:	8082                	ret
    panic("kfree");
    80000b3e:	00007517          	auipc	a0,0x7
    80000b42:	52a50513          	addi	a0,a0,1322 # 80008068 <digits+0x28>
    80000b46:	00000097          	auipc	ra,0x0
    80000b4a:	9f8080e7          	jalr	-1544(ra) # 8000053e <panic>
  memset(pa, 1, PGSIZE);
    80000b4e:	6605                	lui	a2,0x1
    80000b50:	4585                	li	a1,1
    80000b52:	8526                	mv	a0,s1
    80000b54:	00000097          	auipc	ra,0x0
    80000b58:	2d8080e7          	jalr	728(ra) # 80000e2c <memset>
  acquire(&kmem.lock);
    80000b5c:	00010917          	auipc	s2,0x10
    80000b60:	00490913          	addi	s2,s2,4 # 80010b60 <kmem>
    80000b64:	854a                	mv	a0,s2
    80000b66:	00000097          	auipc	ra,0x0
    80000b6a:	1ca080e7          	jalr	458(ra) # 80000d30 <acquire>
  r->next = kmem.freelist;
    80000b6e:	01893783          	ld	a5,24(s2)
    80000b72:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000b74:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000b78:	854a                	mv	a0,s2
    80000b7a:	00000097          	auipc	ra,0x0
    80000b7e:	26a080e7          	jalr	618(ra) # 80000de4 <release>
    80000b82:	bf45                	j	80000b32 <kfree+0x34>

0000000080000b84 <freerange>:
{
    80000b84:	7179                	addi	sp,sp,-48
    80000b86:	f406                	sd	ra,40(sp)
    80000b88:	f022                	sd	s0,32(sp)
    80000b8a:	ec26                	sd	s1,24(sp)
    80000b8c:	e84a                	sd	s2,16(sp)
    80000b8e:	e44e                	sd	s3,8(sp)
    80000b90:	e052                	sd	s4,0(sp)
    80000b92:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000b94:	6785                	lui	a5,0x1
    80000b96:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000b9a:	94aa                	add	s1,s1,a0
    80000b9c:	757d                	lui	a0,0xfffff
    80000b9e:	8ce9                	and	s1,s1,a0
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ba0:	94be                	add	s1,s1,a5
    80000ba2:	0095ee63          	bltu	a1,s1,80000bbe <freerange+0x3a>
    80000ba6:	892e                	mv	s2,a1
    kfree(p);
    80000ba8:	7a7d                	lui	s4,0xfffff
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000baa:	6985                	lui	s3,0x1
    kfree(p);
    80000bac:	01448533          	add	a0,s1,s4
    80000bb0:	00000097          	auipc	ra,0x0
    80000bb4:	f4e080e7          	jalr	-178(ra) # 80000afe <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000bb8:	94ce                	add	s1,s1,s3
    80000bba:	fe9979e3          	bgeu	s2,s1,80000bac <freerange+0x28>
}
    80000bbe:	70a2                	ld	ra,40(sp)
    80000bc0:	7402                	ld	s0,32(sp)
    80000bc2:	64e2                	ld	s1,24(sp)
    80000bc4:	6942                	ld	s2,16(sp)
    80000bc6:	69a2                	ld	s3,8(sp)
    80000bc8:	6a02                	ld	s4,0(sp)
    80000bca:	6145                	addi	sp,sp,48
    80000bcc:	8082                	ret

0000000080000bce <kinit>:
{
    80000bce:	1141                	addi	sp,sp,-16
    80000bd0:	e406                	sd	ra,8(sp)
    80000bd2:	e022                	sd	s0,0(sp)
    80000bd4:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000bd6:	00007597          	auipc	a1,0x7
    80000bda:	49a58593          	addi	a1,a1,1178 # 80008070 <digits+0x30>
    80000bde:	00010517          	auipc	a0,0x10
    80000be2:	f8250513          	addi	a0,a0,-126 # 80010b60 <kmem>
    80000be6:	00000097          	auipc	ra,0x0
    80000bea:	0ba080e7          	jalr	186(ra) # 80000ca0 <initlock>
  refcnt_init();
    80000bee:	00000097          	auipc	ra,0x0
    80000bf2:	dfc080e7          	jalr	-516(ra) # 800009ea <refcnt_init>
  freerange(end, (void *)PHYSTOP);
    80000bf6:	45c5                	li	a1,17
    80000bf8:	05ee                	slli	a1,a1,0x1b
    80000bfa:	00241517          	auipc	a0,0x241
    80000bfe:	1ae50513          	addi	a0,a0,430 # 80241da8 <end>
    80000c02:	00000097          	auipc	ra,0x0
    80000c06:	f82080e7          	jalr	-126(ra) # 80000b84 <freerange>
}
    80000c0a:	60a2                	ld	ra,8(sp)
    80000c0c:	6402                	ld	s0,0(sp)
    80000c0e:	0141                	addi	sp,sp,16
    80000c10:	8082                	ret

0000000080000c12 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000c12:	1101                	addi	sp,sp,-32
    80000c14:	ec06                	sd	ra,24(sp)
    80000c16:	e822                	sd	s0,16(sp)
    80000c18:	e426                	sd	s1,8(sp)
    80000c1a:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000c1c:	00010497          	auipc	s1,0x10
    80000c20:	f4448493          	addi	s1,s1,-188 # 80010b60 <kmem>
    80000c24:	8526                	mv	a0,s1
    80000c26:	00000097          	auipc	ra,0x0
    80000c2a:	10a080e7          	jalr	266(ra) # 80000d30 <acquire>
  r = kmem.freelist;
    80000c2e:	6c84                	ld	s1,24(s1)
  if (r)
    80000c30:	ccb9                	beqz	s1,80000c8e <kalloc+0x7c>
    kmem.freelist = r->next;
    80000c32:	609c                	ld	a5,0(s1)
    80000c34:	00010517          	auipc	a0,0x10
    80000c38:	f2c50513          	addi	a0,a0,-212 # 80010b60 <kmem>
    80000c3c:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000c3e:	00000097          	auipc	ra,0x0
    80000c42:	1a6080e7          	jalr	422(ra) # 80000de4 <release>

  if (r)
  {
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000c46:	6605                	lui	a2,0x1
    80000c48:	4595                	li	a1,5
    80000c4a:	8526                	mv	a0,s1
    80000c4c:	00000097          	auipc	ra,0x0
    80000c50:	1e0080e7          	jalr	480(ra) # 80000e2c <memset>
    // Initialize reference count to 1
    acquire(&pageref.lock);
    80000c54:	00010517          	auipc	a0,0x10
    80000c58:	f2c50513          	addi	a0,a0,-212 # 80010b80 <pageref>
    80000c5c:	00000097          	auipc	ra,0x0
    80000c60:	0d4080e7          	jalr	212(ra) # 80000d30 <acquire>
    pageref.refcnt[((uint64)r) / PGSIZE] = 1;
    80000c64:	00010517          	auipc	a0,0x10
    80000c68:	f1c50513          	addi	a0,a0,-228 # 80010b80 <pageref>
    80000c6c:	00c4d793          	srli	a5,s1,0xc
    80000c70:	0791                	addi	a5,a5,4
    80000c72:	078a                	slli	a5,a5,0x2
    80000c74:	97aa                	add	a5,a5,a0
    80000c76:	4705                	li	a4,1
    80000c78:	c798                	sw	a4,8(a5)
    release(&pageref.lock);
    80000c7a:	00000097          	auipc	ra,0x0
    80000c7e:	16a080e7          	jalr	362(ra) # 80000de4 <release>
  }
  return (void *)r;
}
    80000c82:	8526                	mv	a0,s1
    80000c84:	60e2                	ld	ra,24(sp)
    80000c86:	6442                	ld	s0,16(sp)
    80000c88:	64a2                	ld	s1,8(sp)
    80000c8a:	6105                	addi	sp,sp,32
    80000c8c:	8082                	ret
  release(&kmem.lock);
    80000c8e:	00010517          	auipc	a0,0x10
    80000c92:	ed250513          	addi	a0,a0,-302 # 80010b60 <kmem>
    80000c96:	00000097          	auipc	ra,0x0
    80000c9a:	14e080e7          	jalr	334(ra) # 80000de4 <release>
  if (r)
    80000c9e:	b7d5                	j	80000c82 <kalloc+0x70>

0000000080000ca0 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000ca0:	1141                	addi	sp,sp,-16
    80000ca2:	e422                	sd	s0,8(sp)
    80000ca4:	0800                	addi	s0,sp,16
  lk->name = name;
    80000ca6:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000ca8:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000cac:	00053823          	sd	zero,16(a0)
}
    80000cb0:	6422                	ld	s0,8(sp)
    80000cb2:	0141                	addi	sp,sp,16
    80000cb4:	8082                	ret

0000000080000cb6 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000cb6:	411c                	lw	a5,0(a0)
    80000cb8:	e399                	bnez	a5,80000cbe <holding+0x8>
    80000cba:	4501                	li	a0,0
  return r;
}
    80000cbc:	8082                	ret
{
    80000cbe:	1101                	addi	sp,sp,-32
    80000cc0:	ec06                	sd	ra,24(sp)
    80000cc2:	e822                	sd	s0,16(sp)
    80000cc4:	e426                	sd	s1,8(sp)
    80000cc6:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000cc8:	6904                	ld	s1,16(a0)
    80000cca:	00001097          	auipc	ra,0x1
    80000cce:	f4c080e7          	jalr	-180(ra) # 80001c16 <mycpu>
    80000cd2:	40a48533          	sub	a0,s1,a0
    80000cd6:	00153513          	seqz	a0,a0
}
    80000cda:	60e2                	ld	ra,24(sp)
    80000cdc:	6442                	ld	s0,16(sp)
    80000cde:	64a2                	ld	s1,8(sp)
    80000ce0:	6105                	addi	sp,sp,32
    80000ce2:	8082                	ret

0000000080000ce4 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000ce4:	1101                	addi	sp,sp,-32
    80000ce6:	ec06                	sd	ra,24(sp)
    80000ce8:	e822                	sd	s0,16(sp)
    80000cea:	e426                	sd	s1,8(sp)
    80000cec:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000cee:	100024f3          	csrr	s1,sstatus
    80000cf2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000cf6:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80000cf8:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80000cfc:	00001097          	auipc	ra,0x1
    80000d00:	f1a080e7          	jalr	-230(ra) # 80001c16 <mycpu>
    80000d04:	5d3c                	lw	a5,120(a0)
    80000d06:	cf89                	beqz	a5,80000d20 <push_off+0x3c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000d08:	00001097          	auipc	ra,0x1
    80000d0c:	f0e080e7          	jalr	-242(ra) # 80001c16 <mycpu>
    80000d10:	5d3c                	lw	a5,120(a0)
    80000d12:	2785                	addiw	a5,a5,1
    80000d14:	dd3c                	sw	a5,120(a0)
}
    80000d16:	60e2                	ld	ra,24(sp)
    80000d18:	6442                	ld	s0,16(sp)
    80000d1a:	64a2                	ld	s1,8(sp)
    80000d1c:	6105                	addi	sp,sp,32
    80000d1e:	8082                	ret
    mycpu()->intena = old;
    80000d20:	00001097          	auipc	ra,0x1
    80000d24:	ef6080e7          	jalr	-266(ra) # 80001c16 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000d28:	8085                	srli	s1,s1,0x1
    80000d2a:	8885                	andi	s1,s1,1
    80000d2c:	dd64                	sw	s1,124(a0)
    80000d2e:	bfe9                	j	80000d08 <push_off+0x24>

0000000080000d30 <acquire>:
{
    80000d30:	1101                	addi	sp,sp,-32
    80000d32:	ec06                	sd	ra,24(sp)
    80000d34:	e822                	sd	s0,16(sp)
    80000d36:	e426                	sd	s1,8(sp)
    80000d38:	1000                	addi	s0,sp,32
    80000d3a:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000d3c:	00000097          	auipc	ra,0x0
    80000d40:	fa8080e7          	jalr	-88(ra) # 80000ce4 <push_off>
  if(holding(lk))
    80000d44:	8526                	mv	a0,s1
    80000d46:	00000097          	auipc	ra,0x0
    80000d4a:	f70080e7          	jalr	-144(ra) # 80000cb6 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000d4e:	4705                	li	a4,1
  if(holding(lk))
    80000d50:	e115                	bnez	a0,80000d74 <acquire+0x44>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000d52:	87ba                	mv	a5,a4
    80000d54:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000d58:	2781                	sext.w	a5,a5
    80000d5a:	ffe5                	bnez	a5,80000d52 <acquire+0x22>
  __sync_synchronize();
    80000d5c:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000d60:	00001097          	auipc	ra,0x1
    80000d64:	eb6080e7          	jalr	-330(ra) # 80001c16 <mycpu>
    80000d68:	e888                	sd	a0,16(s1)
}
    80000d6a:	60e2                	ld	ra,24(sp)
    80000d6c:	6442                	ld	s0,16(sp)
    80000d6e:	64a2                	ld	s1,8(sp)
    80000d70:	6105                	addi	sp,sp,32
    80000d72:	8082                	ret
    panic("acquire");
    80000d74:	00007517          	auipc	a0,0x7
    80000d78:	30450513          	addi	a0,a0,772 # 80008078 <digits+0x38>
    80000d7c:	fffff097          	auipc	ra,0xfffff
    80000d80:	7c2080e7          	jalr	1986(ra) # 8000053e <panic>

0000000080000d84 <pop_off>:

void
pop_off(void)
{
    80000d84:	1141                	addi	sp,sp,-16
    80000d86:	e406                	sd	ra,8(sp)
    80000d88:	e022                	sd	s0,0(sp)
    80000d8a:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000d8c:	00001097          	auipc	ra,0x1
    80000d90:	e8a080e7          	jalr	-374(ra) # 80001c16 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000d94:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000d98:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000d9a:	e78d                	bnez	a5,80000dc4 <pop_off+0x40>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000d9c:	5d3c                	lw	a5,120(a0)
    80000d9e:	02f05b63          	blez	a5,80000dd4 <pop_off+0x50>
    panic("pop_off");
  c->noff -= 1;
    80000da2:	37fd                	addiw	a5,a5,-1
    80000da4:	0007871b          	sext.w	a4,a5
    80000da8:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000daa:	eb09                	bnez	a4,80000dbc <pop_off+0x38>
    80000dac:	5d7c                	lw	a5,124(a0)
    80000dae:	c799                	beqz	a5,80000dbc <pop_off+0x38>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000db0:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000db4:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80000db8:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000dbc:	60a2                	ld	ra,8(sp)
    80000dbe:	6402                	ld	s0,0(sp)
    80000dc0:	0141                	addi	sp,sp,16
    80000dc2:	8082                	ret
    panic("pop_off - interruptible");
    80000dc4:	00007517          	auipc	a0,0x7
    80000dc8:	2bc50513          	addi	a0,a0,700 # 80008080 <digits+0x40>
    80000dcc:	fffff097          	auipc	ra,0xfffff
    80000dd0:	772080e7          	jalr	1906(ra) # 8000053e <panic>
    panic("pop_off");
    80000dd4:	00007517          	auipc	a0,0x7
    80000dd8:	2c450513          	addi	a0,a0,708 # 80008098 <digits+0x58>
    80000ddc:	fffff097          	auipc	ra,0xfffff
    80000de0:	762080e7          	jalr	1890(ra) # 8000053e <panic>

0000000080000de4 <release>:
{
    80000de4:	1101                	addi	sp,sp,-32
    80000de6:	ec06                	sd	ra,24(sp)
    80000de8:	e822                	sd	s0,16(sp)
    80000dea:	e426                	sd	s1,8(sp)
    80000dec:	1000                	addi	s0,sp,32
    80000dee:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000df0:	00000097          	auipc	ra,0x0
    80000df4:	ec6080e7          	jalr	-314(ra) # 80000cb6 <holding>
    80000df8:	c115                	beqz	a0,80000e1c <release+0x38>
  lk->cpu = 0;
    80000dfa:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000dfe:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000e02:	0f50000f          	fence	iorw,ow
    80000e06:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000e0a:	00000097          	auipc	ra,0x0
    80000e0e:	f7a080e7          	jalr	-134(ra) # 80000d84 <pop_off>
}
    80000e12:	60e2                	ld	ra,24(sp)
    80000e14:	6442                	ld	s0,16(sp)
    80000e16:	64a2                	ld	s1,8(sp)
    80000e18:	6105                	addi	sp,sp,32
    80000e1a:	8082                	ret
    panic("release");
    80000e1c:	00007517          	auipc	a0,0x7
    80000e20:	28450513          	addi	a0,a0,644 # 800080a0 <digits+0x60>
    80000e24:	fffff097          	auipc	ra,0xfffff
    80000e28:	71a080e7          	jalr	1818(ra) # 8000053e <panic>

0000000080000e2c <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000e2c:	1141                	addi	sp,sp,-16
    80000e2e:	e422                	sd	s0,8(sp)
    80000e30:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000e32:	ca19                	beqz	a2,80000e48 <memset+0x1c>
    80000e34:	87aa                	mv	a5,a0
    80000e36:	1602                	slli	a2,a2,0x20
    80000e38:	9201                	srli	a2,a2,0x20
    80000e3a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000e3e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000e42:	0785                	addi	a5,a5,1
    80000e44:	fee79de3          	bne	a5,a4,80000e3e <memset+0x12>
  }
  return dst;
}
    80000e48:	6422                	ld	s0,8(sp)
    80000e4a:	0141                	addi	sp,sp,16
    80000e4c:	8082                	ret

0000000080000e4e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000e4e:	1141                	addi	sp,sp,-16
    80000e50:	e422                	sd	s0,8(sp)
    80000e52:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000e54:	ca05                	beqz	a2,80000e84 <memcmp+0x36>
    80000e56:	fff6069b          	addiw	a3,a2,-1
    80000e5a:	1682                	slli	a3,a3,0x20
    80000e5c:	9281                	srli	a3,a3,0x20
    80000e5e:	0685                	addi	a3,a3,1
    80000e60:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000e62:	00054783          	lbu	a5,0(a0)
    80000e66:	0005c703          	lbu	a4,0(a1)
    80000e6a:	00e79863          	bne	a5,a4,80000e7a <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000e6e:	0505                	addi	a0,a0,1
    80000e70:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000e72:	fed518e3          	bne	a0,a3,80000e62 <memcmp+0x14>
  }

  return 0;
    80000e76:	4501                	li	a0,0
    80000e78:	a019                	j	80000e7e <memcmp+0x30>
      return *s1 - *s2;
    80000e7a:	40e7853b          	subw	a0,a5,a4
}
    80000e7e:	6422                	ld	s0,8(sp)
    80000e80:	0141                	addi	sp,sp,16
    80000e82:	8082                	ret
  return 0;
    80000e84:	4501                	li	a0,0
    80000e86:	bfe5                	j	80000e7e <memcmp+0x30>

0000000080000e88 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000e88:	1141                	addi	sp,sp,-16
    80000e8a:	e422                	sd	s0,8(sp)
    80000e8c:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000e8e:	c205                	beqz	a2,80000eae <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000e90:	02a5e263          	bltu	a1,a0,80000eb4 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000e94:	1602                	slli	a2,a2,0x20
    80000e96:	9201                	srli	a2,a2,0x20
    80000e98:	00c587b3          	add	a5,a1,a2
{
    80000e9c:	872a                	mv	a4,a0
      *d++ = *s++;
    80000e9e:	0585                	addi	a1,a1,1
    80000ea0:	0705                	addi	a4,a4,1
    80000ea2:	fff5c683          	lbu	a3,-1(a1)
    80000ea6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000eaa:	fef59ae3          	bne	a1,a5,80000e9e <memmove+0x16>

  return dst;
}
    80000eae:	6422                	ld	s0,8(sp)
    80000eb0:	0141                	addi	sp,sp,16
    80000eb2:	8082                	ret
  if(s < d && s + n > d){
    80000eb4:	02061693          	slli	a3,a2,0x20
    80000eb8:	9281                	srli	a3,a3,0x20
    80000eba:	00d58733          	add	a4,a1,a3
    80000ebe:	fce57be3          	bgeu	a0,a4,80000e94 <memmove+0xc>
    d += n;
    80000ec2:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000ec4:	fff6079b          	addiw	a5,a2,-1
    80000ec8:	1782                	slli	a5,a5,0x20
    80000eca:	9381                	srli	a5,a5,0x20
    80000ecc:	fff7c793          	not	a5,a5
    80000ed0:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000ed2:	177d                	addi	a4,a4,-1
    80000ed4:	16fd                	addi	a3,a3,-1
    80000ed6:	00074603          	lbu	a2,0(a4)
    80000eda:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000ede:	fee79ae3          	bne	a5,a4,80000ed2 <memmove+0x4a>
    80000ee2:	b7f1                	j	80000eae <memmove+0x26>

0000000080000ee4 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000ee4:	1141                	addi	sp,sp,-16
    80000ee6:	e406                	sd	ra,8(sp)
    80000ee8:	e022                	sd	s0,0(sp)
    80000eea:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000eec:	00000097          	auipc	ra,0x0
    80000ef0:	f9c080e7          	jalr	-100(ra) # 80000e88 <memmove>
}
    80000ef4:	60a2                	ld	ra,8(sp)
    80000ef6:	6402                	ld	s0,0(sp)
    80000ef8:	0141                	addi	sp,sp,16
    80000efa:	8082                	ret

0000000080000efc <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000efc:	1141                	addi	sp,sp,-16
    80000efe:	e422                	sd	s0,8(sp)
    80000f00:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000f02:	ce11                	beqz	a2,80000f1e <strncmp+0x22>
    80000f04:	00054783          	lbu	a5,0(a0)
    80000f08:	cf89                	beqz	a5,80000f22 <strncmp+0x26>
    80000f0a:	0005c703          	lbu	a4,0(a1)
    80000f0e:	00f71a63          	bne	a4,a5,80000f22 <strncmp+0x26>
    n--, p++, q++;
    80000f12:	367d                	addiw	a2,a2,-1
    80000f14:	0505                	addi	a0,a0,1
    80000f16:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000f18:	f675                	bnez	a2,80000f04 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000f1a:	4501                	li	a0,0
    80000f1c:	a809                	j	80000f2e <strncmp+0x32>
    80000f1e:	4501                	li	a0,0
    80000f20:	a039                	j	80000f2e <strncmp+0x32>
  if(n == 0)
    80000f22:	ca09                	beqz	a2,80000f34 <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000f24:	00054503          	lbu	a0,0(a0)
    80000f28:	0005c783          	lbu	a5,0(a1)
    80000f2c:	9d1d                	subw	a0,a0,a5
}
    80000f2e:	6422                	ld	s0,8(sp)
    80000f30:	0141                	addi	sp,sp,16
    80000f32:	8082                	ret
    return 0;
    80000f34:	4501                	li	a0,0
    80000f36:	bfe5                	j	80000f2e <strncmp+0x32>

0000000080000f38 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000f38:	1141                	addi	sp,sp,-16
    80000f3a:	e422                	sd	s0,8(sp)
    80000f3c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000f3e:	872a                	mv	a4,a0
    80000f40:	8832                	mv	a6,a2
    80000f42:	367d                	addiw	a2,a2,-1
    80000f44:	01005963          	blez	a6,80000f56 <strncpy+0x1e>
    80000f48:	0705                	addi	a4,a4,1
    80000f4a:	0005c783          	lbu	a5,0(a1)
    80000f4e:	fef70fa3          	sb	a5,-1(a4)
    80000f52:	0585                	addi	a1,a1,1
    80000f54:	f7f5                	bnez	a5,80000f40 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000f56:	86ba                	mv	a3,a4
    80000f58:	00c05c63          	blez	a2,80000f70 <strncpy+0x38>
    *s++ = 0;
    80000f5c:	0685                	addi	a3,a3,1
    80000f5e:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000f62:	fff6c793          	not	a5,a3
    80000f66:	9fb9                	addw	a5,a5,a4
    80000f68:	010787bb          	addw	a5,a5,a6
    80000f6c:	fef048e3          	bgtz	a5,80000f5c <strncpy+0x24>
  return os;
}
    80000f70:	6422                	ld	s0,8(sp)
    80000f72:	0141                	addi	sp,sp,16
    80000f74:	8082                	ret

0000000080000f76 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000f76:	1141                	addi	sp,sp,-16
    80000f78:	e422                	sd	s0,8(sp)
    80000f7a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000f7c:	02c05363          	blez	a2,80000fa2 <safestrcpy+0x2c>
    80000f80:	fff6069b          	addiw	a3,a2,-1
    80000f84:	1682                	slli	a3,a3,0x20
    80000f86:	9281                	srli	a3,a3,0x20
    80000f88:	96ae                	add	a3,a3,a1
    80000f8a:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000f8c:	00d58963          	beq	a1,a3,80000f9e <safestrcpy+0x28>
    80000f90:	0585                	addi	a1,a1,1
    80000f92:	0785                	addi	a5,a5,1
    80000f94:	fff5c703          	lbu	a4,-1(a1)
    80000f98:	fee78fa3          	sb	a4,-1(a5)
    80000f9c:	fb65                	bnez	a4,80000f8c <safestrcpy+0x16>
    ;
  *s = 0;
    80000f9e:	00078023          	sb	zero,0(a5)
  return os;
}
    80000fa2:	6422                	ld	s0,8(sp)
    80000fa4:	0141                	addi	sp,sp,16
    80000fa6:	8082                	ret

0000000080000fa8 <strlen>:

int
strlen(const char *s)
{
    80000fa8:	1141                	addi	sp,sp,-16
    80000faa:	e422                	sd	s0,8(sp)
    80000fac:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000fae:	00054783          	lbu	a5,0(a0)
    80000fb2:	cf91                	beqz	a5,80000fce <strlen+0x26>
    80000fb4:	0505                	addi	a0,a0,1
    80000fb6:	87aa                	mv	a5,a0
    80000fb8:	4685                	li	a3,1
    80000fba:	9e89                	subw	a3,a3,a0
    80000fbc:	00f6853b          	addw	a0,a3,a5
    80000fc0:	0785                	addi	a5,a5,1
    80000fc2:	fff7c703          	lbu	a4,-1(a5)
    80000fc6:	fb7d                	bnez	a4,80000fbc <strlen+0x14>
    ;
  return n;
}
    80000fc8:	6422                	ld	s0,8(sp)
    80000fca:	0141                	addi	sp,sp,16
    80000fcc:	8082                	ret
  for(n = 0; s[n]; n++)
    80000fce:	4501                	li	a0,0
    80000fd0:	bfe5                	j	80000fc8 <strlen+0x20>

0000000080000fd2 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000fd2:	1141                	addi	sp,sp,-16
    80000fd4:	e406                	sd	ra,8(sp)
    80000fd6:	e022                	sd	s0,0(sp)
    80000fd8:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000fda:	00001097          	auipc	ra,0x1
    80000fde:	c2c080e7          	jalr	-980(ra) # 80001c06 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000fe2:	00008717          	auipc	a4,0x8
    80000fe6:	91670713          	addi	a4,a4,-1770 # 800088f8 <started>
  if(cpuid() == 0){
    80000fea:	c139                	beqz	a0,80001030 <main+0x5e>
    while(started == 0)
    80000fec:	431c                	lw	a5,0(a4)
    80000fee:	2781                	sext.w	a5,a5
    80000ff0:	dff5                	beqz	a5,80000fec <main+0x1a>
      ;
    __sync_synchronize();
    80000ff2:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000ff6:	00001097          	auipc	ra,0x1
    80000ffa:	c10080e7          	jalr	-1008(ra) # 80001c06 <cpuid>
    80000ffe:	85aa                	mv	a1,a0
    80001000:	00007517          	auipc	a0,0x7
    80001004:	0c050513          	addi	a0,a0,192 # 800080c0 <digits+0x80>
    80001008:	fffff097          	auipc	ra,0xfffff
    8000100c:	580080e7          	jalr	1408(ra) # 80000588 <printf>
    kvminithart();    // turn on paging
    80001010:	00000097          	auipc	ra,0x0
    80001014:	0d8080e7          	jalr	216(ra) # 800010e8 <kvminithart>
    trapinithart();   // install kernel trap vector
    80001018:	00002097          	auipc	ra,0x2
    8000101c:	8bc080e7          	jalr	-1860(ra) # 800028d4 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80001020:	00005097          	auipc	ra,0x5
    80001024:	e90080e7          	jalr	-368(ra) # 80005eb0 <plicinithart>
  }

  scheduler();        
    80001028:	00001097          	auipc	ra,0x1
    8000102c:	104080e7          	jalr	260(ra) # 8000212c <scheduler>
    consoleinit();
    80001030:	fffff097          	auipc	ra,0xfffff
    80001034:	420080e7          	jalr	1056(ra) # 80000450 <consoleinit>
    printfinit();
    80001038:	fffff097          	auipc	ra,0xfffff
    8000103c:	730080e7          	jalr	1840(ra) # 80000768 <printfinit>
    printf("\n");
    80001040:	00007517          	auipc	a0,0x7
    80001044:	09050513          	addi	a0,a0,144 # 800080d0 <digits+0x90>
    80001048:	fffff097          	auipc	ra,0xfffff
    8000104c:	540080e7          	jalr	1344(ra) # 80000588 <printf>
    printf("xv6 kernel is booting\n");
    80001050:	00007517          	auipc	a0,0x7
    80001054:	05850513          	addi	a0,a0,88 # 800080a8 <digits+0x68>
    80001058:	fffff097          	auipc	ra,0xfffff
    8000105c:	530080e7          	jalr	1328(ra) # 80000588 <printf>
    printf("\n");
    80001060:	00007517          	auipc	a0,0x7
    80001064:	07050513          	addi	a0,a0,112 # 800080d0 <digits+0x90>
    80001068:	fffff097          	auipc	ra,0xfffff
    8000106c:	520080e7          	jalr	1312(ra) # 80000588 <printf>
    kinit();         // physical page allocator
    80001070:	00000097          	auipc	ra,0x0
    80001074:	b5e080e7          	jalr	-1186(ra) # 80000bce <kinit>
    kvminit();       // create kernel page table
    80001078:	00000097          	auipc	ra,0x0
    8000107c:	34a080e7          	jalr	842(ra) # 800013c2 <kvminit>
    kvminithart();   // turn on paging
    80001080:	00000097          	auipc	ra,0x0
    80001084:	068080e7          	jalr	104(ra) # 800010e8 <kvminithart>
    procinit();      // process table
    80001088:	00001097          	auipc	ra,0x1
    8000108c:	aca080e7          	jalr	-1334(ra) # 80001b52 <procinit>
    trapinit();      // trap vectors
    80001090:	00002097          	auipc	ra,0x2
    80001094:	81c080e7          	jalr	-2020(ra) # 800028ac <trapinit>
    trapinithart();  // install kernel trap vector
    80001098:	00002097          	auipc	ra,0x2
    8000109c:	83c080e7          	jalr	-1988(ra) # 800028d4 <trapinithart>
    plicinit();      // set up interrupt controller
    800010a0:	00005097          	auipc	ra,0x5
    800010a4:	dfa080e7          	jalr	-518(ra) # 80005e9a <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    800010a8:	00005097          	auipc	ra,0x5
    800010ac:	e08080e7          	jalr	-504(ra) # 80005eb0 <plicinithart>
    binit();         // buffer cache
    800010b0:	00002097          	auipc	ra,0x2
    800010b4:	fd8080e7          	jalr	-40(ra) # 80003088 <binit>
    iinit();         // inode table
    800010b8:	00002097          	auipc	ra,0x2
    800010bc:	67e080e7          	jalr	1662(ra) # 80003736 <iinit>
    fileinit();      // file table
    800010c0:	00003097          	auipc	ra,0x3
    800010c4:	620080e7          	jalr	1568(ra) # 800046e0 <fileinit>
    virtio_disk_init(); // emulated hard disk
    800010c8:	00005097          	auipc	ra,0x5
    800010cc:	ef0080e7          	jalr	-272(ra) # 80005fb8 <virtio_disk_init>
    userinit();      // first user process
    800010d0:	00001097          	auipc	ra,0x1
    800010d4:	e3e080e7          	jalr	-450(ra) # 80001f0e <userinit>
    __sync_synchronize();
    800010d8:	0ff0000f          	fence
    started = 1;
    800010dc:	4785                	li	a5,1
    800010de:	00008717          	auipc	a4,0x8
    800010e2:	80f72d23          	sw	a5,-2022(a4) # 800088f8 <started>
    800010e6:	b789                	j	80001028 <main+0x56>

00000000800010e8 <kvminithart>:
}

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void kvminithart()
{
    800010e8:	1141                	addi	sp,sp,-16
    800010ea:	e422                	sd	s0,8(sp)
    800010ec:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800010ee:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800010f2:	00008797          	auipc	a5,0x8
    800010f6:	80e7b783          	ld	a5,-2034(a5) # 80008900 <kernel_pagetable>
    800010fa:	83b1                	srli	a5,a5,0xc
    800010fc:	577d                	li	a4,-1
    800010fe:	177e                	slli	a4,a4,0x3f
    80001100:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80001102:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80001106:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    8000110a:	6422                	ld	s0,8(sp)
    8000110c:	0141                	addi	sp,sp,16
    8000110e:	8082                	ret

0000000080001110 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80001110:	7139                	addi	sp,sp,-64
    80001112:	fc06                	sd	ra,56(sp)
    80001114:	f822                	sd	s0,48(sp)
    80001116:	f426                	sd	s1,40(sp)
    80001118:	f04a                	sd	s2,32(sp)
    8000111a:	ec4e                	sd	s3,24(sp)
    8000111c:	e852                	sd	s4,16(sp)
    8000111e:	e456                	sd	s5,8(sp)
    80001120:	e05a                	sd	s6,0(sp)
    80001122:	0080                	addi	s0,sp,64
    80001124:	84aa                	mv	s1,a0
    80001126:	89ae                	mv	s3,a1
    80001128:	8ab2                	mv	s5,a2
  if (va >= MAXVA)
    8000112a:	57fd                	li	a5,-1
    8000112c:	83e9                	srli	a5,a5,0x1a
    8000112e:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--)
    80001130:	4b31                	li	s6,12
  if (va >= MAXVA)
    80001132:	04b7f263          	bgeu	a5,a1,80001176 <walk+0x66>
    panic("walk");
    80001136:	00007517          	auipc	a0,0x7
    8000113a:	fa250513          	addi	a0,a0,-94 # 800080d8 <digits+0x98>
    8000113e:	fffff097          	auipc	ra,0xfffff
    80001142:	400080e7          	jalr	1024(ra) # 8000053e <panic>
    {
      pagetable = (pagetable_t)PTE2PA(*pte);
    }
    else
    {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80001146:	060a8663          	beqz	s5,800011b2 <walk+0xa2>
    8000114a:	00000097          	auipc	ra,0x0
    8000114e:	ac8080e7          	jalr	-1336(ra) # 80000c12 <kalloc>
    80001152:	84aa                	mv	s1,a0
    80001154:	c529                	beqz	a0,8000119e <walk+0x8e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80001156:	6605                	lui	a2,0x1
    80001158:	4581                	li	a1,0
    8000115a:	00000097          	auipc	ra,0x0
    8000115e:	cd2080e7          	jalr	-814(ra) # 80000e2c <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001162:	00c4d793          	srli	a5,s1,0xc
    80001166:	07aa                	slli	a5,a5,0xa
    80001168:	0017e793          	ori	a5,a5,1
    8000116c:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--)
    80001170:	3a5d                	addiw	s4,s4,-9
    80001172:	036a0063          	beq	s4,s6,80001192 <walk+0x82>
    pte_t *pte = &pagetable[PX(level, va)];
    80001176:	0149d933          	srl	s2,s3,s4
    8000117a:	1ff97913          	andi	s2,s2,511
    8000117e:	090e                	slli	s2,s2,0x3
    80001180:	9926                	add	s2,s2,s1
    if (*pte & PTE_V)
    80001182:	00093483          	ld	s1,0(s2)
    80001186:	0014f793          	andi	a5,s1,1
    8000118a:	dfd5                	beqz	a5,80001146 <walk+0x36>
      pagetable = (pagetable_t)PTE2PA(*pte);
    8000118c:	80a9                	srli	s1,s1,0xa
    8000118e:	04b2                	slli	s1,s1,0xc
    80001190:	b7c5                	j	80001170 <walk+0x60>
    }
  }
  return &pagetable[PX(0, va)];
    80001192:	00c9d513          	srli	a0,s3,0xc
    80001196:	1ff57513          	andi	a0,a0,511
    8000119a:	050e                	slli	a0,a0,0x3
    8000119c:	9526                	add	a0,a0,s1
}
    8000119e:	70e2                	ld	ra,56(sp)
    800011a0:	7442                	ld	s0,48(sp)
    800011a2:	74a2                	ld	s1,40(sp)
    800011a4:	7902                	ld	s2,32(sp)
    800011a6:	69e2                	ld	s3,24(sp)
    800011a8:	6a42                	ld	s4,16(sp)
    800011aa:	6aa2                	ld	s5,8(sp)
    800011ac:	6b02                	ld	s6,0(sp)
    800011ae:	6121                	addi	sp,sp,64
    800011b0:	8082                	ret
        return 0;
    800011b2:	4501                	li	a0,0
    800011b4:	b7ed                	j	8000119e <walk+0x8e>

00000000800011b6 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    800011b6:	57fd                	li	a5,-1
    800011b8:	83e9                	srli	a5,a5,0x1a
    800011ba:	00b7f463          	bgeu	a5,a1,800011c2 <walkaddr+0xc>
    return 0;
    800011be:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    800011c0:	8082                	ret
{
    800011c2:	1141                	addi	sp,sp,-16
    800011c4:	e406                	sd	ra,8(sp)
    800011c6:	e022                	sd	s0,0(sp)
    800011c8:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    800011ca:	4601                	li	a2,0
    800011cc:	00000097          	auipc	ra,0x0
    800011d0:	f44080e7          	jalr	-188(ra) # 80001110 <walk>
  if (pte == 0)
    800011d4:	c105                	beqz	a0,800011f4 <walkaddr+0x3e>
  if ((*pte & PTE_V) == 0)
    800011d6:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    800011d8:	0117f693          	andi	a3,a5,17
    800011dc:	4745                	li	a4,17
    return 0;
    800011de:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    800011e0:	00e68663          	beq	a3,a4,800011ec <walkaddr+0x36>
}
    800011e4:	60a2                	ld	ra,8(sp)
    800011e6:	6402                	ld	s0,0(sp)
    800011e8:	0141                	addi	sp,sp,16
    800011ea:	8082                	ret
  pa = PTE2PA(*pte);
    800011ec:	00a7d513          	srli	a0,a5,0xa
    800011f0:	0532                	slli	a0,a0,0xc
  return pa;
    800011f2:	bfcd                	j	800011e4 <walkaddr+0x2e>
    return 0;
    800011f4:	4501                	li	a0,0
    800011f6:	b7fd                	j	800011e4 <walkaddr+0x2e>

00000000800011f8 <mappages>:
// physical addresses starting at pa.
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800011f8:	715d                	addi	sp,sp,-80
    800011fa:	e486                	sd	ra,72(sp)
    800011fc:	e0a2                	sd	s0,64(sp)
    800011fe:	fc26                	sd	s1,56(sp)
    80001200:	f84a                	sd	s2,48(sp)
    80001202:	f44e                	sd	s3,40(sp)
    80001204:	f052                	sd	s4,32(sp)
    80001206:	ec56                	sd	s5,24(sp)
    80001208:	e85a                	sd	s6,16(sp)
    8000120a:	e45e                	sd	s7,8(sp)
    8000120c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    8000120e:	03459793          	slli	a5,a1,0x34
    80001212:	e7b9                	bnez	a5,80001260 <mappages+0x68>
    80001214:	8aaa                	mv	s5,a0
    80001216:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80001218:	03461793          	slli	a5,a2,0x34
    8000121c:	ebb1                	bnez	a5,80001270 <mappages+0x78>
    panic("mappages: size not aligned");

  if (size == 0)
    8000121e:	c22d                	beqz	a2,80001280 <mappages+0x88>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    80001220:	79fd                	lui	s3,0xfffff
    80001222:	964e                	add	a2,a2,s3
    80001224:	00b609b3          	add	s3,a2,a1
  a = va;
    80001228:	892e                	mv	s2,a1
    8000122a:	40b68a33          	sub	s4,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    8000122e:	6b85                	lui	s7,0x1
    80001230:	012a04b3          	add	s1,s4,s2
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001234:	4605                	li	a2,1
    80001236:	85ca                	mv	a1,s2
    80001238:	8556                	mv	a0,s5
    8000123a:	00000097          	auipc	ra,0x0
    8000123e:	ed6080e7          	jalr	-298(ra) # 80001110 <walk>
    80001242:	cd39                	beqz	a0,800012a0 <mappages+0xa8>
    if (*pte & PTE_V)
    80001244:	611c                	ld	a5,0(a0)
    80001246:	8b85                	andi	a5,a5,1
    80001248:	e7a1                	bnez	a5,80001290 <mappages+0x98>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000124a:	80b1                	srli	s1,s1,0xc
    8000124c:	04aa                	slli	s1,s1,0xa
    8000124e:	0164e4b3          	or	s1,s1,s6
    80001252:	0014e493          	ori	s1,s1,1
    80001256:	e104                	sd	s1,0(a0)
    if (a == last)
    80001258:	07390063          	beq	s2,s3,800012b8 <mappages+0xc0>
    a += PGSIZE;
    8000125c:	995e                	add	s2,s2,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000125e:	bfc9                	j	80001230 <mappages+0x38>
    panic("mappages: va not aligned");
    80001260:	00007517          	auipc	a0,0x7
    80001264:	e8050513          	addi	a0,a0,-384 # 800080e0 <digits+0xa0>
    80001268:	fffff097          	auipc	ra,0xfffff
    8000126c:	2d6080e7          	jalr	726(ra) # 8000053e <panic>
    panic("mappages: size not aligned");
    80001270:	00007517          	auipc	a0,0x7
    80001274:	e9050513          	addi	a0,a0,-368 # 80008100 <digits+0xc0>
    80001278:	fffff097          	auipc	ra,0xfffff
    8000127c:	2c6080e7          	jalr	710(ra) # 8000053e <panic>
    panic("mappages: size");
    80001280:	00007517          	auipc	a0,0x7
    80001284:	ea050513          	addi	a0,a0,-352 # 80008120 <digits+0xe0>
    80001288:	fffff097          	auipc	ra,0xfffff
    8000128c:	2b6080e7          	jalr	694(ra) # 8000053e <panic>
      panic("mappages: remap");
    80001290:	00007517          	auipc	a0,0x7
    80001294:	ea050513          	addi	a0,a0,-352 # 80008130 <digits+0xf0>
    80001298:	fffff097          	auipc	ra,0xfffff
    8000129c:	2a6080e7          	jalr	678(ra) # 8000053e <panic>
      return -1;
    800012a0:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800012a2:	60a6                	ld	ra,72(sp)
    800012a4:	6406                	ld	s0,64(sp)
    800012a6:	74e2                	ld	s1,56(sp)
    800012a8:	7942                	ld	s2,48(sp)
    800012aa:	79a2                	ld	s3,40(sp)
    800012ac:	7a02                	ld	s4,32(sp)
    800012ae:	6ae2                	ld	s5,24(sp)
    800012b0:	6b42                	ld	s6,16(sp)
    800012b2:	6ba2                	ld	s7,8(sp)
    800012b4:	6161                	addi	sp,sp,80
    800012b6:	8082                	ret
  return 0;
    800012b8:	4501                	li	a0,0
    800012ba:	b7e5                	j	800012a2 <mappages+0xaa>

00000000800012bc <kvmmap>:
{
    800012bc:	1141                	addi	sp,sp,-16
    800012be:	e406                	sd	ra,8(sp)
    800012c0:	e022                	sd	s0,0(sp)
    800012c2:	0800                	addi	s0,sp,16
    800012c4:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    800012c6:	86b2                	mv	a3,a2
    800012c8:	863e                	mv	a2,a5
    800012ca:	00000097          	auipc	ra,0x0
    800012ce:	f2e080e7          	jalr	-210(ra) # 800011f8 <mappages>
    800012d2:	e509                	bnez	a0,800012dc <kvmmap+0x20>
}
    800012d4:	60a2                	ld	ra,8(sp)
    800012d6:	6402                	ld	s0,0(sp)
    800012d8:	0141                	addi	sp,sp,16
    800012da:	8082                	ret
    panic("kvmmap");
    800012dc:	00007517          	auipc	a0,0x7
    800012e0:	e6450513          	addi	a0,a0,-412 # 80008140 <digits+0x100>
    800012e4:	fffff097          	auipc	ra,0xfffff
    800012e8:	25a080e7          	jalr	602(ra) # 8000053e <panic>

00000000800012ec <kvmmake>:
{
    800012ec:	1101                	addi	sp,sp,-32
    800012ee:	ec06                	sd	ra,24(sp)
    800012f0:	e822                	sd	s0,16(sp)
    800012f2:	e426                	sd	s1,8(sp)
    800012f4:	e04a                	sd	s2,0(sp)
    800012f6:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    800012f8:	00000097          	auipc	ra,0x0
    800012fc:	91a080e7          	jalr	-1766(ra) # 80000c12 <kalloc>
    80001300:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001302:	6605                	lui	a2,0x1
    80001304:	4581                	li	a1,0
    80001306:	00000097          	auipc	ra,0x0
    8000130a:	b26080e7          	jalr	-1242(ra) # 80000e2c <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000130e:	4719                	li	a4,6
    80001310:	6685                	lui	a3,0x1
    80001312:	10000637          	lui	a2,0x10000
    80001316:	100005b7          	lui	a1,0x10000
    8000131a:	8526                	mv	a0,s1
    8000131c:	00000097          	auipc	ra,0x0
    80001320:	fa0080e7          	jalr	-96(ra) # 800012bc <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001324:	4719                	li	a4,6
    80001326:	6685                	lui	a3,0x1
    80001328:	10001637          	lui	a2,0x10001
    8000132c:	100015b7          	lui	a1,0x10001
    80001330:	8526                	mv	a0,s1
    80001332:	00000097          	auipc	ra,0x0
    80001336:	f8a080e7          	jalr	-118(ra) # 800012bc <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x400000, PTE_R | PTE_W);
    8000133a:	4719                	li	a4,6
    8000133c:	004006b7          	lui	a3,0x400
    80001340:	0c000637          	lui	a2,0xc000
    80001344:	0c0005b7          	lui	a1,0xc000
    80001348:	8526                	mv	a0,s1
    8000134a:	00000097          	auipc	ra,0x0
    8000134e:	f72080e7          	jalr	-142(ra) # 800012bc <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    80001352:	00007917          	auipc	s2,0x7
    80001356:	cae90913          	addi	s2,s2,-850 # 80008000 <etext>
    8000135a:	4729                	li	a4,10
    8000135c:	80007697          	auipc	a3,0x80007
    80001360:	ca468693          	addi	a3,a3,-860 # 8000 <_entry-0x7fff8000>
    80001364:	4605                	li	a2,1
    80001366:	067e                	slli	a2,a2,0x1f
    80001368:	85b2                	mv	a1,a2
    8000136a:	8526                	mv	a0,s1
    8000136c:	00000097          	auipc	ra,0x0
    80001370:	f50080e7          	jalr	-176(ra) # 800012bc <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext, PTE_R | PTE_W);
    80001374:	4719                	li	a4,6
    80001376:	46c5                	li	a3,17
    80001378:	06ee                	slli	a3,a3,0x1b
    8000137a:	412686b3          	sub	a3,a3,s2
    8000137e:	864a                	mv	a2,s2
    80001380:	85ca                	mv	a1,s2
    80001382:	8526                	mv	a0,s1
    80001384:	00000097          	auipc	ra,0x0
    80001388:	f38080e7          	jalr	-200(ra) # 800012bc <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000138c:	4729                	li	a4,10
    8000138e:	6685                	lui	a3,0x1
    80001390:	00006617          	auipc	a2,0x6
    80001394:	c7060613          	addi	a2,a2,-912 # 80007000 <_trampoline>
    80001398:	040005b7          	lui	a1,0x4000
    8000139c:	15fd                	addi	a1,a1,-1
    8000139e:	05b2                	slli	a1,a1,0xc
    800013a0:	8526                	mv	a0,s1
    800013a2:	00000097          	auipc	ra,0x0
    800013a6:	f1a080e7          	jalr	-230(ra) # 800012bc <kvmmap>
  proc_mapstacks(kpgtbl);
    800013aa:	8526                	mv	a0,s1
    800013ac:	00000097          	auipc	ra,0x0
    800013b0:	710080e7          	jalr	1808(ra) # 80001abc <proc_mapstacks>
}
    800013b4:	8526                	mv	a0,s1
    800013b6:	60e2                	ld	ra,24(sp)
    800013b8:	6442                	ld	s0,16(sp)
    800013ba:	64a2                	ld	s1,8(sp)
    800013bc:	6902                	ld	s2,0(sp)
    800013be:	6105                	addi	sp,sp,32
    800013c0:	8082                	ret

00000000800013c2 <kvminit>:
{
    800013c2:	1141                	addi	sp,sp,-16
    800013c4:	e406                	sd	ra,8(sp)
    800013c6:	e022                	sd	s0,0(sp)
    800013c8:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800013ca:	00000097          	auipc	ra,0x0
    800013ce:	f22080e7          	jalr	-222(ra) # 800012ec <kvmmake>
    800013d2:	00007797          	auipc	a5,0x7
    800013d6:	52a7b723          	sd	a0,1326(a5) # 80008900 <kernel_pagetable>
}
    800013da:	60a2                	ld	ra,8(sp)
    800013dc:	6402                	ld	s0,0(sp)
    800013de:	0141                	addi	sp,sp,16
    800013e0:	8082                	ret

00000000800013e2 <uvmunmap>:

// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800013e2:	715d                	addi	sp,sp,-80
    800013e4:	e486                	sd	ra,72(sp)
    800013e6:	e0a2                	sd	s0,64(sp)
    800013e8:	fc26                	sd	s1,56(sp)
    800013ea:	f84a                	sd	s2,48(sp)
    800013ec:	f44e                	sd	s3,40(sp)
    800013ee:	f052                	sd	s4,32(sp)
    800013f0:	ec56                	sd	s5,24(sp)
    800013f2:	e85a                	sd	s6,16(sp)
    800013f4:	e45e                	sd	s7,8(sp)
    800013f6:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    800013f8:	03459793          	slli	a5,a1,0x34
    800013fc:	e795                	bnez	a5,80001428 <uvmunmap+0x46>
    800013fe:	8a2a                	mv	s4,a0
    80001400:	892e                	mv	s2,a1
    80001402:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE)
    80001404:	0632                	slli	a2,a2,0xc
    80001406:	00b609b3          	add	s3,a2,a1
  {
    if ((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if ((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if (PTE_FLAGS(*pte) == PTE_V)
    8000140a:	4b85                	li	s7,1
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE)
    8000140c:	6b05                	lui	s6,0x1
    8000140e:	0735e263          	bltu	a1,s3,80001472 <uvmunmap+0x90>
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
  }
}
    80001412:	60a6                	ld	ra,72(sp)
    80001414:	6406                	ld	s0,64(sp)
    80001416:	74e2                	ld	s1,56(sp)
    80001418:	7942                	ld	s2,48(sp)
    8000141a:	79a2                	ld	s3,40(sp)
    8000141c:	7a02                	ld	s4,32(sp)
    8000141e:	6ae2                	ld	s5,24(sp)
    80001420:	6b42                	ld	s6,16(sp)
    80001422:	6ba2                	ld	s7,8(sp)
    80001424:	6161                	addi	sp,sp,80
    80001426:	8082                	ret
    panic("uvmunmap: not aligned");
    80001428:	00007517          	auipc	a0,0x7
    8000142c:	d2050513          	addi	a0,a0,-736 # 80008148 <digits+0x108>
    80001430:	fffff097          	auipc	ra,0xfffff
    80001434:	10e080e7          	jalr	270(ra) # 8000053e <panic>
      panic("uvmunmap: walk");
    80001438:	00007517          	auipc	a0,0x7
    8000143c:	d2850513          	addi	a0,a0,-728 # 80008160 <digits+0x120>
    80001440:	fffff097          	auipc	ra,0xfffff
    80001444:	0fe080e7          	jalr	254(ra) # 8000053e <panic>
      panic("uvmunmap: not mapped");
    80001448:	00007517          	auipc	a0,0x7
    8000144c:	d2850513          	addi	a0,a0,-728 # 80008170 <digits+0x130>
    80001450:	fffff097          	auipc	ra,0xfffff
    80001454:	0ee080e7          	jalr	238(ra) # 8000053e <panic>
      panic("uvmunmap: not a leaf");
    80001458:	00007517          	auipc	a0,0x7
    8000145c:	d3050513          	addi	a0,a0,-720 # 80008188 <digits+0x148>
    80001460:	fffff097          	auipc	ra,0xfffff
    80001464:	0de080e7          	jalr	222(ra) # 8000053e <panic>
    *pte = 0;
    80001468:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE)
    8000146c:	995a                	add	s2,s2,s6
    8000146e:	fb3972e3          	bgeu	s2,s3,80001412 <uvmunmap+0x30>
    if ((pte = walk(pagetable, a, 0)) == 0)
    80001472:	4601                	li	a2,0
    80001474:	85ca                	mv	a1,s2
    80001476:	8552                	mv	a0,s4
    80001478:	00000097          	auipc	ra,0x0
    8000147c:	c98080e7          	jalr	-872(ra) # 80001110 <walk>
    80001480:	84aa                	mv	s1,a0
    80001482:	d95d                	beqz	a0,80001438 <uvmunmap+0x56>
    if ((*pte & PTE_V) == 0)
    80001484:	6108                	ld	a0,0(a0)
    80001486:	00157793          	andi	a5,a0,1
    8000148a:	dfdd                	beqz	a5,80001448 <uvmunmap+0x66>
    if (PTE_FLAGS(*pte) == PTE_V)
    8000148c:	3ff57793          	andi	a5,a0,1023
    80001490:	fd7784e3          	beq	a5,s7,80001458 <uvmunmap+0x76>
    if (do_free)
    80001494:	fc0a8ae3          	beqz	s5,80001468 <uvmunmap+0x86>
      uint64 pa = PTE2PA(*pte);
    80001498:	8129                	srli	a0,a0,0xa
      kfree((void *)pa);
    8000149a:	0532                	slli	a0,a0,0xc
    8000149c:	fffff097          	auipc	ra,0xfffff
    800014a0:	662080e7          	jalr	1634(ra) # 80000afe <kfree>
    800014a4:	b7d1                	j	80001468 <uvmunmap+0x86>

00000000800014a6 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800014a6:	1101                	addi	sp,sp,-32
    800014a8:	ec06                	sd	ra,24(sp)
    800014aa:	e822                	sd	s0,16(sp)
    800014ac:	e426                	sd	s1,8(sp)
    800014ae:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    800014b0:	fffff097          	auipc	ra,0xfffff
    800014b4:	762080e7          	jalr	1890(ra) # 80000c12 <kalloc>
    800014b8:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800014ba:	c519                	beqz	a0,800014c8 <uvmcreate+0x22>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800014bc:	6605                	lui	a2,0x1
    800014be:	4581                	li	a1,0
    800014c0:	00000097          	auipc	ra,0x0
    800014c4:	96c080e7          	jalr	-1684(ra) # 80000e2c <memset>
  return pagetable;
}
    800014c8:	8526                	mv	a0,s1
    800014ca:	60e2                	ld	ra,24(sp)
    800014cc:	6442                	ld	s0,16(sp)
    800014ce:	64a2                	ld	s1,8(sp)
    800014d0:	6105                	addi	sp,sp,32
    800014d2:	8082                	ret

00000000800014d4 <uvmfirst>:

// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    800014d4:	7179                	addi	sp,sp,-48
    800014d6:	f406                	sd	ra,40(sp)
    800014d8:	f022                	sd	s0,32(sp)
    800014da:	ec26                	sd	s1,24(sp)
    800014dc:	e84a                	sd	s2,16(sp)
    800014de:	e44e                	sd	s3,8(sp)
    800014e0:	e052                	sd	s4,0(sp)
    800014e2:	1800                	addi	s0,sp,48
  char *mem;

  if (sz >= PGSIZE)
    800014e4:	6785                	lui	a5,0x1
    800014e6:	04f67863          	bgeu	a2,a5,80001536 <uvmfirst+0x62>
    800014ea:	8a2a                	mv	s4,a0
    800014ec:	89ae                	mv	s3,a1
    800014ee:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    800014f0:	fffff097          	auipc	ra,0xfffff
    800014f4:	722080e7          	jalr	1826(ra) # 80000c12 <kalloc>
    800014f8:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    800014fa:	6605                	lui	a2,0x1
    800014fc:	4581                	li	a1,0
    800014fe:	00000097          	auipc	ra,0x0
    80001502:	92e080e7          	jalr	-1746(ra) # 80000e2c <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W | PTE_R | PTE_X | PTE_U);
    80001506:	4779                	li	a4,30
    80001508:	86ca                	mv	a3,s2
    8000150a:	6605                	lui	a2,0x1
    8000150c:	4581                	li	a1,0
    8000150e:	8552                	mv	a0,s4
    80001510:	00000097          	auipc	ra,0x0
    80001514:	ce8080e7          	jalr	-792(ra) # 800011f8 <mappages>
  memmove(mem, src, sz);
    80001518:	8626                	mv	a2,s1
    8000151a:	85ce                	mv	a1,s3
    8000151c:	854a                	mv	a0,s2
    8000151e:	00000097          	auipc	ra,0x0
    80001522:	96a080e7          	jalr	-1686(ra) # 80000e88 <memmove>
}
    80001526:	70a2                	ld	ra,40(sp)
    80001528:	7402                	ld	s0,32(sp)
    8000152a:	64e2                	ld	s1,24(sp)
    8000152c:	6942                	ld	s2,16(sp)
    8000152e:	69a2                	ld	s3,8(sp)
    80001530:	6a02                	ld	s4,0(sp)
    80001532:	6145                	addi	sp,sp,48
    80001534:	8082                	ret
    panic("uvmfirst: more than a page");
    80001536:	00007517          	auipc	a0,0x7
    8000153a:	c6a50513          	addi	a0,a0,-918 # 800081a0 <digits+0x160>
    8000153e:	fffff097          	auipc	ra,0xfffff
    80001542:	000080e7          	jalr	ra # 8000053e <panic>

0000000080001546 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001546:	1101                	addi	sp,sp,-32
    80001548:	ec06                	sd	ra,24(sp)
    8000154a:	e822                	sd	s0,16(sp)
    8000154c:	e426                	sd	s1,8(sp)
    8000154e:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    80001550:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    80001552:	00b67d63          	bgeu	a2,a1,8000156c <uvmdealloc+0x26>
    80001556:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz))
    80001558:	6785                	lui	a5,0x1
    8000155a:	17fd                	addi	a5,a5,-1
    8000155c:	00f60733          	add	a4,a2,a5
    80001560:	767d                	lui	a2,0xfffff
    80001562:	8f71                	and	a4,a4,a2
    80001564:	97ae                	add	a5,a5,a1
    80001566:	8ff1                	and	a5,a5,a2
    80001568:	00f76863          	bltu	a4,a5,80001578 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    8000156c:	8526                	mv	a0,s1
    8000156e:	60e2                	ld	ra,24(sp)
    80001570:	6442                	ld	s0,16(sp)
    80001572:	64a2                	ld	s1,8(sp)
    80001574:	6105                	addi	sp,sp,32
    80001576:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001578:	8f99                	sub	a5,a5,a4
    8000157a:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000157c:	4685                	li	a3,1
    8000157e:	0007861b          	sext.w	a2,a5
    80001582:	85ba                	mv	a1,a4
    80001584:	00000097          	auipc	ra,0x0
    80001588:	e5e080e7          	jalr	-418(ra) # 800013e2 <uvmunmap>
    8000158c:	b7c5                	j	8000156c <uvmdealloc+0x26>

000000008000158e <uvmalloc>:
  if (newsz < oldsz)
    8000158e:	0ab66563          	bltu	a2,a1,80001638 <uvmalloc+0xaa>
{
    80001592:	7139                	addi	sp,sp,-64
    80001594:	fc06                	sd	ra,56(sp)
    80001596:	f822                	sd	s0,48(sp)
    80001598:	f426                	sd	s1,40(sp)
    8000159a:	f04a                	sd	s2,32(sp)
    8000159c:	ec4e                	sd	s3,24(sp)
    8000159e:	e852                	sd	s4,16(sp)
    800015a0:	e456                	sd	s5,8(sp)
    800015a2:	e05a                	sd	s6,0(sp)
    800015a4:	0080                	addi	s0,sp,64
    800015a6:	8aaa                	mv	s5,a0
    800015a8:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800015aa:	6985                	lui	s3,0x1
    800015ac:	19fd                	addi	s3,s3,-1
    800015ae:	95ce                	add	a1,a1,s3
    800015b0:	79fd                	lui	s3,0xfffff
    800015b2:	0135f9b3          	and	s3,a1,s3
  for (a = oldsz; a < newsz; a += PGSIZE)
    800015b6:	08c9f363          	bgeu	s3,a2,8000163c <uvmalloc+0xae>
    800015ba:	894e                	mv	s2,s3
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) != 0)
    800015bc:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800015c0:	fffff097          	auipc	ra,0xfffff
    800015c4:	652080e7          	jalr	1618(ra) # 80000c12 <kalloc>
    800015c8:	84aa                	mv	s1,a0
    if (mem == 0)
    800015ca:	c51d                	beqz	a0,800015f8 <uvmalloc+0x6a>
    memset(mem, 0, PGSIZE);
    800015cc:	6605                	lui	a2,0x1
    800015ce:	4581                	li	a1,0
    800015d0:	00000097          	auipc	ra,0x0
    800015d4:	85c080e7          	jalr	-1956(ra) # 80000e2c <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) != 0)
    800015d8:	875a                	mv	a4,s6
    800015da:	86a6                	mv	a3,s1
    800015dc:	6605                	lui	a2,0x1
    800015de:	85ca                	mv	a1,s2
    800015e0:	8556                	mv	a0,s5
    800015e2:	00000097          	auipc	ra,0x0
    800015e6:	c16080e7          	jalr	-1002(ra) # 800011f8 <mappages>
    800015ea:	e90d                	bnez	a0,8000161c <uvmalloc+0x8e>
  for (a = oldsz; a < newsz; a += PGSIZE)
    800015ec:	6785                	lui	a5,0x1
    800015ee:	993e                	add	s2,s2,a5
    800015f0:	fd4968e3          	bltu	s2,s4,800015c0 <uvmalloc+0x32>
  return newsz;
    800015f4:	8552                	mv	a0,s4
    800015f6:	a809                	j	80001608 <uvmalloc+0x7a>
      uvmdealloc(pagetable, a, oldsz);
    800015f8:	864e                	mv	a2,s3
    800015fa:	85ca                	mv	a1,s2
    800015fc:	8556                	mv	a0,s5
    800015fe:	00000097          	auipc	ra,0x0
    80001602:	f48080e7          	jalr	-184(ra) # 80001546 <uvmdealloc>
      return 0;
    80001606:	4501                	li	a0,0
}
    80001608:	70e2                	ld	ra,56(sp)
    8000160a:	7442                	ld	s0,48(sp)
    8000160c:	74a2                	ld	s1,40(sp)
    8000160e:	7902                	ld	s2,32(sp)
    80001610:	69e2                	ld	s3,24(sp)
    80001612:	6a42                	ld	s4,16(sp)
    80001614:	6aa2                	ld	s5,8(sp)
    80001616:	6b02                	ld	s6,0(sp)
    80001618:	6121                	addi	sp,sp,64
    8000161a:	8082                	ret
      kfree(mem);
    8000161c:	8526                	mv	a0,s1
    8000161e:	fffff097          	auipc	ra,0xfffff
    80001622:	4e0080e7          	jalr	1248(ra) # 80000afe <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001626:	864e                	mv	a2,s3
    80001628:	85ca                	mv	a1,s2
    8000162a:	8556                	mv	a0,s5
    8000162c:	00000097          	auipc	ra,0x0
    80001630:	f1a080e7          	jalr	-230(ra) # 80001546 <uvmdealloc>
      return 0;
    80001634:	4501                	li	a0,0
    80001636:	bfc9                	j	80001608 <uvmalloc+0x7a>
    return oldsz;
    80001638:	852e                	mv	a0,a1
}
    8000163a:	8082                	ret
  return newsz;
    8000163c:	8532                	mv	a0,a2
    8000163e:	b7e9                	j	80001608 <uvmalloc+0x7a>

0000000080001640 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void freewalk(pagetable_t pagetable)
{
    80001640:	7179                	addi	sp,sp,-48
    80001642:	f406                	sd	ra,40(sp)
    80001644:	f022                	sd	s0,32(sp)
    80001646:	ec26                	sd	s1,24(sp)
    80001648:	e84a                	sd	s2,16(sp)
    8000164a:	e44e                	sd	s3,8(sp)
    8000164c:	e052                	sd	s4,0(sp)
    8000164e:	1800                	addi	s0,sp,48
    80001650:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++)
    80001652:	84aa                	mv	s1,a0
    80001654:	6905                	lui	s2,0x1
    80001656:	992a                	add	s2,s2,a0
  {
    pte_t pte = pagetable[i];
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0)
    80001658:	4985                	li	s3,1
    8000165a:	a821                	j	80001672 <freewalk+0x32>
    {
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    8000165c:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    8000165e:	0532                	slli	a0,a0,0xc
    80001660:	00000097          	auipc	ra,0x0
    80001664:	fe0080e7          	jalr	-32(ra) # 80001640 <freewalk>
      pagetable[i] = 0;
    80001668:	0004b023          	sd	zero,0(s1)
  for (int i = 0; i < 512; i++)
    8000166c:	04a1                	addi	s1,s1,8
    8000166e:	03248163          	beq	s1,s2,80001690 <freewalk+0x50>
    pte_t pte = pagetable[i];
    80001672:	6088                	ld	a0,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0)
    80001674:	00f57793          	andi	a5,a0,15
    80001678:	ff3782e3          	beq	a5,s3,8000165c <freewalk+0x1c>
    }
    else if (pte & PTE_V)
    8000167c:	8905                	andi	a0,a0,1
    8000167e:	d57d                	beqz	a0,8000166c <freewalk+0x2c>
    {
      panic("freewalk: leaf");
    80001680:	00007517          	auipc	a0,0x7
    80001684:	b4050513          	addi	a0,a0,-1216 # 800081c0 <digits+0x180>
    80001688:	fffff097          	auipc	ra,0xfffff
    8000168c:	eb6080e7          	jalr	-330(ra) # 8000053e <panic>
    }
  }
  kfree((void *)pagetable);
    80001690:	8552                	mv	a0,s4
    80001692:	fffff097          	auipc	ra,0xfffff
    80001696:	46c080e7          	jalr	1132(ra) # 80000afe <kfree>
}
    8000169a:	70a2                	ld	ra,40(sp)
    8000169c:	7402                	ld	s0,32(sp)
    8000169e:	64e2                	ld	s1,24(sp)
    800016a0:	6942                	ld	s2,16(sp)
    800016a2:	69a2                	ld	s3,8(sp)
    800016a4:	6a02                	ld	s4,0(sp)
    800016a6:	6145                	addi	sp,sp,48
    800016a8:	8082                	ret

00000000800016aa <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void uvmfree(pagetable_t pagetable, uint64 sz)
{
    800016aa:	1101                	addi	sp,sp,-32
    800016ac:	ec06                	sd	ra,24(sp)
    800016ae:	e822                	sd	s0,16(sp)
    800016b0:	e426                	sd	s1,8(sp)
    800016b2:	1000                	addi	s0,sp,32
    800016b4:	84aa                	mv	s1,a0
  if (sz > 0)
    800016b6:	e999                	bnez	a1,800016cc <uvmfree+0x22>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    800016b8:	8526                	mv	a0,s1
    800016ba:	00000097          	auipc	ra,0x0
    800016be:	f86080e7          	jalr	-122(ra) # 80001640 <freewalk>
}
    800016c2:	60e2                	ld	ra,24(sp)
    800016c4:	6442                	ld	s0,16(sp)
    800016c6:	64a2                	ld	s1,8(sp)
    800016c8:	6105                	addi	sp,sp,32
    800016ca:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    800016cc:	6605                	lui	a2,0x1
    800016ce:	167d                	addi	a2,a2,-1
    800016d0:	962e                	add	a2,a2,a1
    800016d2:	4685                	li	a3,1
    800016d4:	8231                	srli	a2,a2,0xc
    800016d6:	4581                	li	a1,0
    800016d8:	00000097          	auipc	ra,0x0
    800016dc:	d0a080e7          	jalr	-758(ra) # 800013e2 <uvmunmap>
    800016e0:	bfe1                	j	800016b8 <uvmfree+0xe>

00000000800016e2 <uvmcopy>:
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.
// Modified uvmcopy() in vm.c for COW
int uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
{
    800016e2:	715d                	addi	sp,sp,-80
    800016e4:	e486                	sd	ra,72(sp)
    800016e6:	e0a2                	sd	s0,64(sp)
    800016e8:	fc26                	sd	s1,56(sp)
    800016ea:	f84a                	sd	s2,48(sp)
    800016ec:	f44e                	sd	s3,40(sp)
    800016ee:	f052                	sd	s4,32(sp)
    800016f0:	ec56                	sd	s5,24(sp)
    800016f2:	e85a                	sd	s6,16(sp)
    800016f4:	e45e                	sd	s7,8(sp)
    800016f6:	0880                	addi	s0,sp,80
  pte_t *pte;
  uint64 pa, i;
  uint flags;

  for (i = 0; i < sz; i += PGSIZE)
    800016f8:	ce5d                	beqz	a2,800017b6 <uvmcopy+0xd4>
    800016fa:	8aaa                	mv	s5,a0
    800016fc:	8a2e                	mv	s4,a1
    800016fe:	89b2                	mv	s3,a2
    80001700:	4481                	li	s1,0

    // If page is writable, make it COW and remove write permission
    if (flags & PTE_W)
    {
      flags = (flags & ~PTE_W) | PTE_COW;
      *pte = PA2PTE(pa) | flags; // Update parent PTE
    80001702:	7b7d                	lui	s6,0xfffff
    80001704:	002b5b13          	srli	s6,s6,0x2
    80001708:	a0a1                	j	80001750 <uvmcopy+0x6e>
      panic("uvmcopy: pte should exist");
    8000170a:	00007517          	auipc	a0,0x7
    8000170e:	ac650513          	addi	a0,a0,-1338 # 800081d0 <digits+0x190>
    80001712:	fffff097          	auipc	ra,0xfffff
    80001716:	e2c080e7          	jalr	-468(ra) # 8000053e <panic>
      panic("uvmcopy: page not present");
    8000171a:	00007517          	auipc	a0,0x7
    8000171e:	ad650513          	addi	a0,a0,-1322 # 800081f0 <digits+0x1b0>
    80001722:	fffff097          	auipc	ra,0xfffff
    80001726:	e1c080e7          	jalr	-484(ra) # 8000053e <panic>
    }

    // Map the same physical page in child
    if (mappages(new, i, PGSIZE, pa, flags) != 0)
    8000172a:	86ca                	mv	a3,s2
    8000172c:	6605                	lui	a2,0x1
    8000172e:	85a6                	mv	a1,s1
    80001730:	8552                	mv	a0,s4
    80001732:	00000097          	auipc	ra,0x0
    80001736:	ac6080e7          	jalr	-1338(ra) # 800011f8 <mappages>
    8000173a:	8baa                	mv	s7,a0
    8000173c:	e539                	bnez	a0,8000178a <uvmcopy+0xa8>
    {
      goto err;
    }

    // Increment reference count for shared page
    inc_refcnt(pa);
    8000173e:	854a                	mv	a0,s2
    80001740:	fffff097          	auipc	ra,0xfffff
    80001744:	316080e7          	jalr	790(ra) # 80000a56 <inc_refcnt>
  for (i = 0; i < sz; i += PGSIZE)
    80001748:	6785                	lui	a5,0x1
    8000174a:	94be                	add	s1,s1,a5
    8000174c:	0534f963          	bgeu	s1,s3,8000179e <uvmcopy+0xbc>
    if ((pte = walk(old, i, 0)) == 0)
    80001750:	4601                	li	a2,0
    80001752:	85a6                	mv	a1,s1
    80001754:	8556                	mv	a0,s5
    80001756:	00000097          	auipc	ra,0x0
    8000175a:	9ba080e7          	jalr	-1606(ra) # 80001110 <walk>
    8000175e:	d555                	beqz	a0,8000170a <uvmcopy+0x28>
    if ((*pte & PTE_V) == 0)
    80001760:	611c                	ld	a5,0(a0)
    80001762:	0017f713          	andi	a4,a5,1
    80001766:	db55                	beqz	a4,8000171a <uvmcopy+0x38>
    pa = PTE2PA(*pte);
    80001768:	00a7d913          	srli	s2,a5,0xa
    8000176c:	0932                	slli	s2,s2,0xc
    flags = PTE_FLAGS(*pte);
    8000176e:	3ff7f713          	andi	a4,a5,1023
    if (flags & PTE_W)
    80001772:	0047f693          	andi	a3,a5,4
    80001776:	dad5                	beqz	a3,8000172a <uvmcopy+0x48>
      flags = (flags & ~PTE_W) | PTE_COW;
    80001778:	efb77693          	andi	a3,a4,-261
    8000177c:	1006e713          	ori	a4,a3,256
      *pte = PA2PTE(pa) | flags; // Update parent PTE
    80001780:	0167f7b3          	and	a5,a5,s6
    80001784:	8fd9                	or	a5,a5,a4
    80001786:	e11c                	sd	a5,0(a0)
    80001788:	b74d                	j	8000172a <uvmcopy+0x48>
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000178a:	4685                	li	a3,1
    8000178c:	00c4d613          	srli	a2,s1,0xc
    80001790:	4581                	li	a1,0
    80001792:	8552                	mv	a0,s4
    80001794:	00000097          	auipc	ra,0x0
    80001798:	c4e080e7          	jalr	-946(ra) # 800013e2 <uvmunmap>
  return -1;
    8000179c:	5bfd                	li	s7,-1
}
    8000179e:	855e                	mv	a0,s7
    800017a0:	60a6                	ld	ra,72(sp)
    800017a2:	6406                	ld	s0,64(sp)
    800017a4:	74e2                	ld	s1,56(sp)
    800017a6:	7942                	ld	s2,48(sp)
    800017a8:	79a2                	ld	s3,40(sp)
    800017aa:	7a02                	ld	s4,32(sp)
    800017ac:	6ae2                	ld	s5,24(sp)
    800017ae:	6b42                	ld	s6,16(sp)
    800017b0:	6ba2                	ld	s7,8(sp)
    800017b2:	6161                	addi	sp,sp,80
    800017b4:	8082                	ret
  return 0;
    800017b6:	4b81                	li	s7,0
    800017b8:	b7dd                	j	8000179e <uvmcopy+0xbc>

00000000800017ba <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void uvmclear(pagetable_t pagetable, uint64 va)
{
    800017ba:	1141                	addi	sp,sp,-16
    800017bc:	e406                	sd	ra,8(sp)
    800017be:	e022                	sd	s0,0(sp)
    800017c0:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    800017c2:	4601                	li	a2,0
    800017c4:	00000097          	auipc	ra,0x0
    800017c8:	94c080e7          	jalr	-1716(ra) # 80001110 <walk>
  if (pte == 0)
    800017cc:	c901                	beqz	a0,800017dc <uvmclear+0x22>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800017ce:	611c                	ld	a5,0(a0)
    800017d0:	9bbd                	andi	a5,a5,-17
    800017d2:	e11c                	sd	a5,0(a0)
}
    800017d4:	60a2                	ld	ra,8(sp)
    800017d6:	6402                	ld	s0,0(sp)
    800017d8:	0141                	addi	sp,sp,16
    800017da:	8082                	ret
    panic("uvmclear");
    800017dc:	00007517          	auipc	a0,0x7
    800017e0:	a3450513          	addi	a0,a0,-1484 # 80008210 <digits+0x1d0>
    800017e4:	fffff097          	auipc	ra,0xfffff
    800017e8:	d5a080e7          	jalr	-678(ra) # 8000053e <panic>

00000000800017ec <cow_alloc>:
// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
int cow_alloc(pagetable_t pagetable, uint64 va)
{
  if (va >= MAXVA)
    800017ec:	57fd                	li	a5,-1
    800017ee:	83e9                	srli	a5,a5,0x1a
    800017f0:	08b7e163          	bltu	a5,a1,80001872 <cow_alloc+0x86>
{
    800017f4:	7179                	addi	sp,sp,-48
    800017f6:	f406                	sd	ra,40(sp)
    800017f8:	f022                	sd	s0,32(sp)
    800017fa:	ec26                	sd	s1,24(sp)
    800017fc:	e84a                	sd	s2,16(sp)
    800017fe:	e44e                	sd	s3,8(sp)
    80001800:	e052                	sd	s4,0(sp)
    80001802:	1800                	addi	s0,sp,48
    return -1;

  pte_t *pte = walk(pagetable, va, 0);
    80001804:	4601                	li	a2,0
    80001806:	00000097          	auipc	ra,0x0
    8000180a:	90a080e7          	jalr	-1782(ra) # 80001110 <walk>
    8000180e:	89aa                	mv	s3,a0
  if (pte == 0)
    80001810:	c13d                	beqz	a0,80001876 <cow_alloc+0x8a>
    return -1;

  if ((*pte & PTE_V) == 0)
    80001812:	6104                	ld	s1,0(a0)
    return -1;

  if ((*pte & PTE_COW) == 0)
    80001814:	1014f713          	andi	a4,s1,257
    80001818:	10100793          	li	a5,257
    8000181c:	04f71f63          	bne	a4,a5,8000187a <cow_alloc+0x8e>
    return -1; // Not a COW page

  uint64 pa = PTE2PA(*pte);
    80001820:	00a4da13          	srli	s4,s1,0xa
    80001824:	0a32                	slli	s4,s4,0xc
  uint flags = PTE_FLAGS(*pte);
    80001826:	3ff4f913          	andi	s2,s1,1023

  // Allocate new page
  char *mem = kalloc();
    8000182a:	fffff097          	auipc	ra,0xfffff
    8000182e:	3e8080e7          	jalr	1000(ra) # 80000c12 <kalloc>
    80001832:	84aa                	mv	s1,a0
  if (mem == 0)
    80001834:	c529                	beqz	a0,8000187e <cow_alloc+0x92>
    return -1; // Out of memory

  // Copy old page to new page
  memmove(mem, (char *)pa, PGSIZE);
    80001836:	6605                	lui	a2,0x1
    80001838:	85d2                	mv	a1,s4
    8000183a:	fffff097          	auipc	ra,0xfffff
    8000183e:	64e080e7          	jalr	1614(ra) # 80000e88 <memmove>

  // Remove COW flag and add write permission
  flags = (flags & ~PTE_COW) | PTE_W;
    80001842:	efb97913          	andi	s2,s2,-261

  // Update PTE to point to new page
  *pte = PA2PTE((uint64)mem) | flags;
    80001846:	80b1                	srli	s1,s1,0xc
    80001848:	04aa                	slli	s1,s1,0xa
    8000184a:	00496913          	ori	s2,s2,4
    8000184e:	0124e4b3          	or	s1,s1,s2
    80001852:	0099b023          	sd	s1,0(s3) # fffffffffffff000 <end+0xffffffff7fdbd258>

  // Decrement reference count of old page
  kfree((void *)pa);
    80001856:	8552                	mv	a0,s4
    80001858:	fffff097          	auipc	ra,0xfffff
    8000185c:	2a6080e7          	jalr	678(ra) # 80000afe <kfree>

  return 0;
    80001860:	4501                	li	a0,0
}
    80001862:	70a2                	ld	ra,40(sp)
    80001864:	7402                	ld	s0,32(sp)
    80001866:	64e2                	ld	s1,24(sp)
    80001868:	6942                	ld	s2,16(sp)
    8000186a:	69a2                	ld	s3,8(sp)
    8000186c:	6a02                	ld	s4,0(sp)
    8000186e:	6145                	addi	sp,sp,48
    80001870:	8082                	ret
    return -1;
    80001872:	557d                	li	a0,-1
}
    80001874:	8082                	ret
    return -1;
    80001876:	557d                	li	a0,-1
    80001878:	b7ed                	j	80001862 <cow_alloc+0x76>
    return -1; // Not a COW page
    8000187a:	557d                	li	a0,-1
    8000187c:	b7dd                	j	80001862 <cow_alloc+0x76>
    return -1; // Out of memory
    8000187e:	557d                	li	a0,-1
    80001880:	b7cd                	j	80001862 <cow_alloc+0x76>

0000000080001882 <copyout>:
int copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while (len > 0)
    80001882:	c2e9                	beqz	a3,80001944 <copyout+0xc2>
{
    80001884:	711d                	addi	sp,sp,-96
    80001886:	ec86                	sd	ra,88(sp)
    80001888:	e8a2                	sd	s0,80(sp)
    8000188a:	e4a6                	sd	s1,72(sp)
    8000188c:	e0ca                	sd	s2,64(sp)
    8000188e:	fc4e                	sd	s3,56(sp)
    80001890:	f852                	sd	s4,48(sp)
    80001892:	f456                	sd	s5,40(sp)
    80001894:	f05a                	sd	s6,32(sp)
    80001896:	ec5e                	sd	s7,24(sp)
    80001898:	e862                	sd	s8,16(sp)
    8000189a:	e466                	sd	s9,8(sp)
    8000189c:	e06a                	sd	s10,0(sp)
    8000189e:	1080                	addi	s0,sp,96
    800018a0:	8aaa                	mv	s5,a0
    800018a2:	89ae                	mv	s3,a1
    800018a4:	8a32                	mv	s4,a2
    800018a6:	8936                	mv	s2,a3
  {
    va0 = PGROUNDDOWN(dstva);
    800018a8:	74fd                	lui	s1,0xfffff
    800018aa:	8ced                	and	s1,s1,a1
    if (va0 >= MAXVA)
    800018ac:	57fd                	li	a5,-1
    800018ae:	83e9                	srli	a5,a5,0x1a
    800018b0:	0897ec63          	bltu	a5,s1,80001948 <copyout+0xc6>
      return -1;

    pte = walk(pagetable, va0, 0);
    if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0)
    800018b4:	4bc5                	li	s7,17
    800018b6:	6c05                	lui	s8,0x1
    if (va0 >= MAXVA)
    800018b8:	8b3e                	mv	s6,a5
    800018ba:	a0b9                	j	80001908 <copyout+0x86>
      return -1;

    // Check if this is a COW page that needs copying
    if (*pte & PTE_COW)
    {
      if (cow_alloc(pagetable, va0) < 0)
    800018bc:	85a6                	mv	a1,s1
    800018be:	8556                	mv	a0,s5
    800018c0:	00000097          	auipc	ra,0x0
    800018c4:	f2c080e7          	jalr	-212(ra) # 800017ec <cow_alloc>
    800018c8:	0a054563          	bltz	a0,80001972 <copyout+0xf0>
        return -1;
      pte = walk(pagetable, va0, 0); // Re-walk after cow_alloc
    800018cc:	4601                	li	a2,0
    800018ce:	85a6                	mv	a1,s1
    800018d0:	8556                	mv	a0,s5
    800018d2:	00000097          	auipc	ra,0x0
    800018d6:	83e080e7          	jalr	-1986(ra) # 80001110 <walk>
    800018da:	a0b9                	j	80001928 <copyout+0xa6>
    }

    if ((*pte & PTE_W) == 0)
      return -1;

    pa0 = PTE2PA(*pte);
    800018dc:	8129                	srli	a0,a0,0xa
    800018de:	00c51793          	slli	a5,a0,0xc
    n = PGSIZE - (dstva - va0);
    if (n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800018e2:	40998533          	sub	a0,s3,s1
    800018e6:	000c861b          	sext.w	a2,s9
    800018ea:	85d2                	mv	a1,s4
    800018ec:	953e                	add	a0,a0,a5
    800018ee:	fffff097          	auipc	ra,0xfffff
    800018f2:	59a080e7          	jalr	1434(ra) # 80000e88 <memmove>

    len -= n;
    800018f6:	41990933          	sub	s2,s2,s9
    src += n;
    800018fa:	9a66                	add	s4,s4,s9
  while (len > 0)
    800018fc:	04090263          	beqz	s2,80001940 <copyout+0xbe>
    if (va0 >= MAXVA)
    80001900:	05ab6663          	bltu	s6,s10,8000194c <copyout+0xca>
    va0 = PGROUNDDOWN(dstva);
    80001904:	84ea                	mv	s1,s10
    dstva = va0 + PGSIZE;
    80001906:	89ea                	mv	s3,s10
    pte = walk(pagetable, va0, 0);
    80001908:	4601                	li	a2,0
    8000190a:	85a6                	mv	a1,s1
    8000190c:	8556                	mv	a0,s5
    8000190e:	00000097          	auipc	ra,0x0
    80001912:	802080e7          	jalr	-2046(ra) # 80001110 <walk>
    if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0)
    80001916:	cd0d                	beqz	a0,80001950 <copyout+0xce>
    80001918:	611c                	ld	a5,0(a0)
    8000191a:	0117f713          	andi	a4,a5,17
    8000191e:	05771863          	bne	a4,s7,8000196e <copyout+0xec>
    if (*pte & PTE_COW)
    80001922:	1007f793          	andi	a5,a5,256
    80001926:	fbd9                	bnez	a5,800018bc <copyout+0x3a>
    if ((*pte & PTE_W) == 0)
    80001928:	6108                	ld	a0,0(a0)
    8000192a:	00457793          	andi	a5,a0,4
    8000192e:	c7a1                	beqz	a5,80001976 <copyout+0xf4>
    n = PGSIZE - (dstva - va0);
    80001930:	01848d33          	add	s10,s1,s8
    80001934:	413d0cb3          	sub	s9,s10,s3
    if (n > len)
    80001938:	fb9972e3          	bgeu	s2,s9,800018dc <copyout+0x5a>
    8000193c:	8cca                	mv	s9,s2
    8000193e:	bf79                	j	800018dc <copyout+0x5a>
  }
  return 0;
    80001940:	4501                	li	a0,0
    80001942:	a801                	j	80001952 <copyout+0xd0>
    80001944:	4501                	li	a0,0
}
    80001946:	8082                	ret
      return -1;
    80001948:	557d                	li	a0,-1
    8000194a:	a021                	j	80001952 <copyout+0xd0>
    8000194c:	557d                	li	a0,-1
    8000194e:	a011                	j	80001952 <copyout+0xd0>
      return -1;
    80001950:	557d                	li	a0,-1
}
    80001952:	60e6                	ld	ra,88(sp)
    80001954:	6446                	ld	s0,80(sp)
    80001956:	64a6                	ld	s1,72(sp)
    80001958:	6906                	ld	s2,64(sp)
    8000195a:	79e2                	ld	s3,56(sp)
    8000195c:	7a42                	ld	s4,48(sp)
    8000195e:	7aa2                	ld	s5,40(sp)
    80001960:	7b02                	ld	s6,32(sp)
    80001962:	6be2                	ld	s7,24(sp)
    80001964:	6c42                	ld	s8,16(sp)
    80001966:	6ca2                	ld	s9,8(sp)
    80001968:	6d02                	ld	s10,0(sp)
    8000196a:	6125                	addi	sp,sp,96
    8000196c:	8082                	ret
      return -1;
    8000196e:	557d                	li	a0,-1
    80001970:	b7cd                	j	80001952 <copyout+0xd0>
        return -1;
    80001972:	557d                	li	a0,-1
    80001974:	bff9                	j	80001952 <copyout+0xd0>
      return -1;
    80001976:	557d                	li	a0,-1
    80001978:	bfe9                	j	80001952 <copyout+0xd0>

000000008000197a <copyin>:
// Return 0 on success, -1 on error.
int copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while (len > 0)
    8000197a:	caa5                	beqz	a3,800019ea <copyin+0x70>
{
    8000197c:	715d                	addi	sp,sp,-80
    8000197e:	e486                	sd	ra,72(sp)
    80001980:	e0a2                	sd	s0,64(sp)
    80001982:	fc26                	sd	s1,56(sp)
    80001984:	f84a                	sd	s2,48(sp)
    80001986:	f44e                	sd	s3,40(sp)
    80001988:	f052                	sd	s4,32(sp)
    8000198a:	ec56                	sd	s5,24(sp)
    8000198c:	e85a                	sd	s6,16(sp)
    8000198e:	e45e                	sd	s7,8(sp)
    80001990:	e062                	sd	s8,0(sp)
    80001992:	0880                	addi	s0,sp,80
    80001994:	8b2a                	mv	s6,a0
    80001996:	8a2e                	mv	s4,a1
    80001998:	8c32                	mv	s8,a2
    8000199a:	89b6                	mv	s3,a3
  {
    va0 = PGROUNDDOWN(srcva);
    8000199c:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if (pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000199e:	6a85                	lui	s5,0x1
    800019a0:	a01d                	j	800019c6 <copyin+0x4c>
    if (n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800019a2:	018505b3          	add	a1,a0,s8
    800019a6:	0004861b          	sext.w	a2,s1
    800019aa:	412585b3          	sub	a1,a1,s2
    800019ae:	8552                	mv	a0,s4
    800019b0:	fffff097          	auipc	ra,0xfffff
    800019b4:	4d8080e7          	jalr	1240(ra) # 80000e88 <memmove>

    len -= n;
    800019b8:	409989b3          	sub	s3,s3,s1
    dst += n;
    800019bc:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    800019be:	01590c33          	add	s8,s2,s5
  while (len > 0)
    800019c2:	02098263          	beqz	s3,800019e6 <copyin+0x6c>
    va0 = PGROUNDDOWN(srcva);
    800019c6:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    800019ca:	85ca                	mv	a1,s2
    800019cc:	855a                	mv	a0,s6
    800019ce:	fffff097          	auipc	ra,0xfffff
    800019d2:	7e8080e7          	jalr	2024(ra) # 800011b6 <walkaddr>
    if (pa0 == 0)
    800019d6:	cd01                	beqz	a0,800019ee <copyin+0x74>
    n = PGSIZE - (srcva - va0);
    800019d8:	418904b3          	sub	s1,s2,s8
    800019dc:	94d6                	add	s1,s1,s5
    if (n > len)
    800019de:	fc99f2e3          	bgeu	s3,s1,800019a2 <copyin+0x28>
    800019e2:	84ce                	mv	s1,s3
    800019e4:	bf7d                	j	800019a2 <copyin+0x28>
  }
  return 0;
    800019e6:	4501                	li	a0,0
    800019e8:	a021                	j	800019f0 <copyin+0x76>
    800019ea:	4501                	li	a0,0
}
    800019ec:	8082                	ret
      return -1;
    800019ee:	557d                	li	a0,-1
}
    800019f0:	60a6                	ld	ra,72(sp)
    800019f2:	6406                	ld	s0,64(sp)
    800019f4:	74e2                	ld	s1,56(sp)
    800019f6:	7942                	ld	s2,48(sp)
    800019f8:	79a2                	ld	s3,40(sp)
    800019fa:	7a02                	ld	s4,32(sp)
    800019fc:	6ae2                	ld	s5,24(sp)
    800019fe:	6b42                	ld	s6,16(sp)
    80001a00:	6ba2                	ld	s7,8(sp)
    80001a02:	6c02                	ld	s8,0(sp)
    80001a04:	6161                	addi	sp,sp,80
    80001a06:	8082                	ret

0000000080001a08 <copyinstr>:
int copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while (got_null == 0 && max > 0)
    80001a08:	c6c5                	beqz	a3,80001ab0 <copyinstr+0xa8>
{
    80001a0a:	715d                	addi	sp,sp,-80
    80001a0c:	e486                	sd	ra,72(sp)
    80001a0e:	e0a2                	sd	s0,64(sp)
    80001a10:	fc26                	sd	s1,56(sp)
    80001a12:	f84a                	sd	s2,48(sp)
    80001a14:	f44e                	sd	s3,40(sp)
    80001a16:	f052                	sd	s4,32(sp)
    80001a18:	ec56                	sd	s5,24(sp)
    80001a1a:	e85a                	sd	s6,16(sp)
    80001a1c:	e45e                	sd	s7,8(sp)
    80001a1e:	0880                	addi	s0,sp,80
    80001a20:	8a2a                	mv	s4,a0
    80001a22:	8b2e                	mv	s6,a1
    80001a24:	8bb2                	mv	s7,a2
    80001a26:	84b6                	mv	s1,a3
  {
    va0 = PGROUNDDOWN(srcva);
    80001a28:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if (pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001a2a:	6985                	lui	s3,0x1
    80001a2c:	a035                	j	80001a58 <copyinstr+0x50>
    char *p = (char *)(pa0 + (srcva - va0));
    while (n > 0)
    {
      if (*p == '\0')
      {
        *dst = '\0';
    80001a2e:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80001a32:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if (got_null)
    80001a34:	0017b793          	seqz	a5,a5
    80001a38:	40f00533          	neg	a0,a5
  }
  else
  {
    return -1;
  }
}
    80001a3c:	60a6                	ld	ra,72(sp)
    80001a3e:	6406                	ld	s0,64(sp)
    80001a40:	74e2                	ld	s1,56(sp)
    80001a42:	7942                	ld	s2,48(sp)
    80001a44:	79a2                	ld	s3,40(sp)
    80001a46:	7a02                	ld	s4,32(sp)
    80001a48:	6ae2                	ld	s5,24(sp)
    80001a4a:	6b42                	ld	s6,16(sp)
    80001a4c:	6ba2                	ld	s7,8(sp)
    80001a4e:	6161                	addi	sp,sp,80
    80001a50:	8082                	ret
    srcva = va0 + PGSIZE;
    80001a52:	01390bb3          	add	s7,s2,s3
  while (got_null == 0 && max > 0)
    80001a56:	c8a9                	beqz	s1,80001aa8 <copyinstr+0xa0>
    va0 = PGROUNDDOWN(srcva);
    80001a58:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    80001a5c:	85ca                	mv	a1,s2
    80001a5e:	8552                	mv	a0,s4
    80001a60:	fffff097          	auipc	ra,0xfffff
    80001a64:	756080e7          	jalr	1878(ra) # 800011b6 <walkaddr>
    if (pa0 == 0)
    80001a68:	c131                	beqz	a0,80001aac <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001a6a:	41790833          	sub	a6,s2,s7
    80001a6e:	984e                	add	a6,a6,s3
    if (n > max)
    80001a70:	0104f363          	bgeu	s1,a6,80001a76 <copyinstr+0x6e>
    80001a74:	8826                	mv	a6,s1
    char *p = (char *)(pa0 + (srcva - va0));
    80001a76:	955e                	add	a0,a0,s7
    80001a78:	41250533          	sub	a0,a0,s2
    while (n > 0)
    80001a7c:	fc080be3          	beqz	a6,80001a52 <copyinstr+0x4a>
    80001a80:	985a                	add	a6,a6,s6
    80001a82:	87da                	mv	a5,s6
      if (*p == '\0')
    80001a84:	41650633          	sub	a2,a0,s6
    80001a88:	14fd                	addi	s1,s1,-1
    80001a8a:	9b26                	add	s6,s6,s1
    80001a8c:	00f60733          	add	a4,a2,a5
    80001a90:	00074703          	lbu	a4,0(a4)
    80001a94:	df49                	beqz	a4,80001a2e <copyinstr+0x26>
        *dst = *p;
    80001a96:	00e78023          	sb	a4,0(a5)
      --max;
    80001a9a:	40fb04b3          	sub	s1,s6,a5
      dst++;
    80001a9e:	0785                	addi	a5,a5,1
    while (n > 0)
    80001aa0:	ff0796e3          	bne	a5,a6,80001a8c <copyinstr+0x84>
      dst++;
    80001aa4:	8b42                	mv	s6,a6
    80001aa6:	b775                	j	80001a52 <copyinstr+0x4a>
    80001aa8:	4781                	li	a5,0
    80001aaa:	b769                	j	80001a34 <copyinstr+0x2c>
      return -1;
    80001aac:	557d                	li	a0,-1
    80001aae:	b779                	j	80001a3c <copyinstr+0x34>
  int got_null = 0;
    80001ab0:	4781                	li	a5,0
  if (got_null)
    80001ab2:	0017b793          	seqz	a5,a5
    80001ab6:	40f00533          	neg	a0,a5
}
    80001aba:	8082                	ret

0000000080001abc <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001abc:	7139                	addi	sp,sp,-64
    80001abe:	fc06                	sd	ra,56(sp)
    80001ac0:	f822                	sd	s0,48(sp)
    80001ac2:	f426                	sd	s1,40(sp)
    80001ac4:	f04a                	sd	s2,32(sp)
    80001ac6:	ec4e                	sd	s3,24(sp)
    80001ac8:	e852                	sd	s4,16(sp)
    80001aca:	e456                	sd	s5,8(sp)
    80001acc:	e05a                	sd	s6,0(sp)
    80001ace:	0080                	addi	s0,sp,64
    80001ad0:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ad2:	0022f497          	auipc	s1,0x22f
    80001ad6:	4f648493          	addi	s1,s1,1270 # 80230fc8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80001ada:	8b26                	mv	s6,s1
    80001adc:	00006a97          	auipc	s5,0x6
    80001ae0:	524a8a93          	addi	s5,s5,1316 # 80008000 <etext>
    80001ae4:	04000937          	lui	s2,0x4000
    80001ae8:	197d                	addi	s2,s2,-1
    80001aea:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001aec:	00235a17          	auipc	s4,0x235
    80001af0:	edca0a13          	addi	s4,s4,-292 # 802369c8 <tickslock>
    char *pa = kalloc();
    80001af4:	fffff097          	auipc	ra,0xfffff
    80001af8:	11e080e7          	jalr	286(ra) # 80000c12 <kalloc>
    80001afc:	862a                	mv	a2,a0
    if(pa == 0)
    80001afe:	c131                	beqz	a0,80001b42 <proc_mapstacks+0x86>
    uint64 va = KSTACK((int) (p - proc));
    80001b00:	416485b3          	sub	a1,s1,s6
    80001b04:	858d                	srai	a1,a1,0x3
    80001b06:	000ab783          	ld	a5,0(s5)
    80001b0a:	02f585b3          	mul	a1,a1,a5
    80001b0e:	2585                	addiw	a1,a1,1
    80001b10:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001b14:	4719                	li	a4,6
    80001b16:	6685                	lui	a3,0x1
    80001b18:	40b905b3          	sub	a1,s2,a1
    80001b1c:	854e                	mv	a0,s3
    80001b1e:	fffff097          	auipc	ra,0xfffff
    80001b22:	79e080e7          	jalr	1950(ra) # 800012bc <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b26:	16848493          	addi	s1,s1,360
    80001b2a:	fd4495e3          	bne	s1,s4,80001af4 <proc_mapstacks+0x38>
  }
}
    80001b2e:	70e2                	ld	ra,56(sp)
    80001b30:	7442                	ld	s0,48(sp)
    80001b32:	74a2                	ld	s1,40(sp)
    80001b34:	7902                	ld	s2,32(sp)
    80001b36:	69e2                	ld	s3,24(sp)
    80001b38:	6a42                	ld	s4,16(sp)
    80001b3a:	6aa2                	ld	s5,8(sp)
    80001b3c:	6b02                	ld	s6,0(sp)
    80001b3e:	6121                	addi	sp,sp,64
    80001b40:	8082                	ret
      panic("kalloc");
    80001b42:	00006517          	auipc	a0,0x6
    80001b46:	6de50513          	addi	a0,a0,1758 # 80008220 <digits+0x1e0>
    80001b4a:	fffff097          	auipc	ra,0xfffff
    80001b4e:	9f4080e7          	jalr	-1548(ra) # 8000053e <panic>

0000000080001b52 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001b52:	7139                	addi	sp,sp,-64
    80001b54:	fc06                	sd	ra,56(sp)
    80001b56:	f822                	sd	s0,48(sp)
    80001b58:	f426                	sd	s1,40(sp)
    80001b5a:	f04a                	sd	s2,32(sp)
    80001b5c:	ec4e                	sd	s3,24(sp)
    80001b5e:	e852                	sd	s4,16(sp)
    80001b60:	e456                	sd	s5,8(sp)
    80001b62:	e05a                	sd	s6,0(sp)
    80001b64:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001b66:	00006597          	auipc	a1,0x6
    80001b6a:	6c258593          	addi	a1,a1,1730 # 80008228 <digits+0x1e8>
    80001b6e:	0022f517          	auipc	a0,0x22f
    80001b72:	02a50513          	addi	a0,a0,42 # 80230b98 <pid_lock>
    80001b76:	fffff097          	auipc	ra,0xfffff
    80001b7a:	12a080e7          	jalr	298(ra) # 80000ca0 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001b7e:	00006597          	auipc	a1,0x6
    80001b82:	6b258593          	addi	a1,a1,1714 # 80008230 <digits+0x1f0>
    80001b86:	0022f517          	auipc	a0,0x22f
    80001b8a:	02a50513          	addi	a0,a0,42 # 80230bb0 <wait_lock>
    80001b8e:	fffff097          	auipc	ra,0xfffff
    80001b92:	112080e7          	jalr	274(ra) # 80000ca0 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b96:	0022f497          	auipc	s1,0x22f
    80001b9a:	43248493          	addi	s1,s1,1074 # 80230fc8 <proc>
      initlock(&p->lock, "proc");
    80001b9e:	00006b17          	auipc	s6,0x6
    80001ba2:	6a2b0b13          	addi	s6,s6,1698 # 80008240 <digits+0x200>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001ba6:	8aa6                	mv	s5,s1
    80001ba8:	00006a17          	auipc	s4,0x6
    80001bac:	458a0a13          	addi	s4,s4,1112 # 80008000 <etext>
    80001bb0:	04000937          	lui	s2,0x4000
    80001bb4:	197d                	addi	s2,s2,-1
    80001bb6:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001bb8:	00235997          	auipc	s3,0x235
    80001bbc:	e1098993          	addi	s3,s3,-496 # 802369c8 <tickslock>
      initlock(&p->lock, "proc");
    80001bc0:	85da                	mv	a1,s6
    80001bc2:	8526                	mv	a0,s1
    80001bc4:	fffff097          	auipc	ra,0xfffff
    80001bc8:	0dc080e7          	jalr	220(ra) # 80000ca0 <initlock>
      p->state = UNUSED;
    80001bcc:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001bd0:	415487b3          	sub	a5,s1,s5
    80001bd4:	878d                	srai	a5,a5,0x3
    80001bd6:	000a3703          	ld	a4,0(s4)
    80001bda:	02e787b3          	mul	a5,a5,a4
    80001bde:	2785                	addiw	a5,a5,1
    80001be0:	00d7979b          	slliw	a5,a5,0xd
    80001be4:	40f907b3          	sub	a5,s2,a5
    80001be8:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001bea:	16848493          	addi	s1,s1,360
    80001bee:	fd3499e3          	bne	s1,s3,80001bc0 <procinit+0x6e>
  }
}
    80001bf2:	70e2                	ld	ra,56(sp)
    80001bf4:	7442                	ld	s0,48(sp)
    80001bf6:	74a2                	ld	s1,40(sp)
    80001bf8:	7902                	ld	s2,32(sp)
    80001bfa:	69e2                	ld	s3,24(sp)
    80001bfc:	6a42                	ld	s4,16(sp)
    80001bfe:	6aa2                	ld	s5,8(sp)
    80001c00:	6b02                	ld	s6,0(sp)
    80001c02:	6121                	addi	sp,sp,64
    80001c04:	8082                	ret

0000000080001c06 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001c06:	1141                	addi	sp,sp,-16
    80001c08:	e422                	sd	s0,8(sp)
    80001c0a:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    80001c0c:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001c0e:	2501                	sext.w	a0,a0
    80001c10:	6422                	ld	s0,8(sp)
    80001c12:	0141                	addi	sp,sp,16
    80001c14:	8082                	ret

0000000080001c16 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001c16:	1141                	addi	sp,sp,-16
    80001c18:	e422                	sd	s0,8(sp)
    80001c1a:	0800                	addi	s0,sp,16
    80001c1c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001c1e:	2781                	sext.w	a5,a5
    80001c20:	079e                	slli	a5,a5,0x7
  return c;
}
    80001c22:	0022f517          	auipc	a0,0x22f
    80001c26:	fa650513          	addi	a0,a0,-90 # 80230bc8 <cpus>
    80001c2a:	953e                	add	a0,a0,a5
    80001c2c:	6422                	ld	s0,8(sp)
    80001c2e:	0141                	addi	sp,sp,16
    80001c30:	8082                	ret

0000000080001c32 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001c32:	1101                	addi	sp,sp,-32
    80001c34:	ec06                	sd	ra,24(sp)
    80001c36:	e822                	sd	s0,16(sp)
    80001c38:	e426                	sd	s1,8(sp)
    80001c3a:	1000                	addi	s0,sp,32
  push_off();
    80001c3c:	fffff097          	auipc	ra,0xfffff
    80001c40:	0a8080e7          	jalr	168(ra) # 80000ce4 <push_off>
    80001c44:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001c46:	2781                	sext.w	a5,a5
    80001c48:	079e                	slli	a5,a5,0x7
    80001c4a:	0022f717          	auipc	a4,0x22f
    80001c4e:	f4e70713          	addi	a4,a4,-178 # 80230b98 <pid_lock>
    80001c52:	97ba                	add	a5,a5,a4
    80001c54:	7b84                	ld	s1,48(a5)
  pop_off();
    80001c56:	fffff097          	auipc	ra,0xfffff
    80001c5a:	12e080e7          	jalr	302(ra) # 80000d84 <pop_off>
  return p;
}
    80001c5e:	8526                	mv	a0,s1
    80001c60:	60e2                	ld	ra,24(sp)
    80001c62:	6442                	ld	s0,16(sp)
    80001c64:	64a2                	ld	s1,8(sp)
    80001c66:	6105                	addi	sp,sp,32
    80001c68:	8082                	ret

0000000080001c6a <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001c6a:	1141                	addi	sp,sp,-16
    80001c6c:	e406                	sd	ra,8(sp)
    80001c6e:	e022                	sd	s0,0(sp)
    80001c70:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80001c72:	00000097          	auipc	ra,0x0
    80001c76:	fc0080e7          	jalr	-64(ra) # 80001c32 <myproc>
    80001c7a:	fffff097          	auipc	ra,0xfffff
    80001c7e:	16a080e7          	jalr	362(ra) # 80000de4 <release>

  if (first) {
    80001c82:	00007797          	auipc	a5,0x7
    80001c86:	c0e7a783          	lw	a5,-1010(a5) # 80008890 <first.1>
    80001c8a:	eb89                	bnez	a5,80001c9c <forkret+0x32>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80001c8c:	00001097          	auipc	ra,0x1
    80001c90:	c60080e7          	jalr	-928(ra) # 800028ec <usertrapret>
}
    80001c94:	60a2                	ld	ra,8(sp)
    80001c96:	6402                	ld	s0,0(sp)
    80001c98:	0141                	addi	sp,sp,16
    80001c9a:	8082                	ret
    fsinit(ROOTDEV);
    80001c9c:	4505                	li	a0,1
    80001c9e:	00002097          	auipc	ra,0x2
    80001ca2:	a18080e7          	jalr	-1512(ra) # 800036b6 <fsinit>
    first = 0;
    80001ca6:	00007797          	auipc	a5,0x7
    80001caa:	be07a523          	sw	zero,-1046(a5) # 80008890 <first.1>
    __sync_synchronize();
    80001cae:	0ff0000f          	fence
    80001cb2:	bfe9                	j	80001c8c <forkret+0x22>

0000000080001cb4 <allocpid>:
{
    80001cb4:	1101                	addi	sp,sp,-32
    80001cb6:	ec06                	sd	ra,24(sp)
    80001cb8:	e822                	sd	s0,16(sp)
    80001cba:	e426                	sd	s1,8(sp)
    80001cbc:	e04a                	sd	s2,0(sp)
    80001cbe:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001cc0:	0022f917          	auipc	s2,0x22f
    80001cc4:	ed890913          	addi	s2,s2,-296 # 80230b98 <pid_lock>
    80001cc8:	854a                	mv	a0,s2
    80001cca:	fffff097          	auipc	ra,0xfffff
    80001cce:	066080e7          	jalr	102(ra) # 80000d30 <acquire>
  pid = nextpid;
    80001cd2:	00007797          	auipc	a5,0x7
    80001cd6:	bc278793          	addi	a5,a5,-1086 # 80008894 <nextpid>
    80001cda:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001cdc:	0014871b          	addiw	a4,s1,1
    80001ce0:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001ce2:	854a                	mv	a0,s2
    80001ce4:	fffff097          	auipc	ra,0xfffff
    80001ce8:	100080e7          	jalr	256(ra) # 80000de4 <release>
}
    80001cec:	8526                	mv	a0,s1
    80001cee:	60e2                	ld	ra,24(sp)
    80001cf0:	6442                	ld	s0,16(sp)
    80001cf2:	64a2                	ld	s1,8(sp)
    80001cf4:	6902                	ld	s2,0(sp)
    80001cf6:	6105                	addi	sp,sp,32
    80001cf8:	8082                	ret

0000000080001cfa <proc_pagetable>:
{
    80001cfa:	1101                	addi	sp,sp,-32
    80001cfc:	ec06                	sd	ra,24(sp)
    80001cfe:	e822                	sd	s0,16(sp)
    80001d00:	e426                	sd	s1,8(sp)
    80001d02:	e04a                	sd	s2,0(sp)
    80001d04:	1000                	addi	s0,sp,32
    80001d06:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001d08:	fffff097          	auipc	ra,0xfffff
    80001d0c:	79e080e7          	jalr	1950(ra) # 800014a6 <uvmcreate>
    80001d10:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001d12:	c121                	beqz	a0,80001d52 <proc_pagetable+0x58>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001d14:	4729                	li	a4,10
    80001d16:	00005697          	auipc	a3,0x5
    80001d1a:	2ea68693          	addi	a3,a3,746 # 80007000 <_trampoline>
    80001d1e:	6605                	lui	a2,0x1
    80001d20:	040005b7          	lui	a1,0x4000
    80001d24:	15fd                	addi	a1,a1,-1
    80001d26:	05b2                	slli	a1,a1,0xc
    80001d28:	fffff097          	auipc	ra,0xfffff
    80001d2c:	4d0080e7          	jalr	1232(ra) # 800011f8 <mappages>
    80001d30:	02054863          	bltz	a0,80001d60 <proc_pagetable+0x66>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001d34:	4719                	li	a4,6
    80001d36:	05893683          	ld	a3,88(s2)
    80001d3a:	6605                	lui	a2,0x1
    80001d3c:	020005b7          	lui	a1,0x2000
    80001d40:	15fd                	addi	a1,a1,-1
    80001d42:	05b6                	slli	a1,a1,0xd
    80001d44:	8526                	mv	a0,s1
    80001d46:	fffff097          	auipc	ra,0xfffff
    80001d4a:	4b2080e7          	jalr	1202(ra) # 800011f8 <mappages>
    80001d4e:	02054163          	bltz	a0,80001d70 <proc_pagetable+0x76>
}
    80001d52:	8526                	mv	a0,s1
    80001d54:	60e2                	ld	ra,24(sp)
    80001d56:	6442                	ld	s0,16(sp)
    80001d58:	64a2                	ld	s1,8(sp)
    80001d5a:	6902                	ld	s2,0(sp)
    80001d5c:	6105                	addi	sp,sp,32
    80001d5e:	8082                	ret
    uvmfree(pagetable, 0);
    80001d60:	4581                	li	a1,0
    80001d62:	8526                	mv	a0,s1
    80001d64:	00000097          	auipc	ra,0x0
    80001d68:	946080e7          	jalr	-1722(ra) # 800016aa <uvmfree>
    return 0;
    80001d6c:	4481                	li	s1,0
    80001d6e:	b7d5                	j	80001d52 <proc_pagetable+0x58>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001d70:	4681                	li	a3,0
    80001d72:	4605                	li	a2,1
    80001d74:	040005b7          	lui	a1,0x4000
    80001d78:	15fd                	addi	a1,a1,-1
    80001d7a:	05b2                	slli	a1,a1,0xc
    80001d7c:	8526                	mv	a0,s1
    80001d7e:	fffff097          	auipc	ra,0xfffff
    80001d82:	664080e7          	jalr	1636(ra) # 800013e2 <uvmunmap>
    uvmfree(pagetable, 0);
    80001d86:	4581                	li	a1,0
    80001d88:	8526                	mv	a0,s1
    80001d8a:	00000097          	auipc	ra,0x0
    80001d8e:	920080e7          	jalr	-1760(ra) # 800016aa <uvmfree>
    return 0;
    80001d92:	4481                	li	s1,0
    80001d94:	bf7d                	j	80001d52 <proc_pagetable+0x58>

0000000080001d96 <proc_freepagetable>:
{
    80001d96:	1101                	addi	sp,sp,-32
    80001d98:	ec06                	sd	ra,24(sp)
    80001d9a:	e822                	sd	s0,16(sp)
    80001d9c:	e426                	sd	s1,8(sp)
    80001d9e:	e04a                	sd	s2,0(sp)
    80001da0:	1000                	addi	s0,sp,32
    80001da2:	84aa                	mv	s1,a0
    80001da4:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001da6:	4681                	li	a3,0
    80001da8:	4605                	li	a2,1
    80001daa:	040005b7          	lui	a1,0x4000
    80001dae:	15fd                	addi	a1,a1,-1
    80001db0:	05b2                	slli	a1,a1,0xc
    80001db2:	fffff097          	auipc	ra,0xfffff
    80001db6:	630080e7          	jalr	1584(ra) # 800013e2 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001dba:	4681                	li	a3,0
    80001dbc:	4605                	li	a2,1
    80001dbe:	020005b7          	lui	a1,0x2000
    80001dc2:	15fd                	addi	a1,a1,-1
    80001dc4:	05b6                	slli	a1,a1,0xd
    80001dc6:	8526                	mv	a0,s1
    80001dc8:	fffff097          	auipc	ra,0xfffff
    80001dcc:	61a080e7          	jalr	1562(ra) # 800013e2 <uvmunmap>
  uvmfree(pagetable, sz);
    80001dd0:	85ca                	mv	a1,s2
    80001dd2:	8526                	mv	a0,s1
    80001dd4:	00000097          	auipc	ra,0x0
    80001dd8:	8d6080e7          	jalr	-1834(ra) # 800016aa <uvmfree>
}
    80001ddc:	60e2                	ld	ra,24(sp)
    80001dde:	6442                	ld	s0,16(sp)
    80001de0:	64a2                	ld	s1,8(sp)
    80001de2:	6902                	ld	s2,0(sp)
    80001de4:	6105                	addi	sp,sp,32
    80001de6:	8082                	ret

0000000080001de8 <freeproc>:
{
    80001de8:	1101                	addi	sp,sp,-32
    80001dea:	ec06                	sd	ra,24(sp)
    80001dec:	e822                	sd	s0,16(sp)
    80001dee:	e426                	sd	s1,8(sp)
    80001df0:	1000                	addi	s0,sp,32
    80001df2:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001df4:	6d28                	ld	a0,88(a0)
    80001df6:	c509                	beqz	a0,80001e00 <freeproc+0x18>
    kfree((void*)p->trapframe);
    80001df8:	fffff097          	auipc	ra,0xfffff
    80001dfc:	d06080e7          	jalr	-762(ra) # 80000afe <kfree>
  p->trapframe = 0;
    80001e00:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001e04:	68a8                	ld	a0,80(s1)
    80001e06:	c511                	beqz	a0,80001e12 <freeproc+0x2a>
    proc_freepagetable(p->pagetable, p->sz);
    80001e08:	64ac                	ld	a1,72(s1)
    80001e0a:	00000097          	auipc	ra,0x0
    80001e0e:	f8c080e7          	jalr	-116(ra) # 80001d96 <proc_freepagetable>
  p->pagetable = 0;
    80001e12:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001e16:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001e1a:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001e1e:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001e22:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001e26:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001e2a:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001e2e:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001e32:	0004ac23          	sw	zero,24(s1)
}
    80001e36:	60e2                	ld	ra,24(sp)
    80001e38:	6442                	ld	s0,16(sp)
    80001e3a:	64a2                	ld	s1,8(sp)
    80001e3c:	6105                	addi	sp,sp,32
    80001e3e:	8082                	ret

0000000080001e40 <allocproc>:
{
    80001e40:	1101                	addi	sp,sp,-32
    80001e42:	ec06                	sd	ra,24(sp)
    80001e44:	e822                	sd	s0,16(sp)
    80001e46:	e426                	sd	s1,8(sp)
    80001e48:	e04a                	sd	s2,0(sp)
    80001e4a:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001e4c:	0022f497          	auipc	s1,0x22f
    80001e50:	17c48493          	addi	s1,s1,380 # 80230fc8 <proc>
    80001e54:	00235917          	auipc	s2,0x235
    80001e58:	b7490913          	addi	s2,s2,-1164 # 802369c8 <tickslock>
    acquire(&p->lock);
    80001e5c:	8526                	mv	a0,s1
    80001e5e:	fffff097          	auipc	ra,0xfffff
    80001e62:	ed2080e7          	jalr	-302(ra) # 80000d30 <acquire>
    if(p->state == UNUSED) {
    80001e66:	4c9c                	lw	a5,24(s1)
    80001e68:	cf81                	beqz	a5,80001e80 <allocproc+0x40>
      release(&p->lock);
    80001e6a:	8526                	mv	a0,s1
    80001e6c:	fffff097          	auipc	ra,0xfffff
    80001e70:	f78080e7          	jalr	-136(ra) # 80000de4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001e74:	16848493          	addi	s1,s1,360
    80001e78:	ff2492e3          	bne	s1,s2,80001e5c <allocproc+0x1c>
  return 0;
    80001e7c:	4481                	li	s1,0
    80001e7e:	a889                	j	80001ed0 <allocproc+0x90>
  p->pid = allocpid();
    80001e80:	00000097          	auipc	ra,0x0
    80001e84:	e34080e7          	jalr	-460(ra) # 80001cb4 <allocpid>
    80001e88:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001e8a:	4785                	li	a5,1
    80001e8c:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001e8e:	fffff097          	auipc	ra,0xfffff
    80001e92:	d84080e7          	jalr	-636(ra) # 80000c12 <kalloc>
    80001e96:	892a                	mv	s2,a0
    80001e98:	eca8                	sd	a0,88(s1)
    80001e9a:	c131                	beqz	a0,80001ede <allocproc+0x9e>
  p->pagetable = proc_pagetable(p);
    80001e9c:	8526                	mv	a0,s1
    80001e9e:	00000097          	auipc	ra,0x0
    80001ea2:	e5c080e7          	jalr	-420(ra) # 80001cfa <proc_pagetable>
    80001ea6:	892a                	mv	s2,a0
    80001ea8:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001eaa:	c531                	beqz	a0,80001ef6 <allocproc+0xb6>
  memset(&p->context, 0, sizeof(p->context));
    80001eac:	07000613          	li	a2,112
    80001eb0:	4581                	li	a1,0
    80001eb2:	06048513          	addi	a0,s1,96
    80001eb6:	fffff097          	auipc	ra,0xfffff
    80001eba:	f76080e7          	jalr	-138(ra) # 80000e2c <memset>
  p->context.ra = (uint64)forkret;
    80001ebe:	00000797          	auipc	a5,0x0
    80001ec2:	dac78793          	addi	a5,a5,-596 # 80001c6a <forkret>
    80001ec6:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001ec8:	60bc                	ld	a5,64(s1)
    80001eca:	6705                	lui	a4,0x1
    80001ecc:	97ba                	add	a5,a5,a4
    80001ece:	f4bc                	sd	a5,104(s1)
}
    80001ed0:	8526                	mv	a0,s1
    80001ed2:	60e2                	ld	ra,24(sp)
    80001ed4:	6442                	ld	s0,16(sp)
    80001ed6:	64a2                	ld	s1,8(sp)
    80001ed8:	6902                	ld	s2,0(sp)
    80001eda:	6105                	addi	sp,sp,32
    80001edc:	8082                	ret
    freeproc(p);
    80001ede:	8526                	mv	a0,s1
    80001ee0:	00000097          	auipc	ra,0x0
    80001ee4:	f08080e7          	jalr	-248(ra) # 80001de8 <freeproc>
    release(&p->lock);
    80001ee8:	8526                	mv	a0,s1
    80001eea:	fffff097          	auipc	ra,0xfffff
    80001eee:	efa080e7          	jalr	-262(ra) # 80000de4 <release>
    return 0;
    80001ef2:	84ca                	mv	s1,s2
    80001ef4:	bff1                	j	80001ed0 <allocproc+0x90>
    freeproc(p);
    80001ef6:	8526                	mv	a0,s1
    80001ef8:	00000097          	auipc	ra,0x0
    80001efc:	ef0080e7          	jalr	-272(ra) # 80001de8 <freeproc>
    release(&p->lock);
    80001f00:	8526                	mv	a0,s1
    80001f02:	fffff097          	auipc	ra,0xfffff
    80001f06:	ee2080e7          	jalr	-286(ra) # 80000de4 <release>
    return 0;
    80001f0a:	84ca                	mv	s1,s2
    80001f0c:	b7d1                	j	80001ed0 <allocproc+0x90>

0000000080001f0e <userinit>:
{
    80001f0e:	1101                	addi	sp,sp,-32
    80001f10:	ec06                	sd	ra,24(sp)
    80001f12:	e822                	sd	s0,16(sp)
    80001f14:	e426                	sd	s1,8(sp)
    80001f16:	1000                	addi	s0,sp,32
  p = allocproc();
    80001f18:	00000097          	auipc	ra,0x0
    80001f1c:	f28080e7          	jalr	-216(ra) # 80001e40 <allocproc>
    80001f20:	84aa                	mv	s1,a0
  initproc = p;
    80001f22:	00007797          	auipc	a5,0x7
    80001f26:	9ea7b323          	sd	a0,-1562(a5) # 80008908 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001f2a:	03400613          	li	a2,52
    80001f2e:	00007597          	auipc	a1,0x7
    80001f32:	97258593          	addi	a1,a1,-1678 # 800088a0 <initcode>
    80001f36:	6928                	ld	a0,80(a0)
    80001f38:	fffff097          	auipc	ra,0xfffff
    80001f3c:	59c080e7          	jalr	1436(ra) # 800014d4 <uvmfirst>
  p->sz = PGSIZE;
    80001f40:	6785                	lui	a5,0x1
    80001f42:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001f44:	6cb8                	ld	a4,88(s1)
    80001f46:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001f4a:	6cb8                	ld	a4,88(s1)
    80001f4c:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001f4e:	4641                	li	a2,16
    80001f50:	00006597          	auipc	a1,0x6
    80001f54:	2f858593          	addi	a1,a1,760 # 80008248 <digits+0x208>
    80001f58:	15848513          	addi	a0,s1,344
    80001f5c:	fffff097          	auipc	ra,0xfffff
    80001f60:	01a080e7          	jalr	26(ra) # 80000f76 <safestrcpy>
  p->cwd = namei("/");
    80001f64:	00006517          	auipc	a0,0x6
    80001f68:	2f450513          	addi	a0,a0,756 # 80008258 <digits+0x218>
    80001f6c:	00002097          	auipc	ra,0x2
    80001f70:	16c080e7          	jalr	364(ra) # 800040d8 <namei>
    80001f74:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001f78:	478d                	li	a5,3
    80001f7a:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001f7c:	8526                	mv	a0,s1
    80001f7e:	fffff097          	auipc	ra,0xfffff
    80001f82:	e66080e7          	jalr	-410(ra) # 80000de4 <release>
}
    80001f86:	60e2                	ld	ra,24(sp)
    80001f88:	6442                	ld	s0,16(sp)
    80001f8a:	64a2                	ld	s1,8(sp)
    80001f8c:	6105                	addi	sp,sp,32
    80001f8e:	8082                	ret

0000000080001f90 <growproc>:
{
    80001f90:	1101                	addi	sp,sp,-32
    80001f92:	ec06                	sd	ra,24(sp)
    80001f94:	e822                	sd	s0,16(sp)
    80001f96:	e426                	sd	s1,8(sp)
    80001f98:	e04a                	sd	s2,0(sp)
    80001f9a:	1000                	addi	s0,sp,32
    80001f9c:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001f9e:	00000097          	auipc	ra,0x0
    80001fa2:	c94080e7          	jalr	-876(ra) # 80001c32 <myproc>
    80001fa6:	84aa                	mv	s1,a0
  sz = p->sz;
    80001fa8:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001faa:	01204c63          	bgtz	s2,80001fc2 <growproc+0x32>
  } else if(n < 0){
    80001fae:	02094663          	bltz	s2,80001fda <growproc+0x4a>
  p->sz = sz;
    80001fb2:	e4ac                	sd	a1,72(s1)
  return 0;
    80001fb4:	4501                	li	a0,0
}
    80001fb6:	60e2                	ld	ra,24(sp)
    80001fb8:	6442                	ld	s0,16(sp)
    80001fba:	64a2                	ld	s1,8(sp)
    80001fbc:	6902                	ld	s2,0(sp)
    80001fbe:	6105                	addi	sp,sp,32
    80001fc0:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001fc2:	4691                	li	a3,4
    80001fc4:	00b90633          	add	a2,s2,a1
    80001fc8:	6928                	ld	a0,80(a0)
    80001fca:	fffff097          	auipc	ra,0xfffff
    80001fce:	5c4080e7          	jalr	1476(ra) # 8000158e <uvmalloc>
    80001fd2:	85aa                	mv	a1,a0
    80001fd4:	fd79                	bnez	a0,80001fb2 <growproc+0x22>
      return -1;
    80001fd6:	557d                	li	a0,-1
    80001fd8:	bff9                	j	80001fb6 <growproc+0x26>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001fda:	00b90633          	add	a2,s2,a1
    80001fde:	6928                	ld	a0,80(a0)
    80001fe0:	fffff097          	auipc	ra,0xfffff
    80001fe4:	566080e7          	jalr	1382(ra) # 80001546 <uvmdealloc>
    80001fe8:	85aa                	mv	a1,a0
    80001fea:	b7e1                	j	80001fb2 <growproc+0x22>

0000000080001fec <fork>:
{
    80001fec:	7139                	addi	sp,sp,-64
    80001fee:	fc06                	sd	ra,56(sp)
    80001ff0:	f822                	sd	s0,48(sp)
    80001ff2:	f426                	sd	s1,40(sp)
    80001ff4:	f04a                	sd	s2,32(sp)
    80001ff6:	ec4e                	sd	s3,24(sp)
    80001ff8:	e852                	sd	s4,16(sp)
    80001ffa:	e456                	sd	s5,8(sp)
    80001ffc:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001ffe:	00000097          	auipc	ra,0x0
    80002002:	c34080e7          	jalr	-972(ra) # 80001c32 <myproc>
    80002006:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80002008:	00000097          	auipc	ra,0x0
    8000200c:	e38080e7          	jalr	-456(ra) # 80001e40 <allocproc>
    80002010:	10050c63          	beqz	a0,80002128 <fork+0x13c>
    80002014:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80002016:	048ab603          	ld	a2,72(s5)
    8000201a:	692c                	ld	a1,80(a0)
    8000201c:	050ab503          	ld	a0,80(s5)
    80002020:	fffff097          	auipc	ra,0xfffff
    80002024:	6c2080e7          	jalr	1730(ra) # 800016e2 <uvmcopy>
    80002028:	04054863          	bltz	a0,80002078 <fork+0x8c>
  np->sz = p->sz;
    8000202c:	048ab783          	ld	a5,72(s5)
    80002030:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80002034:	058ab683          	ld	a3,88(s5)
    80002038:	87b6                	mv	a5,a3
    8000203a:	058a3703          	ld	a4,88(s4)
    8000203e:	12068693          	addi	a3,a3,288
    80002042:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80002046:	6788                	ld	a0,8(a5)
    80002048:	6b8c                	ld	a1,16(a5)
    8000204a:	6f90                	ld	a2,24(a5)
    8000204c:	01073023          	sd	a6,0(a4)
    80002050:	e708                	sd	a0,8(a4)
    80002052:	eb0c                	sd	a1,16(a4)
    80002054:	ef10                	sd	a2,24(a4)
    80002056:	02078793          	addi	a5,a5,32
    8000205a:	02070713          	addi	a4,a4,32
    8000205e:	fed792e3          	bne	a5,a3,80002042 <fork+0x56>
  np->trapframe->a0 = 0;
    80002062:	058a3783          	ld	a5,88(s4)
    80002066:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    8000206a:	0d0a8493          	addi	s1,s5,208
    8000206e:	0d0a0913          	addi	s2,s4,208
    80002072:	150a8993          	addi	s3,s5,336
    80002076:	a00d                	j	80002098 <fork+0xac>
    freeproc(np);
    80002078:	8552                	mv	a0,s4
    8000207a:	00000097          	auipc	ra,0x0
    8000207e:	d6e080e7          	jalr	-658(ra) # 80001de8 <freeproc>
    release(&np->lock);
    80002082:	8552                	mv	a0,s4
    80002084:	fffff097          	auipc	ra,0xfffff
    80002088:	d60080e7          	jalr	-672(ra) # 80000de4 <release>
    return -1;
    8000208c:	597d                	li	s2,-1
    8000208e:	a059                	j	80002114 <fork+0x128>
  for(i = 0; i < NOFILE; i++)
    80002090:	04a1                	addi	s1,s1,8
    80002092:	0921                	addi	s2,s2,8
    80002094:	01348b63          	beq	s1,s3,800020aa <fork+0xbe>
    if(p->ofile[i])
    80002098:	6088                	ld	a0,0(s1)
    8000209a:	d97d                	beqz	a0,80002090 <fork+0xa4>
      np->ofile[i] = filedup(p->ofile[i]);
    8000209c:	00002097          	auipc	ra,0x2
    800020a0:	6d6080e7          	jalr	1750(ra) # 80004772 <filedup>
    800020a4:	00a93023          	sd	a0,0(s2)
    800020a8:	b7e5                	j	80002090 <fork+0xa4>
  np->cwd = idup(p->cwd);
    800020aa:	150ab503          	ld	a0,336(s5)
    800020ae:	00002097          	auipc	ra,0x2
    800020b2:	846080e7          	jalr	-1978(ra) # 800038f4 <idup>
    800020b6:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    800020ba:	4641                	li	a2,16
    800020bc:	158a8593          	addi	a1,s5,344
    800020c0:	158a0513          	addi	a0,s4,344
    800020c4:	fffff097          	auipc	ra,0xfffff
    800020c8:	eb2080e7          	jalr	-334(ra) # 80000f76 <safestrcpy>
  pid = np->pid;
    800020cc:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    800020d0:	8552                	mv	a0,s4
    800020d2:	fffff097          	auipc	ra,0xfffff
    800020d6:	d12080e7          	jalr	-750(ra) # 80000de4 <release>
  acquire(&wait_lock);
    800020da:	0022f497          	auipc	s1,0x22f
    800020de:	ad648493          	addi	s1,s1,-1322 # 80230bb0 <wait_lock>
    800020e2:	8526                	mv	a0,s1
    800020e4:	fffff097          	auipc	ra,0xfffff
    800020e8:	c4c080e7          	jalr	-948(ra) # 80000d30 <acquire>
  np->parent = p;
    800020ec:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    800020f0:	8526                	mv	a0,s1
    800020f2:	fffff097          	auipc	ra,0xfffff
    800020f6:	cf2080e7          	jalr	-782(ra) # 80000de4 <release>
  acquire(&np->lock);
    800020fa:	8552                	mv	a0,s4
    800020fc:	fffff097          	auipc	ra,0xfffff
    80002100:	c34080e7          	jalr	-972(ra) # 80000d30 <acquire>
  np->state = RUNNABLE;
    80002104:	478d                	li	a5,3
    80002106:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    8000210a:	8552                	mv	a0,s4
    8000210c:	fffff097          	auipc	ra,0xfffff
    80002110:	cd8080e7          	jalr	-808(ra) # 80000de4 <release>
}
    80002114:	854a                	mv	a0,s2
    80002116:	70e2                	ld	ra,56(sp)
    80002118:	7442                	ld	s0,48(sp)
    8000211a:	74a2                	ld	s1,40(sp)
    8000211c:	7902                	ld	s2,32(sp)
    8000211e:	69e2                	ld	s3,24(sp)
    80002120:	6a42                	ld	s4,16(sp)
    80002122:	6aa2                	ld	s5,8(sp)
    80002124:	6121                	addi	sp,sp,64
    80002126:	8082                	ret
    return -1;
    80002128:	597d                	li	s2,-1
    8000212a:	b7ed                	j	80002114 <fork+0x128>

000000008000212c <scheduler>:
{
    8000212c:	7139                	addi	sp,sp,-64
    8000212e:	fc06                	sd	ra,56(sp)
    80002130:	f822                	sd	s0,48(sp)
    80002132:	f426                	sd	s1,40(sp)
    80002134:	f04a                	sd	s2,32(sp)
    80002136:	ec4e                	sd	s3,24(sp)
    80002138:	e852                	sd	s4,16(sp)
    8000213a:	e456                	sd	s5,8(sp)
    8000213c:	e05a                	sd	s6,0(sp)
    8000213e:	0080                	addi	s0,sp,64
    80002140:	8792                	mv	a5,tp
  int id = r_tp();
    80002142:	2781                	sext.w	a5,a5
  c->proc = 0;
    80002144:	00779a93          	slli	s5,a5,0x7
    80002148:	0022f717          	auipc	a4,0x22f
    8000214c:	a5070713          	addi	a4,a4,-1456 # 80230b98 <pid_lock>
    80002150:	9756                	add	a4,a4,s5
    80002152:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80002156:	0022f717          	auipc	a4,0x22f
    8000215a:	a7a70713          	addi	a4,a4,-1414 # 80230bd0 <cpus+0x8>
    8000215e:	9aba                	add	s5,s5,a4
      if(p->state == RUNNABLE) {
    80002160:	498d                	li	s3,3
        p->state = RUNNING;
    80002162:	4b11                	li	s6,4
        c->proc = p;
    80002164:	079e                	slli	a5,a5,0x7
    80002166:	0022fa17          	auipc	s4,0x22f
    8000216a:	a32a0a13          	addi	s4,s4,-1486 # 80230b98 <pid_lock>
    8000216e:	9a3e                	add	s4,s4,a5
    for(p = proc; p < &proc[NPROC]; p++) {
    80002170:	00235917          	auipc	s2,0x235
    80002174:	85890913          	addi	s2,s2,-1960 # 802369c8 <tickslock>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002178:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000217c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002180:	10079073          	csrw	sstatus,a5
    80002184:	0022f497          	auipc	s1,0x22f
    80002188:	e4448493          	addi	s1,s1,-444 # 80230fc8 <proc>
    8000218c:	a811                	j	800021a0 <scheduler+0x74>
      release(&p->lock);
    8000218e:	8526                	mv	a0,s1
    80002190:	fffff097          	auipc	ra,0xfffff
    80002194:	c54080e7          	jalr	-940(ra) # 80000de4 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80002198:	16848493          	addi	s1,s1,360
    8000219c:	fd248ee3          	beq	s1,s2,80002178 <scheduler+0x4c>
      acquire(&p->lock);
    800021a0:	8526                	mv	a0,s1
    800021a2:	fffff097          	auipc	ra,0xfffff
    800021a6:	b8e080e7          	jalr	-1138(ra) # 80000d30 <acquire>
      if(p->state == RUNNABLE) {
    800021aa:	4c9c                	lw	a5,24(s1)
    800021ac:	ff3791e3          	bne	a5,s3,8000218e <scheduler+0x62>
        p->state = RUNNING;
    800021b0:	0164ac23          	sw	s6,24(s1)
        c->proc = p;
    800021b4:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    800021b8:	06048593          	addi	a1,s1,96
    800021bc:	8556                	mv	a0,s5
    800021be:	00000097          	auipc	ra,0x0
    800021c2:	684080e7          	jalr	1668(ra) # 80002842 <swtch>
        c->proc = 0;
    800021c6:	020a3823          	sd	zero,48(s4)
    800021ca:	b7d1                	j	8000218e <scheduler+0x62>

00000000800021cc <sched>:
{
    800021cc:	7179                	addi	sp,sp,-48
    800021ce:	f406                	sd	ra,40(sp)
    800021d0:	f022                	sd	s0,32(sp)
    800021d2:	ec26                	sd	s1,24(sp)
    800021d4:	e84a                	sd	s2,16(sp)
    800021d6:	e44e                	sd	s3,8(sp)
    800021d8:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800021da:	00000097          	auipc	ra,0x0
    800021de:	a58080e7          	jalr	-1448(ra) # 80001c32 <myproc>
    800021e2:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    800021e4:	fffff097          	auipc	ra,0xfffff
    800021e8:	ad2080e7          	jalr	-1326(ra) # 80000cb6 <holding>
    800021ec:	c93d                	beqz	a0,80002262 <sched+0x96>
  asm volatile("mv %0, tp" : "=r"(x));
    800021ee:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800021f0:	2781                	sext.w	a5,a5
    800021f2:	079e                	slli	a5,a5,0x7
    800021f4:	0022f717          	auipc	a4,0x22f
    800021f8:	9a470713          	addi	a4,a4,-1628 # 80230b98 <pid_lock>
    800021fc:	97ba                	add	a5,a5,a4
    800021fe:	0a87a703          	lw	a4,168(a5)
    80002202:	4785                	li	a5,1
    80002204:	06f71763          	bne	a4,a5,80002272 <sched+0xa6>
  if(p->state == RUNNING)
    80002208:	4c98                	lw	a4,24(s1)
    8000220a:	4791                	li	a5,4
    8000220c:	06f70b63          	beq	a4,a5,80002282 <sched+0xb6>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002210:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002214:	8b89                	andi	a5,a5,2
  if(intr_get())
    80002216:	efb5                	bnez	a5,80002292 <sched+0xc6>
  asm volatile("mv %0, tp" : "=r"(x));
    80002218:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    8000221a:	0022f917          	auipc	s2,0x22f
    8000221e:	97e90913          	addi	s2,s2,-1666 # 80230b98 <pid_lock>
    80002222:	2781                	sext.w	a5,a5
    80002224:	079e                	slli	a5,a5,0x7
    80002226:	97ca                	add	a5,a5,s2
    80002228:	0ac7a983          	lw	s3,172(a5)
    8000222c:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    8000222e:	2781                	sext.w	a5,a5
    80002230:	079e                	slli	a5,a5,0x7
    80002232:	0022f597          	auipc	a1,0x22f
    80002236:	99e58593          	addi	a1,a1,-1634 # 80230bd0 <cpus+0x8>
    8000223a:	95be                	add	a1,a1,a5
    8000223c:	06048513          	addi	a0,s1,96
    80002240:	00000097          	auipc	ra,0x0
    80002244:	602080e7          	jalr	1538(ra) # 80002842 <swtch>
    80002248:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    8000224a:	2781                	sext.w	a5,a5
    8000224c:	079e                	slli	a5,a5,0x7
    8000224e:	97ca                	add	a5,a5,s2
    80002250:	0b37a623          	sw	s3,172(a5)
}
    80002254:	70a2                	ld	ra,40(sp)
    80002256:	7402                	ld	s0,32(sp)
    80002258:	64e2                	ld	s1,24(sp)
    8000225a:	6942                	ld	s2,16(sp)
    8000225c:	69a2                	ld	s3,8(sp)
    8000225e:	6145                	addi	sp,sp,48
    80002260:	8082                	ret
    panic("sched p->lock");
    80002262:	00006517          	auipc	a0,0x6
    80002266:	ffe50513          	addi	a0,a0,-2 # 80008260 <digits+0x220>
    8000226a:	ffffe097          	auipc	ra,0xffffe
    8000226e:	2d4080e7          	jalr	724(ra) # 8000053e <panic>
    panic("sched locks");
    80002272:	00006517          	auipc	a0,0x6
    80002276:	ffe50513          	addi	a0,a0,-2 # 80008270 <digits+0x230>
    8000227a:	ffffe097          	auipc	ra,0xffffe
    8000227e:	2c4080e7          	jalr	708(ra) # 8000053e <panic>
    panic("sched running");
    80002282:	00006517          	auipc	a0,0x6
    80002286:	ffe50513          	addi	a0,a0,-2 # 80008280 <digits+0x240>
    8000228a:	ffffe097          	auipc	ra,0xffffe
    8000228e:	2b4080e7          	jalr	692(ra) # 8000053e <panic>
    panic("sched interruptible");
    80002292:	00006517          	auipc	a0,0x6
    80002296:	ffe50513          	addi	a0,a0,-2 # 80008290 <digits+0x250>
    8000229a:	ffffe097          	auipc	ra,0xffffe
    8000229e:	2a4080e7          	jalr	676(ra) # 8000053e <panic>

00000000800022a2 <yield>:
{
    800022a2:	1101                	addi	sp,sp,-32
    800022a4:	ec06                	sd	ra,24(sp)
    800022a6:	e822                	sd	s0,16(sp)
    800022a8:	e426                	sd	s1,8(sp)
    800022aa:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800022ac:	00000097          	auipc	ra,0x0
    800022b0:	986080e7          	jalr	-1658(ra) # 80001c32 <myproc>
    800022b4:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800022b6:	fffff097          	auipc	ra,0xfffff
    800022ba:	a7a080e7          	jalr	-1414(ra) # 80000d30 <acquire>
  p->state = RUNNABLE;
    800022be:	478d                	li	a5,3
    800022c0:	cc9c                	sw	a5,24(s1)
  sched();
    800022c2:	00000097          	auipc	ra,0x0
    800022c6:	f0a080e7          	jalr	-246(ra) # 800021cc <sched>
  release(&p->lock);
    800022ca:	8526                	mv	a0,s1
    800022cc:	fffff097          	auipc	ra,0xfffff
    800022d0:	b18080e7          	jalr	-1256(ra) # 80000de4 <release>
}
    800022d4:	60e2                	ld	ra,24(sp)
    800022d6:	6442                	ld	s0,16(sp)
    800022d8:	64a2                	ld	s1,8(sp)
    800022da:	6105                	addi	sp,sp,32
    800022dc:	8082                	ret

00000000800022de <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    800022de:	7179                	addi	sp,sp,-48
    800022e0:	f406                	sd	ra,40(sp)
    800022e2:	f022                	sd	s0,32(sp)
    800022e4:	ec26                	sd	s1,24(sp)
    800022e6:	e84a                	sd	s2,16(sp)
    800022e8:	e44e                	sd	s3,8(sp)
    800022ea:	1800                	addi	s0,sp,48
    800022ec:	89aa                	mv	s3,a0
    800022ee:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800022f0:	00000097          	auipc	ra,0x0
    800022f4:	942080e7          	jalr	-1726(ra) # 80001c32 <myproc>
    800022f8:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    800022fa:	fffff097          	auipc	ra,0xfffff
    800022fe:	a36080e7          	jalr	-1482(ra) # 80000d30 <acquire>
  release(lk);
    80002302:	854a                	mv	a0,s2
    80002304:	fffff097          	auipc	ra,0xfffff
    80002308:	ae0080e7          	jalr	-1312(ra) # 80000de4 <release>

  // Go to sleep.
  p->chan = chan;
    8000230c:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80002310:	4789                	li	a5,2
    80002312:	cc9c                	sw	a5,24(s1)

  sched();
    80002314:	00000097          	auipc	ra,0x0
    80002318:	eb8080e7          	jalr	-328(ra) # 800021cc <sched>

  // Tidy up.
  p->chan = 0;
    8000231c:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80002320:	8526                	mv	a0,s1
    80002322:	fffff097          	auipc	ra,0xfffff
    80002326:	ac2080e7          	jalr	-1342(ra) # 80000de4 <release>
  acquire(lk);
    8000232a:	854a                	mv	a0,s2
    8000232c:	fffff097          	auipc	ra,0xfffff
    80002330:	a04080e7          	jalr	-1532(ra) # 80000d30 <acquire>
}
    80002334:	70a2                	ld	ra,40(sp)
    80002336:	7402                	ld	s0,32(sp)
    80002338:	64e2                	ld	s1,24(sp)
    8000233a:	6942                	ld	s2,16(sp)
    8000233c:	69a2                	ld	s3,8(sp)
    8000233e:	6145                	addi	sp,sp,48
    80002340:	8082                	ret

0000000080002342 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80002342:	7139                	addi	sp,sp,-64
    80002344:	fc06                	sd	ra,56(sp)
    80002346:	f822                	sd	s0,48(sp)
    80002348:	f426                	sd	s1,40(sp)
    8000234a:	f04a                	sd	s2,32(sp)
    8000234c:	ec4e                	sd	s3,24(sp)
    8000234e:	e852                	sd	s4,16(sp)
    80002350:	e456                	sd	s5,8(sp)
    80002352:	0080                	addi	s0,sp,64
    80002354:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80002356:	0022f497          	auipc	s1,0x22f
    8000235a:	c7248493          	addi	s1,s1,-910 # 80230fc8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    8000235e:	4989                	li	s3,2
        p->state = RUNNABLE;
    80002360:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80002362:	00234917          	auipc	s2,0x234
    80002366:	66690913          	addi	s2,s2,1638 # 802369c8 <tickslock>
    8000236a:	a811                	j	8000237e <wakeup+0x3c>
      }
      release(&p->lock);
    8000236c:	8526                	mv	a0,s1
    8000236e:	fffff097          	auipc	ra,0xfffff
    80002372:	a76080e7          	jalr	-1418(ra) # 80000de4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80002376:	16848493          	addi	s1,s1,360
    8000237a:	03248663          	beq	s1,s2,800023a6 <wakeup+0x64>
    if(p != myproc()){
    8000237e:	00000097          	auipc	ra,0x0
    80002382:	8b4080e7          	jalr	-1868(ra) # 80001c32 <myproc>
    80002386:	fea488e3          	beq	s1,a0,80002376 <wakeup+0x34>
      acquire(&p->lock);
    8000238a:	8526                	mv	a0,s1
    8000238c:	fffff097          	auipc	ra,0xfffff
    80002390:	9a4080e7          	jalr	-1628(ra) # 80000d30 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80002394:	4c9c                	lw	a5,24(s1)
    80002396:	fd379be3          	bne	a5,s3,8000236c <wakeup+0x2a>
    8000239a:	709c                	ld	a5,32(s1)
    8000239c:	fd4798e3          	bne	a5,s4,8000236c <wakeup+0x2a>
        p->state = RUNNABLE;
    800023a0:	0154ac23          	sw	s5,24(s1)
    800023a4:	b7e1                	j	8000236c <wakeup+0x2a>
    }
  }
}
    800023a6:	70e2                	ld	ra,56(sp)
    800023a8:	7442                	ld	s0,48(sp)
    800023aa:	74a2                	ld	s1,40(sp)
    800023ac:	7902                	ld	s2,32(sp)
    800023ae:	69e2                	ld	s3,24(sp)
    800023b0:	6a42                	ld	s4,16(sp)
    800023b2:	6aa2                	ld	s5,8(sp)
    800023b4:	6121                	addi	sp,sp,64
    800023b6:	8082                	ret

00000000800023b8 <reparent>:
{
    800023b8:	7179                	addi	sp,sp,-48
    800023ba:	f406                	sd	ra,40(sp)
    800023bc:	f022                	sd	s0,32(sp)
    800023be:	ec26                	sd	s1,24(sp)
    800023c0:	e84a                	sd	s2,16(sp)
    800023c2:	e44e                	sd	s3,8(sp)
    800023c4:	e052                	sd	s4,0(sp)
    800023c6:	1800                	addi	s0,sp,48
    800023c8:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800023ca:	0022f497          	auipc	s1,0x22f
    800023ce:	bfe48493          	addi	s1,s1,-1026 # 80230fc8 <proc>
      pp->parent = initproc;
    800023d2:	00006a17          	auipc	s4,0x6
    800023d6:	536a0a13          	addi	s4,s4,1334 # 80008908 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800023da:	00234997          	auipc	s3,0x234
    800023de:	5ee98993          	addi	s3,s3,1518 # 802369c8 <tickslock>
    800023e2:	a029                	j	800023ec <reparent+0x34>
    800023e4:	16848493          	addi	s1,s1,360
    800023e8:	01348d63          	beq	s1,s3,80002402 <reparent+0x4a>
    if(pp->parent == p){
    800023ec:	7c9c                	ld	a5,56(s1)
    800023ee:	ff279be3          	bne	a5,s2,800023e4 <reparent+0x2c>
      pp->parent = initproc;
    800023f2:	000a3503          	ld	a0,0(s4)
    800023f6:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    800023f8:	00000097          	auipc	ra,0x0
    800023fc:	f4a080e7          	jalr	-182(ra) # 80002342 <wakeup>
    80002400:	b7d5                	j	800023e4 <reparent+0x2c>
}
    80002402:	70a2                	ld	ra,40(sp)
    80002404:	7402                	ld	s0,32(sp)
    80002406:	64e2                	ld	s1,24(sp)
    80002408:	6942                	ld	s2,16(sp)
    8000240a:	69a2                	ld	s3,8(sp)
    8000240c:	6a02                	ld	s4,0(sp)
    8000240e:	6145                	addi	sp,sp,48
    80002410:	8082                	ret

0000000080002412 <exit>:
{
    80002412:	7179                	addi	sp,sp,-48
    80002414:	f406                	sd	ra,40(sp)
    80002416:	f022                	sd	s0,32(sp)
    80002418:	ec26                	sd	s1,24(sp)
    8000241a:	e84a                	sd	s2,16(sp)
    8000241c:	e44e                	sd	s3,8(sp)
    8000241e:	e052                	sd	s4,0(sp)
    80002420:	1800                	addi	s0,sp,48
    80002422:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002424:	00000097          	auipc	ra,0x0
    80002428:	80e080e7          	jalr	-2034(ra) # 80001c32 <myproc>
    8000242c:	89aa                	mv	s3,a0
  if(p == initproc)
    8000242e:	00006797          	auipc	a5,0x6
    80002432:	4da7b783          	ld	a5,1242(a5) # 80008908 <initproc>
    80002436:	0d050493          	addi	s1,a0,208
    8000243a:	15050913          	addi	s2,a0,336
    8000243e:	02a79363          	bne	a5,a0,80002464 <exit+0x52>
    panic("init exiting");
    80002442:	00006517          	auipc	a0,0x6
    80002446:	e6650513          	addi	a0,a0,-410 # 800082a8 <digits+0x268>
    8000244a:	ffffe097          	auipc	ra,0xffffe
    8000244e:	0f4080e7          	jalr	244(ra) # 8000053e <panic>
      fileclose(f);
    80002452:	00002097          	auipc	ra,0x2
    80002456:	372080e7          	jalr	882(ra) # 800047c4 <fileclose>
      p->ofile[fd] = 0;
    8000245a:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    8000245e:	04a1                	addi	s1,s1,8
    80002460:	01248563          	beq	s1,s2,8000246a <exit+0x58>
    if(p->ofile[fd]){
    80002464:	6088                	ld	a0,0(s1)
    80002466:	f575                	bnez	a0,80002452 <exit+0x40>
    80002468:	bfdd                	j	8000245e <exit+0x4c>
  begin_op();
    8000246a:	00002097          	auipc	ra,0x2
    8000246e:	e8e080e7          	jalr	-370(ra) # 800042f8 <begin_op>
  iput(p->cwd);
    80002472:	1509b503          	ld	a0,336(s3)
    80002476:	00001097          	auipc	ra,0x1
    8000247a:	676080e7          	jalr	1654(ra) # 80003aec <iput>
  end_op();
    8000247e:	00002097          	auipc	ra,0x2
    80002482:	efa080e7          	jalr	-262(ra) # 80004378 <end_op>
  p->cwd = 0;
    80002486:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000248a:	0022e497          	auipc	s1,0x22e
    8000248e:	72648493          	addi	s1,s1,1830 # 80230bb0 <wait_lock>
    80002492:	8526                	mv	a0,s1
    80002494:	fffff097          	auipc	ra,0xfffff
    80002498:	89c080e7          	jalr	-1892(ra) # 80000d30 <acquire>
  reparent(p);
    8000249c:	854e                	mv	a0,s3
    8000249e:	00000097          	auipc	ra,0x0
    800024a2:	f1a080e7          	jalr	-230(ra) # 800023b8 <reparent>
  wakeup(p->parent);
    800024a6:	0389b503          	ld	a0,56(s3)
    800024aa:	00000097          	auipc	ra,0x0
    800024ae:	e98080e7          	jalr	-360(ra) # 80002342 <wakeup>
  acquire(&p->lock);
    800024b2:	854e                	mv	a0,s3
    800024b4:	fffff097          	auipc	ra,0xfffff
    800024b8:	87c080e7          	jalr	-1924(ra) # 80000d30 <acquire>
  p->xstate = status;
    800024bc:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800024c0:	4795                	li	a5,5
    800024c2:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800024c6:	8526                	mv	a0,s1
    800024c8:	fffff097          	auipc	ra,0xfffff
    800024cc:	91c080e7          	jalr	-1764(ra) # 80000de4 <release>
  sched();
    800024d0:	00000097          	auipc	ra,0x0
    800024d4:	cfc080e7          	jalr	-772(ra) # 800021cc <sched>
  panic("zombie exit");
    800024d8:	00006517          	auipc	a0,0x6
    800024dc:	de050513          	addi	a0,a0,-544 # 800082b8 <digits+0x278>
    800024e0:	ffffe097          	auipc	ra,0xffffe
    800024e4:	05e080e7          	jalr	94(ra) # 8000053e <panic>

00000000800024e8 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    800024e8:	7179                	addi	sp,sp,-48
    800024ea:	f406                	sd	ra,40(sp)
    800024ec:	f022                	sd	s0,32(sp)
    800024ee:	ec26                	sd	s1,24(sp)
    800024f0:	e84a                	sd	s2,16(sp)
    800024f2:	e44e                	sd	s3,8(sp)
    800024f4:	1800                	addi	s0,sp,48
    800024f6:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800024f8:	0022f497          	auipc	s1,0x22f
    800024fc:	ad048493          	addi	s1,s1,-1328 # 80230fc8 <proc>
    80002500:	00234997          	auipc	s3,0x234
    80002504:	4c898993          	addi	s3,s3,1224 # 802369c8 <tickslock>
    acquire(&p->lock);
    80002508:	8526                	mv	a0,s1
    8000250a:	fffff097          	auipc	ra,0xfffff
    8000250e:	826080e7          	jalr	-2010(ra) # 80000d30 <acquire>
    if(p->pid == pid){
    80002512:	589c                	lw	a5,48(s1)
    80002514:	01278d63          	beq	a5,s2,8000252e <kill+0x46>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002518:	8526                	mv	a0,s1
    8000251a:	fffff097          	auipc	ra,0xfffff
    8000251e:	8ca080e7          	jalr	-1846(ra) # 80000de4 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002522:	16848493          	addi	s1,s1,360
    80002526:	ff3491e3          	bne	s1,s3,80002508 <kill+0x20>
  }
  return -1;
    8000252a:	557d                	li	a0,-1
    8000252c:	a829                	j	80002546 <kill+0x5e>
      p->killed = 1;
    8000252e:	4785                	li	a5,1
    80002530:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002532:	4c98                	lw	a4,24(s1)
    80002534:	4789                	li	a5,2
    80002536:	00f70f63          	beq	a4,a5,80002554 <kill+0x6c>
      release(&p->lock);
    8000253a:	8526                	mv	a0,s1
    8000253c:	fffff097          	auipc	ra,0xfffff
    80002540:	8a8080e7          	jalr	-1880(ra) # 80000de4 <release>
      return 0;
    80002544:	4501                	li	a0,0
}
    80002546:	70a2                	ld	ra,40(sp)
    80002548:	7402                	ld	s0,32(sp)
    8000254a:	64e2                	ld	s1,24(sp)
    8000254c:	6942                	ld	s2,16(sp)
    8000254e:	69a2                	ld	s3,8(sp)
    80002550:	6145                	addi	sp,sp,48
    80002552:	8082                	ret
        p->state = RUNNABLE;
    80002554:	478d                	li	a5,3
    80002556:	cc9c                	sw	a5,24(s1)
    80002558:	b7cd                	j	8000253a <kill+0x52>

000000008000255a <setkilled>:

void
setkilled(struct proc *p)
{
    8000255a:	1101                	addi	sp,sp,-32
    8000255c:	ec06                	sd	ra,24(sp)
    8000255e:	e822                	sd	s0,16(sp)
    80002560:	e426                	sd	s1,8(sp)
    80002562:	1000                	addi	s0,sp,32
    80002564:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002566:	ffffe097          	auipc	ra,0xffffe
    8000256a:	7ca080e7          	jalr	1994(ra) # 80000d30 <acquire>
  p->killed = 1;
    8000256e:	4785                	li	a5,1
    80002570:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002572:	8526                	mv	a0,s1
    80002574:	fffff097          	auipc	ra,0xfffff
    80002578:	870080e7          	jalr	-1936(ra) # 80000de4 <release>
}
    8000257c:	60e2                	ld	ra,24(sp)
    8000257e:	6442                	ld	s0,16(sp)
    80002580:	64a2                	ld	s1,8(sp)
    80002582:	6105                	addi	sp,sp,32
    80002584:	8082                	ret

0000000080002586 <killed>:

int
killed(struct proc *p)
{
    80002586:	1101                	addi	sp,sp,-32
    80002588:	ec06                	sd	ra,24(sp)
    8000258a:	e822                	sd	s0,16(sp)
    8000258c:	e426                	sd	s1,8(sp)
    8000258e:	e04a                	sd	s2,0(sp)
    80002590:	1000                	addi	s0,sp,32
    80002592:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002594:	ffffe097          	auipc	ra,0xffffe
    80002598:	79c080e7          	jalr	1948(ra) # 80000d30 <acquire>
  k = p->killed;
    8000259c:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800025a0:	8526                	mv	a0,s1
    800025a2:	fffff097          	auipc	ra,0xfffff
    800025a6:	842080e7          	jalr	-1982(ra) # 80000de4 <release>
  return k;
}
    800025aa:	854a                	mv	a0,s2
    800025ac:	60e2                	ld	ra,24(sp)
    800025ae:	6442                	ld	s0,16(sp)
    800025b0:	64a2                	ld	s1,8(sp)
    800025b2:	6902                	ld	s2,0(sp)
    800025b4:	6105                	addi	sp,sp,32
    800025b6:	8082                	ret

00000000800025b8 <wait>:
{
    800025b8:	715d                	addi	sp,sp,-80
    800025ba:	e486                	sd	ra,72(sp)
    800025bc:	e0a2                	sd	s0,64(sp)
    800025be:	fc26                	sd	s1,56(sp)
    800025c0:	f84a                	sd	s2,48(sp)
    800025c2:	f44e                	sd	s3,40(sp)
    800025c4:	f052                	sd	s4,32(sp)
    800025c6:	ec56                	sd	s5,24(sp)
    800025c8:	e85a                	sd	s6,16(sp)
    800025ca:	e45e                	sd	s7,8(sp)
    800025cc:	e062                	sd	s8,0(sp)
    800025ce:	0880                	addi	s0,sp,80
    800025d0:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800025d2:	fffff097          	auipc	ra,0xfffff
    800025d6:	660080e7          	jalr	1632(ra) # 80001c32 <myproc>
    800025da:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800025dc:	0022e517          	auipc	a0,0x22e
    800025e0:	5d450513          	addi	a0,a0,1492 # 80230bb0 <wait_lock>
    800025e4:	ffffe097          	auipc	ra,0xffffe
    800025e8:	74c080e7          	jalr	1868(ra) # 80000d30 <acquire>
    havekids = 0;
    800025ec:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    800025ee:	4a15                	li	s4,5
        havekids = 1;
    800025f0:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800025f2:	00234997          	auipc	s3,0x234
    800025f6:	3d698993          	addi	s3,s3,982 # 802369c8 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800025fa:	0022ec17          	auipc	s8,0x22e
    800025fe:	5b6c0c13          	addi	s8,s8,1462 # 80230bb0 <wait_lock>
    havekids = 0;
    80002602:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002604:	0022f497          	auipc	s1,0x22f
    80002608:	9c448493          	addi	s1,s1,-1596 # 80230fc8 <proc>
    8000260c:	a0bd                	j	8000267a <wait+0xc2>
          pid = pp->pid;
    8000260e:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002612:	000b0e63          	beqz	s6,8000262e <wait+0x76>
    80002616:	4691                	li	a3,4
    80002618:	02c48613          	addi	a2,s1,44
    8000261c:	85da                	mv	a1,s6
    8000261e:	05093503          	ld	a0,80(s2)
    80002622:	fffff097          	auipc	ra,0xfffff
    80002626:	260080e7          	jalr	608(ra) # 80001882 <copyout>
    8000262a:	02054563          	bltz	a0,80002654 <wait+0x9c>
          freeproc(pp);
    8000262e:	8526                	mv	a0,s1
    80002630:	fffff097          	auipc	ra,0xfffff
    80002634:	7b8080e7          	jalr	1976(ra) # 80001de8 <freeproc>
          release(&pp->lock);
    80002638:	8526                	mv	a0,s1
    8000263a:	ffffe097          	auipc	ra,0xffffe
    8000263e:	7aa080e7          	jalr	1962(ra) # 80000de4 <release>
          release(&wait_lock);
    80002642:	0022e517          	auipc	a0,0x22e
    80002646:	56e50513          	addi	a0,a0,1390 # 80230bb0 <wait_lock>
    8000264a:	ffffe097          	auipc	ra,0xffffe
    8000264e:	79a080e7          	jalr	1946(ra) # 80000de4 <release>
          return pid;
    80002652:	a0b5                	j	800026be <wait+0x106>
            release(&pp->lock);
    80002654:	8526                	mv	a0,s1
    80002656:	ffffe097          	auipc	ra,0xffffe
    8000265a:	78e080e7          	jalr	1934(ra) # 80000de4 <release>
            release(&wait_lock);
    8000265e:	0022e517          	auipc	a0,0x22e
    80002662:	55250513          	addi	a0,a0,1362 # 80230bb0 <wait_lock>
    80002666:	ffffe097          	auipc	ra,0xffffe
    8000266a:	77e080e7          	jalr	1918(ra) # 80000de4 <release>
            return -1;
    8000266e:	59fd                	li	s3,-1
    80002670:	a0b9                	j	800026be <wait+0x106>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002672:	16848493          	addi	s1,s1,360
    80002676:	03348463          	beq	s1,s3,8000269e <wait+0xe6>
      if(pp->parent == p){
    8000267a:	7c9c                	ld	a5,56(s1)
    8000267c:	ff279be3          	bne	a5,s2,80002672 <wait+0xba>
        acquire(&pp->lock);
    80002680:	8526                	mv	a0,s1
    80002682:	ffffe097          	auipc	ra,0xffffe
    80002686:	6ae080e7          	jalr	1710(ra) # 80000d30 <acquire>
        if(pp->state == ZOMBIE){
    8000268a:	4c9c                	lw	a5,24(s1)
    8000268c:	f94781e3          	beq	a5,s4,8000260e <wait+0x56>
        release(&pp->lock);
    80002690:	8526                	mv	a0,s1
    80002692:	ffffe097          	auipc	ra,0xffffe
    80002696:	752080e7          	jalr	1874(ra) # 80000de4 <release>
        havekids = 1;
    8000269a:	8756                	mv	a4,s5
    8000269c:	bfd9                	j	80002672 <wait+0xba>
    if(!havekids || killed(p)){
    8000269e:	c719                	beqz	a4,800026ac <wait+0xf4>
    800026a0:	854a                	mv	a0,s2
    800026a2:	00000097          	auipc	ra,0x0
    800026a6:	ee4080e7          	jalr	-284(ra) # 80002586 <killed>
    800026aa:	c51d                	beqz	a0,800026d8 <wait+0x120>
      release(&wait_lock);
    800026ac:	0022e517          	auipc	a0,0x22e
    800026b0:	50450513          	addi	a0,a0,1284 # 80230bb0 <wait_lock>
    800026b4:	ffffe097          	auipc	ra,0xffffe
    800026b8:	730080e7          	jalr	1840(ra) # 80000de4 <release>
      return -1;
    800026bc:	59fd                	li	s3,-1
}
    800026be:	854e                	mv	a0,s3
    800026c0:	60a6                	ld	ra,72(sp)
    800026c2:	6406                	ld	s0,64(sp)
    800026c4:	74e2                	ld	s1,56(sp)
    800026c6:	7942                	ld	s2,48(sp)
    800026c8:	79a2                	ld	s3,40(sp)
    800026ca:	7a02                	ld	s4,32(sp)
    800026cc:	6ae2                	ld	s5,24(sp)
    800026ce:	6b42                	ld	s6,16(sp)
    800026d0:	6ba2                	ld	s7,8(sp)
    800026d2:	6c02                	ld	s8,0(sp)
    800026d4:	6161                	addi	sp,sp,80
    800026d6:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800026d8:	85e2                	mv	a1,s8
    800026da:	854a                	mv	a0,s2
    800026dc:	00000097          	auipc	ra,0x0
    800026e0:	c02080e7          	jalr	-1022(ra) # 800022de <sleep>
    havekids = 0;
    800026e4:	bf39                	j	80002602 <wait+0x4a>

00000000800026e6 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800026e6:	7179                	addi	sp,sp,-48
    800026e8:	f406                	sd	ra,40(sp)
    800026ea:	f022                	sd	s0,32(sp)
    800026ec:	ec26                	sd	s1,24(sp)
    800026ee:	e84a                	sd	s2,16(sp)
    800026f0:	e44e                	sd	s3,8(sp)
    800026f2:	e052                	sd	s4,0(sp)
    800026f4:	1800                	addi	s0,sp,48
    800026f6:	84aa                	mv	s1,a0
    800026f8:	892e                	mv	s2,a1
    800026fa:	89b2                	mv	s3,a2
    800026fc:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800026fe:	fffff097          	auipc	ra,0xfffff
    80002702:	534080e7          	jalr	1332(ra) # 80001c32 <myproc>
  if(user_dst){
    80002706:	c08d                	beqz	s1,80002728 <either_copyout+0x42>
    return copyout(p->pagetable, dst, src, len);
    80002708:	86d2                	mv	a3,s4
    8000270a:	864e                	mv	a2,s3
    8000270c:	85ca                	mv	a1,s2
    8000270e:	6928                	ld	a0,80(a0)
    80002710:	fffff097          	auipc	ra,0xfffff
    80002714:	172080e7          	jalr	370(ra) # 80001882 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002718:	70a2                	ld	ra,40(sp)
    8000271a:	7402                	ld	s0,32(sp)
    8000271c:	64e2                	ld	s1,24(sp)
    8000271e:	6942                	ld	s2,16(sp)
    80002720:	69a2                	ld	s3,8(sp)
    80002722:	6a02                	ld	s4,0(sp)
    80002724:	6145                	addi	sp,sp,48
    80002726:	8082                	ret
    memmove((char *)dst, src, len);
    80002728:	000a061b          	sext.w	a2,s4
    8000272c:	85ce                	mv	a1,s3
    8000272e:	854a                	mv	a0,s2
    80002730:	ffffe097          	auipc	ra,0xffffe
    80002734:	758080e7          	jalr	1880(ra) # 80000e88 <memmove>
    return 0;
    80002738:	8526                	mv	a0,s1
    8000273a:	bff9                	j	80002718 <either_copyout+0x32>

000000008000273c <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000273c:	7179                	addi	sp,sp,-48
    8000273e:	f406                	sd	ra,40(sp)
    80002740:	f022                	sd	s0,32(sp)
    80002742:	ec26                	sd	s1,24(sp)
    80002744:	e84a                	sd	s2,16(sp)
    80002746:	e44e                	sd	s3,8(sp)
    80002748:	e052                	sd	s4,0(sp)
    8000274a:	1800                	addi	s0,sp,48
    8000274c:	892a                	mv	s2,a0
    8000274e:	84ae                	mv	s1,a1
    80002750:	89b2                	mv	s3,a2
    80002752:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002754:	fffff097          	auipc	ra,0xfffff
    80002758:	4de080e7          	jalr	1246(ra) # 80001c32 <myproc>
  if(user_src){
    8000275c:	c08d                	beqz	s1,8000277e <either_copyin+0x42>
    return copyin(p->pagetable, dst, src, len);
    8000275e:	86d2                	mv	a3,s4
    80002760:	864e                	mv	a2,s3
    80002762:	85ca                	mv	a1,s2
    80002764:	6928                	ld	a0,80(a0)
    80002766:	fffff097          	auipc	ra,0xfffff
    8000276a:	214080e7          	jalr	532(ra) # 8000197a <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    8000276e:	70a2                	ld	ra,40(sp)
    80002770:	7402                	ld	s0,32(sp)
    80002772:	64e2                	ld	s1,24(sp)
    80002774:	6942                	ld	s2,16(sp)
    80002776:	69a2                	ld	s3,8(sp)
    80002778:	6a02                	ld	s4,0(sp)
    8000277a:	6145                	addi	sp,sp,48
    8000277c:	8082                	ret
    memmove(dst, (char*)src, len);
    8000277e:	000a061b          	sext.w	a2,s4
    80002782:	85ce                	mv	a1,s3
    80002784:	854a                	mv	a0,s2
    80002786:	ffffe097          	auipc	ra,0xffffe
    8000278a:	702080e7          	jalr	1794(ra) # 80000e88 <memmove>
    return 0;
    8000278e:	8526                	mv	a0,s1
    80002790:	bff9                	j	8000276e <either_copyin+0x32>

0000000080002792 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002792:	715d                	addi	sp,sp,-80
    80002794:	e486                	sd	ra,72(sp)
    80002796:	e0a2                	sd	s0,64(sp)
    80002798:	fc26                	sd	s1,56(sp)
    8000279a:	f84a                	sd	s2,48(sp)
    8000279c:	f44e                	sd	s3,40(sp)
    8000279e:	f052                	sd	s4,32(sp)
    800027a0:	ec56                	sd	s5,24(sp)
    800027a2:	e85a                	sd	s6,16(sp)
    800027a4:	e45e                	sd	s7,8(sp)
    800027a6:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800027a8:	00006517          	auipc	a0,0x6
    800027ac:	92850513          	addi	a0,a0,-1752 # 800080d0 <digits+0x90>
    800027b0:	ffffe097          	auipc	ra,0xffffe
    800027b4:	dd8080e7          	jalr	-552(ra) # 80000588 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800027b8:	0022f497          	auipc	s1,0x22f
    800027bc:	96848493          	addi	s1,s1,-1688 # 80231120 <proc+0x158>
    800027c0:	00234917          	auipc	s2,0x234
    800027c4:	36090913          	addi	s2,s2,864 # 80236b20 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800027c8:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800027ca:	00006997          	auipc	s3,0x6
    800027ce:	afe98993          	addi	s3,s3,-1282 # 800082c8 <digits+0x288>
    printf("%d %s %s", p->pid, state, p->name);
    800027d2:	00006a97          	auipc	s5,0x6
    800027d6:	afea8a93          	addi	s5,s5,-1282 # 800082d0 <digits+0x290>
    printf("\n");
    800027da:	00006a17          	auipc	s4,0x6
    800027de:	8f6a0a13          	addi	s4,s4,-1802 # 800080d0 <digits+0x90>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800027e2:	00006b97          	auipc	s7,0x6
    800027e6:	b2eb8b93          	addi	s7,s7,-1234 # 80008310 <states.0>
    800027ea:	a00d                	j	8000280c <procdump+0x7a>
    printf("%d %s %s", p->pid, state, p->name);
    800027ec:	ed86a583          	lw	a1,-296(a3)
    800027f0:	8556                	mv	a0,s5
    800027f2:	ffffe097          	auipc	ra,0xffffe
    800027f6:	d96080e7          	jalr	-618(ra) # 80000588 <printf>
    printf("\n");
    800027fa:	8552                	mv	a0,s4
    800027fc:	ffffe097          	auipc	ra,0xffffe
    80002800:	d8c080e7          	jalr	-628(ra) # 80000588 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002804:	16848493          	addi	s1,s1,360
    80002808:	03248263          	beq	s1,s2,8000282c <procdump+0x9a>
    if(p->state == UNUSED)
    8000280c:	86a6                	mv	a3,s1
    8000280e:	ec04a783          	lw	a5,-320(s1)
    80002812:	dbed                	beqz	a5,80002804 <procdump+0x72>
      state = "???";
    80002814:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002816:	fcfb6be3          	bltu	s6,a5,800027ec <procdump+0x5a>
    8000281a:	02079713          	slli	a4,a5,0x20
    8000281e:	01d75793          	srli	a5,a4,0x1d
    80002822:	97de                	add	a5,a5,s7
    80002824:	6390                	ld	a2,0(a5)
    80002826:	f279                	bnez	a2,800027ec <procdump+0x5a>
      state = "???";
    80002828:	864e                	mv	a2,s3
    8000282a:	b7c9                	j	800027ec <procdump+0x5a>
  }
}
    8000282c:	60a6                	ld	ra,72(sp)
    8000282e:	6406                	ld	s0,64(sp)
    80002830:	74e2                	ld	s1,56(sp)
    80002832:	7942                	ld	s2,48(sp)
    80002834:	79a2                	ld	s3,40(sp)
    80002836:	7a02                	ld	s4,32(sp)
    80002838:	6ae2                	ld	s5,24(sp)
    8000283a:	6b42                	ld	s6,16(sp)
    8000283c:	6ba2                	ld	s7,8(sp)
    8000283e:	6161                	addi	sp,sp,80
    80002840:	8082                	ret

0000000080002842 <swtch>:
    80002842:	00153023          	sd	ra,0(a0)
    80002846:	00253423          	sd	sp,8(a0)
    8000284a:	e900                	sd	s0,16(a0)
    8000284c:	ed04                	sd	s1,24(a0)
    8000284e:	03253023          	sd	s2,32(a0)
    80002852:	03353423          	sd	s3,40(a0)
    80002856:	03453823          	sd	s4,48(a0)
    8000285a:	03553c23          	sd	s5,56(a0)
    8000285e:	05653023          	sd	s6,64(a0)
    80002862:	05753423          	sd	s7,72(a0)
    80002866:	05853823          	sd	s8,80(a0)
    8000286a:	05953c23          	sd	s9,88(a0)
    8000286e:	07a53023          	sd	s10,96(a0)
    80002872:	07b53423          	sd	s11,104(a0)
    80002876:	0005b083          	ld	ra,0(a1)
    8000287a:	0085b103          	ld	sp,8(a1)
    8000287e:	6980                	ld	s0,16(a1)
    80002880:	6d84                	ld	s1,24(a1)
    80002882:	0205b903          	ld	s2,32(a1)
    80002886:	0285b983          	ld	s3,40(a1)
    8000288a:	0305ba03          	ld	s4,48(a1)
    8000288e:	0385ba83          	ld	s5,56(a1)
    80002892:	0405bb03          	ld	s6,64(a1)
    80002896:	0485bb83          	ld	s7,72(a1)
    8000289a:	0505bc03          	ld	s8,80(a1)
    8000289e:	0585bc83          	ld	s9,88(a1)
    800028a2:	0605bd03          	ld	s10,96(a1)
    800028a6:	0685bd83          	ld	s11,104(a1)
    800028aa:	8082                	ret

00000000800028ac <trapinit>:
void kernelvec();

extern int devintr();

void trapinit(void)
{
    800028ac:	1141                	addi	sp,sp,-16
    800028ae:	e406                	sd	ra,8(sp)
    800028b0:	e022                	sd	s0,0(sp)
    800028b2:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800028b4:	00006597          	auipc	a1,0x6
    800028b8:	a8c58593          	addi	a1,a1,-1396 # 80008340 <states.0+0x30>
    800028bc:	00234517          	auipc	a0,0x234
    800028c0:	10c50513          	addi	a0,a0,268 # 802369c8 <tickslock>
    800028c4:	ffffe097          	auipc	ra,0xffffe
    800028c8:	3dc080e7          	jalr	988(ra) # 80000ca0 <initlock>
}
    800028cc:	60a2                	ld	ra,8(sp)
    800028ce:	6402                	ld	s0,0(sp)
    800028d0:	0141                	addi	sp,sp,16
    800028d2:	8082                	ret

00000000800028d4 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void trapinithart(void)
{
    800028d4:	1141                	addi	sp,sp,-16
    800028d6:	e422                	sd	s0,8(sp)
    800028d8:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    800028da:	00003797          	auipc	a5,0x3
    800028de:	53678793          	addi	a5,a5,1334 # 80005e10 <kernelvec>
    800028e2:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800028e6:	6422                	ld	s0,8(sp)
    800028e8:	0141                	addi	sp,sp,16
    800028ea:	8082                	ret

00000000800028ec <usertrapret>:

//
// return to user space
//
void usertrapret(void)
{
    800028ec:	1141                	addi	sp,sp,-16
    800028ee:	e406                	sd	ra,8(sp)
    800028f0:	e022                	sd	s0,0(sp)
    800028f2:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800028f4:	fffff097          	auipc	ra,0xfffff
    800028f8:	33e080e7          	jalr	830(ra) # 80001c32 <myproc>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800028fc:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002900:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002902:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002906:	00004617          	auipc	a2,0x4
    8000290a:	6fa60613          	addi	a2,a2,1786 # 80007000 <_trampoline>
    8000290e:	00004697          	auipc	a3,0x4
    80002912:	6f268693          	addi	a3,a3,1778 # 80007000 <_trampoline>
    80002916:	8e91                	sub	a3,a3,a2
    80002918:	040007b7          	lui	a5,0x4000
    8000291c:	17fd                	addi	a5,a5,-1
    8000291e:	07b2                	slli	a5,a5,0xc
    80002920:	96be                	add	a3,a3,a5
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002922:	10569073          	csrw	stvec,a3
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002926:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    80002928:	180026f3          	csrr	a3,satp
    8000292c:	e314                	sd	a3,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000292e:	6d38                	ld	a4,88(a0)
    80002930:	6134                	ld	a3,64(a0)
    80002932:	6585                	lui	a1,0x1
    80002934:	96ae                	add	a3,a3,a1
    80002936:	e714                	sd	a3,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002938:	6d38                	ld	a4,88(a0)
    8000293a:	00000697          	auipc	a3,0x0
    8000293e:	13068693          	addi	a3,a3,304 # 80002a6a <usertrap>
    80002942:	eb14                	sd	a3,16(a4)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    80002944:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    80002946:	8692                	mv	a3,tp
    80002948:	f314                	sd	a3,32(a4)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000294a:	100026f3          	csrr	a3,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000294e:	eff6f693          	andi	a3,a3,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002952:	0206e693          	ori	a3,a3,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002956:	10069073          	csrw	sstatus,a3
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000295a:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000295c:	6f18                	ld	a4,24(a4)
    8000295e:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80002962:	6928                	ld	a0,80(a0)
    80002964:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80002966:	00004717          	auipc	a4,0x4
    8000296a:	73670713          	addi	a4,a4,1846 # 8000709c <userret>
    8000296e:	8f11                	sub	a4,a4,a2
    80002970:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80002972:	577d                	li	a4,-1
    80002974:	177e                	slli	a4,a4,0x3f
    80002976:	8d59                	or	a0,a0,a4
    80002978:	9782                	jalr	a5
}
    8000297a:	60a2                	ld	ra,8(sp)
    8000297c:	6402                	ld	s0,0(sp)
    8000297e:	0141                	addi	sp,sp,16
    80002980:	8082                	ret

0000000080002982 <clockintr>:
  w_sepc(sepc);
  w_sstatus(sstatus);
}

void clockintr()
{
    80002982:	1101                	addi	sp,sp,-32
    80002984:	ec06                	sd	ra,24(sp)
    80002986:	e822                	sd	s0,16(sp)
    80002988:	e426                	sd	s1,8(sp)
    8000298a:	1000                	addi	s0,sp,32
  acquire(&tickslock);
    8000298c:	00234497          	auipc	s1,0x234
    80002990:	03c48493          	addi	s1,s1,60 # 802369c8 <tickslock>
    80002994:	8526                	mv	a0,s1
    80002996:	ffffe097          	auipc	ra,0xffffe
    8000299a:	39a080e7          	jalr	922(ra) # 80000d30 <acquire>
  ticks++;
    8000299e:	00006517          	auipc	a0,0x6
    800029a2:	f7250513          	addi	a0,a0,-142 # 80008910 <ticks>
    800029a6:	411c                	lw	a5,0(a0)
    800029a8:	2785                	addiw	a5,a5,1
    800029aa:	c11c                	sw	a5,0(a0)
  wakeup(&ticks);
    800029ac:	00000097          	auipc	ra,0x0
    800029b0:	996080e7          	jalr	-1642(ra) # 80002342 <wakeup>
  release(&tickslock);
    800029b4:	8526                	mv	a0,s1
    800029b6:	ffffe097          	auipc	ra,0xffffe
    800029ba:	42e080e7          	jalr	1070(ra) # 80000de4 <release>
}
    800029be:	60e2                	ld	ra,24(sp)
    800029c0:	6442                	ld	s0,16(sp)
    800029c2:	64a2                	ld	s1,8(sp)
    800029c4:	6105                	addi	sp,sp,32
    800029c6:	8082                	ret

00000000800029c8 <devintr>:
// and handle it.
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int devintr()
{
    800029c8:	1101                	addi	sp,sp,-32
    800029ca:	ec06                	sd	ra,24(sp)
    800029cc:	e822                	sd	s0,16(sp)
    800029ce:	e426                	sd	s1,8(sp)
    800029d0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    800029d2:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if ((scause & 0x8000000000000000L) &&
    800029d6:	00074d63          	bltz	a4,800029f0 <devintr+0x28>
    if (irq)
      plic_complete(irq);

    return 1;
  }
  else if (scause == 0x8000000000000001L)
    800029da:	57fd                	li	a5,-1
    800029dc:	17fe                	slli	a5,a5,0x3f
    800029de:	0785                	addi	a5,a5,1

    return 2;
  }
  else
  {
    return 0;
    800029e0:	4501                	li	a0,0
  else if (scause == 0x8000000000000001L)
    800029e2:	06f70363          	beq	a4,a5,80002a48 <devintr+0x80>
  }
}
    800029e6:	60e2                	ld	ra,24(sp)
    800029e8:	6442                	ld	s0,16(sp)
    800029ea:	64a2                	ld	s1,8(sp)
    800029ec:	6105                	addi	sp,sp,32
    800029ee:	8082                	ret
      (scause & 0xff) == 9)
    800029f0:	0ff77793          	zext.b	a5,a4
  if ((scause & 0x8000000000000000L) &&
    800029f4:	46a5                	li	a3,9
    800029f6:	fed792e3          	bne	a5,a3,800029da <devintr+0x12>
    int irq = plic_claim();
    800029fa:	00003097          	auipc	ra,0x3
    800029fe:	4ee080e7          	jalr	1262(ra) # 80005ee8 <plic_claim>
    80002a02:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ)
    80002a04:	47a9                	li	a5,10
    80002a06:	02f50763          	beq	a0,a5,80002a34 <devintr+0x6c>
    else if (irq == VIRTIO0_IRQ)
    80002a0a:	4785                	li	a5,1
    80002a0c:	02f50963          	beq	a0,a5,80002a3e <devintr+0x76>
    return 1;
    80002a10:	4505                	li	a0,1
    else if (irq)
    80002a12:	d8f1                	beqz	s1,800029e6 <devintr+0x1e>
      printf("unexpected interrupt irq=%d\n", irq);
    80002a14:	85a6                	mv	a1,s1
    80002a16:	00006517          	auipc	a0,0x6
    80002a1a:	93250513          	addi	a0,a0,-1742 # 80008348 <states.0+0x38>
    80002a1e:	ffffe097          	auipc	ra,0xffffe
    80002a22:	b6a080e7          	jalr	-1174(ra) # 80000588 <printf>
      plic_complete(irq);
    80002a26:	8526                	mv	a0,s1
    80002a28:	00003097          	auipc	ra,0x3
    80002a2c:	4e4080e7          	jalr	1252(ra) # 80005f0c <plic_complete>
    return 1;
    80002a30:	4505                	li	a0,1
    80002a32:	bf55                	j	800029e6 <devintr+0x1e>
      uartintr();
    80002a34:	ffffe097          	auipc	ra,0xffffe
    80002a38:	f66080e7          	jalr	-154(ra) # 8000099a <uartintr>
    80002a3c:	b7ed                	j	80002a26 <devintr+0x5e>
      virtio_disk_intr();
    80002a3e:	00004097          	auipc	ra,0x4
    80002a42:	99a080e7          	jalr	-1638(ra) # 800063d8 <virtio_disk_intr>
    80002a46:	b7c5                	j	80002a26 <devintr+0x5e>
    if (cpuid() == 0)
    80002a48:	fffff097          	auipc	ra,0xfffff
    80002a4c:	1be080e7          	jalr	446(ra) # 80001c06 <cpuid>
    80002a50:	c901                	beqz	a0,80002a60 <devintr+0x98>
  asm volatile("csrr %0, sip" : "=r"(x));
    80002a52:	144027f3          	csrr	a5,sip
    w_sip(r_sip() & ~2);
    80002a56:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sip, %0" : : "r"(x));
    80002a58:	14479073          	csrw	sip,a5
    return 2;
    80002a5c:	4509                	li	a0,2
    80002a5e:	b761                	j	800029e6 <devintr+0x1e>
      clockintr();
    80002a60:	00000097          	auipc	ra,0x0
    80002a64:	f22080e7          	jalr	-222(ra) # 80002982 <clockintr>
    80002a68:	b7ed                	j	80002a52 <devintr+0x8a>

0000000080002a6a <usertrap>:
{
    80002a6a:	1101                	addi	sp,sp,-32
    80002a6c:	ec06                	sd	ra,24(sp)
    80002a6e:	e822                	sd	s0,16(sp)
    80002a70:	e426                	sd	s1,8(sp)
    80002a72:	e04a                	sd	s2,0(sp)
    80002a74:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002a76:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    80002a7a:	1007f793          	andi	a5,a5,256
    80002a7e:	e3d5                	bnez	a5,80002b22 <usertrap+0xb8>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002a80:	00003797          	auipc	a5,0x3
    80002a84:	39078793          	addi	a5,a5,912 # 80005e10 <kernelvec>
    80002a88:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002a8c:	fffff097          	auipc	ra,0xfffff
    80002a90:	1a6080e7          	jalr	422(ra) # 80001c32 <myproc>
    80002a94:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002a96:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002a98:	14102773          	csrr	a4,sepc
    80002a9c:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    80002a9e:	14202773          	csrr	a4,scause
  if (r_scause() == 8)
    80002aa2:	47a1                	li	a5,8
    80002aa4:	08f70763          	beq	a4,a5,80002b32 <usertrap+0xc8>
    80002aa8:	14202773          	csrr	a4,scause
  else if (r_scause() == 13 || r_scause() == 15)
    80002aac:	47b5                	li	a5,13
    80002aae:	00f70763          	beq	a4,a5,80002abc <usertrap+0x52>
    80002ab2:	14202773          	csrr	a4,scause
    80002ab6:	47bd                	li	a5,15
    80002ab8:	0af71e63          	bne	a4,a5,80002b74 <usertrap+0x10a>
  asm volatile("csrr %0, stval" : "=r"(x));
    80002abc:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    80002ac0:	14202773          	csrr	a4,scause
    if (r_scause() == 15 && cow_alloc(p->pagetable, va) == 0)
    80002ac4:	47bd                	li	a5,15
    80002ac6:	0af70063          	beq	a4,a5,80002b66 <usertrap+0xfc>
    80002aca:	142025f3          	csrr	a1,scause
      printf("usertrap(): unexpected scause %p pid=%d\n", r_scause(), p->pid);
    80002ace:	5890                	lw	a2,48(s1)
    80002ad0:	00006517          	auipc	a0,0x6
    80002ad4:	8b850513          	addi	a0,a0,-1864 # 80008388 <states.0+0x78>
    80002ad8:	ffffe097          	auipc	ra,0xffffe
    80002adc:	ab0080e7          	jalr	-1360(ra) # 80000588 <printf>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002ae0:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002ae4:	14302673          	csrr	a2,stval
      printf("            sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002ae8:	00006517          	auipc	a0,0x6
    80002aec:	8d050513          	addi	a0,a0,-1840 # 800083b8 <states.0+0xa8>
    80002af0:	ffffe097          	auipc	ra,0xffffe
    80002af4:	a98080e7          	jalr	-1384(ra) # 80000588 <printf>
      setkilled(p);
    80002af8:	8526                	mv	a0,s1
    80002afa:	00000097          	auipc	ra,0x0
    80002afe:	a60080e7          	jalr	-1440(ra) # 8000255a <setkilled>
  if (killed(p))
    80002b02:	8526                	mv	a0,s1
    80002b04:	00000097          	auipc	ra,0x0
    80002b08:	a82080e7          	jalr	-1406(ra) # 80002586 <killed>
    80002b0c:	ed55                	bnez	a0,80002bc8 <usertrap+0x15e>
  usertrapret();
    80002b0e:	00000097          	auipc	ra,0x0
    80002b12:	dde080e7          	jalr	-546(ra) # 800028ec <usertrapret>
}
    80002b16:	60e2                	ld	ra,24(sp)
    80002b18:	6442                	ld	s0,16(sp)
    80002b1a:	64a2                	ld	s1,8(sp)
    80002b1c:	6902                	ld	s2,0(sp)
    80002b1e:	6105                	addi	sp,sp,32
    80002b20:	8082                	ret
    panic("usertrap: not from user mode");
    80002b22:	00006517          	auipc	a0,0x6
    80002b26:	84650513          	addi	a0,a0,-1978 # 80008368 <states.0+0x58>
    80002b2a:	ffffe097          	auipc	ra,0xffffe
    80002b2e:	a14080e7          	jalr	-1516(ra) # 8000053e <panic>
    if (killed(p))
    80002b32:	00000097          	auipc	ra,0x0
    80002b36:	a54080e7          	jalr	-1452(ra) # 80002586 <killed>
    80002b3a:	e105                	bnez	a0,80002b5a <usertrap+0xf0>
    p->trapframe->epc += 4;
    80002b3c:	6cb8                	ld	a4,88(s1)
    80002b3e:	6f1c                	ld	a5,24(a4)
    80002b40:	0791                	addi	a5,a5,4
    80002b42:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002b44:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002b48:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002b4c:	10079073          	csrw	sstatus,a5
    syscall();
    80002b50:	00000097          	auipc	ra,0x0
    80002b54:	2de080e7          	jalr	734(ra) # 80002e2e <syscall>
    80002b58:	b76d                	j	80002b02 <usertrap+0x98>
      exit(-1);
    80002b5a:	557d                	li	a0,-1
    80002b5c:	00000097          	auipc	ra,0x0
    80002b60:	8b6080e7          	jalr	-1866(ra) # 80002412 <exit>
    80002b64:	bfe1                	j	80002b3c <usertrap+0xd2>
    if (r_scause() == 15 && cow_alloc(p->pagetable, va) == 0)
    80002b66:	68a8                	ld	a0,80(s1)
    80002b68:	fffff097          	auipc	ra,0xfffff
    80002b6c:	c84080e7          	jalr	-892(ra) # 800017ec <cow_alloc>
    80002b70:	d949                	beqz	a0,80002b02 <usertrap+0x98>
    80002b72:	bfa1                	j	80002aca <usertrap+0x60>
  else if ((which_dev = devintr()) != 0)
    80002b74:	00000097          	auipc	ra,0x0
    80002b78:	e54080e7          	jalr	-428(ra) # 800029c8 <devintr>
    80002b7c:	892a                	mv	s2,a0
    80002b7e:	c901                	beqz	a0,80002b8e <usertrap+0x124>
  if (killed(p))
    80002b80:	8526                	mv	a0,s1
    80002b82:	00000097          	auipc	ra,0x0
    80002b86:	a04080e7          	jalr	-1532(ra) # 80002586 <killed>
    80002b8a:	c529                	beqz	a0,80002bd4 <usertrap+0x16a>
    80002b8c:	a83d                	j	80002bca <usertrap+0x160>
  asm volatile("csrr %0, scause" : "=r"(x));
    80002b8e:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause %p pid=%d\n", r_scause(), p->pid);
    80002b92:	5890                	lw	a2,48(s1)
    80002b94:	00005517          	auipc	a0,0x5
    80002b98:	7f450513          	addi	a0,a0,2036 # 80008388 <states.0+0x78>
    80002b9c:	ffffe097          	auipc	ra,0xffffe
    80002ba0:	9ec080e7          	jalr	-1556(ra) # 80000588 <printf>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002ba4:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002ba8:	14302673          	csrr	a2,stval
    printf("            sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002bac:	00006517          	auipc	a0,0x6
    80002bb0:	80c50513          	addi	a0,a0,-2036 # 800083b8 <states.0+0xa8>
    80002bb4:	ffffe097          	auipc	ra,0xffffe
    80002bb8:	9d4080e7          	jalr	-1580(ra) # 80000588 <printf>
    setkilled(p);
    80002bbc:	8526                	mv	a0,s1
    80002bbe:	00000097          	auipc	ra,0x0
    80002bc2:	99c080e7          	jalr	-1636(ra) # 8000255a <setkilled>
    80002bc6:	bf35                	j	80002b02 <usertrap+0x98>
  if (killed(p))
    80002bc8:	4901                	li	s2,0
    exit(-1);
    80002bca:	557d                	li	a0,-1
    80002bcc:	00000097          	auipc	ra,0x0
    80002bd0:	846080e7          	jalr	-1978(ra) # 80002412 <exit>
  if (which_dev == 2)
    80002bd4:	4789                	li	a5,2
    80002bd6:	f2f91ce3          	bne	s2,a5,80002b0e <usertrap+0xa4>
    yield();
    80002bda:	fffff097          	auipc	ra,0xfffff
    80002bde:	6c8080e7          	jalr	1736(ra) # 800022a2 <yield>
    80002be2:	b735                	j	80002b0e <usertrap+0xa4>

0000000080002be4 <kerneltrap>:
{
    80002be4:	7179                	addi	sp,sp,-48
    80002be6:	f406                	sd	ra,40(sp)
    80002be8:	f022                	sd	s0,32(sp)
    80002bea:	ec26                	sd	s1,24(sp)
    80002bec:	e84a                	sd	s2,16(sp)
    80002bee:	e44e                	sd	s3,8(sp)
    80002bf0:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002bf2:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002bf6:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    80002bfa:	142029f3          	csrr	s3,scause
  if ((sstatus & SSTATUS_SPP) == 0)
    80002bfe:	1004f793          	andi	a5,s1,256
    80002c02:	cb85                	beqz	a5,80002c32 <kerneltrap+0x4e>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002c04:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002c08:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    80002c0a:	ef85                	bnez	a5,80002c42 <kerneltrap+0x5e>
  if ((which_dev = devintr()) == 0)
    80002c0c:	00000097          	auipc	ra,0x0
    80002c10:	dbc080e7          	jalr	-580(ra) # 800029c8 <devintr>
    80002c14:	cd1d                	beqz	a0,80002c52 <kerneltrap+0x6e>
  if (which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002c16:	4789                	li	a5,2
    80002c18:	06f50a63          	beq	a0,a5,80002c8c <kerneltrap+0xa8>
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002c1c:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002c20:	10049073          	csrw	sstatus,s1
}
    80002c24:	70a2                	ld	ra,40(sp)
    80002c26:	7402                	ld	s0,32(sp)
    80002c28:	64e2                	ld	s1,24(sp)
    80002c2a:	6942                	ld	s2,16(sp)
    80002c2c:	69a2                	ld	s3,8(sp)
    80002c2e:	6145                	addi	sp,sp,48
    80002c30:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002c32:	00005517          	auipc	a0,0x5
    80002c36:	7a650513          	addi	a0,a0,1958 # 800083d8 <states.0+0xc8>
    80002c3a:	ffffe097          	auipc	ra,0xffffe
    80002c3e:	904080e7          	jalr	-1788(ra) # 8000053e <panic>
    panic("kerneltrap: interrupts enabled");
    80002c42:	00005517          	auipc	a0,0x5
    80002c46:	7be50513          	addi	a0,a0,1982 # 80008400 <states.0+0xf0>
    80002c4a:	ffffe097          	auipc	ra,0xffffe
    80002c4e:	8f4080e7          	jalr	-1804(ra) # 8000053e <panic>
    printf("scause %p\n", scause);
    80002c52:	85ce                	mv	a1,s3
    80002c54:	00005517          	auipc	a0,0x5
    80002c58:	7cc50513          	addi	a0,a0,1996 # 80008420 <states.0+0x110>
    80002c5c:	ffffe097          	auipc	ra,0xffffe
    80002c60:	92c080e7          	jalr	-1748(ra) # 80000588 <printf>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002c64:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002c68:	14302673          	csrr	a2,stval
    printf("sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002c6c:	00005517          	auipc	a0,0x5
    80002c70:	7c450513          	addi	a0,a0,1988 # 80008430 <states.0+0x120>
    80002c74:	ffffe097          	auipc	ra,0xffffe
    80002c78:	914080e7          	jalr	-1772(ra) # 80000588 <printf>
    panic("kerneltrap");
    80002c7c:	00005517          	auipc	a0,0x5
    80002c80:	7cc50513          	addi	a0,a0,1996 # 80008448 <states.0+0x138>
    80002c84:	ffffe097          	auipc	ra,0xffffe
    80002c88:	8ba080e7          	jalr	-1862(ra) # 8000053e <panic>
  if (which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002c8c:	fffff097          	auipc	ra,0xfffff
    80002c90:	fa6080e7          	jalr	-90(ra) # 80001c32 <myproc>
    80002c94:	d541                	beqz	a0,80002c1c <kerneltrap+0x38>
    80002c96:	fffff097          	auipc	ra,0xfffff
    80002c9a:	f9c080e7          	jalr	-100(ra) # 80001c32 <myproc>
    80002c9e:	4d18                	lw	a4,24(a0)
    80002ca0:	4791                	li	a5,4
    80002ca2:	f6f71de3          	bne	a4,a5,80002c1c <kerneltrap+0x38>
    yield();
    80002ca6:	fffff097          	auipc	ra,0xfffff
    80002caa:	5fc080e7          	jalr	1532(ra) # 800022a2 <yield>
    80002cae:	b7bd                	j	80002c1c <kerneltrap+0x38>

0000000080002cb0 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002cb0:	1101                	addi	sp,sp,-32
    80002cb2:	ec06                	sd	ra,24(sp)
    80002cb4:	e822                	sd	s0,16(sp)
    80002cb6:	e426                	sd	s1,8(sp)
    80002cb8:	1000                	addi	s0,sp,32
    80002cba:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002cbc:	fffff097          	auipc	ra,0xfffff
    80002cc0:	f76080e7          	jalr	-138(ra) # 80001c32 <myproc>
  switch (n) {
    80002cc4:	4795                	li	a5,5
    80002cc6:	0497e163          	bltu	a5,s1,80002d08 <argraw+0x58>
    80002cca:	048a                	slli	s1,s1,0x2
    80002ccc:	00005717          	auipc	a4,0x5
    80002cd0:	7b470713          	addi	a4,a4,1972 # 80008480 <states.0+0x170>
    80002cd4:	94ba                	add	s1,s1,a4
    80002cd6:	409c                	lw	a5,0(s1)
    80002cd8:	97ba                	add	a5,a5,a4
    80002cda:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002cdc:	6d3c                	ld	a5,88(a0)
    80002cde:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002ce0:	60e2                	ld	ra,24(sp)
    80002ce2:	6442                	ld	s0,16(sp)
    80002ce4:	64a2                	ld	s1,8(sp)
    80002ce6:	6105                	addi	sp,sp,32
    80002ce8:	8082                	ret
    return p->trapframe->a1;
    80002cea:	6d3c                	ld	a5,88(a0)
    80002cec:	7fa8                	ld	a0,120(a5)
    80002cee:	bfcd                	j	80002ce0 <argraw+0x30>
    return p->trapframe->a2;
    80002cf0:	6d3c                	ld	a5,88(a0)
    80002cf2:	63c8                	ld	a0,128(a5)
    80002cf4:	b7f5                	j	80002ce0 <argraw+0x30>
    return p->trapframe->a3;
    80002cf6:	6d3c                	ld	a5,88(a0)
    80002cf8:	67c8                	ld	a0,136(a5)
    80002cfa:	b7dd                	j	80002ce0 <argraw+0x30>
    return p->trapframe->a4;
    80002cfc:	6d3c                	ld	a5,88(a0)
    80002cfe:	6bc8                	ld	a0,144(a5)
    80002d00:	b7c5                	j	80002ce0 <argraw+0x30>
    return p->trapframe->a5;
    80002d02:	6d3c                	ld	a5,88(a0)
    80002d04:	6fc8                	ld	a0,152(a5)
    80002d06:	bfe9                	j	80002ce0 <argraw+0x30>
  panic("argraw");
    80002d08:	00005517          	auipc	a0,0x5
    80002d0c:	75050513          	addi	a0,a0,1872 # 80008458 <states.0+0x148>
    80002d10:	ffffe097          	auipc	ra,0xffffe
    80002d14:	82e080e7          	jalr	-2002(ra) # 8000053e <panic>

0000000080002d18 <fetchaddr>:
{
    80002d18:	1101                	addi	sp,sp,-32
    80002d1a:	ec06                	sd	ra,24(sp)
    80002d1c:	e822                	sd	s0,16(sp)
    80002d1e:	e426                	sd	s1,8(sp)
    80002d20:	e04a                	sd	s2,0(sp)
    80002d22:	1000                	addi	s0,sp,32
    80002d24:	84aa                	mv	s1,a0
    80002d26:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002d28:	fffff097          	auipc	ra,0xfffff
    80002d2c:	f0a080e7          	jalr	-246(ra) # 80001c32 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002d30:	653c                	ld	a5,72(a0)
    80002d32:	02f4f863          	bgeu	s1,a5,80002d62 <fetchaddr+0x4a>
    80002d36:	00848713          	addi	a4,s1,8
    80002d3a:	02e7e663          	bltu	a5,a4,80002d66 <fetchaddr+0x4e>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002d3e:	46a1                	li	a3,8
    80002d40:	8626                	mv	a2,s1
    80002d42:	85ca                	mv	a1,s2
    80002d44:	6928                	ld	a0,80(a0)
    80002d46:	fffff097          	auipc	ra,0xfffff
    80002d4a:	c34080e7          	jalr	-972(ra) # 8000197a <copyin>
    80002d4e:	00a03533          	snez	a0,a0
    80002d52:	40a00533          	neg	a0,a0
}
    80002d56:	60e2                	ld	ra,24(sp)
    80002d58:	6442                	ld	s0,16(sp)
    80002d5a:	64a2                	ld	s1,8(sp)
    80002d5c:	6902                	ld	s2,0(sp)
    80002d5e:	6105                	addi	sp,sp,32
    80002d60:	8082                	ret
    return -1;
    80002d62:	557d                	li	a0,-1
    80002d64:	bfcd                	j	80002d56 <fetchaddr+0x3e>
    80002d66:	557d                	li	a0,-1
    80002d68:	b7fd                	j	80002d56 <fetchaddr+0x3e>

0000000080002d6a <fetchstr>:
{
    80002d6a:	7179                	addi	sp,sp,-48
    80002d6c:	f406                	sd	ra,40(sp)
    80002d6e:	f022                	sd	s0,32(sp)
    80002d70:	ec26                	sd	s1,24(sp)
    80002d72:	e84a                	sd	s2,16(sp)
    80002d74:	e44e                	sd	s3,8(sp)
    80002d76:	1800                	addi	s0,sp,48
    80002d78:	892a                	mv	s2,a0
    80002d7a:	84ae                	mv	s1,a1
    80002d7c:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002d7e:	fffff097          	auipc	ra,0xfffff
    80002d82:	eb4080e7          	jalr	-332(ra) # 80001c32 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002d86:	86ce                	mv	a3,s3
    80002d88:	864a                	mv	a2,s2
    80002d8a:	85a6                	mv	a1,s1
    80002d8c:	6928                	ld	a0,80(a0)
    80002d8e:	fffff097          	auipc	ra,0xfffff
    80002d92:	c7a080e7          	jalr	-902(ra) # 80001a08 <copyinstr>
    80002d96:	00054e63          	bltz	a0,80002db2 <fetchstr+0x48>
  return strlen(buf);
    80002d9a:	8526                	mv	a0,s1
    80002d9c:	ffffe097          	auipc	ra,0xffffe
    80002da0:	20c080e7          	jalr	524(ra) # 80000fa8 <strlen>
}
    80002da4:	70a2                	ld	ra,40(sp)
    80002da6:	7402                	ld	s0,32(sp)
    80002da8:	64e2                	ld	s1,24(sp)
    80002daa:	6942                	ld	s2,16(sp)
    80002dac:	69a2                	ld	s3,8(sp)
    80002dae:	6145                	addi	sp,sp,48
    80002db0:	8082                	ret
    return -1;
    80002db2:	557d                	li	a0,-1
    80002db4:	bfc5                	j	80002da4 <fetchstr+0x3a>

0000000080002db6 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002db6:	1101                	addi	sp,sp,-32
    80002db8:	ec06                	sd	ra,24(sp)
    80002dba:	e822                	sd	s0,16(sp)
    80002dbc:	e426                	sd	s1,8(sp)
    80002dbe:	1000                	addi	s0,sp,32
    80002dc0:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002dc2:	00000097          	auipc	ra,0x0
    80002dc6:	eee080e7          	jalr	-274(ra) # 80002cb0 <argraw>
    80002dca:	c088                	sw	a0,0(s1)
}
    80002dcc:	60e2                	ld	ra,24(sp)
    80002dce:	6442                	ld	s0,16(sp)
    80002dd0:	64a2                	ld	s1,8(sp)
    80002dd2:	6105                	addi	sp,sp,32
    80002dd4:	8082                	ret

0000000080002dd6 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002dd6:	1101                	addi	sp,sp,-32
    80002dd8:	ec06                	sd	ra,24(sp)
    80002dda:	e822                	sd	s0,16(sp)
    80002ddc:	e426                	sd	s1,8(sp)
    80002dde:	1000                	addi	s0,sp,32
    80002de0:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002de2:	00000097          	auipc	ra,0x0
    80002de6:	ece080e7          	jalr	-306(ra) # 80002cb0 <argraw>
    80002dea:	e088                	sd	a0,0(s1)
}
    80002dec:	60e2                	ld	ra,24(sp)
    80002dee:	6442                	ld	s0,16(sp)
    80002df0:	64a2                	ld	s1,8(sp)
    80002df2:	6105                	addi	sp,sp,32
    80002df4:	8082                	ret

0000000080002df6 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002df6:	7179                	addi	sp,sp,-48
    80002df8:	f406                	sd	ra,40(sp)
    80002dfa:	f022                	sd	s0,32(sp)
    80002dfc:	ec26                	sd	s1,24(sp)
    80002dfe:	e84a                	sd	s2,16(sp)
    80002e00:	1800                	addi	s0,sp,48
    80002e02:	84ae                	mv	s1,a1
    80002e04:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002e06:	fd840593          	addi	a1,s0,-40
    80002e0a:	00000097          	auipc	ra,0x0
    80002e0e:	fcc080e7          	jalr	-52(ra) # 80002dd6 <argaddr>
  return fetchstr(addr, buf, max);
    80002e12:	864a                	mv	a2,s2
    80002e14:	85a6                	mv	a1,s1
    80002e16:	fd843503          	ld	a0,-40(s0)
    80002e1a:	00000097          	auipc	ra,0x0
    80002e1e:	f50080e7          	jalr	-176(ra) # 80002d6a <fetchstr>
}
    80002e22:	70a2                	ld	ra,40(sp)
    80002e24:	7402                	ld	s0,32(sp)
    80002e26:	64e2                	ld	s1,24(sp)
    80002e28:	6942                	ld	s2,16(sp)
    80002e2a:	6145                	addi	sp,sp,48
    80002e2c:	8082                	ret

0000000080002e2e <syscall>:
[SYS_close]   sys_close,
};

void
syscall(void)
{
    80002e2e:	1101                	addi	sp,sp,-32
    80002e30:	ec06                	sd	ra,24(sp)
    80002e32:	e822                	sd	s0,16(sp)
    80002e34:	e426                	sd	s1,8(sp)
    80002e36:	e04a                	sd	s2,0(sp)
    80002e38:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002e3a:	fffff097          	auipc	ra,0xfffff
    80002e3e:	df8080e7          	jalr	-520(ra) # 80001c32 <myproc>
    80002e42:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002e44:	05853903          	ld	s2,88(a0)
    80002e48:	0a893783          	ld	a5,168(s2)
    80002e4c:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002e50:	37fd                	addiw	a5,a5,-1
    80002e52:	4751                	li	a4,20
    80002e54:	00f76f63          	bltu	a4,a5,80002e72 <syscall+0x44>
    80002e58:	00369713          	slli	a4,a3,0x3
    80002e5c:	00005797          	auipc	a5,0x5
    80002e60:	63c78793          	addi	a5,a5,1596 # 80008498 <syscalls>
    80002e64:	97ba                	add	a5,a5,a4
    80002e66:	639c                	ld	a5,0(a5)
    80002e68:	c789                	beqz	a5,80002e72 <syscall+0x44>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002e6a:	9782                	jalr	a5
    80002e6c:	06a93823          	sd	a0,112(s2)
    80002e70:	a839                	j	80002e8e <syscall+0x60>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002e72:	15848613          	addi	a2,s1,344
    80002e76:	588c                	lw	a1,48(s1)
    80002e78:	00005517          	auipc	a0,0x5
    80002e7c:	5e850513          	addi	a0,a0,1512 # 80008460 <states.0+0x150>
    80002e80:	ffffd097          	auipc	ra,0xffffd
    80002e84:	708080e7          	jalr	1800(ra) # 80000588 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002e88:	6cbc                	ld	a5,88(s1)
    80002e8a:	577d                	li	a4,-1
    80002e8c:	fbb8                	sd	a4,112(a5)
  }
}
    80002e8e:	60e2                	ld	ra,24(sp)
    80002e90:	6442                	ld	s0,16(sp)
    80002e92:	64a2                	ld	s1,8(sp)
    80002e94:	6902                	ld	s2,0(sp)
    80002e96:	6105                	addi	sp,sp,32
    80002e98:	8082                	ret

0000000080002e9a <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002e9a:	1101                	addi	sp,sp,-32
    80002e9c:	ec06                	sd	ra,24(sp)
    80002e9e:	e822                	sd	s0,16(sp)
    80002ea0:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002ea2:	fec40593          	addi	a1,s0,-20
    80002ea6:	4501                	li	a0,0
    80002ea8:	00000097          	auipc	ra,0x0
    80002eac:	f0e080e7          	jalr	-242(ra) # 80002db6 <argint>
  exit(n);
    80002eb0:	fec42503          	lw	a0,-20(s0)
    80002eb4:	fffff097          	auipc	ra,0xfffff
    80002eb8:	55e080e7          	jalr	1374(ra) # 80002412 <exit>
  return 0;  // not reached
}
    80002ebc:	4501                	li	a0,0
    80002ebe:	60e2                	ld	ra,24(sp)
    80002ec0:	6442                	ld	s0,16(sp)
    80002ec2:	6105                	addi	sp,sp,32
    80002ec4:	8082                	ret

0000000080002ec6 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002ec6:	1141                	addi	sp,sp,-16
    80002ec8:	e406                	sd	ra,8(sp)
    80002eca:	e022                	sd	s0,0(sp)
    80002ecc:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002ece:	fffff097          	auipc	ra,0xfffff
    80002ed2:	d64080e7          	jalr	-668(ra) # 80001c32 <myproc>
}
    80002ed6:	5908                	lw	a0,48(a0)
    80002ed8:	60a2                	ld	ra,8(sp)
    80002eda:	6402                	ld	s0,0(sp)
    80002edc:	0141                	addi	sp,sp,16
    80002ede:	8082                	ret

0000000080002ee0 <sys_fork>:

uint64
sys_fork(void)
{
    80002ee0:	1141                	addi	sp,sp,-16
    80002ee2:	e406                	sd	ra,8(sp)
    80002ee4:	e022                	sd	s0,0(sp)
    80002ee6:	0800                	addi	s0,sp,16
  return fork();
    80002ee8:	fffff097          	auipc	ra,0xfffff
    80002eec:	104080e7          	jalr	260(ra) # 80001fec <fork>
}
    80002ef0:	60a2                	ld	ra,8(sp)
    80002ef2:	6402                	ld	s0,0(sp)
    80002ef4:	0141                	addi	sp,sp,16
    80002ef6:	8082                	ret

0000000080002ef8 <sys_wait>:

uint64
sys_wait(void)
{
    80002ef8:	1101                	addi	sp,sp,-32
    80002efa:	ec06                	sd	ra,24(sp)
    80002efc:	e822                	sd	s0,16(sp)
    80002efe:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002f00:	fe840593          	addi	a1,s0,-24
    80002f04:	4501                	li	a0,0
    80002f06:	00000097          	auipc	ra,0x0
    80002f0a:	ed0080e7          	jalr	-304(ra) # 80002dd6 <argaddr>
  return wait(p);
    80002f0e:	fe843503          	ld	a0,-24(s0)
    80002f12:	fffff097          	auipc	ra,0xfffff
    80002f16:	6a6080e7          	jalr	1702(ra) # 800025b8 <wait>
}
    80002f1a:	60e2                	ld	ra,24(sp)
    80002f1c:	6442                	ld	s0,16(sp)
    80002f1e:	6105                	addi	sp,sp,32
    80002f20:	8082                	ret

0000000080002f22 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002f22:	7179                	addi	sp,sp,-48
    80002f24:	f406                	sd	ra,40(sp)
    80002f26:	f022                	sd	s0,32(sp)
    80002f28:	ec26                	sd	s1,24(sp)
    80002f2a:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002f2c:	fdc40593          	addi	a1,s0,-36
    80002f30:	4501                	li	a0,0
    80002f32:	00000097          	auipc	ra,0x0
    80002f36:	e84080e7          	jalr	-380(ra) # 80002db6 <argint>
  addr = myproc()->sz;
    80002f3a:	fffff097          	auipc	ra,0xfffff
    80002f3e:	cf8080e7          	jalr	-776(ra) # 80001c32 <myproc>
    80002f42:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80002f44:	fdc42503          	lw	a0,-36(s0)
    80002f48:	fffff097          	auipc	ra,0xfffff
    80002f4c:	048080e7          	jalr	72(ra) # 80001f90 <growproc>
    80002f50:	00054863          	bltz	a0,80002f60 <sys_sbrk+0x3e>
    return -1;
  return addr;
}
    80002f54:	8526                	mv	a0,s1
    80002f56:	70a2                	ld	ra,40(sp)
    80002f58:	7402                	ld	s0,32(sp)
    80002f5a:	64e2                	ld	s1,24(sp)
    80002f5c:	6145                	addi	sp,sp,48
    80002f5e:	8082                	ret
    return -1;
    80002f60:	54fd                	li	s1,-1
    80002f62:	bfcd                	j	80002f54 <sys_sbrk+0x32>

0000000080002f64 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002f64:	7139                	addi	sp,sp,-64
    80002f66:	fc06                	sd	ra,56(sp)
    80002f68:	f822                	sd	s0,48(sp)
    80002f6a:	f426                	sd	s1,40(sp)
    80002f6c:	f04a                	sd	s2,32(sp)
    80002f6e:	ec4e                	sd	s3,24(sp)
    80002f70:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002f72:	fcc40593          	addi	a1,s0,-52
    80002f76:	4501                	li	a0,0
    80002f78:	00000097          	auipc	ra,0x0
    80002f7c:	e3e080e7          	jalr	-450(ra) # 80002db6 <argint>
  if(n < 0)
    80002f80:	fcc42783          	lw	a5,-52(s0)
    80002f84:	0607cf63          	bltz	a5,80003002 <sys_sleep+0x9e>
    n = 0;
  acquire(&tickslock);
    80002f88:	00234517          	auipc	a0,0x234
    80002f8c:	a4050513          	addi	a0,a0,-1472 # 802369c8 <tickslock>
    80002f90:	ffffe097          	auipc	ra,0xffffe
    80002f94:	da0080e7          	jalr	-608(ra) # 80000d30 <acquire>
  ticks0 = ticks;
    80002f98:	00006917          	auipc	s2,0x6
    80002f9c:	97892903          	lw	s2,-1672(s2) # 80008910 <ticks>
  while(ticks - ticks0 < n){
    80002fa0:	fcc42783          	lw	a5,-52(s0)
    80002fa4:	cf9d                	beqz	a5,80002fe2 <sys_sleep+0x7e>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002fa6:	00234997          	auipc	s3,0x234
    80002faa:	a2298993          	addi	s3,s3,-1502 # 802369c8 <tickslock>
    80002fae:	00006497          	auipc	s1,0x6
    80002fb2:	96248493          	addi	s1,s1,-1694 # 80008910 <ticks>
    if(killed(myproc())){
    80002fb6:	fffff097          	auipc	ra,0xfffff
    80002fba:	c7c080e7          	jalr	-900(ra) # 80001c32 <myproc>
    80002fbe:	fffff097          	auipc	ra,0xfffff
    80002fc2:	5c8080e7          	jalr	1480(ra) # 80002586 <killed>
    80002fc6:	e129                	bnez	a0,80003008 <sys_sleep+0xa4>
    sleep(&ticks, &tickslock);
    80002fc8:	85ce                	mv	a1,s3
    80002fca:	8526                	mv	a0,s1
    80002fcc:	fffff097          	auipc	ra,0xfffff
    80002fd0:	312080e7          	jalr	786(ra) # 800022de <sleep>
  while(ticks - ticks0 < n){
    80002fd4:	409c                	lw	a5,0(s1)
    80002fd6:	412787bb          	subw	a5,a5,s2
    80002fda:	fcc42703          	lw	a4,-52(s0)
    80002fde:	fce7ece3          	bltu	a5,a4,80002fb6 <sys_sleep+0x52>
  }
  release(&tickslock);
    80002fe2:	00234517          	auipc	a0,0x234
    80002fe6:	9e650513          	addi	a0,a0,-1562 # 802369c8 <tickslock>
    80002fea:	ffffe097          	auipc	ra,0xffffe
    80002fee:	dfa080e7          	jalr	-518(ra) # 80000de4 <release>
  return 0;
    80002ff2:	4501                	li	a0,0
}
    80002ff4:	70e2                	ld	ra,56(sp)
    80002ff6:	7442                	ld	s0,48(sp)
    80002ff8:	74a2                	ld	s1,40(sp)
    80002ffa:	7902                	ld	s2,32(sp)
    80002ffc:	69e2                	ld	s3,24(sp)
    80002ffe:	6121                	addi	sp,sp,64
    80003000:	8082                	ret
    n = 0;
    80003002:	fc042623          	sw	zero,-52(s0)
    80003006:	b749                	j	80002f88 <sys_sleep+0x24>
      release(&tickslock);
    80003008:	00234517          	auipc	a0,0x234
    8000300c:	9c050513          	addi	a0,a0,-1600 # 802369c8 <tickslock>
    80003010:	ffffe097          	auipc	ra,0xffffe
    80003014:	dd4080e7          	jalr	-556(ra) # 80000de4 <release>
      return -1;
    80003018:	557d                	li	a0,-1
    8000301a:	bfe9                	j	80002ff4 <sys_sleep+0x90>

000000008000301c <sys_kill>:

uint64
sys_kill(void)
{
    8000301c:	1101                	addi	sp,sp,-32
    8000301e:	ec06                	sd	ra,24(sp)
    80003020:	e822                	sd	s0,16(sp)
    80003022:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80003024:	fec40593          	addi	a1,s0,-20
    80003028:	4501                	li	a0,0
    8000302a:	00000097          	auipc	ra,0x0
    8000302e:	d8c080e7          	jalr	-628(ra) # 80002db6 <argint>
  return kill(pid);
    80003032:	fec42503          	lw	a0,-20(s0)
    80003036:	fffff097          	auipc	ra,0xfffff
    8000303a:	4b2080e7          	jalr	1202(ra) # 800024e8 <kill>
}
    8000303e:	60e2                	ld	ra,24(sp)
    80003040:	6442                	ld	s0,16(sp)
    80003042:	6105                	addi	sp,sp,32
    80003044:	8082                	ret

0000000080003046 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80003046:	1101                	addi	sp,sp,-32
    80003048:	ec06                	sd	ra,24(sp)
    8000304a:	e822                	sd	s0,16(sp)
    8000304c:	e426                	sd	s1,8(sp)
    8000304e:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80003050:	00234517          	auipc	a0,0x234
    80003054:	97850513          	addi	a0,a0,-1672 # 802369c8 <tickslock>
    80003058:	ffffe097          	auipc	ra,0xffffe
    8000305c:	cd8080e7          	jalr	-808(ra) # 80000d30 <acquire>
  xticks = ticks;
    80003060:	00006497          	auipc	s1,0x6
    80003064:	8b04a483          	lw	s1,-1872(s1) # 80008910 <ticks>
  release(&tickslock);
    80003068:	00234517          	auipc	a0,0x234
    8000306c:	96050513          	addi	a0,a0,-1696 # 802369c8 <tickslock>
    80003070:	ffffe097          	auipc	ra,0xffffe
    80003074:	d74080e7          	jalr	-652(ra) # 80000de4 <release>
  return xticks;
}
    80003078:	02049513          	slli	a0,s1,0x20
    8000307c:	9101                	srli	a0,a0,0x20
    8000307e:	60e2                	ld	ra,24(sp)
    80003080:	6442                	ld	s0,16(sp)
    80003082:	64a2                	ld	s1,8(sp)
    80003084:	6105                	addi	sp,sp,32
    80003086:	8082                	ret

0000000080003088 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80003088:	7179                	addi	sp,sp,-48
    8000308a:	f406                	sd	ra,40(sp)
    8000308c:	f022                	sd	s0,32(sp)
    8000308e:	ec26                	sd	s1,24(sp)
    80003090:	e84a                	sd	s2,16(sp)
    80003092:	e44e                	sd	s3,8(sp)
    80003094:	e052                	sd	s4,0(sp)
    80003096:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80003098:	00005597          	auipc	a1,0x5
    8000309c:	4b058593          	addi	a1,a1,1200 # 80008548 <syscalls+0xb0>
    800030a0:	00234517          	auipc	a0,0x234
    800030a4:	94050513          	addi	a0,a0,-1728 # 802369e0 <bcache>
    800030a8:	ffffe097          	auipc	ra,0xffffe
    800030ac:	bf8080e7          	jalr	-1032(ra) # 80000ca0 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    800030b0:	0023c797          	auipc	a5,0x23c
    800030b4:	93078793          	addi	a5,a5,-1744 # 8023e9e0 <bcache+0x8000>
    800030b8:	0023c717          	auipc	a4,0x23c
    800030bc:	b9070713          	addi	a4,a4,-1136 # 8023ec48 <bcache+0x8268>
    800030c0:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    800030c4:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    800030c8:	00234497          	auipc	s1,0x234
    800030cc:	93048493          	addi	s1,s1,-1744 # 802369f8 <bcache+0x18>
    b->next = bcache.head.next;
    800030d0:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    800030d2:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    800030d4:	00005a17          	auipc	s4,0x5
    800030d8:	47ca0a13          	addi	s4,s4,1148 # 80008550 <syscalls+0xb8>
    b->next = bcache.head.next;
    800030dc:	2b893783          	ld	a5,696(s2)
    800030e0:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    800030e2:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    800030e6:	85d2                	mv	a1,s4
    800030e8:	01048513          	addi	a0,s1,16
    800030ec:	00001097          	auipc	ra,0x1
    800030f0:	4ca080e7          	jalr	1226(ra) # 800045b6 <initsleeplock>
    bcache.head.next->prev = b;
    800030f4:	2b893783          	ld	a5,696(s2)
    800030f8:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    800030fa:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    800030fe:	45848493          	addi	s1,s1,1112
    80003102:	fd349de3          	bne	s1,s3,800030dc <binit+0x54>
  }
}
    80003106:	70a2                	ld	ra,40(sp)
    80003108:	7402                	ld	s0,32(sp)
    8000310a:	64e2                	ld	s1,24(sp)
    8000310c:	6942                	ld	s2,16(sp)
    8000310e:	69a2                	ld	s3,8(sp)
    80003110:	6a02                	ld	s4,0(sp)
    80003112:	6145                	addi	sp,sp,48
    80003114:	8082                	ret

0000000080003116 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80003116:	7179                	addi	sp,sp,-48
    80003118:	f406                	sd	ra,40(sp)
    8000311a:	f022                	sd	s0,32(sp)
    8000311c:	ec26                	sd	s1,24(sp)
    8000311e:	e84a                	sd	s2,16(sp)
    80003120:	e44e                	sd	s3,8(sp)
    80003122:	1800                	addi	s0,sp,48
    80003124:	892a                	mv	s2,a0
    80003126:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80003128:	00234517          	auipc	a0,0x234
    8000312c:	8b850513          	addi	a0,a0,-1864 # 802369e0 <bcache>
    80003130:	ffffe097          	auipc	ra,0xffffe
    80003134:	c00080e7          	jalr	-1024(ra) # 80000d30 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80003138:	0023c497          	auipc	s1,0x23c
    8000313c:	b604b483          	ld	s1,-1184(s1) # 8023ec98 <bcache+0x82b8>
    80003140:	0023c797          	auipc	a5,0x23c
    80003144:	b0878793          	addi	a5,a5,-1272 # 8023ec48 <bcache+0x8268>
    80003148:	02f48f63          	beq	s1,a5,80003186 <bread+0x70>
    8000314c:	873e                	mv	a4,a5
    8000314e:	a021                	j	80003156 <bread+0x40>
    80003150:	68a4                	ld	s1,80(s1)
    80003152:	02e48a63          	beq	s1,a4,80003186 <bread+0x70>
    if(b->dev == dev && b->blockno == blockno){
    80003156:	449c                	lw	a5,8(s1)
    80003158:	ff279ce3          	bne	a5,s2,80003150 <bread+0x3a>
    8000315c:	44dc                	lw	a5,12(s1)
    8000315e:	ff3799e3          	bne	a5,s3,80003150 <bread+0x3a>
      b->refcnt++;
    80003162:	40bc                	lw	a5,64(s1)
    80003164:	2785                	addiw	a5,a5,1
    80003166:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80003168:	00234517          	auipc	a0,0x234
    8000316c:	87850513          	addi	a0,a0,-1928 # 802369e0 <bcache>
    80003170:	ffffe097          	auipc	ra,0xffffe
    80003174:	c74080e7          	jalr	-908(ra) # 80000de4 <release>
      acquiresleep(&b->lock);
    80003178:	01048513          	addi	a0,s1,16
    8000317c:	00001097          	auipc	ra,0x1
    80003180:	474080e7          	jalr	1140(ra) # 800045f0 <acquiresleep>
      return b;
    80003184:	a8b9                	j	800031e2 <bread+0xcc>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80003186:	0023c497          	auipc	s1,0x23c
    8000318a:	b0a4b483          	ld	s1,-1270(s1) # 8023ec90 <bcache+0x82b0>
    8000318e:	0023c797          	auipc	a5,0x23c
    80003192:	aba78793          	addi	a5,a5,-1350 # 8023ec48 <bcache+0x8268>
    80003196:	00f48863          	beq	s1,a5,800031a6 <bread+0x90>
    8000319a:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    8000319c:	40bc                	lw	a5,64(s1)
    8000319e:	cf81                	beqz	a5,800031b6 <bread+0xa0>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800031a0:	64a4                	ld	s1,72(s1)
    800031a2:	fee49de3          	bne	s1,a4,8000319c <bread+0x86>
  panic("bget: no buffers");
    800031a6:	00005517          	auipc	a0,0x5
    800031aa:	3b250513          	addi	a0,a0,946 # 80008558 <syscalls+0xc0>
    800031ae:	ffffd097          	auipc	ra,0xffffd
    800031b2:	390080e7          	jalr	912(ra) # 8000053e <panic>
      b->dev = dev;
    800031b6:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    800031ba:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    800031be:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    800031c2:	4785                	li	a5,1
    800031c4:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800031c6:	00234517          	auipc	a0,0x234
    800031ca:	81a50513          	addi	a0,a0,-2022 # 802369e0 <bcache>
    800031ce:	ffffe097          	auipc	ra,0xffffe
    800031d2:	c16080e7          	jalr	-1002(ra) # 80000de4 <release>
      acquiresleep(&b->lock);
    800031d6:	01048513          	addi	a0,s1,16
    800031da:	00001097          	auipc	ra,0x1
    800031de:	416080e7          	jalr	1046(ra) # 800045f0 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    800031e2:	409c                	lw	a5,0(s1)
    800031e4:	cb89                	beqz	a5,800031f6 <bread+0xe0>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    800031e6:	8526                	mv	a0,s1
    800031e8:	70a2                	ld	ra,40(sp)
    800031ea:	7402                	ld	s0,32(sp)
    800031ec:	64e2                	ld	s1,24(sp)
    800031ee:	6942                	ld	s2,16(sp)
    800031f0:	69a2                	ld	s3,8(sp)
    800031f2:	6145                	addi	sp,sp,48
    800031f4:	8082                	ret
    virtio_disk_rw(b, 0);
    800031f6:	4581                	li	a1,0
    800031f8:	8526                	mv	a0,s1
    800031fa:	00003097          	auipc	ra,0x3
    800031fe:	faa080e7          	jalr	-86(ra) # 800061a4 <virtio_disk_rw>
    b->valid = 1;
    80003202:	4785                	li	a5,1
    80003204:	c09c                	sw	a5,0(s1)
  return b;
    80003206:	b7c5                	j	800031e6 <bread+0xd0>

0000000080003208 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80003208:	1101                	addi	sp,sp,-32
    8000320a:	ec06                	sd	ra,24(sp)
    8000320c:	e822                	sd	s0,16(sp)
    8000320e:	e426                	sd	s1,8(sp)
    80003210:	1000                	addi	s0,sp,32
    80003212:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003214:	0541                	addi	a0,a0,16
    80003216:	00001097          	auipc	ra,0x1
    8000321a:	474080e7          	jalr	1140(ra) # 8000468a <holdingsleep>
    8000321e:	cd01                	beqz	a0,80003236 <bwrite+0x2e>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80003220:	4585                	li	a1,1
    80003222:	8526                	mv	a0,s1
    80003224:	00003097          	auipc	ra,0x3
    80003228:	f80080e7          	jalr	-128(ra) # 800061a4 <virtio_disk_rw>
}
    8000322c:	60e2                	ld	ra,24(sp)
    8000322e:	6442                	ld	s0,16(sp)
    80003230:	64a2                	ld	s1,8(sp)
    80003232:	6105                	addi	sp,sp,32
    80003234:	8082                	ret
    panic("bwrite");
    80003236:	00005517          	auipc	a0,0x5
    8000323a:	33a50513          	addi	a0,a0,826 # 80008570 <syscalls+0xd8>
    8000323e:	ffffd097          	auipc	ra,0xffffd
    80003242:	300080e7          	jalr	768(ra) # 8000053e <panic>

0000000080003246 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80003246:	1101                	addi	sp,sp,-32
    80003248:	ec06                	sd	ra,24(sp)
    8000324a:	e822                	sd	s0,16(sp)
    8000324c:	e426                	sd	s1,8(sp)
    8000324e:	e04a                	sd	s2,0(sp)
    80003250:	1000                	addi	s0,sp,32
    80003252:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003254:	01050913          	addi	s2,a0,16
    80003258:	854a                	mv	a0,s2
    8000325a:	00001097          	auipc	ra,0x1
    8000325e:	430080e7          	jalr	1072(ra) # 8000468a <holdingsleep>
    80003262:	c92d                	beqz	a0,800032d4 <brelse+0x8e>
    panic("brelse");

  releasesleep(&b->lock);
    80003264:	854a                	mv	a0,s2
    80003266:	00001097          	auipc	ra,0x1
    8000326a:	3e0080e7          	jalr	992(ra) # 80004646 <releasesleep>

  acquire(&bcache.lock);
    8000326e:	00233517          	auipc	a0,0x233
    80003272:	77250513          	addi	a0,a0,1906 # 802369e0 <bcache>
    80003276:	ffffe097          	auipc	ra,0xffffe
    8000327a:	aba080e7          	jalr	-1350(ra) # 80000d30 <acquire>
  b->refcnt--;
    8000327e:	40bc                	lw	a5,64(s1)
    80003280:	37fd                	addiw	a5,a5,-1
    80003282:	0007871b          	sext.w	a4,a5
    80003286:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80003288:	eb05                	bnez	a4,800032b8 <brelse+0x72>
    // no one is waiting for it.
    b->next->prev = b->prev;
    8000328a:	68bc                	ld	a5,80(s1)
    8000328c:	64b8                	ld	a4,72(s1)
    8000328e:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    80003290:	64bc                	ld	a5,72(s1)
    80003292:	68b8                	ld	a4,80(s1)
    80003294:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80003296:	0023b797          	auipc	a5,0x23b
    8000329a:	74a78793          	addi	a5,a5,1866 # 8023e9e0 <bcache+0x8000>
    8000329e:	2b87b703          	ld	a4,696(a5)
    800032a2:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800032a4:	0023c717          	auipc	a4,0x23c
    800032a8:	9a470713          	addi	a4,a4,-1628 # 8023ec48 <bcache+0x8268>
    800032ac:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800032ae:	2b87b703          	ld	a4,696(a5)
    800032b2:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800032b4:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800032b8:	00233517          	auipc	a0,0x233
    800032bc:	72850513          	addi	a0,a0,1832 # 802369e0 <bcache>
    800032c0:	ffffe097          	auipc	ra,0xffffe
    800032c4:	b24080e7          	jalr	-1244(ra) # 80000de4 <release>
}
    800032c8:	60e2                	ld	ra,24(sp)
    800032ca:	6442                	ld	s0,16(sp)
    800032cc:	64a2                	ld	s1,8(sp)
    800032ce:	6902                	ld	s2,0(sp)
    800032d0:	6105                	addi	sp,sp,32
    800032d2:	8082                	ret
    panic("brelse");
    800032d4:	00005517          	auipc	a0,0x5
    800032d8:	2a450513          	addi	a0,a0,676 # 80008578 <syscalls+0xe0>
    800032dc:	ffffd097          	auipc	ra,0xffffd
    800032e0:	262080e7          	jalr	610(ra) # 8000053e <panic>

00000000800032e4 <bpin>:

void
bpin(struct buf *b) {
    800032e4:	1101                	addi	sp,sp,-32
    800032e6:	ec06                	sd	ra,24(sp)
    800032e8:	e822                	sd	s0,16(sp)
    800032ea:	e426                	sd	s1,8(sp)
    800032ec:	1000                	addi	s0,sp,32
    800032ee:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800032f0:	00233517          	auipc	a0,0x233
    800032f4:	6f050513          	addi	a0,a0,1776 # 802369e0 <bcache>
    800032f8:	ffffe097          	auipc	ra,0xffffe
    800032fc:	a38080e7          	jalr	-1480(ra) # 80000d30 <acquire>
  b->refcnt++;
    80003300:	40bc                	lw	a5,64(s1)
    80003302:	2785                	addiw	a5,a5,1
    80003304:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003306:	00233517          	auipc	a0,0x233
    8000330a:	6da50513          	addi	a0,a0,1754 # 802369e0 <bcache>
    8000330e:	ffffe097          	auipc	ra,0xffffe
    80003312:	ad6080e7          	jalr	-1322(ra) # 80000de4 <release>
}
    80003316:	60e2                	ld	ra,24(sp)
    80003318:	6442                	ld	s0,16(sp)
    8000331a:	64a2                	ld	s1,8(sp)
    8000331c:	6105                	addi	sp,sp,32
    8000331e:	8082                	ret

0000000080003320 <bunpin>:

void
bunpin(struct buf *b) {
    80003320:	1101                	addi	sp,sp,-32
    80003322:	ec06                	sd	ra,24(sp)
    80003324:	e822                	sd	s0,16(sp)
    80003326:	e426                	sd	s1,8(sp)
    80003328:	1000                	addi	s0,sp,32
    8000332a:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000332c:	00233517          	auipc	a0,0x233
    80003330:	6b450513          	addi	a0,a0,1716 # 802369e0 <bcache>
    80003334:	ffffe097          	auipc	ra,0xffffe
    80003338:	9fc080e7          	jalr	-1540(ra) # 80000d30 <acquire>
  b->refcnt--;
    8000333c:	40bc                	lw	a5,64(s1)
    8000333e:	37fd                	addiw	a5,a5,-1
    80003340:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003342:	00233517          	auipc	a0,0x233
    80003346:	69e50513          	addi	a0,a0,1694 # 802369e0 <bcache>
    8000334a:	ffffe097          	auipc	ra,0xffffe
    8000334e:	a9a080e7          	jalr	-1382(ra) # 80000de4 <release>
}
    80003352:	60e2                	ld	ra,24(sp)
    80003354:	6442                	ld	s0,16(sp)
    80003356:	64a2                	ld	s1,8(sp)
    80003358:	6105                	addi	sp,sp,32
    8000335a:	8082                	ret

000000008000335c <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    8000335c:	1101                	addi	sp,sp,-32
    8000335e:	ec06                	sd	ra,24(sp)
    80003360:	e822                	sd	s0,16(sp)
    80003362:	e426                	sd	s1,8(sp)
    80003364:	e04a                	sd	s2,0(sp)
    80003366:	1000                	addi	s0,sp,32
    80003368:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000336a:	00d5d59b          	srliw	a1,a1,0xd
    8000336e:	0023c797          	auipc	a5,0x23c
    80003372:	d4e7a783          	lw	a5,-690(a5) # 8023f0bc <sb+0x1c>
    80003376:	9dbd                	addw	a1,a1,a5
    80003378:	00000097          	auipc	ra,0x0
    8000337c:	d9e080e7          	jalr	-610(ra) # 80003116 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003380:	0074f713          	andi	a4,s1,7
    80003384:	4785                	li	a5,1
    80003386:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    8000338a:	14ce                	slli	s1,s1,0x33
    8000338c:	90d9                	srli	s1,s1,0x36
    8000338e:	00950733          	add	a4,a0,s1
    80003392:	05874703          	lbu	a4,88(a4)
    80003396:	00e7f6b3          	and	a3,a5,a4
    8000339a:	c69d                	beqz	a3,800033c8 <bfree+0x6c>
    8000339c:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    8000339e:	94aa                	add	s1,s1,a0
    800033a0:	fff7c793          	not	a5,a5
    800033a4:	8ff9                	and	a5,a5,a4
    800033a6:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    800033aa:	00001097          	auipc	ra,0x1
    800033ae:	126080e7          	jalr	294(ra) # 800044d0 <log_write>
  brelse(bp);
    800033b2:	854a                	mv	a0,s2
    800033b4:	00000097          	auipc	ra,0x0
    800033b8:	e92080e7          	jalr	-366(ra) # 80003246 <brelse>
}
    800033bc:	60e2                	ld	ra,24(sp)
    800033be:	6442                	ld	s0,16(sp)
    800033c0:	64a2                	ld	s1,8(sp)
    800033c2:	6902                	ld	s2,0(sp)
    800033c4:	6105                	addi	sp,sp,32
    800033c6:	8082                	ret
    panic("freeing free block");
    800033c8:	00005517          	auipc	a0,0x5
    800033cc:	1b850513          	addi	a0,a0,440 # 80008580 <syscalls+0xe8>
    800033d0:	ffffd097          	auipc	ra,0xffffd
    800033d4:	16e080e7          	jalr	366(ra) # 8000053e <panic>

00000000800033d8 <balloc>:
{
    800033d8:	711d                	addi	sp,sp,-96
    800033da:	ec86                	sd	ra,88(sp)
    800033dc:	e8a2                	sd	s0,80(sp)
    800033de:	e4a6                	sd	s1,72(sp)
    800033e0:	e0ca                	sd	s2,64(sp)
    800033e2:	fc4e                	sd	s3,56(sp)
    800033e4:	f852                	sd	s4,48(sp)
    800033e6:	f456                	sd	s5,40(sp)
    800033e8:	f05a                	sd	s6,32(sp)
    800033ea:	ec5e                	sd	s7,24(sp)
    800033ec:	e862                	sd	s8,16(sp)
    800033ee:	e466                	sd	s9,8(sp)
    800033f0:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    800033f2:	0023c797          	auipc	a5,0x23c
    800033f6:	cb27a783          	lw	a5,-846(a5) # 8023f0a4 <sb+0x4>
    800033fa:	10078163          	beqz	a5,800034fc <balloc+0x124>
    800033fe:	8baa                	mv	s7,a0
    80003400:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003402:	0023cb17          	auipc	s6,0x23c
    80003406:	c9eb0b13          	addi	s6,s6,-866 # 8023f0a0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000340a:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    8000340c:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000340e:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003410:	6c89                	lui	s9,0x2
    80003412:	a061                	j	8000349a <balloc+0xc2>
        bp->data[bi/8] |= m;  // Mark block in use.
    80003414:	974a                	add	a4,a4,s2
    80003416:	8fd5                	or	a5,a5,a3
    80003418:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    8000341c:	854a                	mv	a0,s2
    8000341e:	00001097          	auipc	ra,0x1
    80003422:	0b2080e7          	jalr	178(ra) # 800044d0 <log_write>
        brelse(bp);
    80003426:	854a                	mv	a0,s2
    80003428:	00000097          	auipc	ra,0x0
    8000342c:	e1e080e7          	jalr	-482(ra) # 80003246 <brelse>
  bp = bread(dev, bno);
    80003430:	85a6                	mv	a1,s1
    80003432:	855e                	mv	a0,s7
    80003434:	00000097          	auipc	ra,0x0
    80003438:	ce2080e7          	jalr	-798(ra) # 80003116 <bread>
    8000343c:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    8000343e:	40000613          	li	a2,1024
    80003442:	4581                	li	a1,0
    80003444:	05850513          	addi	a0,a0,88
    80003448:	ffffe097          	auipc	ra,0xffffe
    8000344c:	9e4080e7          	jalr	-1564(ra) # 80000e2c <memset>
  log_write(bp);
    80003450:	854a                	mv	a0,s2
    80003452:	00001097          	auipc	ra,0x1
    80003456:	07e080e7          	jalr	126(ra) # 800044d0 <log_write>
  brelse(bp);
    8000345a:	854a                	mv	a0,s2
    8000345c:	00000097          	auipc	ra,0x0
    80003460:	dea080e7          	jalr	-534(ra) # 80003246 <brelse>
}
    80003464:	8526                	mv	a0,s1
    80003466:	60e6                	ld	ra,88(sp)
    80003468:	6446                	ld	s0,80(sp)
    8000346a:	64a6                	ld	s1,72(sp)
    8000346c:	6906                	ld	s2,64(sp)
    8000346e:	79e2                	ld	s3,56(sp)
    80003470:	7a42                	ld	s4,48(sp)
    80003472:	7aa2                	ld	s5,40(sp)
    80003474:	7b02                	ld	s6,32(sp)
    80003476:	6be2                	ld	s7,24(sp)
    80003478:	6c42                	ld	s8,16(sp)
    8000347a:	6ca2                	ld	s9,8(sp)
    8000347c:	6125                	addi	sp,sp,96
    8000347e:	8082                	ret
    brelse(bp);
    80003480:	854a                	mv	a0,s2
    80003482:	00000097          	auipc	ra,0x0
    80003486:	dc4080e7          	jalr	-572(ra) # 80003246 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    8000348a:	015c87bb          	addw	a5,s9,s5
    8000348e:	00078a9b          	sext.w	s5,a5
    80003492:	004b2703          	lw	a4,4(s6)
    80003496:	06eaf363          	bgeu	s5,a4,800034fc <balloc+0x124>
    bp = bread(dev, BBLOCK(b, sb));
    8000349a:	41fad79b          	sraiw	a5,s5,0x1f
    8000349e:	0137d79b          	srliw	a5,a5,0x13
    800034a2:	015787bb          	addw	a5,a5,s5
    800034a6:	40d7d79b          	sraiw	a5,a5,0xd
    800034aa:	01cb2583          	lw	a1,28(s6)
    800034ae:	9dbd                	addw	a1,a1,a5
    800034b0:	855e                	mv	a0,s7
    800034b2:	00000097          	auipc	ra,0x0
    800034b6:	c64080e7          	jalr	-924(ra) # 80003116 <bread>
    800034ba:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800034bc:	004b2503          	lw	a0,4(s6)
    800034c0:	000a849b          	sext.w	s1,s5
    800034c4:	8662                	mv	a2,s8
    800034c6:	faa4fde3          	bgeu	s1,a0,80003480 <balloc+0xa8>
      m = 1 << (bi % 8);
    800034ca:	41f6579b          	sraiw	a5,a2,0x1f
    800034ce:	01d7d69b          	srliw	a3,a5,0x1d
    800034d2:	00c6873b          	addw	a4,a3,a2
    800034d6:	00777793          	andi	a5,a4,7
    800034da:	9f95                	subw	a5,a5,a3
    800034dc:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800034e0:	4037571b          	sraiw	a4,a4,0x3
    800034e4:	00e906b3          	add	a3,s2,a4
    800034e8:	0586c683          	lbu	a3,88(a3)
    800034ec:	00d7f5b3          	and	a1,a5,a3
    800034f0:	d195                	beqz	a1,80003414 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800034f2:	2605                	addiw	a2,a2,1
    800034f4:	2485                	addiw	s1,s1,1
    800034f6:	fd4618e3          	bne	a2,s4,800034c6 <balloc+0xee>
    800034fa:	b759                	j	80003480 <balloc+0xa8>
  printf("balloc: out of blocks\n");
    800034fc:	00005517          	auipc	a0,0x5
    80003500:	09c50513          	addi	a0,a0,156 # 80008598 <syscalls+0x100>
    80003504:	ffffd097          	auipc	ra,0xffffd
    80003508:	084080e7          	jalr	132(ra) # 80000588 <printf>
  return 0;
    8000350c:	4481                	li	s1,0
    8000350e:	bf99                	j	80003464 <balloc+0x8c>

0000000080003510 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80003510:	7179                	addi	sp,sp,-48
    80003512:	f406                	sd	ra,40(sp)
    80003514:	f022                	sd	s0,32(sp)
    80003516:	ec26                	sd	s1,24(sp)
    80003518:	e84a                	sd	s2,16(sp)
    8000351a:	e44e                	sd	s3,8(sp)
    8000351c:	e052                	sd	s4,0(sp)
    8000351e:	1800                	addi	s0,sp,48
    80003520:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80003522:	47ad                	li	a5,11
    80003524:	02b7e863          	bltu	a5,a1,80003554 <bmap+0x44>
    if((addr = ip->addrs[bn]) == 0){
    80003528:	02059793          	slli	a5,a1,0x20
    8000352c:	01e7d593          	srli	a1,a5,0x1e
    80003530:	00b504b3          	add	s1,a0,a1
    80003534:	0504a903          	lw	s2,80(s1)
    80003538:	06091e63          	bnez	s2,800035b4 <bmap+0xa4>
      addr = balloc(ip->dev);
    8000353c:	4108                	lw	a0,0(a0)
    8000353e:	00000097          	auipc	ra,0x0
    80003542:	e9a080e7          	jalr	-358(ra) # 800033d8 <balloc>
    80003546:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    8000354a:	06090563          	beqz	s2,800035b4 <bmap+0xa4>
        return 0;
      ip->addrs[bn] = addr;
    8000354e:	0524a823          	sw	s2,80(s1)
    80003552:	a08d                	j	800035b4 <bmap+0xa4>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003554:	ff45849b          	addiw	s1,a1,-12
    80003558:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    8000355c:	0ff00793          	li	a5,255
    80003560:	08e7e563          	bltu	a5,a4,800035ea <bmap+0xda>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80003564:	08052903          	lw	s2,128(a0)
    80003568:	00091d63          	bnez	s2,80003582 <bmap+0x72>
      addr = balloc(ip->dev);
    8000356c:	4108                	lw	a0,0(a0)
    8000356e:	00000097          	auipc	ra,0x0
    80003572:	e6a080e7          	jalr	-406(ra) # 800033d8 <balloc>
    80003576:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    8000357a:	02090d63          	beqz	s2,800035b4 <bmap+0xa4>
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000357e:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80003582:	85ca                	mv	a1,s2
    80003584:	0009a503          	lw	a0,0(s3)
    80003588:	00000097          	auipc	ra,0x0
    8000358c:	b8e080e7          	jalr	-1138(ra) # 80003116 <bread>
    80003590:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003592:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80003596:	02049713          	slli	a4,s1,0x20
    8000359a:	01e75593          	srli	a1,a4,0x1e
    8000359e:	00b784b3          	add	s1,a5,a1
    800035a2:	0004a903          	lw	s2,0(s1)
    800035a6:	02090063          	beqz	s2,800035c6 <bmap+0xb6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800035aa:	8552                	mv	a0,s4
    800035ac:	00000097          	auipc	ra,0x0
    800035b0:	c9a080e7          	jalr	-870(ra) # 80003246 <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    800035b4:	854a                	mv	a0,s2
    800035b6:	70a2                	ld	ra,40(sp)
    800035b8:	7402                	ld	s0,32(sp)
    800035ba:	64e2                	ld	s1,24(sp)
    800035bc:	6942                	ld	s2,16(sp)
    800035be:	69a2                	ld	s3,8(sp)
    800035c0:	6a02                	ld	s4,0(sp)
    800035c2:	6145                	addi	sp,sp,48
    800035c4:	8082                	ret
      addr = balloc(ip->dev);
    800035c6:	0009a503          	lw	a0,0(s3)
    800035ca:	00000097          	auipc	ra,0x0
    800035ce:	e0e080e7          	jalr	-498(ra) # 800033d8 <balloc>
    800035d2:	0005091b          	sext.w	s2,a0
      if(addr){
    800035d6:	fc090ae3          	beqz	s2,800035aa <bmap+0x9a>
        a[bn] = addr;
    800035da:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    800035de:	8552                	mv	a0,s4
    800035e0:	00001097          	auipc	ra,0x1
    800035e4:	ef0080e7          	jalr	-272(ra) # 800044d0 <log_write>
    800035e8:	b7c9                	j	800035aa <bmap+0x9a>
  panic("bmap: out of range");
    800035ea:	00005517          	auipc	a0,0x5
    800035ee:	fc650513          	addi	a0,a0,-58 # 800085b0 <syscalls+0x118>
    800035f2:	ffffd097          	auipc	ra,0xffffd
    800035f6:	f4c080e7          	jalr	-180(ra) # 8000053e <panic>

00000000800035fa <iget>:
{
    800035fa:	7179                	addi	sp,sp,-48
    800035fc:	f406                	sd	ra,40(sp)
    800035fe:	f022                	sd	s0,32(sp)
    80003600:	ec26                	sd	s1,24(sp)
    80003602:	e84a                	sd	s2,16(sp)
    80003604:	e44e                	sd	s3,8(sp)
    80003606:	e052                	sd	s4,0(sp)
    80003608:	1800                	addi	s0,sp,48
    8000360a:	89aa                	mv	s3,a0
    8000360c:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000360e:	0023c517          	auipc	a0,0x23c
    80003612:	ab250513          	addi	a0,a0,-1358 # 8023f0c0 <itable>
    80003616:	ffffd097          	auipc	ra,0xffffd
    8000361a:	71a080e7          	jalr	1818(ra) # 80000d30 <acquire>
  empty = 0;
    8000361e:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003620:	0023c497          	auipc	s1,0x23c
    80003624:	ab848493          	addi	s1,s1,-1352 # 8023f0d8 <itable+0x18>
    80003628:	0023d697          	auipc	a3,0x23d
    8000362c:	54068693          	addi	a3,a3,1344 # 80240b68 <log>
    80003630:	a039                	j	8000363e <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003632:	02090b63          	beqz	s2,80003668 <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003636:	08848493          	addi	s1,s1,136
    8000363a:	02d48a63          	beq	s1,a3,8000366e <iget+0x74>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    8000363e:	449c                	lw	a5,8(s1)
    80003640:	fef059e3          	blez	a5,80003632 <iget+0x38>
    80003644:	4098                	lw	a4,0(s1)
    80003646:	ff3716e3          	bne	a4,s3,80003632 <iget+0x38>
    8000364a:	40d8                	lw	a4,4(s1)
    8000364c:	ff4713e3          	bne	a4,s4,80003632 <iget+0x38>
      ip->ref++;
    80003650:	2785                	addiw	a5,a5,1
    80003652:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003654:	0023c517          	auipc	a0,0x23c
    80003658:	a6c50513          	addi	a0,a0,-1428 # 8023f0c0 <itable>
    8000365c:	ffffd097          	auipc	ra,0xffffd
    80003660:	788080e7          	jalr	1928(ra) # 80000de4 <release>
      return ip;
    80003664:	8926                	mv	s2,s1
    80003666:	a03d                	j	80003694 <iget+0x9a>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003668:	f7f9                	bnez	a5,80003636 <iget+0x3c>
    8000366a:	8926                	mv	s2,s1
    8000366c:	b7e9                	j	80003636 <iget+0x3c>
  if(empty == 0)
    8000366e:	02090c63          	beqz	s2,800036a6 <iget+0xac>
  ip->dev = dev;
    80003672:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003676:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    8000367a:	4785                	li	a5,1
    8000367c:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003680:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80003684:	0023c517          	auipc	a0,0x23c
    80003688:	a3c50513          	addi	a0,a0,-1476 # 8023f0c0 <itable>
    8000368c:	ffffd097          	auipc	ra,0xffffd
    80003690:	758080e7          	jalr	1880(ra) # 80000de4 <release>
}
    80003694:	854a                	mv	a0,s2
    80003696:	70a2                	ld	ra,40(sp)
    80003698:	7402                	ld	s0,32(sp)
    8000369a:	64e2                	ld	s1,24(sp)
    8000369c:	6942                	ld	s2,16(sp)
    8000369e:	69a2                	ld	s3,8(sp)
    800036a0:	6a02                	ld	s4,0(sp)
    800036a2:	6145                	addi	sp,sp,48
    800036a4:	8082                	ret
    panic("iget: no inodes");
    800036a6:	00005517          	auipc	a0,0x5
    800036aa:	f2250513          	addi	a0,a0,-222 # 800085c8 <syscalls+0x130>
    800036ae:	ffffd097          	auipc	ra,0xffffd
    800036b2:	e90080e7          	jalr	-368(ra) # 8000053e <panic>

00000000800036b6 <fsinit>:
fsinit(int dev) {
    800036b6:	7179                	addi	sp,sp,-48
    800036b8:	f406                	sd	ra,40(sp)
    800036ba:	f022                	sd	s0,32(sp)
    800036bc:	ec26                	sd	s1,24(sp)
    800036be:	e84a                	sd	s2,16(sp)
    800036c0:	e44e                	sd	s3,8(sp)
    800036c2:	1800                	addi	s0,sp,48
    800036c4:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800036c6:	4585                	li	a1,1
    800036c8:	00000097          	auipc	ra,0x0
    800036cc:	a4e080e7          	jalr	-1458(ra) # 80003116 <bread>
    800036d0:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800036d2:	0023c997          	auipc	s3,0x23c
    800036d6:	9ce98993          	addi	s3,s3,-1586 # 8023f0a0 <sb>
    800036da:	02000613          	li	a2,32
    800036de:	05850593          	addi	a1,a0,88
    800036e2:	854e                	mv	a0,s3
    800036e4:	ffffd097          	auipc	ra,0xffffd
    800036e8:	7a4080e7          	jalr	1956(ra) # 80000e88 <memmove>
  brelse(bp);
    800036ec:	8526                	mv	a0,s1
    800036ee:	00000097          	auipc	ra,0x0
    800036f2:	b58080e7          	jalr	-1192(ra) # 80003246 <brelse>
  if(sb.magic != FSMAGIC)
    800036f6:	0009a703          	lw	a4,0(s3)
    800036fa:	102037b7          	lui	a5,0x10203
    800036fe:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003702:	02f71263          	bne	a4,a5,80003726 <fsinit+0x70>
  initlog(dev, &sb);
    80003706:	0023c597          	auipc	a1,0x23c
    8000370a:	99a58593          	addi	a1,a1,-1638 # 8023f0a0 <sb>
    8000370e:	854a                	mv	a0,s2
    80003710:	00001097          	auipc	ra,0x1
    80003714:	b42080e7          	jalr	-1214(ra) # 80004252 <initlog>
}
    80003718:	70a2                	ld	ra,40(sp)
    8000371a:	7402                	ld	s0,32(sp)
    8000371c:	64e2                	ld	s1,24(sp)
    8000371e:	6942                	ld	s2,16(sp)
    80003720:	69a2                	ld	s3,8(sp)
    80003722:	6145                	addi	sp,sp,48
    80003724:	8082                	ret
    panic("invalid file system");
    80003726:	00005517          	auipc	a0,0x5
    8000372a:	eb250513          	addi	a0,a0,-334 # 800085d8 <syscalls+0x140>
    8000372e:	ffffd097          	auipc	ra,0xffffd
    80003732:	e10080e7          	jalr	-496(ra) # 8000053e <panic>

0000000080003736 <iinit>:
{
    80003736:	7179                	addi	sp,sp,-48
    80003738:	f406                	sd	ra,40(sp)
    8000373a:	f022                	sd	s0,32(sp)
    8000373c:	ec26                	sd	s1,24(sp)
    8000373e:	e84a                	sd	s2,16(sp)
    80003740:	e44e                	sd	s3,8(sp)
    80003742:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003744:	00005597          	auipc	a1,0x5
    80003748:	eac58593          	addi	a1,a1,-340 # 800085f0 <syscalls+0x158>
    8000374c:	0023c517          	auipc	a0,0x23c
    80003750:	97450513          	addi	a0,a0,-1676 # 8023f0c0 <itable>
    80003754:	ffffd097          	auipc	ra,0xffffd
    80003758:	54c080e7          	jalr	1356(ra) # 80000ca0 <initlock>
  for(i = 0; i < NINODE; i++) {
    8000375c:	0023c497          	auipc	s1,0x23c
    80003760:	98c48493          	addi	s1,s1,-1652 # 8023f0e8 <itable+0x28>
    80003764:	0023d997          	auipc	s3,0x23d
    80003768:	41498993          	addi	s3,s3,1044 # 80240b78 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000376c:	00005917          	auipc	s2,0x5
    80003770:	e8c90913          	addi	s2,s2,-372 # 800085f8 <syscalls+0x160>
    80003774:	85ca                	mv	a1,s2
    80003776:	8526                	mv	a0,s1
    80003778:	00001097          	auipc	ra,0x1
    8000377c:	e3e080e7          	jalr	-450(ra) # 800045b6 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003780:	08848493          	addi	s1,s1,136
    80003784:	ff3498e3          	bne	s1,s3,80003774 <iinit+0x3e>
}
    80003788:	70a2                	ld	ra,40(sp)
    8000378a:	7402                	ld	s0,32(sp)
    8000378c:	64e2                	ld	s1,24(sp)
    8000378e:	6942                	ld	s2,16(sp)
    80003790:	69a2                	ld	s3,8(sp)
    80003792:	6145                	addi	sp,sp,48
    80003794:	8082                	ret

0000000080003796 <ialloc>:
{
    80003796:	715d                	addi	sp,sp,-80
    80003798:	e486                	sd	ra,72(sp)
    8000379a:	e0a2                	sd	s0,64(sp)
    8000379c:	fc26                	sd	s1,56(sp)
    8000379e:	f84a                	sd	s2,48(sp)
    800037a0:	f44e                	sd	s3,40(sp)
    800037a2:	f052                	sd	s4,32(sp)
    800037a4:	ec56                	sd	s5,24(sp)
    800037a6:	e85a                	sd	s6,16(sp)
    800037a8:	e45e                	sd	s7,8(sp)
    800037aa:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    800037ac:	0023c717          	auipc	a4,0x23c
    800037b0:	90072703          	lw	a4,-1792(a4) # 8023f0ac <sb+0xc>
    800037b4:	4785                	li	a5,1
    800037b6:	04e7fa63          	bgeu	a5,a4,8000380a <ialloc+0x74>
    800037ba:	8aaa                	mv	s5,a0
    800037bc:	8bae                	mv	s7,a1
    800037be:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    800037c0:	0023ca17          	auipc	s4,0x23c
    800037c4:	8e0a0a13          	addi	s4,s4,-1824 # 8023f0a0 <sb>
    800037c8:	00048b1b          	sext.w	s6,s1
    800037cc:	0044d793          	srli	a5,s1,0x4
    800037d0:	018a2583          	lw	a1,24(s4)
    800037d4:	9dbd                	addw	a1,a1,a5
    800037d6:	8556                	mv	a0,s5
    800037d8:	00000097          	auipc	ra,0x0
    800037dc:	93e080e7          	jalr	-1730(ra) # 80003116 <bread>
    800037e0:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800037e2:	05850993          	addi	s3,a0,88
    800037e6:	00f4f793          	andi	a5,s1,15
    800037ea:	079a                	slli	a5,a5,0x6
    800037ec:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800037ee:	00099783          	lh	a5,0(s3)
    800037f2:	c3a1                	beqz	a5,80003832 <ialloc+0x9c>
    brelse(bp);
    800037f4:	00000097          	auipc	ra,0x0
    800037f8:	a52080e7          	jalr	-1454(ra) # 80003246 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800037fc:	0485                	addi	s1,s1,1
    800037fe:	00ca2703          	lw	a4,12(s4)
    80003802:	0004879b          	sext.w	a5,s1
    80003806:	fce7e1e3          	bltu	a5,a4,800037c8 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    8000380a:	00005517          	auipc	a0,0x5
    8000380e:	df650513          	addi	a0,a0,-522 # 80008600 <syscalls+0x168>
    80003812:	ffffd097          	auipc	ra,0xffffd
    80003816:	d76080e7          	jalr	-650(ra) # 80000588 <printf>
  return 0;
    8000381a:	4501                	li	a0,0
}
    8000381c:	60a6                	ld	ra,72(sp)
    8000381e:	6406                	ld	s0,64(sp)
    80003820:	74e2                	ld	s1,56(sp)
    80003822:	7942                	ld	s2,48(sp)
    80003824:	79a2                	ld	s3,40(sp)
    80003826:	7a02                	ld	s4,32(sp)
    80003828:	6ae2                	ld	s5,24(sp)
    8000382a:	6b42                	ld	s6,16(sp)
    8000382c:	6ba2                	ld	s7,8(sp)
    8000382e:	6161                	addi	sp,sp,80
    80003830:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003832:	04000613          	li	a2,64
    80003836:	4581                	li	a1,0
    80003838:	854e                	mv	a0,s3
    8000383a:	ffffd097          	auipc	ra,0xffffd
    8000383e:	5f2080e7          	jalr	1522(ra) # 80000e2c <memset>
      dip->type = type;
    80003842:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003846:	854a                	mv	a0,s2
    80003848:	00001097          	auipc	ra,0x1
    8000384c:	c88080e7          	jalr	-888(ra) # 800044d0 <log_write>
      brelse(bp);
    80003850:	854a                	mv	a0,s2
    80003852:	00000097          	auipc	ra,0x0
    80003856:	9f4080e7          	jalr	-1548(ra) # 80003246 <brelse>
      return iget(dev, inum);
    8000385a:	85da                	mv	a1,s6
    8000385c:	8556                	mv	a0,s5
    8000385e:	00000097          	auipc	ra,0x0
    80003862:	d9c080e7          	jalr	-612(ra) # 800035fa <iget>
    80003866:	bf5d                	j	8000381c <ialloc+0x86>

0000000080003868 <iupdate>:
{
    80003868:	1101                	addi	sp,sp,-32
    8000386a:	ec06                	sd	ra,24(sp)
    8000386c:	e822                	sd	s0,16(sp)
    8000386e:	e426                	sd	s1,8(sp)
    80003870:	e04a                	sd	s2,0(sp)
    80003872:	1000                	addi	s0,sp,32
    80003874:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003876:	415c                	lw	a5,4(a0)
    80003878:	0047d79b          	srliw	a5,a5,0x4
    8000387c:	0023c597          	auipc	a1,0x23c
    80003880:	83c5a583          	lw	a1,-1988(a1) # 8023f0b8 <sb+0x18>
    80003884:	9dbd                	addw	a1,a1,a5
    80003886:	4108                	lw	a0,0(a0)
    80003888:	00000097          	auipc	ra,0x0
    8000388c:	88e080e7          	jalr	-1906(ra) # 80003116 <bread>
    80003890:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003892:	05850793          	addi	a5,a0,88
    80003896:	40c8                	lw	a0,4(s1)
    80003898:	893d                	andi	a0,a0,15
    8000389a:	051a                	slli	a0,a0,0x6
    8000389c:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    8000389e:	04449703          	lh	a4,68(s1)
    800038a2:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    800038a6:	04649703          	lh	a4,70(s1)
    800038aa:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    800038ae:	04849703          	lh	a4,72(s1)
    800038b2:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    800038b6:	04a49703          	lh	a4,74(s1)
    800038ba:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    800038be:	44f8                	lw	a4,76(s1)
    800038c0:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800038c2:	03400613          	li	a2,52
    800038c6:	05048593          	addi	a1,s1,80
    800038ca:	0531                	addi	a0,a0,12
    800038cc:	ffffd097          	auipc	ra,0xffffd
    800038d0:	5bc080e7          	jalr	1468(ra) # 80000e88 <memmove>
  log_write(bp);
    800038d4:	854a                	mv	a0,s2
    800038d6:	00001097          	auipc	ra,0x1
    800038da:	bfa080e7          	jalr	-1030(ra) # 800044d0 <log_write>
  brelse(bp);
    800038de:	854a                	mv	a0,s2
    800038e0:	00000097          	auipc	ra,0x0
    800038e4:	966080e7          	jalr	-1690(ra) # 80003246 <brelse>
}
    800038e8:	60e2                	ld	ra,24(sp)
    800038ea:	6442                	ld	s0,16(sp)
    800038ec:	64a2                	ld	s1,8(sp)
    800038ee:	6902                	ld	s2,0(sp)
    800038f0:	6105                	addi	sp,sp,32
    800038f2:	8082                	ret

00000000800038f4 <idup>:
{
    800038f4:	1101                	addi	sp,sp,-32
    800038f6:	ec06                	sd	ra,24(sp)
    800038f8:	e822                	sd	s0,16(sp)
    800038fa:	e426                	sd	s1,8(sp)
    800038fc:	1000                	addi	s0,sp,32
    800038fe:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003900:	0023b517          	auipc	a0,0x23b
    80003904:	7c050513          	addi	a0,a0,1984 # 8023f0c0 <itable>
    80003908:	ffffd097          	auipc	ra,0xffffd
    8000390c:	428080e7          	jalr	1064(ra) # 80000d30 <acquire>
  ip->ref++;
    80003910:	449c                	lw	a5,8(s1)
    80003912:	2785                	addiw	a5,a5,1
    80003914:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003916:	0023b517          	auipc	a0,0x23b
    8000391a:	7aa50513          	addi	a0,a0,1962 # 8023f0c0 <itable>
    8000391e:	ffffd097          	auipc	ra,0xffffd
    80003922:	4c6080e7          	jalr	1222(ra) # 80000de4 <release>
}
    80003926:	8526                	mv	a0,s1
    80003928:	60e2                	ld	ra,24(sp)
    8000392a:	6442                	ld	s0,16(sp)
    8000392c:	64a2                	ld	s1,8(sp)
    8000392e:	6105                	addi	sp,sp,32
    80003930:	8082                	ret

0000000080003932 <ilock>:
{
    80003932:	1101                	addi	sp,sp,-32
    80003934:	ec06                	sd	ra,24(sp)
    80003936:	e822                	sd	s0,16(sp)
    80003938:	e426                	sd	s1,8(sp)
    8000393a:	e04a                	sd	s2,0(sp)
    8000393c:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000393e:	c115                	beqz	a0,80003962 <ilock+0x30>
    80003940:	84aa                	mv	s1,a0
    80003942:	451c                	lw	a5,8(a0)
    80003944:	00f05f63          	blez	a5,80003962 <ilock+0x30>
  acquiresleep(&ip->lock);
    80003948:	0541                	addi	a0,a0,16
    8000394a:	00001097          	auipc	ra,0x1
    8000394e:	ca6080e7          	jalr	-858(ra) # 800045f0 <acquiresleep>
  if(ip->valid == 0){
    80003952:	40bc                	lw	a5,64(s1)
    80003954:	cf99                	beqz	a5,80003972 <ilock+0x40>
}
    80003956:	60e2                	ld	ra,24(sp)
    80003958:	6442                	ld	s0,16(sp)
    8000395a:	64a2                	ld	s1,8(sp)
    8000395c:	6902                	ld	s2,0(sp)
    8000395e:	6105                	addi	sp,sp,32
    80003960:	8082                	ret
    panic("ilock");
    80003962:	00005517          	auipc	a0,0x5
    80003966:	cb650513          	addi	a0,a0,-842 # 80008618 <syscalls+0x180>
    8000396a:	ffffd097          	auipc	ra,0xffffd
    8000396e:	bd4080e7          	jalr	-1068(ra) # 8000053e <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003972:	40dc                	lw	a5,4(s1)
    80003974:	0047d79b          	srliw	a5,a5,0x4
    80003978:	0023b597          	auipc	a1,0x23b
    8000397c:	7405a583          	lw	a1,1856(a1) # 8023f0b8 <sb+0x18>
    80003980:	9dbd                	addw	a1,a1,a5
    80003982:	4088                	lw	a0,0(s1)
    80003984:	fffff097          	auipc	ra,0xfffff
    80003988:	792080e7          	jalr	1938(ra) # 80003116 <bread>
    8000398c:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000398e:	05850593          	addi	a1,a0,88
    80003992:	40dc                	lw	a5,4(s1)
    80003994:	8bbd                	andi	a5,a5,15
    80003996:	079a                	slli	a5,a5,0x6
    80003998:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    8000399a:	00059783          	lh	a5,0(a1)
    8000399e:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800039a2:	00259783          	lh	a5,2(a1)
    800039a6:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800039aa:	00459783          	lh	a5,4(a1)
    800039ae:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800039b2:	00659783          	lh	a5,6(a1)
    800039b6:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800039ba:	459c                	lw	a5,8(a1)
    800039bc:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800039be:	03400613          	li	a2,52
    800039c2:	05b1                	addi	a1,a1,12
    800039c4:	05048513          	addi	a0,s1,80
    800039c8:	ffffd097          	auipc	ra,0xffffd
    800039cc:	4c0080e7          	jalr	1216(ra) # 80000e88 <memmove>
    brelse(bp);
    800039d0:	854a                	mv	a0,s2
    800039d2:	00000097          	auipc	ra,0x0
    800039d6:	874080e7          	jalr	-1932(ra) # 80003246 <brelse>
    ip->valid = 1;
    800039da:	4785                	li	a5,1
    800039dc:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800039de:	04449783          	lh	a5,68(s1)
    800039e2:	fbb5                	bnez	a5,80003956 <ilock+0x24>
      panic("ilock: no type");
    800039e4:	00005517          	auipc	a0,0x5
    800039e8:	c3c50513          	addi	a0,a0,-964 # 80008620 <syscalls+0x188>
    800039ec:	ffffd097          	auipc	ra,0xffffd
    800039f0:	b52080e7          	jalr	-1198(ra) # 8000053e <panic>

00000000800039f4 <iunlock>:
{
    800039f4:	1101                	addi	sp,sp,-32
    800039f6:	ec06                	sd	ra,24(sp)
    800039f8:	e822                	sd	s0,16(sp)
    800039fa:	e426                	sd	s1,8(sp)
    800039fc:	e04a                	sd	s2,0(sp)
    800039fe:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003a00:	c905                	beqz	a0,80003a30 <iunlock+0x3c>
    80003a02:	84aa                	mv	s1,a0
    80003a04:	01050913          	addi	s2,a0,16
    80003a08:	854a                	mv	a0,s2
    80003a0a:	00001097          	auipc	ra,0x1
    80003a0e:	c80080e7          	jalr	-896(ra) # 8000468a <holdingsleep>
    80003a12:	cd19                	beqz	a0,80003a30 <iunlock+0x3c>
    80003a14:	449c                	lw	a5,8(s1)
    80003a16:	00f05d63          	blez	a5,80003a30 <iunlock+0x3c>
  releasesleep(&ip->lock);
    80003a1a:	854a                	mv	a0,s2
    80003a1c:	00001097          	auipc	ra,0x1
    80003a20:	c2a080e7          	jalr	-982(ra) # 80004646 <releasesleep>
}
    80003a24:	60e2                	ld	ra,24(sp)
    80003a26:	6442                	ld	s0,16(sp)
    80003a28:	64a2                	ld	s1,8(sp)
    80003a2a:	6902                	ld	s2,0(sp)
    80003a2c:	6105                	addi	sp,sp,32
    80003a2e:	8082                	ret
    panic("iunlock");
    80003a30:	00005517          	auipc	a0,0x5
    80003a34:	c0050513          	addi	a0,a0,-1024 # 80008630 <syscalls+0x198>
    80003a38:	ffffd097          	auipc	ra,0xffffd
    80003a3c:	b06080e7          	jalr	-1274(ra) # 8000053e <panic>

0000000080003a40 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003a40:	7179                	addi	sp,sp,-48
    80003a42:	f406                	sd	ra,40(sp)
    80003a44:	f022                	sd	s0,32(sp)
    80003a46:	ec26                	sd	s1,24(sp)
    80003a48:	e84a                	sd	s2,16(sp)
    80003a4a:	e44e                	sd	s3,8(sp)
    80003a4c:	e052                	sd	s4,0(sp)
    80003a4e:	1800                	addi	s0,sp,48
    80003a50:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003a52:	05050493          	addi	s1,a0,80
    80003a56:	08050913          	addi	s2,a0,128
    80003a5a:	a021                	j	80003a62 <itrunc+0x22>
    80003a5c:	0491                	addi	s1,s1,4
    80003a5e:	01248d63          	beq	s1,s2,80003a78 <itrunc+0x38>
    if(ip->addrs[i]){
    80003a62:	408c                	lw	a1,0(s1)
    80003a64:	dde5                	beqz	a1,80003a5c <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    80003a66:	0009a503          	lw	a0,0(s3)
    80003a6a:	00000097          	auipc	ra,0x0
    80003a6e:	8f2080e7          	jalr	-1806(ra) # 8000335c <bfree>
      ip->addrs[i] = 0;
    80003a72:	0004a023          	sw	zero,0(s1)
    80003a76:	b7dd                	j	80003a5c <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003a78:	0809a583          	lw	a1,128(s3)
    80003a7c:	e185                	bnez	a1,80003a9c <itrunc+0x5c>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003a7e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003a82:	854e                	mv	a0,s3
    80003a84:	00000097          	auipc	ra,0x0
    80003a88:	de4080e7          	jalr	-540(ra) # 80003868 <iupdate>
}
    80003a8c:	70a2                	ld	ra,40(sp)
    80003a8e:	7402                	ld	s0,32(sp)
    80003a90:	64e2                	ld	s1,24(sp)
    80003a92:	6942                	ld	s2,16(sp)
    80003a94:	69a2                	ld	s3,8(sp)
    80003a96:	6a02                	ld	s4,0(sp)
    80003a98:	6145                	addi	sp,sp,48
    80003a9a:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003a9c:	0009a503          	lw	a0,0(s3)
    80003aa0:	fffff097          	auipc	ra,0xfffff
    80003aa4:	676080e7          	jalr	1654(ra) # 80003116 <bread>
    80003aa8:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003aaa:	05850493          	addi	s1,a0,88
    80003aae:	45850913          	addi	s2,a0,1112
    80003ab2:	a021                	j	80003aba <itrunc+0x7a>
    80003ab4:	0491                	addi	s1,s1,4
    80003ab6:	01248b63          	beq	s1,s2,80003acc <itrunc+0x8c>
      if(a[j])
    80003aba:	408c                	lw	a1,0(s1)
    80003abc:	dde5                	beqz	a1,80003ab4 <itrunc+0x74>
        bfree(ip->dev, a[j]);
    80003abe:	0009a503          	lw	a0,0(s3)
    80003ac2:	00000097          	auipc	ra,0x0
    80003ac6:	89a080e7          	jalr	-1894(ra) # 8000335c <bfree>
    80003aca:	b7ed                	j	80003ab4 <itrunc+0x74>
    brelse(bp);
    80003acc:	8552                	mv	a0,s4
    80003ace:	fffff097          	auipc	ra,0xfffff
    80003ad2:	778080e7          	jalr	1912(ra) # 80003246 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003ad6:	0809a583          	lw	a1,128(s3)
    80003ada:	0009a503          	lw	a0,0(s3)
    80003ade:	00000097          	auipc	ra,0x0
    80003ae2:	87e080e7          	jalr	-1922(ra) # 8000335c <bfree>
    ip->addrs[NDIRECT] = 0;
    80003ae6:	0809a023          	sw	zero,128(s3)
    80003aea:	bf51                	j	80003a7e <itrunc+0x3e>

0000000080003aec <iput>:
{
    80003aec:	1101                	addi	sp,sp,-32
    80003aee:	ec06                	sd	ra,24(sp)
    80003af0:	e822                	sd	s0,16(sp)
    80003af2:	e426                	sd	s1,8(sp)
    80003af4:	e04a                	sd	s2,0(sp)
    80003af6:	1000                	addi	s0,sp,32
    80003af8:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003afa:	0023b517          	auipc	a0,0x23b
    80003afe:	5c650513          	addi	a0,a0,1478 # 8023f0c0 <itable>
    80003b02:	ffffd097          	auipc	ra,0xffffd
    80003b06:	22e080e7          	jalr	558(ra) # 80000d30 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003b0a:	4498                	lw	a4,8(s1)
    80003b0c:	4785                	li	a5,1
    80003b0e:	02f70363          	beq	a4,a5,80003b34 <iput+0x48>
  ip->ref--;
    80003b12:	449c                	lw	a5,8(s1)
    80003b14:	37fd                	addiw	a5,a5,-1
    80003b16:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003b18:	0023b517          	auipc	a0,0x23b
    80003b1c:	5a850513          	addi	a0,a0,1448 # 8023f0c0 <itable>
    80003b20:	ffffd097          	auipc	ra,0xffffd
    80003b24:	2c4080e7          	jalr	708(ra) # 80000de4 <release>
}
    80003b28:	60e2                	ld	ra,24(sp)
    80003b2a:	6442                	ld	s0,16(sp)
    80003b2c:	64a2                	ld	s1,8(sp)
    80003b2e:	6902                	ld	s2,0(sp)
    80003b30:	6105                	addi	sp,sp,32
    80003b32:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003b34:	40bc                	lw	a5,64(s1)
    80003b36:	dff1                	beqz	a5,80003b12 <iput+0x26>
    80003b38:	04a49783          	lh	a5,74(s1)
    80003b3c:	fbf9                	bnez	a5,80003b12 <iput+0x26>
    acquiresleep(&ip->lock);
    80003b3e:	01048913          	addi	s2,s1,16
    80003b42:	854a                	mv	a0,s2
    80003b44:	00001097          	auipc	ra,0x1
    80003b48:	aac080e7          	jalr	-1364(ra) # 800045f0 <acquiresleep>
    release(&itable.lock);
    80003b4c:	0023b517          	auipc	a0,0x23b
    80003b50:	57450513          	addi	a0,a0,1396 # 8023f0c0 <itable>
    80003b54:	ffffd097          	auipc	ra,0xffffd
    80003b58:	290080e7          	jalr	656(ra) # 80000de4 <release>
    itrunc(ip);
    80003b5c:	8526                	mv	a0,s1
    80003b5e:	00000097          	auipc	ra,0x0
    80003b62:	ee2080e7          	jalr	-286(ra) # 80003a40 <itrunc>
    ip->type = 0;
    80003b66:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003b6a:	8526                	mv	a0,s1
    80003b6c:	00000097          	auipc	ra,0x0
    80003b70:	cfc080e7          	jalr	-772(ra) # 80003868 <iupdate>
    ip->valid = 0;
    80003b74:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003b78:	854a                	mv	a0,s2
    80003b7a:	00001097          	auipc	ra,0x1
    80003b7e:	acc080e7          	jalr	-1332(ra) # 80004646 <releasesleep>
    acquire(&itable.lock);
    80003b82:	0023b517          	auipc	a0,0x23b
    80003b86:	53e50513          	addi	a0,a0,1342 # 8023f0c0 <itable>
    80003b8a:	ffffd097          	auipc	ra,0xffffd
    80003b8e:	1a6080e7          	jalr	422(ra) # 80000d30 <acquire>
    80003b92:	b741                	j	80003b12 <iput+0x26>

0000000080003b94 <iunlockput>:
{
    80003b94:	1101                	addi	sp,sp,-32
    80003b96:	ec06                	sd	ra,24(sp)
    80003b98:	e822                	sd	s0,16(sp)
    80003b9a:	e426                	sd	s1,8(sp)
    80003b9c:	1000                	addi	s0,sp,32
    80003b9e:	84aa                	mv	s1,a0
  iunlock(ip);
    80003ba0:	00000097          	auipc	ra,0x0
    80003ba4:	e54080e7          	jalr	-428(ra) # 800039f4 <iunlock>
  iput(ip);
    80003ba8:	8526                	mv	a0,s1
    80003baa:	00000097          	auipc	ra,0x0
    80003bae:	f42080e7          	jalr	-190(ra) # 80003aec <iput>
}
    80003bb2:	60e2                	ld	ra,24(sp)
    80003bb4:	6442                	ld	s0,16(sp)
    80003bb6:	64a2                	ld	s1,8(sp)
    80003bb8:	6105                	addi	sp,sp,32
    80003bba:	8082                	ret

0000000080003bbc <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003bbc:	1141                	addi	sp,sp,-16
    80003bbe:	e422                	sd	s0,8(sp)
    80003bc0:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003bc2:	411c                	lw	a5,0(a0)
    80003bc4:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003bc6:	415c                	lw	a5,4(a0)
    80003bc8:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003bca:	04451783          	lh	a5,68(a0)
    80003bce:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003bd2:	04a51783          	lh	a5,74(a0)
    80003bd6:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003bda:	04c56783          	lwu	a5,76(a0)
    80003bde:	e99c                	sd	a5,16(a1)
}
    80003be0:	6422                	ld	s0,8(sp)
    80003be2:	0141                	addi	sp,sp,16
    80003be4:	8082                	ret

0000000080003be6 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003be6:	457c                	lw	a5,76(a0)
    80003be8:	0ed7e963          	bltu	a5,a3,80003cda <readi+0xf4>
{
    80003bec:	7159                	addi	sp,sp,-112
    80003bee:	f486                	sd	ra,104(sp)
    80003bf0:	f0a2                	sd	s0,96(sp)
    80003bf2:	eca6                	sd	s1,88(sp)
    80003bf4:	e8ca                	sd	s2,80(sp)
    80003bf6:	e4ce                	sd	s3,72(sp)
    80003bf8:	e0d2                	sd	s4,64(sp)
    80003bfa:	fc56                	sd	s5,56(sp)
    80003bfc:	f85a                	sd	s6,48(sp)
    80003bfe:	f45e                	sd	s7,40(sp)
    80003c00:	f062                	sd	s8,32(sp)
    80003c02:	ec66                	sd	s9,24(sp)
    80003c04:	e86a                	sd	s10,16(sp)
    80003c06:	e46e                	sd	s11,8(sp)
    80003c08:	1880                	addi	s0,sp,112
    80003c0a:	8b2a                	mv	s6,a0
    80003c0c:	8bae                	mv	s7,a1
    80003c0e:	8a32                	mv	s4,a2
    80003c10:	84b6                	mv	s1,a3
    80003c12:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003c14:	9f35                	addw	a4,a4,a3
    return 0;
    80003c16:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003c18:	0ad76063          	bltu	a4,a3,80003cb8 <readi+0xd2>
  if(off + n > ip->size)
    80003c1c:	00e7f463          	bgeu	a5,a4,80003c24 <readi+0x3e>
    n = ip->size - off;
    80003c20:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003c24:	0a0a8963          	beqz	s5,80003cd6 <readi+0xf0>
    80003c28:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003c2a:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003c2e:	5c7d                	li	s8,-1
    80003c30:	a82d                	j	80003c6a <readi+0x84>
    80003c32:	020d1d93          	slli	s11,s10,0x20
    80003c36:	020ddd93          	srli	s11,s11,0x20
    80003c3a:	05890793          	addi	a5,s2,88
    80003c3e:	86ee                	mv	a3,s11
    80003c40:	963e                	add	a2,a2,a5
    80003c42:	85d2                	mv	a1,s4
    80003c44:	855e                	mv	a0,s7
    80003c46:	fffff097          	auipc	ra,0xfffff
    80003c4a:	aa0080e7          	jalr	-1376(ra) # 800026e6 <either_copyout>
    80003c4e:	05850d63          	beq	a0,s8,80003ca8 <readi+0xc2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003c52:	854a                	mv	a0,s2
    80003c54:	fffff097          	auipc	ra,0xfffff
    80003c58:	5f2080e7          	jalr	1522(ra) # 80003246 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003c5c:	013d09bb          	addw	s3,s10,s3
    80003c60:	009d04bb          	addw	s1,s10,s1
    80003c64:	9a6e                	add	s4,s4,s11
    80003c66:	0559f763          	bgeu	s3,s5,80003cb4 <readi+0xce>
    uint addr = bmap(ip, off/BSIZE);
    80003c6a:	00a4d59b          	srliw	a1,s1,0xa
    80003c6e:	855a                	mv	a0,s6
    80003c70:	00000097          	auipc	ra,0x0
    80003c74:	8a0080e7          	jalr	-1888(ra) # 80003510 <bmap>
    80003c78:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003c7c:	cd85                	beqz	a1,80003cb4 <readi+0xce>
    bp = bread(ip->dev, addr);
    80003c7e:	000b2503          	lw	a0,0(s6)
    80003c82:	fffff097          	auipc	ra,0xfffff
    80003c86:	494080e7          	jalr	1172(ra) # 80003116 <bread>
    80003c8a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003c8c:	3ff4f613          	andi	a2,s1,1023
    80003c90:	40cc87bb          	subw	a5,s9,a2
    80003c94:	413a873b          	subw	a4,s5,s3
    80003c98:	8d3e                	mv	s10,a5
    80003c9a:	2781                	sext.w	a5,a5
    80003c9c:	0007069b          	sext.w	a3,a4
    80003ca0:	f8f6f9e3          	bgeu	a3,a5,80003c32 <readi+0x4c>
    80003ca4:	8d3a                	mv	s10,a4
    80003ca6:	b771                	j	80003c32 <readi+0x4c>
      brelse(bp);
    80003ca8:	854a                	mv	a0,s2
    80003caa:	fffff097          	auipc	ra,0xfffff
    80003cae:	59c080e7          	jalr	1436(ra) # 80003246 <brelse>
      tot = -1;
    80003cb2:	59fd                	li	s3,-1
  }
  return tot;
    80003cb4:	0009851b          	sext.w	a0,s3
}
    80003cb8:	70a6                	ld	ra,104(sp)
    80003cba:	7406                	ld	s0,96(sp)
    80003cbc:	64e6                	ld	s1,88(sp)
    80003cbe:	6946                	ld	s2,80(sp)
    80003cc0:	69a6                	ld	s3,72(sp)
    80003cc2:	6a06                	ld	s4,64(sp)
    80003cc4:	7ae2                	ld	s5,56(sp)
    80003cc6:	7b42                	ld	s6,48(sp)
    80003cc8:	7ba2                	ld	s7,40(sp)
    80003cca:	7c02                	ld	s8,32(sp)
    80003ccc:	6ce2                	ld	s9,24(sp)
    80003cce:	6d42                	ld	s10,16(sp)
    80003cd0:	6da2                	ld	s11,8(sp)
    80003cd2:	6165                	addi	sp,sp,112
    80003cd4:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003cd6:	89d6                	mv	s3,s5
    80003cd8:	bff1                	j	80003cb4 <readi+0xce>
    return 0;
    80003cda:	4501                	li	a0,0
}
    80003cdc:	8082                	ret

0000000080003cde <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003cde:	457c                	lw	a5,76(a0)
    80003ce0:	10d7e863          	bltu	a5,a3,80003df0 <writei+0x112>
{
    80003ce4:	7159                	addi	sp,sp,-112
    80003ce6:	f486                	sd	ra,104(sp)
    80003ce8:	f0a2                	sd	s0,96(sp)
    80003cea:	eca6                	sd	s1,88(sp)
    80003cec:	e8ca                	sd	s2,80(sp)
    80003cee:	e4ce                	sd	s3,72(sp)
    80003cf0:	e0d2                	sd	s4,64(sp)
    80003cf2:	fc56                	sd	s5,56(sp)
    80003cf4:	f85a                	sd	s6,48(sp)
    80003cf6:	f45e                	sd	s7,40(sp)
    80003cf8:	f062                	sd	s8,32(sp)
    80003cfa:	ec66                	sd	s9,24(sp)
    80003cfc:	e86a                	sd	s10,16(sp)
    80003cfe:	e46e                	sd	s11,8(sp)
    80003d00:	1880                	addi	s0,sp,112
    80003d02:	8aaa                	mv	s5,a0
    80003d04:	8bae                	mv	s7,a1
    80003d06:	8a32                	mv	s4,a2
    80003d08:	8936                	mv	s2,a3
    80003d0a:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003d0c:	00e687bb          	addw	a5,a3,a4
    80003d10:	0ed7e263          	bltu	a5,a3,80003df4 <writei+0x116>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003d14:	00043737          	lui	a4,0x43
    80003d18:	0ef76063          	bltu	a4,a5,80003df8 <writei+0x11a>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003d1c:	0c0b0863          	beqz	s6,80003dec <writei+0x10e>
    80003d20:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003d22:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003d26:	5c7d                	li	s8,-1
    80003d28:	a091                	j	80003d6c <writei+0x8e>
    80003d2a:	020d1d93          	slli	s11,s10,0x20
    80003d2e:	020ddd93          	srli	s11,s11,0x20
    80003d32:	05848793          	addi	a5,s1,88
    80003d36:	86ee                	mv	a3,s11
    80003d38:	8652                	mv	a2,s4
    80003d3a:	85de                	mv	a1,s7
    80003d3c:	953e                	add	a0,a0,a5
    80003d3e:	fffff097          	auipc	ra,0xfffff
    80003d42:	9fe080e7          	jalr	-1538(ra) # 8000273c <either_copyin>
    80003d46:	07850263          	beq	a0,s8,80003daa <writei+0xcc>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003d4a:	8526                	mv	a0,s1
    80003d4c:	00000097          	auipc	ra,0x0
    80003d50:	784080e7          	jalr	1924(ra) # 800044d0 <log_write>
    brelse(bp);
    80003d54:	8526                	mv	a0,s1
    80003d56:	fffff097          	auipc	ra,0xfffff
    80003d5a:	4f0080e7          	jalr	1264(ra) # 80003246 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003d5e:	013d09bb          	addw	s3,s10,s3
    80003d62:	012d093b          	addw	s2,s10,s2
    80003d66:	9a6e                	add	s4,s4,s11
    80003d68:	0569f663          	bgeu	s3,s6,80003db4 <writei+0xd6>
    uint addr = bmap(ip, off/BSIZE);
    80003d6c:	00a9559b          	srliw	a1,s2,0xa
    80003d70:	8556                	mv	a0,s5
    80003d72:	fffff097          	auipc	ra,0xfffff
    80003d76:	79e080e7          	jalr	1950(ra) # 80003510 <bmap>
    80003d7a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003d7e:	c99d                	beqz	a1,80003db4 <writei+0xd6>
    bp = bread(ip->dev, addr);
    80003d80:	000aa503          	lw	a0,0(s5)
    80003d84:	fffff097          	auipc	ra,0xfffff
    80003d88:	392080e7          	jalr	914(ra) # 80003116 <bread>
    80003d8c:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003d8e:	3ff97513          	andi	a0,s2,1023
    80003d92:	40ac87bb          	subw	a5,s9,a0
    80003d96:	413b073b          	subw	a4,s6,s3
    80003d9a:	8d3e                	mv	s10,a5
    80003d9c:	2781                	sext.w	a5,a5
    80003d9e:	0007069b          	sext.w	a3,a4
    80003da2:	f8f6f4e3          	bgeu	a3,a5,80003d2a <writei+0x4c>
    80003da6:	8d3a                	mv	s10,a4
    80003da8:	b749                	j	80003d2a <writei+0x4c>
      brelse(bp);
    80003daa:	8526                	mv	a0,s1
    80003dac:	fffff097          	auipc	ra,0xfffff
    80003db0:	49a080e7          	jalr	1178(ra) # 80003246 <brelse>
  }

  if(off > ip->size)
    80003db4:	04caa783          	lw	a5,76(s5)
    80003db8:	0127f463          	bgeu	a5,s2,80003dc0 <writei+0xe2>
    ip->size = off;
    80003dbc:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003dc0:	8556                	mv	a0,s5
    80003dc2:	00000097          	auipc	ra,0x0
    80003dc6:	aa6080e7          	jalr	-1370(ra) # 80003868 <iupdate>

  return tot;
    80003dca:	0009851b          	sext.w	a0,s3
}
    80003dce:	70a6                	ld	ra,104(sp)
    80003dd0:	7406                	ld	s0,96(sp)
    80003dd2:	64e6                	ld	s1,88(sp)
    80003dd4:	6946                	ld	s2,80(sp)
    80003dd6:	69a6                	ld	s3,72(sp)
    80003dd8:	6a06                	ld	s4,64(sp)
    80003dda:	7ae2                	ld	s5,56(sp)
    80003ddc:	7b42                	ld	s6,48(sp)
    80003dde:	7ba2                	ld	s7,40(sp)
    80003de0:	7c02                	ld	s8,32(sp)
    80003de2:	6ce2                	ld	s9,24(sp)
    80003de4:	6d42                	ld	s10,16(sp)
    80003de6:	6da2                	ld	s11,8(sp)
    80003de8:	6165                	addi	sp,sp,112
    80003dea:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003dec:	89da                	mv	s3,s6
    80003dee:	bfc9                	j	80003dc0 <writei+0xe2>
    return -1;
    80003df0:	557d                	li	a0,-1
}
    80003df2:	8082                	ret
    return -1;
    80003df4:	557d                	li	a0,-1
    80003df6:	bfe1                	j	80003dce <writei+0xf0>
    return -1;
    80003df8:	557d                	li	a0,-1
    80003dfa:	bfd1                	j	80003dce <writei+0xf0>

0000000080003dfc <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003dfc:	1141                	addi	sp,sp,-16
    80003dfe:	e406                	sd	ra,8(sp)
    80003e00:	e022                	sd	s0,0(sp)
    80003e02:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003e04:	4639                	li	a2,14
    80003e06:	ffffd097          	auipc	ra,0xffffd
    80003e0a:	0f6080e7          	jalr	246(ra) # 80000efc <strncmp>
}
    80003e0e:	60a2                	ld	ra,8(sp)
    80003e10:	6402                	ld	s0,0(sp)
    80003e12:	0141                	addi	sp,sp,16
    80003e14:	8082                	ret

0000000080003e16 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003e16:	7139                	addi	sp,sp,-64
    80003e18:	fc06                	sd	ra,56(sp)
    80003e1a:	f822                	sd	s0,48(sp)
    80003e1c:	f426                	sd	s1,40(sp)
    80003e1e:	f04a                	sd	s2,32(sp)
    80003e20:	ec4e                	sd	s3,24(sp)
    80003e22:	e852                	sd	s4,16(sp)
    80003e24:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003e26:	04451703          	lh	a4,68(a0)
    80003e2a:	4785                	li	a5,1
    80003e2c:	00f71a63          	bne	a4,a5,80003e40 <dirlookup+0x2a>
    80003e30:	892a                	mv	s2,a0
    80003e32:	89ae                	mv	s3,a1
    80003e34:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e36:	457c                	lw	a5,76(a0)
    80003e38:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003e3a:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e3c:	e79d                	bnez	a5,80003e6a <dirlookup+0x54>
    80003e3e:	a8a5                	j	80003eb6 <dirlookup+0xa0>
    panic("dirlookup not DIR");
    80003e40:	00004517          	auipc	a0,0x4
    80003e44:	7f850513          	addi	a0,a0,2040 # 80008638 <syscalls+0x1a0>
    80003e48:	ffffc097          	auipc	ra,0xffffc
    80003e4c:	6f6080e7          	jalr	1782(ra) # 8000053e <panic>
      panic("dirlookup read");
    80003e50:	00005517          	auipc	a0,0x5
    80003e54:	80050513          	addi	a0,a0,-2048 # 80008650 <syscalls+0x1b8>
    80003e58:	ffffc097          	auipc	ra,0xffffc
    80003e5c:	6e6080e7          	jalr	1766(ra) # 8000053e <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e60:	24c1                	addiw	s1,s1,16
    80003e62:	04c92783          	lw	a5,76(s2)
    80003e66:	04f4f763          	bgeu	s1,a5,80003eb4 <dirlookup+0x9e>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003e6a:	4741                	li	a4,16
    80003e6c:	86a6                	mv	a3,s1
    80003e6e:	fc040613          	addi	a2,s0,-64
    80003e72:	4581                	li	a1,0
    80003e74:	854a                	mv	a0,s2
    80003e76:	00000097          	auipc	ra,0x0
    80003e7a:	d70080e7          	jalr	-656(ra) # 80003be6 <readi>
    80003e7e:	47c1                	li	a5,16
    80003e80:	fcf518e3          	bne	a0,a5,80003e50 <dirlookup+0x3a>
    if(de.inum == 0)
    80003e84:	fc045783          	lhu	a5,-64(s0)
    80003e88:	dfe1                	beqz	a5,80003e60 <dirlookup+0x4a>
    if(namecmp(name, de.name) == 0){
    80003e8a:	fc240593          	addi	a1,s0,-62
    80003e8e:	854e                	mv	a0,s3
    80003e90:	00000097          	auipc	ra,0x0
    80003e94:	f6c080e7          	jalr	-148(ra) # 80003dfc <namecmp>
    80003e98:	f561                	bnez	a0,80003e60 <dirlookup+0x4a>
      if(poff)
    80003e9a:	000a0463          	beqz	s4,80003ea2 <dirlookup+0x8c>
        *poff = off;
    80003e9e:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003ea2:	fc045583          	lhu	a1,-64(s0)
    80003ea6:	00092503          	lw	a0,0(s2)
    80003eaa:	fffff097          	auipc	ra,0xfffff
    80003eae:	750080e7          	jalr	1872(ra) # 800035fa <iget>
    80003eb2:	a011                	j	80003eb6 <dirlookup+0xa0>
  return 0;
    80003eb4:	4501                	li	a0,0
}
    80003eb6:	70e2                	ld	ra,56(sp)
    80003eb8:	7442                	ld	s0,48(sp)
    80003eba:	74a2                	ld	s1,40(sp)
    80003ebc:	7902                	ld	s2,32(sp)
    80003ebe:	69e2                	ld	s3,24(sp)
    80003ec0:	6a42                	ld	s4,16(sp)
    80003ec2:	6121                	addi	sp,sp,64
    80003ec4:	8082                	ret

0000000080003ec6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003ec6:	711d                	addi	sp,sp,-96
    80003ec8:	ec86                	sd	ra,88(sp)
    80003eca:	e8a2                	sd	s0,80(sp)
    80003ecc:	e4a6                	sd	s1,72(sp)
    80003ece:	e0ca                	sd	s2,64(sp)
    80003ed0:	fc4e                	sd	s3,56(sp)
    80003ed2:	f852                	sd	s4,48(sp)
    80003ed4:	f456                	sd	s5,40(sp)
    80003ed6:	f05a                	sd	s6,32(sp)
    80003ed8:	ec5e                	sd	s7,24(sp)
    80003eda:	e862                	sd	s8,16(sp)
    80003edc:	e466                	sd	s9,8(sp)
    80003ede:	1080                	addi	s0,sp,96
    80003ee0:	84aa                	mv	s1,a0
    80003ee2:	8aae                	mv	s5,a1
    80003ee4:	8a32                	mv	s4,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003ee6:	00054703          	lbu	a4,0(a0)
    80003eea:	02f00793          	li	a5,47
    80003eee:	02f70363          	beq	a4,a5,80003f14 <namex+0x4e>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003ef2:	ffffe097          	auipc	ra,0xffffe
    80003ef6:	d40080e7          	jalr	-704(ra) # 80001c32 <myproc>
    80003efa:	15053503          	ld	a0,336(a0)
    80003efe:	00000097          	auipc	ra,0x0
    80003f02:	9f6080e7          	jalr	-1546(ra) # 800038f4 <idup>
    80003f06:	89aa                	mv	s3,a0
  while(*path == '/')
    80003f08:	02f00913          	li	s2,47
  len = path - s;
    80003f0c:	4b01                	li	s6,0
  if(len >= DIRSIZ)
    80003f0e:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003f10:	4b85                	li	s7,1
    80003f12:	a865                	j	80003fca <namex+0x104>
    ip = iget(ROOTDEV, ROOTINO);
    80003f14:	4585                	li	a1,1
    80003f16:	4505                	li	a0,1
    80003f18:	fffff097          	auipc	ra,0xfffff
    80003f1c:	6e2080e7          	jalr	1762(ra) # 800035fa <iget>
    80003f20:	89aa                	mv	s3,a0
    80003f22:	b7dd                	j	80003f08 <namex+0x42>
      iunlockput(ip);
    80003f24:	854e                	mv	a0,s3
    80003f26:	00000097          	auipc	ra,0x0
    80003f2a:	c6e080e7          	jalr	-914(ra) # 80003b94 <iunlockput>
      return 0;
    80003f2e:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003f30:	854e                	mv	a0,s3
    80003f32:	60e6                	ld	ra,88(sp)
    80003f34:	6446                	ld	s0,80(sp)
    80003f36:	64a6                	ld	s1,72(sp)
    80003f38:	6906                	ld	s2,64(sp)
    80003f3a:	79e2                	ld	s3,56(sp)
    80003f3c:	7a42                	ld	s4,48(sp)
    80003f3e:	7aa2                	ld	s5,40(sp)
    80003f40:	7b02                	ld	s6,32(sp)
    80003f42:	6be2                	ld	s7,24(sp)
    80003f44:	6c42                	ld	s8,16(sp)
    80003f46:	6ca2                	ld	s9,8(sp)
    80003f48:	6125                	addi	sp,sp,96
    80003f4a:	8082                	ret
      iunlock(ip);
    80003f4c:	854e                	mv	a0,s3
    80003f4e:	00000097          	auipc	ra,0x0
    80003f52:	aa6080e7          	jalr	-1370(ra) # 800039f4 <iunlock>
      return ip;
    80003f56:	bfe9                	j	80003f30 <namex+0x6a>
      iunlockput(ip);
    80003f58:	854e                	mv	a0,s3
    80003f5a:	00000097          	auipc	ra,0x0
    80003f5e:	c3a080e7          	jalr	-966(ra) # 80003b94 <iunlockput>
      return 0;
    80003f62:	89e6                	mv	s3,s9
    80003f64:	b7f1                	j	80003f30 <namex+0x6a>
  len = path - s;
    80003f66:	40b48633          	sub	a2,s1,a1
    80003f6a:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003f6e:	099c5463          	bge	s8,s9,80003ff6 <namex+0x130>
    memmove(name, s, DIRSIZ);
    80003f72:	4639                	li	a2,14
    80003f74:	8552                	mv	a0,s4
    80003f76:	ffffd097          	auipc	ra,0xffffd
    80003f7a:	f12080e7          	jalr	-238(ra) # 80000e88 <memmove>
  while(*path == '/')
    80003f7e:	0004c783          	lbu	a5,0(s1)
    80003f82:	01279763          	bne	a5,s2,80003f90 <namex+0xca>
    path++;
    80003f86:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003f88:	0004c783          	lbu	a5,0(s1)
    80003f8c:	ff278de3          	beq	a5,s2,80003f86 <namex+0xc0>
    ilock(ip);
    80003f90:	854e                	mv	a0,s3
    80003f92:	00000097          	auipc	ra,0x0
    80003f96:	9a0080e7          	jalr	-1632(ra) # 80003932 <ilock>
    if(ip->type != T_DIR){
    80003f9a:	04499783          	lh	a5,68(s3)
    80003f9e:	f97793e3          	bne	a5,s7,80003f24 <namex+0x5e>
    if(nameiparent && *path == '\0'){
    80003fa2:	000a8563          	beqz	s5,80003fac <namex+0xe6>
    80003fa6:	0004c783          	lbu	a5,0(s1)
    80003faa:	d3cd                	beqz	a5,80003f4c <namex+0x86>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003fac:	865a                	mv	a2,s6
    80003fae:	85d2                	mv	a1,s4
    80003fb0:	854e                	mv	a0,s3
    80003fb2:	00000097          	auipc	ra,0x0
    80003fb6:	e64080e7          	jalr	-412(ra) # 80003e16 <dirlookup>
    80003fba:	8caa                	mv	s9,a0
    80003fbc:	dd51                	beqz	a0,80003f58 <namex+0x92>
    iunlockput(ip);
    80003fbe:	854e                	mv	a0,s3
    80003fc0:	00000097          	auipc	ra,0x0
    80003fc4:	bd4080e7          	jalr	-1068(ra) # 80003b94 <iunlockput>
    ip = next;
    80003fc8:	89e6                	mv	s3,s9
  while(*path == '/')
    80003fca:	0004c783          	lbu	a5,0(s1)
    80003fce:	05279763          	bne	a5,s2,8000401c <namex+0x156>
    path++;
    80003fd2:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003fd4:	0004c783          	lbu	a5,0(s1)
    80003fd8:	ff278de3          	beq	a5,s2,80003fd2 <namex+0x10c>
  if(*path == 0)
    80003fdc:	c79d                	beqz	a5,8000400a <namex+0x144>
    path++;
    80003fde:	85a6                	mv	a1,s1
  len = path - s;
    80003fe0:	8cda                	mv	s9,s6
    80003fe2:	865a                	mv	a2,s6
  while(*path != '/' && *path != 0)
    80003fe4:	01278963          	beq	a5,s2,80003ff6 <namex+0x130>
    80003fe8:	dfbd                	beqz	a5,80003f66 <namex+0xa0>
    path++;
    80003fea:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80003fec:	0004c783          	lbu	a5,0(s1)
    80003ff0:	ff279ce3          	bne	a5,s2,80003fe8 <namex+0x122>
    80003ff4:	bf8d                	j	80003f66 <namex+0xa0>
    memmove(name, s, len);
    80003ff6:	2601                	sext.w	a2,a2
    80003ff8:	8552                	mv	a0,s4
    80003ffa:	ffffd097          	auipc	ra,0xffffd
    80003ffe:	e8e080e7          	jalr	-370(ra) # 80000e88 <memmove>
    name[len] = 0;
    80004002:	9cd2                	add	s9,s9,s4
    80004004:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80004008:	bf9d                	j	80003f7e <namex+0xb8>
  if(nameiparent){
    8000400a:	f20a83e3          	beqz	s5,80003f30 <namex+0x6a>
    iput(ip);
    8000400e:	854e                	mv	a0,s3
    80004010:	00000097          	auipc	ra,0x0
    80004014:	adc080e7          	jalr	-1316(ra) # 80003aec <iput>
    return 0;
    80004018:	4981                	li	s3,0
    8000401a:	bf19                	j	80003f30 <namex+0x6a>
  if(*path == 0)
    8000401c:	d7fd                	beqz	a5,8000400a <namex+0x144>
  while(*path != '/' && *path != 0)
    8000401e:	0004c783          	lbu	a5,0(s1)
    80004022:	85a6                	mv	a1,s1
    80004024:	b7d1                	j	80003fe8 <namex+0x122>

0000000080004026 <dirlink>:
{
    80004026:	7139                	addi	sp,sp,-64
    80004028:	fc06                	sd	ra,56(sp)
    8000402a:	f822                	sd	s0,48(sp)
    8000402c:	f426                	sd	s1,40(sp)
    8000402e:	f04a                	sd	s2,32(sp)
    80004030:	ec4e                	sd	s3,24(sp)
    80004032:	e852                	sd	s4,16(sp)
    80004034:	0080                	addi	s0,sp,64
    80004036:	892a                	mv	s2,a0
    80004038:	8a2e                	mv	s4,a1
    8000403a:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    8000403c:	4601                	li	a2,0
    8000403e:	00000097          	auipc	ra,0x0
    80004042:	dd8080e7          	jalr	-552(ra) # 80003e16 <dirlookup>
    80004046:	e93d                	bnez	a0,800040bc <dirlink+0x96>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80004048:	04c92483          	lw	s1,76(s2)
    8000404c:	c49d                	beqz	s1,8000407a <dirlink+0x54>
    8000404e:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004050:	4741                	li	a4,16
    80004052:	86a6                	mv	a3,s1
    80004054:	fc040613          	addi	a2,s0,-64
    80004058:	4581                	li	a1,0
    8000405a:	854a                	mv	a0,s2
    8000405c:	00000097          	auipc	ra,0x0
    80004060:	b8a080e7          	jalr	-1142(ra) # 80003be6 <readi>
    80004064:	47c1                	li	a5,16
    80004066:	06f51163          	bne	a0,a5,800040c8 <dirlink+0xa2>
    if(de.inum == 0)
    8000406a:	fc045783          	lhu	a5,-64(s0)
    8000406e:	c791                	beqz	a5,8000407a <dirlink+0x54>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80004070:	24c1                	addiw	s1,s1,16
    80004072:	04c92783          	lw	a5,76(s2)
    80004076:	fcf4ede3          	bltu	s1,a5,80004050 <dirlink+0x2a>
  strncpy(de.name, name, DIRSIZ);
    8000407a:	4639                	li	a2,14
    8000407c:	85d2                	mv	a1,s4
    8000407e:	fc240513          	addi	a0,s0,-62
    80004082:	ffffd097          	auipc	ra,0xffffd
    80004086:	eb6080e7          	jalr	-330(ra) # 80000f38 <strncpy>
  de.inum = inum;
    8000408a:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000408e:	4741                	li	a4,16
    80004090:	86a6                	mv	a3,s1
    80004092:	fc040613          	addi	a2,s0,-64
    80004096:	4581                	li	a1,0
    80004098:	854a                	mv	a0,s2
    8000409a:	00000097          	auipc	ra,0x0
    8000409e:	c44080e7          	jalr	-956(ra) # 80003cde <writei>
    800040a2:	1541                	addi	a0,a0,-16
    800040a4:	00a03533          	snez	a0,a0
    800040a8:	40a00533          	neg	a0,a0
}
    800040ac:	70e2                	ld	ra,56(sp)
    800040ae:	7442                	ld	s0,48(sp)
    800040b0:	74a2                	ld	s1,40(sp)
    800040b2:	7902                	ld	s2,32(sp)
    800040b4:	69e2                	ld	s3,24(sp)
    800040b6:	6a42                	ld	s4,16(sp)
    800040b8:	6121                	addi	sp,sp,64
    800040ba:	8082                	ret
    iput(ip);
    800040bc:	00000097          	auipc	ra,0x0
    800040c0:	a30080e7          	jalr	-1488(ra) # 80003aec <iput>
    return -1;
    800040c4:	557d                	li	a0,-1
    800040c6:	b7dd                	j	800040ac <dirlink+0x86>
      panic("dirlink read");
    800040c8:	00004517          	auipc	a0,0x4
    800040cc:	59850513          	addi	a0,a0,1432 # 80008660 <syscalls+0x1c8>
    800040d0:	ffffc097          	auipc	ra,0xffffc
    800040d4:	46e080e7          	jalr	1134(ra) # 8000053e <panic>

00000000800040d8 <namei>:

struct inode*
namei(char *path)
{
    800040d8:	1101                	addi	sp,sp,-32
    800040da:	ec06                	sd	ra,24(sp)
    800040dc:	e822                	sd	s0,16(sp)
    800040de:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    800040e0:	fe040613          	addi	a2,s0,-32
    800040e4:	4581                	li	a1,0
    800040e6:	00000097          	auipc	ra,0x0
    800040ea:	de0080e7          	jalr	-544(ra) # 80003ec6 <namex>
}
    800040ee:	60e2                	ld	ra,24(sp)
    800040f0:	6442                	ld	s0,16(sp)
    800040f2:	6105                	addi	sp,sp,32
    800040f4:	8082                	ret

00000000800040f6 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    800040f6:	1141                	addi	sp,sp,-16
    800040f8:	e406                	sd	ra,8(sp)
    800040fa:	e022                	sd	s0,0(sp)
    800040fc:	0800                	addi	s0,sp,16
    800040fe:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80004100:	4585                	li	a1,1
    80004102:	00000097          	auipc	ra,0x0
    80004106:	dc4080e7          	jalr	-572(ra) # 80003ec6 <namex>
}
    8000410a:	60a2                	ld	ra,8(sp)
    8000410c:	6402                	ld	s0,0(sp)
    8000410e:	0141                	addi	sp,sp,16
    80004110:	8082                	ret

0000000080004112 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80004112:	1101                	addi	sp,sp,-32
    80004114:	ec06                	sd	ra,24(sp)
    80004116:	e822                	sd	s0,16(sp)
    80004118:	e426                	sd	s1,8(sp)
    8000411a:	e04a                	sd	s2,0(sp)
    8000411c:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    8000411e:	0023d917          	auipc	s2,0x23d
    80004122:	a4a90913          	addi	s2,s2,-1462 # 80240b68 <log>
    80004126:	01892583          	lw	a1,24(s2)
    8000412a:	02892503          	lw	a0,40(s2)
    8000412e:	fffff097          	auipc	ra,0xfffff
    80004132:	fe8080e7          	jalr	-24(ra) # 80003116 <bread>
    80004136:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80004138:	02c92683          	lw	a3,44(s2)
    8000413c:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    8000413e:	02d05863          	blez	a3,8000416e <write_head+0x5c>
    80004142:	0023d797          	auipc	a5,0x23d
    80004146:	a5678793          	addi	a5,a5,-1450 # 80240b98 <log+0x30>
    8000414a:	05c50713          	addi	a4,a0,92
    8000414e:	36fd                	addiw	a3,a3,-1
    80004150:	02069613          	slli	a2,a3,0x20
    80004154:	01e65693          	srli	a3,a2,0x1e
    80004158:	0023d617          	auipc	a2,0x23d
    8000415c:	a4460613          	addi	a2,a2,-1468 # 80240b9c <log+0x34>
    80004160:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80004162:	4390                	lw	a2,0(a5)
    80004164:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80004166:	0791                	addi	a5,a5,4
    80004168:	0711                	addi	a4,a4,4
    8000416a:	fed79ce3          	bne	a5,a3,80004162 <write_head+0x50>
  }
  bwrite(buf);
    8000416e:	8526                	mv	a0,s1
    80004170:	fffff097          	auipc	ra,0xfffff
    80004174:	098080e7          	jalr	152(ra) # 80003208 <bwrite>
  brelse(buf);
    80004178:	8526                	mv	a0,s1
    8000417a:	fffff097          	auipc	ra,0xfffff
    8000417e:	0cc080e7          	jalr	204(ra) # 80003246 <brelse>
}
    80004182:	60e2                	ld	ra,24(sp)
    80004184:	6442                	ld	s0,16(sp)
    80004186:	64a2                	ld	s1,8(sp)
    80004188:	6902                	ld	s2,0(sp)
    8000418a:	6105                	addi	sp,sp,32
    8000418c:	8082                	ret

000000008000418e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    8000418e:	0023d797          	auipc	a5,0x23d
    80004192:	a067a783          	lw	a5,-1530(a5) # 80240b94 <log+0x2c>
    80004196:	0af05d63          	blez	a5,80004250 <install_trans+0xc2>
{
    8000419a:	7139                	addi	sp,sp,-64
    8000419c:	fc06                	sd	ra,56(sp)
    8000419e:	f822                	sd	s0,48(sp)
    800041a0:	f426                	sd	s1,40(sp)
    800041a2:	f04a                	sd	s2,32(sp)
    800041a4:	ec4e                	sd	s3,24(sp)
    800041a6:	e852                	sd	s4,16(sp)
    800041a8:	e456                	sd	s5,8(sp)
    800041aa:	e05a                	sd	s6,0(sp)
    800041ac:	0080                	addi	s0,sp,64
    800041ae:	8b2a                	mv	s6,a0
    800041b0:	0023da97          	auipc	s5,0x23d
    800041b4:	9e8a8a93          	addi	s5,s5,-1560 # 80240b98 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    800041b8:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800041ba:	0023d997          	auipc	s3,0x23d
    800041be:	9ae98993          	addi	s3,s3,-1618 # 80240b68 <log>
    800041c2:	a00d                	j	800041e4 <install_trans+0x56>
    brelse(lbuf);
    800041c4:	854a                	mv	a0,s2
    800041c6:	fffff097          	auipc	ra,0xfffff
    800041ca:	080080e7          	jalr	128(ra) # 80003246 <brelse>
    brelse(dbuf);
    800041ce:	8526                	mv	a0,s1
    800041d0:	fffff097          	auipc	ra,0xfffff
    800041d4:	076080e7          	jalr	118(ra) # 80003246 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800041d8:	2a05                	addiw	s4,s4,1
    800041da:	0a91                	addi	s5,s5,4
    800041dc:	02c9a783          	lw	a5,44(s3)
    800041e0:	04fa5e63          	bge	s4,a5,8000423c <install_trans+0xae>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800041e4:	0189a583          	lw	a1,24(s3)
    800041e8:	014585bb          	addw	a1,a1,s4
    800041ec:	2585                	addiw	a1,a1,1
    800041ee:	0289a503          	lw	a0,40(s3)
    800041f2:	fffff097          	auipc	ra,0xfffff
    800041f6:	f24080e7          	jalr	-220(ra) # 80003116 <bread>
    800041fa:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    800041fc:	000aa583          	lw	a1,0(s5)
    80004200:	0289a503          	lw	a0,40(s3)
    80004204:	fffff097          	auipc	ra,0xfffff
    80004208:	f12080e7          	jalr	-238(ra) # 80003116 <bread>
    8000420c:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    8000420e:	40000613          	li	a2,1024
    80004212:	05890593          	addi	a1,s2,88
    80004216:	05850513          	addi	a0,a0,88
    8000421a:	ffffd097          	auipc	ra,0xffffd
    8000421e:	c6e080e7          	jalr	-914(ra) # 80000e88 <memmove>
    bwrite(dbuf);  // write dst to disk
    80004222:	8526                	mv	a0,s1
    80004224:	fffff097          	auipc	ra,0xfffff
    80004228:	fe4080e7          	jalr	-28(ra) # 80003208 <bwrite>
    if(recovering == 0)
    8000422c:	f80b1ce3          	bnez	s6,800041c4 <install_trans+0x36>
      bunpin(dbuf);
    80004230:	8526                	mv	a0,s1
    80004232:	fffff097          	auipc	ra,0xfffff
    80004236:	0ee080e7          	jalr	238(ra) # 80003320 <bunpin>
    8000423a:	b769                	j	800041c4 <install_trans+0x36>
}
    8000423c:	70e2                	ld	ra,56(sp)
    8000423e:	7442                	ld	s0,48(sp)
    80004240:	74a2                	ld	s1,40(sp)
    80004242:	7902                	ld	s2,32(sp)
    80004244:	69e2                	ld	s3,24(sp)
    80004246:	6a42                	ld	s4,16(sp)
    80004248:	6aa2                	ld	s5,8(sp)
    8000424a:	6b02                	ld	s6,0(sp)
    8000424c:	6121                	addi	sp,sp,64
    8000424e:	8082                	ret
    80004250:	8082                	ret

0000000080004252 <initlog>:
{
    80004252:	7179                	addi	sp,sp,-48
    80004254:	f406                	sd	ra,40(sp)
    80004256:	f022                	sd	s0,32(sp)
    80004258:	ec26                	sd	s1,24(sp)
    8000425a:	e84a                	sd	s2,16(sp)
    8000425c:	e44e                	sd	s3,8(sp)
    8000425e:	1800                	addi	s0,sp,48
    80004260:	892a                	mv	s2,a0
    80004262:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80004264:	0023d497          	auipc	s1,0x23d
    80004268:	90448493          	addi	s1,s1,-1788 # 80240b68 <log>
    8000426c:	00004597          	auipc	a1,0x4
    80004270:	40458593          	addi	a1,a1,1028 # 80008670 <syscalls+0x1d8>
    80004274:	8526                	mv	a0,s1
    80004276:	ffffd097          	auipc	ra,0xffffd
    8000427a:	a2a080e7          	jalr	-1494(ra) # 80000ca0 <initlock>
  log.start = sb->logstart;
    8000427e:	0149a583          	lw	a1,20(s3)
    80004282:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80004284:	0109a783          	lw	a5,16(s3)
    80004288:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    8000428a:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    8000428e:	854a                	mv	a0,s2
    80004290:	fffff097          	auipc	ra,0xfffff
    80004294:	e86080e7          	jalr	-378(ra) # 80003116 <bread>
  log.lh.n = lh->n;
    80004298:	4d34                	lw	a3,88(a0)
    8000429a:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    8000429c:	02d05663          	blez	a3,800042c8 <initlog+0x76>
    800042a0:	05c50793          	addi	a5,a0,92
    800042a4:	0023d717          	auipc	a4,0x23d
    800042a8:	8f470713          	addi	a4,a4,-1804 # 80240b98 <log+0x30>
    800042ac:	36fd                	addiw	a3,a3,-1
    800042ae:	02069613          	slli	a2,a3,0x20
    800042b2:	01e65693          	srli	a3,a2,0x1e
    800042b6:	06050613          	addi	a2,a0,96
    800042ba:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    800042bc:	4390                	lw	a2,0(a5)
    800042be:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800042c0:	0791                	addi	a5,a5,4
    800042c2:	0711                	addi	a4,a4,4
    800042c4:	fed79ce3          	bne	a5,a3,800042bc <initlog+0x6a>
  brelse(buf);
    800042c8:	fffff097          	auipc	ra,0xfffff
    800042cc:	f7e080e7          	jalr	-130(ra) # 80003246 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800042d0:	4505                	li	a0,1
    800042d2:	00000097          	auipc	ra,0x0
    800042d6:	ebc080e7          	jalr	-324(ra) # 8000418e <install_trans>
  log.lh.n = 0;
    800042da:	0023d797          	auipc	a5,0x23d
    800042de:	8a07ad23          	sw	zero,-1862(a5) # 80240b94 <log+0x2c>
  write_head(); // clear the log
    800042e2:	00000097          	auipc	ra,0x0
    800042e6:	e30080e7          	jalr	-464(ra) # 80004112 <write_head>
}
    800042ea:	70a2                	ld	ra,40(sp)
    800042ec:	7402                	ld	s0,32(sp)
    800042ee:	64e2                	ld	s1,24(sp)
    800042f0:	6942                	ld	s2,16(sp)
    800042f2:	69a2                	ld	s3,8(sp)
    800042f4:	6145                	addi	sp,sp,48
    800042f6:	8082                	ret

00000000800042f8 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    800042f8:	1101                	addi	sp,sp,-32
    800042fa:	ec06                	sd	ra,24(sp)
    800042fc:	e822                	sd	s0,16(sp)
    800042fe:	e426                	sd	s1,8(sp)
    80004300:	e04a                	sd	s2,0(sp)
    80004302:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004304:	0023d517          	auipc	a0,0x23d
    80004308:	86450513          	addi	a0,a0,-1948 # 80240b68 <log>
    8000430c:	ffffd097          	auipc	ra,0xffffd
    80004310:	a24080e7          	jalr	-1500(ra) # 80000d30 <acquire>
  while(1){
    if(log.committing){
    80004314:	0023d497          	auipc	s1,0x23d
    80004318:	85448493          	addi	s1,s1,-1964 # 80240b68 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    8000431c:	4979                	li	s2,30
    8000431e:	a039                	j	8000432c <begin_op+0x34>
      sleep(&log, &log.lock);
    80004320:	85a6                	mv	a1,s1
    80004322:	8526                	mv	a0,s1
    80004324:	ffffe097          	auipc	ra,0xffffe
    80004328:	fba080e7          	jalr	-70(ra) # 800022de <sleep>
    if(log.committing){
    8000432c:	50dc                	lw	a5,36(s1)
    8000432e:	fbed                	bnez	a5,80004320 <begin_op+0x28>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80004330:	509c                	lw	a5,32(s1)
    80004332:	0017871b          	addiw	a4,a5,1
    80004336:	0007069b          	sext.w	a3,a4
    8000433a:	0027179b          	slliw	a5,a4,0x2
    8000433e:	9fb9                	addw	a5,a5,a4
    80004340:	0017979b          	slliw	a5,a5,0x1
    80004344:	54d8                	lw	a4,44(s1)
    80004346:	9fb9                	addw	a5,a5,a4
    80004348:	00f95963          	bge	s2,a5,8000435a <begin_op+0x62>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    8000434c:	85a6                	mv	a1,s1
    8000434e:	8526                	mv	a0,s1
    80004350:	ffffe097          	auipc	ra,0xffffe
    80004354:	f8e080e7          	jalr	-114(ra) # 800022de <sleep>
    80004358:	bfd1                	j	8000432c <begin_op+0x34>
    } else {
      log.outstanding += 1;
    8000435a:	0023d517          	auipc	a0,0x23d
    8000435e:	80e50513          	addi	a0,a0,-2034 # 80240b68 <log>
    80004362:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80004364:	ffffd097          	auipc	ra,0xffffd
    80004368:	a80080e7          	jalr	-1408(ra) # 80000de4 <release>
      break;
    }
  }
}
    8000436c:	60e2                	ld	ra,24(sp)
    8000436e:	6442                	ld	s0,16(sp)
    80004370:	64a2                	ld	s1,8(sp)
    80004372:	6902                	ld	s2,0(sp)
    80004374:	6105                	addi	sp,sp,32
    80004376:	8082                	ret

0000000080004378 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80004378:	7139                	addi	sp,sp,-64
    8000437a:	fc06                	sd	ra,56(sp)
    8000437c:	f822                	sd	s0,48(sp)
    8000437e:	f426                	sd	s1,40(sp)
    80004380:	f04a                	sd	s2,32(sp)
    80004382:	ec4e                	sd	s3,24(sp)
    80004384:	e852                	sd	s4,16(sp)
    80004386:	e456                	sd	s5,8(sp)
    80004388:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    8000438a:	0023c497          	auipc	s1,0x23c
    8000438e:	7de48493          	addi	s1,s1,2014 # 80240b68 <log>
    80004392:	8526                	mv	a0,s1
    80004394:	ffffd097          	auipc	ra,0xffffd
    80004398:	99c080e7          	jalr	-1636(ra) # 80000d30 <acquire>
  log.outstanding -= 1;
    8000439c:	509c                	lw	a5,32(s1)
    8000439e:	37fd                	addiw	a5,a5,-1
    800043a0:	0007891b          	sext.w	s2,a5
    800043a4:	d09c                	sw	a5,32(s1)
  if(log.committing)
    800043a6:	50dc                	lw	a5,36(s1)
    800043a8:	e7b9                	bnez	a5,800043f6 <end_op+0x7e>
    panic("log.committing");
  if(log.outstanding == 0){
    800043aa:	04091e63          	bnez	s2,80004406 <end_op+0x8e>
    do_commit = 1;
    log.committing = 1;
    800043ae:	0023c497          	auipc	s1,0x23c
    800043b2:	7ba48493          	addi	s1,s1,1978 # 80240b68 <log>
    800043b6:	4785                	li	a5,1
    800043b8:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800043ba:	8526                	mv	a0,s1
    800043bc:	ffffd097          	auipc	ra,0xffffd
    800043c0:	a28080e7          	jalr	-1496(ra) # 80000de4 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800043c4:	54dc                	lw	a5,44(s1)
    800043c6:	06f04763          	bgtz	a5,80004434 <end_op+0xbc>
    acquire(&log.lock);
    800043ca:	0023c497          	auipc	s1,0x23c
    800043ce:	79e48493          	addi	s1,s1,1950 # 80240b68 <log>
    800043d2:	8526                	mv	a0,s1
    800043d4:	ffffd097          	auipc	ra,0xffffd
    800043d8:	95c080e7          	jalr	-1700(ra) # 80000d30 <acquire>
    log.committing = 0;
    800043dc:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    800043e0:	8526                	mv	a0,s1
    800043e2:	ffffe097          	auipc	ra,0xffffe
    800043e6:	f60080e7          	jalr	-160(ra) # 80002342 <wakeup>
    release(&log.lock);
    800043ea:	8526                	mv	a0,s1
    800043ec:	ffffd097          	auipc	ra,0xffffd
    800043f0:	9f8080e7          	jalr	-1544(ra) # 80000de4 <release>
}
    800043f4:	a03d                	j	80004422 <end_op+0xaa>
    panic("log.committing");
    800043f6:	00004517          	auipc	a0,0x4
    800043fa:	28250513          	addi	a0,a0,642 # 80008678 <syscalls+0x1e0>
    800043fe:	ffffc097          	auipc	ra,0xffffc
    80004402:	140080e7          	jalr	320(ra) # 8000053e <panic>
    wakeup(&log);
    80004406:	0023c497          	auipc	s1,0x23c
    8000440a:	76248493          	addi	s1,s1,1890 # 80240b68 <log>
    8000440e:	8526                	mv	a0,s1
    80004410:	ffffe097          	auipc	ra,0xffffe
    80004414:	f32080e7          	jalr	-206(ra) # 80002342 <wakeup>
  release(&log.lock);
    80004418:	8526                	mv	a0,s1
    8000441a:	ffffd097          	auipc	ra,0xffffd
    8000441e:	9ca080e7          	jalr	-1590(ra) # 80000de4 <release>
}
    80004422:	70e2                	ld	ra,56(sp)
    80004424:	7442                	ld	s0,48(sp)
    80004426:	74a2                	ld	s1,40(sp)
    80004428:	7902                	ld	s2,32(sp)
    8000442a:	69e2                	ld	s3,24(sp)
    8000442c:	6a42                	ld	s4,16(sp)
    8000442e:	6aa2                	ld	s5,8(sp)
    80004430:	6121                	addi	sp,sp,64
    80004432:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    80004434:	0023ca97          	auipc	s5,0x23c
    80004438:	764a8a93          	addi	s5,s5,1892 # 80240b98 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    8000443c:	0023ca17          	auipc	s4,0x23c
    80004440:	72ca0a13          	addi	s4,s4,1836 # 80240b68 <log>
    80004444:	018a2583          	lw	a1,24(s4)
    80004448:	012585bb          	addw	a1,a1,s2
    8000444c:	2585                	addiw	a1,a1,1
    8000444e:	028a2503          	lw	a0,40(s4)
    80004452:	fffff097          	auipc	ra,0xfffff
    80004456:	cc4080e7          	jalr	-828(ra) # 80003116 <bread>
    8000445a:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    8000445c:	000aa583          	lw	a1,0(s5)
    80004460:	028a2503          	lw	a0,40(s4)
    80004464:	fffff097          	auipc	ra,0xfffff
    80004468:	cb2080e7          	jalr	-846(ra) # 80003116 <bread>
    8000446c:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    8000446e:	40000613          	li	a2,1024
    80004472:	05850593          	addi	a1,a0,88
    80004476:	05848513          	addi	a0,s1,88
    8000447a:	ffffd097          	auipc	ra,0xffffd
    8000447e:	a0e080e7          	jalr	-1522(ra) # 80000e88 <memmove>
    bwrite(to);  // write the log
    80004482:	8526                	mv	a0,s1
    80004484:	fffff097          	auipc	ra,0xfffff
    80004488:	d84080e7          	jalr	-636(ra) # 80003208 <bwrite>
    brelse(from);
    8000448c:	854e                	mv	a0,s3
    8000448e:	fffff097          	auipc	ra,0xfffff
    80004492:	db8080e7          	jalr	-584(ra) # 80003246 <brelse>
    brelse(to);
    80004496:	8526                	mv	a0,s1
    80004498:	fffff097          	auipc	ra,0xfffff
    8000449c:	dae080e7          	jalr	-594(ra) # 80003246 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800044a0:	2905                	addiw	s2,s2,1
    800044a2:	0a91                	addi	s5,s5,4
    800044a4:	02ca2783          	lw	a5,44(s4)
    800044a8:	f8f94ee3          	blt	s2,a5,80004444 <end_op+0xcc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800044ac:	00000097          	auipc	ra,0x0
    800044b0:	c66080e7          	jalr	-922(ra) # 80004112 <write_head>
    install_trans(0); // Now install writes to home locations
    800044b4:	4501                	li	a0,0
    800044b6:	00000097          	auipc	ra,0x0
    800044ba:	cd8080e7          	jalr	-808(ra) # 8000418e <install_trans>
    log.lh.n = 0;
    800044be:	0023c797          	auipc	a5,0x23c
    800044c2:	6c07ab23          	sw	zero,1750(a5) # 80240b94 <log+0x2c>
    write_head();    // Erase the transaction from the log
    800044c6:	00000097          	auipc	ra,0x0
    800044ca:	c4c080e7          	jalr	-948(ra) # 80004112 <write_head>
    800044ce:	bdf5                	j	800043ca <end_op+0x52>

00000000800044d0 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800044d0:	1101                	addi	sp,sp,-32
    800044d2:	ec06                	sd	ra,24(sp)
    800044d4:	e822                	sd	s0,16(sp)
    800044d6:	e426                	sd	s1,8(sp)
    800044d8:	e04a                	sd	s2,0(sp)
    800044da:	1000                	addi	s0,sp,32
    800044dc:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800044de:	0023c917          	auipc	s2,0x23c
    800044e2:	68a90913          	addi	s2,s2,1674 # 80240b68 <log>
    800044e6:	854a                	mv	a0,s2
    800044e8:	ffffd097          	auipc	ra,0xffffd
    800044ec:	848080e7          	jalr	-1976(ra) # 80000d30 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800044f0:	02c92603          	lw	a2,44(s2)
    800044f4:	47f5                	li	a5,29
    800044f6:	06c7c563          	blt	a5,a2,80004560 <log_write+0x90>
    800044fa:	0023c797          	auipc	a5,0x23c
    800044fe:	68a7a783          	lw	a5,1674(a5) # 80240b84 <log+0x1c>
    80004502:	37fd                	addiw	a5,a5,-1
    80004504:	04f65e63          	bge	a2,a5,80004560 <log_write+0x90>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80004508:	0023c797          	auipc	a5,0x23c
    8000450c:	6807a783          	lw	a5,1664(a5) # 80240b88 <log+0x20>
    80004510:	06f05063          	blez	a5,80004570 <log_write+0xa0>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004514:	4781                	li	a5,0
    80004516:	06c05563          	blez	a2,80004580 <log_write+0xb0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000451a:	44cc                	lw	a1,12(s1)
    8000451c:	0023c717          	auipc	a4,0x23c
    80004520:	67c70713          	addi	a4,a4,1660 # 80240b98 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80004524:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80004526:	4314                	lw	a3,0(a4)
    80004528:	04b68c63          	beq	a3,a1,80004580 <log_write+0xb0>
  for (i = 0; i < log.lh.n; i++) {
    8000452c:	2785                	addiw	a5,a5,1
    8000452e:	0711                	addi	a4,a4,4
    80004530:	fef61be3          	bne	a2,a5,80004526 <log_write+0x56>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004534:	0621                	addi	a2,a2,8
    80004536:	060a                	slli	a2,a2,0x2
    80004538:	0023c797          	auipc	a5,0x23c
    8000453c:	63078793          	addi	a5,a5,1584 # 80240b68 <log>
    80004540:	963e                	add	a2,a2,a5
    80004542:	44dc                	lw	a5,12(s1)
    80004544:	ca1c                	sw	a5,16(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80004546:	8526                	mv	a0,s1
    80004548:	fffff097          	auipc	ra,0xfffff
    8000454c:	d9c080e7          	jalr	-612(ra) # 800032e4 <bpin>
    log.lh.n++;
    80004550:	0023c717          	auipc	a4,0x23c
    80004554:	61870713          	addi	a4,a4,1560 # 80240b68 <log>
    80004558:	575c                	lw	a5,44(a4)
    8000455a:	2785                	addiw	a5,a5,1
    8000455c:	d75c                	sw	a5,44(a4)
    8000455e:	a835                	j	8000459a <log_write+0xca>
    panic("too big a transaction");
    80004560:	00004517          	auipc	a0,0x4
    80004564:	12850513          	addi	a0,a0,296 # 80008688 <syscalls+0x1f0>
    80004568:	ffffc097          	auipc	ra,0xffffc
    8000456c:	fd6080e7          	jalr	-42(ra) # 8000053e <panic>
    panic("log_write outside of trans");
    80004570:	00004517          	auipc	a0,0x4
    80004574:	13050513          	addi	a0,a0,304 # 800086a0 <syscalls+0x208>
    80004578:	ffffc097          	auipc	ra,0xffffc
    8000457c:	fc6080e7          	jalr	-58(ra) # 8000053e <panic>
  log.lh.block[i] = b->blockno;
    80004580:	00878713          	addi	a4,a5,8
    80004584:	00271693          	slli	a3,a4,0x2
    80004588:	0023c717          	auipc	a4,0x23c
    8000458c:	5e070713          	addi	a4,a4,1504 # 80240b68 <log>
    80004590:	9736                	add	a4,a4,a3
    80004592:	44d4                	lw	a3,12(s1)
    80004594:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80004596:	faf608e3          	beq	a2,a5,80004546 <log_write+0x76>
  }
  release(&log.lock);
    8000459a:	0023c517          	auipc	a0,0x23c
    8000459e:	5ce50513          	addi	a0,a0,1486 # 80240b68 <log>
    800045a2:	ffffd097          	auipc	ra,0xffffd
    800045a6:	842080e7          	jalr	-1982(ra) # 80000de4 <release>
}
    800045aa:	60e2                	ld	ra,24(sp)
    800045ac:	6442                	ld	s0,16(sp)
    800045ae:	64a2                	ld	s1,8(sp)
    800045b0:	6902                	ld	s2,0(sp)
    800045b2:	6105                	addi	sp,sp,32
    800045b4:	8082                	ret

00000000800045b6 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800045b6:	1101                	addi	sp,sp,-32
    800045b8:	ec06                	sd	ra,24(sp)
    800045ba:	e822                	sd	s0,16(sp)
    800045bc:	e426                	sd	s1,8(sp)
    800045be:	e04a                	sd	s2,0(sp)
    800045c0:	1000                	addi	s0,sp,32
    800045c2:	84aa                	mv	s1,a0
    800045c4:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800045c6:	00004597          	auipc	a1,0x4
    800045ca:	0fa58593          	addi	a1,a1,250 # 800086c0 <syscalls+0x228>
    800045ce:	0521                	addi	a0,a0,8
    800045d0:	ffffc097          	auipc	ra,0xffffc
    800045d4:	6d0080e7          	jalr	1744(ra) # 80000ca0 <initlock>
  lk->name = name;
    800045d8:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800045dc:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800045e0:	0204a423          	sw	zero,40(s1)
}
    800045e4:	60e2                	ld	ra,24(sp)
    800045e6:	6442                	ld	s0,16(sp)
    800045e8:	64a2                	ld	s1,8(sp)
    800045ea:	6902                	ld	s2,0(sp)
    800045ec:	6105                	addi	sp,sp,32
    800045ee:	8082                	ret

00000000800045f0 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800045f0:	1101                	addi	sp,sp,-32
    800045f2:	ec06                	sd	ra,24(sp)
    800045f4:	e822                	sd	s0,16(sp)
    800045f6:	e426                	sd	s1,8(sp)
    800045f8:	e04a                	sd	s2,0(sp)
    800045fa:	1000                	addi	s0,sp,32
    800045fc:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800045fe:	00850913          	addi	s2,a0,8
    80004602:	854a                	mv	a0,s2
    80004604:	ffffc097          	auipc	ra,0xffffc
    80004608:	72c080e7          	jalr	1836(ra) # 80000d30 <acquire>
  while (lk->locked) {
    8000460c:	409c                	lw	a5,0(s1)
    8000460e:	cb89                	beqz	a5,80004620 <acquiresleep+0x30>
    sleep(lk, &lk->lk);
    80004610:	85ca                	mv	a1,s2
    80004612:	8526                	mv	a0,s1
    80004614:	ffffe097          	auipc	ra,0xffffe
    80004618:	cca080e7          	jalr	-822(ra) # 800022de <sleep>
  while (lk->locked) {
    8000461c:	409c                	lw	a5,0(s1)
    8000461e:	fbed                	bnez	a5,80004610 <acquiresleep+0x20>
  }
  lk->locked = 1;
    80004620:	4785                	li	a5,1
    80004622:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004624:	ffffd097          	auipc	ra,0xffffd
    80004628:	60e080e7          	jalr	1550(ra) # 80001c32 <myproc>
    8000462c:	591c                	lw	a5,48(a0)
    8000462e:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004630:	854a                	mv	a0,s2
    80004632:	ffffc097          	auipc	ra,0xffffc
    80004636:	7b2080e7          	jalr	1970(ra) # 80000de4 <release>
}
    8000463a:	60e2                	ld	ra,24(sp)
    8000463c:	6442                	ld	s0,16(sp)
    8000463e:	64a2                	ld	s1,8(sp)
    80004640:	6902                	ld	s2,0(sp)
    80004642:	6105                	addi	sp,sp,32
    80004644:	8082                	ret

0000000080004646 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004646:	1101                	addi	sp,sp,-32
    80004648:	ec06                	sd	ra,24(sp)
    8000464a:	e822                	sd	s0,16(sp)
    8000464c:	e426                	sd	s1,8(sp)
    8000464e:	e04a                	sd	s2,0(sp)
    80004650:	1000                	addi	s0,sp,32
    80004652:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004654:	00850913          	addi	s2,a0,8
    80004658:	854a                	mv	a0,s2
    8000465a:	ffffc097          	auipc	ra,0xffffc
    8000465e:	6d6080e7          	jalr	1750(ra) # 80000d30 <acquire>
  lk->locked = 0;
    80004662:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004666:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000466a:	8526                	mv	a0,s1
    8000466c:	ffffe097          	auipc	ra,0xffffe
    80004670:	cd6080e7          	jalr	-810(ra) # 80002342 <wakeup>
  release(&lk->lk);
    80004674:	854a                	mv	a0,s2
    80004676:	ffffc097          	auipc	ra,0xffffc
    8000467a:	76e080e7          	jalr	1902(ra) # 80000de4 <release>
}
    8000467e:	60e2                	ld	ra,24(sp)
    80004680:	6442                	ld	s0,16(sp)
    80004682:	64a2                	ld	s1,8(sp)
    80004684:	6902                	ld	s2,0(sp)
    80004686:	6105                	addi	sp,sp,32
    80004688:	8082                	ret

000000008000468a <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000468a:	7179                	addi	sp,sp,-48
    8000468c:	f406                	sd	ra,40(sp)
    8000468e:	f022                	sd	s0,32(sp)
    80004690:	ec26                	sd	s1,24(sp)
    80004692:	e84a                	sd	s2,16(sp)
    80004694:	e44e                	sd	s3,8(sp)
    80004696:	1800                	addi	s0,sp,48
    80004698:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000469a:	00850913          	addi	s2,a0,8
    8000469e:	854a                	mv	a0,s2
    800046a0:	ffffc097          	auipc	ra,0xffffc
    800046a4:	690080e7          	jalr	1680(ra) # 80000d30 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800046a8:	409c                	lw	a5,0(s1)
    800046aa:	ef99                	bnez	a5,800046c8 <holdingsleep+0x3e>
    800046ac:	4481                	li	s1,0
  release(&lk->lk);
    800046ae:	854a                	mv	a0,s2
    800046b0:	ffffc097          	auipc	ra,0xffffc
    800046b4:	734080e7          	jalr	1844(ra) # 80000de4 <release>
  return r;
}
    800046b8:	8526                	mv	a0,s1
    800046ba:	70a2                	ld	ra,40(sp)
    800046bc:	7402                	ld	s0,32(sp)
    800046be:	64e2                	ld	s1,24(sp)
    800046c0:	6942                	ld	s2,16(sp)
    800046c2:	69a2                	ld	s3,8(sp)
    800046c4:	6145                	addi	sp,sp,48
    800046c6:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    800046c8:	0284a983          	lw	s3,40(s1)
    800046cc:	ffffd097          	auipc	ra,0xffffd
    800046d0:	566080e7          	jalr	1382(ra) # 80001c32 <myproc>
    800046d4:	5904                	lw	s1,48(a0)
    800046d6:	413484b3          	sub	s1,s1,s3
    800046da:	0014b493          	seqz	s1,s1
    800046de:	bfc1                	j	800046ae <holdingsleep+0x24>

00000000800046e0 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800046e0:	1141                	addi	sp,sp,-16
    800046e2:	e406                	sd	ra,8(sp)
    800046e4:	e022                	sd	s0,0(sp)
    800046e6:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800046e8:	00004597          	auipc	a1,0x4
    800046ec:	fe858593          	addi	a1,a1,-24 # 800086d0 <syscalls+0x238>
    800046f0:	0023c517          	auipc	a0,0x23c
    800046f4:	5c050513          	addi	a0,a0,1472 # 80240cb0 <ftable>
    800046f8:	ffffc097          	auipc	ra,0xffffc
    800046fc:	5a8080e7          	jalr	1448(ra) # 80000ca0 <initlock>
}
    80004700:	60a2                	ld	ra,8(sp)
    80004702:	6402                	ld	s0,0(sp)
    80004704:	0141                	addi	sp,sp,16
    80004706:	8082                	ret

0000000080004708 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80004708:	1101                	addi	sp,sp,-32
    8000470a:	ec06                	sd	ra,24(sp)
    8000470c:	e822                	sd	s0,16(sp)
    8000470e:	e426                	sd	s1,8(sp)
    80004710:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004712:	0023c517          	auipc	a0,0x23c
    80004716:	59e50513          	addi	a0,a0,1438 # 80240cb0 <ftable>
    8000471a:	ffffc097          	auipc	ra,0xffffc
    8000471e:	616080e7          	jalr	1558(ra) # 80000d30 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004722:	0023c497          	auipc	s1,0x23c
    80004726:	5a648493          	addi	s1,s1,1446 # 80240cc8 <ftable+0x18>
    8000472a:	0023d717          	auipc	a4,0x23d
    8000472e:	53e70713          	addi	a4,a4,1342 # 80241c68 <disk>
    if(f->ref == 0){
    80004732:	40dc                	lw	a5,4(s1)
    80004734:	cf99                	beqz	a5,80004752 <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004736:	02848493          	addi	s1,s1,40
    8000473a:	fee49ce3          	bne	s1,a4,80004732 <filealloc+0x2a>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000473e:	0023c517          	auipc	a0,0x23c
    80004742:	57250513          	addi	a0,a0,1394 # 80240cb0 <ftable>
    80004746:	ffffc097          	auipc	ra,0xffffc
    8000474a:	69e080e7          	jalr	1694(ra) # 80000de4 <release>
  return 0;
    8000474e:	4481                	li	s1,0
    80004750:	a819                	j	80004766 <filealloc+0x5e>
      f->ref = 1;
    80004752:	4785                	li	a5,1
    80004754:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004756:	0023c517          	auipc	a0,0x23c
    8000475a:	55a50513          	addi	a0,a0,1370 # 80240cb0 <ftable>
    8000475e:	ffffc097          	auipc	ra,0xffffc
    80004762:	686080e7          	jalr	1670(ra) # 80000de4 <release>
}
    80004766:	8526                	mv	a0,s1
    80004768:	60e2                	ld	ra,24(sp)
    8000476a:	6442                	ld	s0,16(sp)
    8000476c:	64a2                	ld	s1,8(sp)
    8000476e:	6105                	addi	sp,sp,32
    80004770:	8082                	ret

0000000080004772 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004772:	1101                	addi	sp,sp,-32
    80004774:	ec06                	sd	ra,24(sp)
    80004776:	e822                	sd	s0,16(sp)
    80004778:	e426                	sd	s1,8(sp)
    8000477a:	1000                	addi	s0,sp,32
    8000477c:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000477e:	0023c517          	auipc	a0,0x23c
    80004782:	53250513          	addi	a0,a0,1330 # 80240cb0 <ftable>
    80004786:	ffffc097          	auipc	ra,0xffffc
    8000478a:	5aa080e7          	jalr	1450(ra) # 80000d30 <acquire>
  if(f->ref < 1)
    8000478e:	40dc                	lw	a5,4(s1)
    80004790:	02f05263          	blez	a5,800047b4 <filedup+0x42>
    panic("filedup");
  f->ref++;
    80004794:	2785                	addiw	a5,a5,1
    80004796:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004798:	0023c517          	auipc	a0,0x23c
    8000479c:	51850513          	addi	a0,a0,1304 # 80240cb0 <ftable>
    800047a0:	ffffc097          	auipc	ra,0xffffc
    800047a4:	644080e7          	jalr	1604(ra) # 80000de4 <release>
  return f;
}
    800047a8:	8526                	mv	a0,s1
    800047aa:	60e2                	ld	ra,24(sp)
    800047ac:	6442                	ld	s0,16(sp)
    800047ae:	64a2                	ld	s1,8(sp)
    800047b0:	6105                	addi	sp,sp,32
    800047b2:	8082                	ret
    panic("filedup");
    800047b4:	00004517          	auipc	a0,0x4
    800047b8:	f2450513          	addi	a0,a0,-220 # 800086d8 <syscalls+0x240>
    800047bc:	ffffc097          	auipc	ra,0xffffc
    800047c0:	d82080e7          	jalr	-638(ra) # 8000053e <panic>

00000000800047c4 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800047c4:	7139                	addi	sp,sp,-64
    800047c6:	fc06                	sd	ra,56(sp)
    800047c8:	f822                	sd	s0,48(sp)
    800047ca:	f426                	sd	s1,40(sp)
    800047cc:	f04a                	sd	s2,32(sp)
    800047ce:	ec4e                	sd	s3,24(sp)
    800047d0:	e852                	sd	s4,16(sp)
    800047d2:	e456                	sd	s5,8(sp)
    800047d4:	0080                	addi	s0,sp,64
    800047d6:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800047d8:	0023c517          	auipc	a0,0x23c
    800047dc:	4d850513          	addi	a0,a0,1240 # 80240cb0 <ftable>
    800047e0:	ffffc097          	auipc	ra,0xffffc
    800047e4:	550080e7          	jalr	1360(ra) # 80000d30 <acquire>
  if(f->ref < 1)
    800047e8:	40dc                	lw	a5,4(s1)
    800047ea:	06f05163          	blez	a5,8000484c <fileclose+0x88>
    panic("fileclose");
  if(--f->ref > 0){
    800047ee:	37fd                	addiw	a5,a5,-1
    800047f0:	0007871b          	sext.w	a4,a5
    800047f4:	c0dc                	sw	a5,4(s1)
    800047f6:	06e04363          	bgtz	a4,8000485c <fileclose+0x98>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800047fa:	0004a903          	lw	s2,0(s1)
    800047fe:	0094ca83          	lbu	s5,9(s1)
    80004802:	0104ba03          	ld	s4,16(s1)
    80004806:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000480a:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000480e:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004812:	0023c517          	auipc	a0,0x23c
    80004816:	49e50513          	addi	a0,a0,1182 # 80240cb0 <ftable>
    8000481a:	ffffc097          	auipc	ra,0xffffc
    8000481e:	5ca080e7          	jalr	1482(ra) # 80000de4 <release>

  if(ff.type == FD_PIPE){
    80004822:	4785                	li	a5,1
    80004824:	04f90d63          	beq	s2,a5,8000487e <fileclose+0xba>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004828:	3979                	addiw	s2,s2,-2
    8000482a:	4785                	li	a5,1
    8000482c:	0527e063          	bltu	a5,s2,8000486c <fileclose+0xa8>
    begin_op();
    80004830:	00000097          	auipc	ra,0x0
    80004834:	ac8080e7          	jalr	-1336(ra) # 800042f8 <begin_op>
    iput(ff.ip);
    80004838:	854e                	mv	a0,s3
    8000483a:	fffff097          	auipc	ra,0xfffff
    8000483e:	2b2080e7          	jalr	690(ra) # 80003aec <iput>
    end_op();
    80004842:	00000097          	auipc	ra,0x0
    80004846:	b36080e7          	jalr	-1226(ra) # 80004378 <end_op>
    8000484a:	a00d                	j	8000486c <fileclose+0xa8>
    panic("fileclose");
    8000484c:	00004517          	auipc	a0,0x4
    80004850:	e9450513          	addi	a0,a0,-364 # 800086e0 <syscalls+0x248>
    80004854:	ffffc097          	auipc	ra,0xffffc
    80004858:	cea080e7          	jalr	-790(ra) # 8000053e <panic>
    release(&ftable.lock);
    8000485c:	0023c517          	auipc	a0,0x23c
    80004860:	45450513          	addi	a0,a0,1108 # 80240cb0 <ftable>
    80004864:	ffffc097          	auipc	ra,0xffffc
    80004868:	580080e7          	jalr	1408(ra) # 80000de4 <release>
  }
}
    8000486c:	70e2                	ld	ra,56(sp)
    8000486e:	7442                	ld	s0,48(sp)
    80004870:	74a2                	ld	s1,40(sp)
    80004872:	7902                	ld	s2,32(sp)
    80004874:	69e2                	ld	s3,24(sp)
    80004876:	6a42                	ld	s4,16(sp)
    80004878:	6aa2                	ld	s5,8(sp)
    8000487a:	6121                	addi	sp,sp,64
    8000487c:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    8000487e:	85d6                	mv	a1,s5
    80004880:	8552                	mv	a0,s4
    80004882:	00000097          	auipc	ra,0x0
    80004886:	34c080e7          	jalr	844(ra) # 80004bce <pipeclose>
    8000488a:	b7cd                	j	8000486c <fileclose+0xa8>

000000008000488c <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000488c:	715d                	addi	sp,sp,-80
    8000488e:	e486                	sd	ra,72(sp)
    80004890:	e0a2                	sd	s0,64(sp)
    80004892:	fc26                	sd	s1,56(sp)
    80004894:	f84a                	sd	s2,48(sp)
    80004896:	f44e                	sd	s3,40(sp)
    80004898:	0880                	addi	s0,sp,80
    8000489a:	84aa                	mv	s1,a0
    8000489c:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    8000489e:	ffffd097          	auipc	ra,0xffffd
    800048a2:	394080e7          	jalr	916(ra) # 80001c32 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800048a6:	409c                	lw	a5,0(s1)
    800048a8:	37f9                	addiw	a5,a5,-2
    800048aa:	4705                	li	a4,1
    800048ac:	04f76763          	bltu	a4,a5,800048fa <filestat+0x6e>
    800048b0:	892a                	mv	s2,a0
    ilock(f->ip);
    800048b2:	6c88                	ld	a0,24(s1)
    800048b4:	fffff097          	auipc	ra,0xfffff
    800048b8:	07e080e7          	jalr	126(ra) # 80003932 <ilock>
    stati(f->ip, &st);
    800048bc:	fb840593          	addi	a1,s0,-72
    800048c0:	6c88                	ld	a0,24(s1)
    800048c2:	fffff097          	auipc	ra,0xfffff
    800048c6:	2fa080e7          	jalr	762(ra) # 80003bbc <stati>
    iunlock(f->ip);
    800048ca:	6c88                	ld	a0,24(s1)
    800048cc:	fffff097          	auipc	ra,0xfffff
    800048d0:	128080e7          	jalr	296(ra) # 800039f4 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800048d4:	46e1                	li	a3,24
    800048d6:	fb840613          	addi	a2,s0,-72
    800048da:	85ce                	mv	a1,s3
    800048dc:	05093503          	ld	a0,80(s2)
    800048e0:	ffffd097          	auipc	ra,0xffffd
    800048e4:	fa2080e7          	jalr	-94(ra) # 80001882 <copyout>
    800048e8:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    800048ec:	60a6                	ld	ra,72(sp)
    800048ee:	6406                	ld	s0,64(sp)
    800048f0:	74e2                	ld	s1,56(sp)
    800048f2:	7942                	ld	s2,48(sp)
    800048f4:	79a2                	ld	s3,40(sp)
    800048f6:	6161                	addi	sp,sp,80
    800048f8:	8082                	ret
  return -1;
    800048fa:	557d                	li	a0,-1
    800048fc:	bfc5                	j	800048ec <filestat+0x60>

00000000800048fe <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800048fe:	7179                	addi	sp,sp,-48
    80004900:	f406                	sd	ra,40(sp)
    80004902:	f022                	sd	s0,32(sp)
    80004904:	ec26                	sd	s1,24(sp)
    80004906:	e84a                	sd	s2,16(sp)
    80004908:	e44e                	sd	s3,8(sp)
    8000490a:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    8000490c:	00854783          	lbu	a5,8(a0)
    80004910:	c3d5                	beqz	a5,800049b4 <fileread+0xb6>
    80004912:	84aa                	mv	s1,a0
    80004914:	89ae                	mv	s3,a1
    80004916:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80004918:	411c                	lw	a5,0(a0)
    8000491a:	4705                	li	a4,1
    8000491c:	04e78963          	beq	a5,a4,8000496e <fileread+0x70>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004920:	470d                	li	a4,3
    80004922:	04e78d63          	beq	a5,a4,8000497c <fileread+0x7e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004926:	4709                	li	a4,2
    80004928:	06e79e63          	bne	a5,a4,800049a4 <fileread+0xa6>
    ilock(f->ip);
    8000492c:	6d08                	ld	a0,24(a0)
    8000492e:	fffff097          	auipc	ra,0xfffff
    80004932:	004080e7          	jalr	4(ra) # 80003932 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004936:	874a                	mv	a4,s2
    80004938:	5094                	lw	a3,32(s1)
    8000493a:	864e                	mv	a2,s3
    8000493c:	4585                	li	a1,1
    8000493e:	6c88                	ld	a0,24(s1)
    80004940:	fffff097          	auipc	ra,0xfffff
    80004944:	2a6080e7          	jalr	678(ra) # 80003be6 <readi>
    80004948:	892a                	mv	s2,a0
    8000494a:	00a05563          	blez	a0,80004954 <fileread+0x56>
      f->off += r;
    8000494e:	509c                	lw	a5,32(s1)
    80004950:	9fa9                	addw	a5,a5,a0
    80004952:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004954:	6c88                	ld	a0,24(s1)
    80004956:	fffff097          	auipc	ra,0xfffff
    8000495a:	09e080e7          	jalr	158(ra) # 800039f4 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    8000495e:	854a                	mv	a0,s2
    80004960:	70a2                	ld	ra,40(sp)
    80004962:	7402                	ld	s0,32(sp)
    80004964:	64e2                	ld	s1,24(sp)
    80004966:	6942                	ld	s2,16(sp)
    80004968:	69a2                	ld	s3,8(sp)
    8000496a:	6145                	addi	sp,sp,48
    8000496c:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000496e:	6908                	ld	a0,16(a0)
    80004970:	00000097          	auipc	ra,0x0
    80004974:	3c6080e7          	jalr	966(ra) # 80004d36 <piperead>
    80004978:	892a                	mv	s2,a0
    8000497a:	b7d5                	j	8000495e <fileread+0x60>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000497c:	02451783          	lh	a5,36(a0)
    80004980:	03079693          	slli	a3,a5,0x30
    80004984:	92c1                	srli	a3,a3,0x30
    80004986:	4725                	li	a4,9
    80004988:	02d76863          	bltu	a4,a3,800049b8 <fileread+0xba>
    8000498c:	0792                	slli	a5,a5,0x4
    8000498e:	0023c717          	auipc	a4,0x23c
    80004992:	28270713          	addi	a4,a4,642 # 80240c10 <devsw>
    80004996:	97ba                	add	a5,a5,a4
    80004998:	639c                	ld	a5,0(a5)
    8000499a:	c38d                	beqz	a5,800049bc <fileread+0xbe>
    r = devsw[f->major].read(1, addr, n);
    8000499c:	4505                	li	a0,1
    8000499e:	9782                	jalr	a5
    800049a0:	892a                	mv	s2,a0
    800049a2:	bf75                	j	8000495e <fileread+0x60>
    panic("fileread");
    800049a4:	00004517          	auipc	a0,0x4
    800049a8:	d4c50513          	addi	a0,a0,-692 # 800086f0 <syscalls+0x258>
    800049ac:	ffffc097          	auipc	ra,0xffffc
    800049b0:	b92080e7          	jalr	-1134(ra) # 8000053e <panic>
    return -1;
    800049b4:	597d                	li	s2,-1
    800049b6:	b765                	j	8000495e <fileread+0x60>
      return -1;
    800049b8:	597d                	li	s2,-1
    800049ba:	b755                	j	8000495e <fileread+0x60>
    800049bc:	597d                	li	s2,-1
    800049be:	b745                	j	8000495e <fileread+0x60>

00000000800049c0 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800049c0:	715d                	addi	sp,sp,-80
    800049c2:	e486                	sd	ra,72(sp)
    800049c4:	e0a2                	sd	s0,64(sp)
    800049c6:	fc26                	sd	s1,56(sp)
    800049c8:	f84a                	sd	s2,48(sp)
    800049ca:	f44e                	sd	s3,40(sp)
    800049cc:	f052                	sd	s4,32(sp)
    800049ce:	ec56                	sd	s5,24(sp)
    800049d0:	e85a                	sd	s6,16(sp)
    800049d2:	e45e                	sd	s7,8(sp)
    800049d4:	e062                	sd	s8,0(sp)
    800049d6:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800049d8:	00954783          	lbu	a5,9(a0)
    800049dc:	10078663          	beqz	a5,80004ae8 <filewrite+0x128>
    800049e0:	892a                	mv	s2,a0
    800049e2:	8aae                	mv	s5,a1
    800049e4:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800049e6:	411c                	lw	a5,0(a0)
    800049e8:	4705                	li	a4,1
    800049ea:	02e78263          	beq	a5,a4,80004a0e <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800049ee:	470d                	li	a4,3
    800049f0:	02e78663          	beq	a5,a4,80004a1c <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800049f4:	4709                	li	a4,2
    800049f6:	0ee79163          	bne	a5,a4,80004ad8 <filewrite+0x118>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800049fa:	0ac05d63          	blez	a2,80004ab4 <filewrite+0xf4>
    int i = 0;
    800049fe:	4981                	li	s3,0
    80004a00:	6b05                	lui	s6,0x1
    80004a02:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    80004a06:	6b85                	lui	s7,0x1
    80004a08:	c00b8b9b          	addiw	s7,s7,-1024
    80004a0c:	a861                	j	80004aa4 <filewrite+0xe4>
    ret = pipewrite(f->pipe, addr, n);
    80004a0e:	6908                	ld	a0,16(a0)
    80004a10:	00000097          	auipc	ra,0x0
    80004a14:	22e080e7          	jalr	558(ra) # 80004c3e <pipewrite>
    80004a18:	8a2a                	mv	s4,a0
    80004a1a:	a045                	j	80004aba <filewrite+0xfa>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004a1c:	02451783          	lh	a5,36(a0)
    80004a20:	03079693          	slli	a3,a5,0x30
    80004a24:	92c1                	srli	a3,a3,0x30
    80004a26:	4725                	li	a4,9
    80004a28:	0cd76263          	bltu	a4,a3,80004aec <filewrite+0x12c>
    80004a2c:	0792                	slli	a5,a5,0x4
    80004a2e:	0023c717          	auipc	a4,0x23c
    80004a32:	1e270713          	addi	a4,a4,482 # 80240c10 <devsw>
    80004a36:	97ba                	add	a5,a5,a4
    80004a38:	679c                	ld	a5,8(a5)
    80004a3a:	cbdd                	beqz	a5,80004af0 <filewrite+0x130>
    ret = devsw[f->major].write(1, addr, n);
    80004a3c:	4505                	li	a0,1
    80004a3e:	9782                	jalr	a5
    80004a40:	8a2a                	mv	s4,a0
    80004a42:	a8a5                	j	80004aba <filewrite+0xfa>
    80004a44:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    80004a48:	00000097          	auipc	ra,0x0
    80004a4c:	8b0080e7          	jalr	-1872(ra) # 800042f8 <begin_op>
      ilock(f->ip);
    80004a50:	01893503          	ld	a0,24(s2)
    80004a54:	fffff097          	auipc	ra,0xfffff
    80004a58:	ede080e7          	jalr	-290(ra) # 80003932 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004a5c:	8762                	mv	a4,s8
    80004a5e:	02092683          	lw	a3,32(s2)
    80004a62:	01598633          	add	a2,s3,s5
    80004a66:	4585                	li	a1,1
    80004a68:	01893503          	ld	a0,24(s2)
    80004a6c:	fffff097          	auipc	ra,0xfffff
    80004a70:	272080e7          	jalr	626(ra) # 80003cde <writei>
    80004a74:	84aa                	mv	s1,a0
    80004a76:	00a05763          	blez	a0,80004a84 <filewrite+0xc4>
        f->off += r;
    80004a7a:	02092783          	lw	a5,32(s2)
    80004a7e:	9fa9                	addw	a5,a5,a0
    80004a80:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004a84:	01893503          	ld	a0,24(s2)
    80004a88:	fffff097          	auipc	ra,0xfffff
    80004a8c:	f6c080e7          	jalr	-148(ra) # 800039f4 <iunlock>
      end_op();
    80004a90:	00000097          	auipc	ra,0x0
    80004a94:	8e8080e7          	jalr	-1816(ra) # 80004378 <end_op>

      if(r != n1){
    80004a98:	009c1f63          	bne	s8,s1,80004ab6 <filewrite+0xf6>
        // error from writei
        break;
      }
      i += r;
    80004a9c:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80004aa0:	0149db63          	bge	s3,s4,80004ab6 <filewrite+0xf6>
      int n1 = n - i;
    80004aa4:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    80004aa8:	84be                	mv	s1,a5
    80004aaa:	2781                	sext.w	a5,a5
    80004aac:	f8fb5ce3          	bge	s6,a5,80004a44 <filewrite+0x84>
    80004ab0:	84de                	mv	s1,s7
    80004ab2:	bf49                	j	80004a44 <filewrite+0x84>
    int i = 0;
    80004ab4:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    80004ab6:	013a1f63          	bne	s4,s3,80004ad4 <filewrite+0x114>
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004aba:	8552                	mv	a0,s4
    80004abc:	60a6                	ld	ra,72(sp)
    80004abe:	6406                	ld	s0,64(sp)
    80004ac0:	74e2                	ld	s1,56(sp)
    80004ac2:	7942                	ld	s2,48(sp)
    80004ac4:	79a2                	ld	s3,40(sp)
    80004ac6:	7a02                	ld	s4,32(sp)
    80004ac8:	6ae2                	ld	s5,24(sp)
    80004aca:	6b42                	ld	s6,16(sp)
    80004acc:	6ba2                	ld	s7,8(sp)
    80004ace:	6c02                	ld	s8,0(sp)
    80004ad0:	6161                	addi	sp,sp,80
    80004ad2:	8082                	ret
    ret = (i == n ? n : -1);
    80004ad4:	5a7d                	li	s4,-1
    80004ad6:	b7d5                	j	80004aba <filewrite+0xfa>
    panic("filewrite");
    80004ad8:	00004517          	auipc	a0,0x4
    80004adc:	c2850513          	addi	a0,a0,-984 # 80008700 <syscalls+0x268>
    80004ae0:	ffffc097          	auipc	ra,0xffffc
    80004ae4:	a5e080e7          	jalr	-1442(ra) # 8000053e <panic>
    return -1;
    80004ae8:	5a7d                	li	s4,-1
    80004aea:	bfc1                	j	80004aba <filewrite+0xfa>
      return -1;
    80004aec:	5a7d                	li	s4,-1
    80004aee:	b7f1                	j	80004aba <filewrite+0xfa>
    80004af0:	5a7d                	li	s4,-1
    80004af2:	b7e1                	j	80004aba <filewrite+0xfa>

0000000080004af4 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004af4:	7179                	addi	sp,sp,-48
    80004af6:	f406                	sd	ra,40(sp)
    80004af8:	f022                	sd	s0,32(sp)
    80004afa:	ec26                	sd	s1,24(sp)
    80004afc:	e84a                	sd	s2,16(sp)
    80004afe:	e44e                	sd	s3,8(sp)
    80004b00:	e052                	sd	s4,0(sp)
    80004b02:	1800                	addi	s0,sp,48
    80004b04:	84aa                	mv	s1,a0
    80004b06:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004b08:	0005b023          	sd	zero,0(a1)
    80004b0c:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004b10:	00000097          	auipc	ra,0x0
    80004b14:	bf8080e7          	jalr	-1032(ra) # 80004708 <filealloc>
    80004b18:	e088                	sd	a0,0(s1)
    80004b1a:	c551                	beqz	a0,80004ba6 <pipealloc+0xb2>
    80004b1c:	00000097          	auipc	ra,0x0
    80004b20:	bec080e7          	jalr	-1044(ra) # 80004708 <filealloc>
    80004b24:	00aa3023          	sd	a0,0(s4)
    80004b28:	c92d                	beqz	a0,80004b9a <pipealloc+0xa6>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004b2a:	ffffc097          	auipc	ra,0xffffc
    80004b2e:	0e8080e7          	jalr	232(ra) # 80000c12 <kalloc>
    80004b32:	892a                	mv	s2,a0
    80004b34:	c125                	beqz	a0,80004b94 <pipealloc+0xa0>
    goto bad;
  pi->readopen = 1;
    80004b36:	4985                	li	s3,1
    80004b38:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004b3c:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004b40:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004b44:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004b48:	00004597          	auipc	a1,0x4
    80004b4c:	bc858593          	addi	a1,a1,-1080 # 80008710 <syscalls+0x278>
    80004b50:	ffffc097          	auipc	ra,0xffffc
    80004b54:	150080e7          	jalr	336(ra) # 80000ca0 <initlock>
  (*f0)->type = FD_PIPE;
    80004b58:	609c                	ld	a5,0(s1)
    80004b5a:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004b5e:	609c                	ld	a5,0(s1)
    80004b60:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004b64:	609c                	ld	a5,0(s1)
    80004b66:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004b6a:	609c                	ld	a5,0(s1)
    80004b6c:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004b70:	000a3783          	ld	a5,0(s4)
    80004b74:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004b78:	000a3783          	ld	a5,0(s4)
    80004b7c:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004b80:	000a3783          	ld	a5,0(s4)
    80004b84:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004b88:	000a3783          	ld	a5,0(s4)
    80004b8c:	0127b823          	sd	s2,16(a5)
  return 0;
    80004b90:	4501                	li	a0,0
    80004b92:	a025                	j	80004bba <pipealloc+0xc6>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004b94:	6088                	ld	a0,0(s1)
    80004b96:	e501                	bnez	a0,80004b9e <pipealloc+0xaa>
    80004b98:	a039                	j	80004ba6 <pipealloc+0xb2>
    80004b9a:	6088                	ld	a0,0(s1)
    80004b9c:	c51d                	beqz	a0,80004bca <pipealloc+0xd6>
    fileclose(*f0);
    80004b9e:	00000097          	auipc	ra,0x0
    80004ba2:	c26080e7          	jalr	-986(ra) # 800047c4 <fileclose>
  if(*f1)
    80004ba6:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004baa:	557d                	li	a0,-1
  if(*f1)
    80004bac:	c799                	beqz	a5,80004bba <pipealloc+0xc6>
    fileclose(*f1);
    80004bae:	853e                	mv	a0,a5
    80004bb0:	00000097          	auipc	ra,0x0
    80004bb4:	c14080e7          	jalr	-1004(ra) # 800047c4 <fileclose>
  return -1;
    80004bb8:	557d                	li	a0,-1
}
    80004bba:	70a2                	ld	ra,40(sp)
    80004bbc:	7402                	ld	s0,32(sp)
    80004bbe:	64e2                	ld	s1,24(sp)
    80004bc0:	6942                	ld	s2,16(sp)
    80004bc2:	69a2                	ld	s3,8(sp)
    80004bc4:	6a02                	ld	s4,0(sp)
    80004bc6:	6145                	addi	sp,sp,48
    80004bc8:	8082                	ret
  return -1;
    80004bca:	557d                	li	a0,-1
    80004bcc:	b7fd                	j	80004bba <pipealloc+0xc6>

0000000080004bce <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004bce:	1101                	addi	sp,sp,-32
    80004bd0:	ec06                	sd	ra,24(sp)
    80004bd2:	e822                	sd	s0,16(sp)
    80004bd4:	e426                	sd	s1,8(sp)
    80004bd6:	e04a                	sd	s2,0(sp)
    80004bd8:	1000                	addi	s0,sp,32
    80004bda:	84aa                	mv	s1,a0
    80004bdc:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004bde:	ffffc097          	auipc	ra,0xffffc
    80004be2:	152080e7          	jalr	338(ra) # 80000d30 <acquire>
  if(writable){
    80004be6:	02090d63          	beqz	s2,80004c20 <pipeclose+0x52>
    pi->writeopen = 0;
    80004bea:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004bee:	21848513          	addi	a0,s1,536
    80004bf2:	ffffd097          	auipc	ra,0xffffd
    80004bf6:	750080e7          	jalr	1872(ra) # 80002342 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004bfa:	2204b783          	ld	a5,544(s1)
    80004bfe:	eb95                	bnez	a5,80004c32 <pipeclose+0x64>
    release(&pi->lock);
    80004c00:	8526                	mv	a0,s1
    80004c02:	ffffc097          	auipc	ra,0xffffc
    80004c06:	1e2080e7          	jalr	482(ra) # 80000de4 <release>
    kfree((char*)pi);
    80004c0a:	8526                	mv	a0,s1
    80004c0c:	ffffc097          	auipc	ra,0xffffc
    80004c10:	ef2080e7          	jalr	-270(ra) # 80000afe <kfree>
  } else
    release(&pi->lock);
}
    80004c14:	60e2                	ld	ra,24(sp)
    80004c16:	6442                	ld	s0,16(sp)
    80004c18:	64a2                	ld	s1,8(sp)
    80004c1a:	6902                	ld	s2,0(sp)
    80004c1c:	6105                	addi	sp,sp,32
    80004c1e:	8082                	ret
    pi->readopen = 0;
    80004c20:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004c24:	21c48513          	addi	a0,s1,540
    80004c28:	ffffd097          	auipc	ra,0xffffd
    80004c2c:	71a080e7          	jalr	1818(ra) # 80002342 <wakeup>
    80004c30:	b7e9                	j	80004bfa <pipeclose+0x2c>
    release(&pi->lock);
    80004c32:	8526                	mv	a0,s1
    80004c34:	ffffc097          	auipc	ra,0xffffc
    80004c38:	1b0080e7          	jalr	432(ra) # 80000de4 <release>
}
    80004c3c:	bfe1                	j	80004c14 <pipeclose+0x46>

0000000080004c3e <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004c3e:	711d                	addi	sp,sp,-96
    80004c40:	ec86                	sd	ra,88(sp)
    80004c42:	e8a2                	sd	s0,80(sp)
    80004c44:	e4a6                	sd	s1,72(sp)
    80004c46:	e0ca                	sd	s2,64(sp)
    80004c48:	fc4e                	sd	s3,56(sp)
    80004c4a:	f852                	sd	s4,48(sp)
    80004c4c:	f456                	sd	s5,40(sp)
    80004c4e:	f05a                	sd	s6,32(sp)
    80004c50:	ec5e                	sd	s7,24(sp)
    80004c52:	e862                	sd	s8,16(sp)
    80004c54:	1080                	addi	s0,sp,96
    80004c56:	84aa                	mv	s1,a0
    80004c58:	8aae                	mv	s5,a1
    80004c5a:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004c5c:	ffffd097          	auipc	ra,0xffffd
    80004c60:	fd6080e7          	jalr	-42(ra) # 80001c32 <myproc>
    80004c64:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004c66:	8526                	mv	a0,s1
    80004c68:	ffffc097          	auipc	ra,0xffffc
    80004c6c:	0c8080e7          	jalr	200(ra) # 80000d30 <acquire>
  while(i < n){
    80004c70:	0b405663          	blez	s4,80004d1c <pipewrite+0xde>
  int i = 0;
    80004c74:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004c76:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004c78:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004c7c:	21c48b93          	addi	s7,s1,540
    80004c80:	a089                	j	80004cc2 <pipewrite+0x84>
      release(&pi->lock);
    80004c82:	8526                	mv	a0,s1
    80004c84:	ffffc097          	auipc	ra,0xffffc
    80004c88:	160080e7          	jalr	352(ra) # 80000de4 <release>
      return -1;
    80004c8c:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004c8e:	854a                	mv	a0,s2
    80004c90:	60e6                	ld	ra,88(sp)
    80004c92:	6446                	ld	s0,80(sp)
    80004c94:	64a6                	ld	s1,72(sp)
    80004c96:	6906                	ld	s2,64(sp)
    80004c98:	79e2                	ld	s3,56(sp)
    80004c9a:	7a42                	ld	s4,48(sp)
    80004c9c:	7aa2                	ld	s5,40(sp)
    80004c9e:	7b02                	ld	s6,32(sp)
    80004ca0:	6be2                	ld	s7,24(sp)
    80004ca2:	6c42                	ld	s8,16(sp)
    80004ca4:	6125                	addi	sp,sp,96
    80004ca6:	8082                	ret
      wakeup(&pi->nread);
    80004ca8:	8562                	mv	a0,s8
    80004caa:	ffffd097          	auipc	ra,0xffffd
    80004cae:	698080e7          	jalr	1688(ra) # 80002342 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004cb2:	85a6                	mv	a1,s1
    80004cb4:	855e                	mv	a0,s7
    80004cb6:	ffffd097          	auipc	ra,0xffffd
    80004cba:	628080e7          	jalr	1576(ra) # 800022de <sleep>
  while(i < n){
    80004cbe:	07495063          	bge	s2,s4,80004d1e <pipewrite+0xe0>
    if(pi->readopen == 0 || killed(pr)){
    80004cc2:	2204a783          	lw	a5,544(s1)
    80004cc6:	dfd5                	beqz	a5,80004c82 <pipewrite+0x44>
    80004cc8:	854e                	mv	a0,s3
    80004cca:	ffffe097          	auipc	ra,0xffffe
    80004cce:	8bc080e7          	jalr	-1860(ra) # 80002586 <killed>
    80004cd2:	f945                	bnez	a0,80004c82 <pipewrite+0x44>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004cd4:	2184a783          	lw	a5,536(s1)
    80004cd8:	21c4a703          	lw	a4,540(s1)
    80004cdc:	2007879b          	addiw	a5,a5,512
    80004ce0:	fcf704e3          	beq	a4,a5,80004ca8 <pipewrite+0x6a>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004ce4:	4685                	li	a3,1
    80004ce6:	01590633          	add	a2,s2,s5
    80004cea:	faf40593          	addi	a1,s0,-81
    80004cee:	0509b503          	ld	a0,80(s3)
    80004cf2:	ffffd097          	auipc	ra,0xffffd
    80004cf6:	c88080e7          	jalr	-888(ra) # 8000197a <copyin>
    80004cfa:	03650263          	beq	a0,s6,80004d1e <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004cfe:	21c4a783          	lw	a5,540(s1)
    80004d02:	0017871b          	addiw	a4,a5,1
    80004d06:	20e4ae23          	sw	a4,540(s1)
    80004d0a:	1ff7f793          	andi	a5,a5,511
    80004d0e:	97a6                	add	a5,a5,s1
    80004d10:	faf44703          	lbu	a4,-81(s0)
    80004d14:	00e78c23          	sb	a4,24(a5)
      i++;
    80004d18:	2905                	addiw	s2,s2,1
    80004d1a:	b755                	j	80004cbe <pipewrite+0x80>
  int i = 0;
    80004d1c:	4901                	li	s2,0
  wakeup(&pi->nread);
    80004d1e:	21848513          	addi	a0,s1,536
    80004d22:	ffffd097          	auipc	ra,0xffffd
    80004d26:	620080e7          	jalr	1568(ra) # 80002342 <wakeup>
  release(&pi->lock);
    80004d2a:	8526                	mv	a0,s1
    80004d2c:	ffffc097          	auipc	ra,0xffffc
    80004d30:	0b8080e7          	jalr	184(ra) # 80000de4 <release>
  return i;
    80004d34:	bfa9                	j	80004c8e <pipewrite+0x50>

0000000080004d36 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004d36:	715d                	addi	sp,sp,-80
    80004d38:	e486                	sd	ra,72(sp)
    80004d3a:	e0a2                	sd	s0,64(sp)
    80004d3c:	fc26                	sd	s1,56(sp)
    80004d3e:	f84a                	sd	s2,48(sp)
    80004d40:	f44e                	sd	s3,40(sp)
    80004d42:	f052                	sd	s4,32(sp)
    80004d44:	ec56                	sd	s5,24(sp)
    80004d46:	e85a                	sd	s6,16(sp)
    80004d48:	0880                	addi	s0,sp,80
    80004d4a:	84aa                	mv	s1,a0
    80004d4c:	892e                	mv	s2,a1
    80004d4e:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004d50:	ffffd097          	auipc	ra,0xffffd
    80004d54:	ee2080e7          	jalr	-286(ra) # 80001c32 <myproc>
    80004d58:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004d5a:	8526                	mv	a0,s1
    80004d5c:	ffffc097          	auipc	ra,0xffffc
    80004d60:	fd4080e7          	jalr	-44(ra) # 80000d30 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004d64:	2184a703          	lw	a4,536(s1)
    80004d68:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004d6c:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004d70:	02f71763          	bne	a4,a5,80004d9e <piperead+0x68>
    80004d74:	2244a783          	lw	a5,548(s1)
    80004d78:	c39d                	beqz	a5,80004d9e <piperead+0x68>
    if(killed(pr)){
    80004d7a:	8552                	mv	a0,s4
    80004d7c:	ffffe097          	auipc	ra,0xffffe
    80004d80:	80a080e7          	jalr	-2038(ra) # 80002586 <killed>
    80004d84:	e941                	bnez	a0,80004e14 <piperead+0xde>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004d86:	85a6                	mv	a1,s1
    80004d88:	854e                	mv	a0,s3
    80004d8a:	ffffd097          	auipc	ra,0xffffd
    80004d8e:	554080e7          	jalr	1364(ra) # 800022de <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004d92:	2184a703          	lw	a4,536(s1)
    80004d96:	21c4a783          	lw	a5,540(s1)
    80004d9a:	fcf70de3          	beq	a4,a5,80004d74 <piperead+0x3e>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004d9e:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004da0:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004da2:	05505363          	blez	s5,80004de8 <piperead+0xb2>
    if(pi->nread == pi->nwrite)
    80004da6:	2184a783          	lw	a5,536(s1)
    80004daa:	21c4a703          	lw	a4,540(s1)
    80004dae:	02f70d63          	beq	a4,a5,80004de8 <piperead+0xb2>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004db2:	0017871b          	addiw	a4,a5,1
    80004db6:	20e4ac23          	sw	a4,536(s1)
    80004dba:	1ff7f793          	andi	a5,a5,511
    80004dbe:	97a6                	add	a5,a5,s1
    80004dc0:	0187c783          	lbu	a5,24(a5)
    80004dc4:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004dc8:	4685                	li	a3,1
    80004dca:	fbf40613          	addi	a2,s0,-65
    80004dce:	85ca                	mv	a1,s2
    80004dd0:	050a3503          	ld	a0,80(s4)
    80004dd4:	ffffd097          	auipc	ra,0xffffd
    80004dd8:	aae080e7          	jalr	-1362(ra) # 80001882 <copyout>
    80004ddc:	01650663          	beq	a0,s6,80004de8 <piperead+0xb2>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004de0:	2985                	addiw	s3,s3,1
    80004de2:	0905                	addi	s2,s2,1
    80004de4:	fd3a91e3          	bne	s5,s3,80004da6 <piperead+0x70>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004de8:	21c48513          	addi	a0,s1,540
    80004dec:	ffffd097          	auipc	ra,0xffffd
    80004df0:	556080e7          	jalr	1366(ra) # 80002342 <wakeup>
  release(&pi->lock);
    80004df4:	8526                	mv	a0,s1
    80004df6:	ffffc097          	auipc	ra,0xffffc
    80004dfa:	fee080e7          	jalr	-18(ra) # 80000de4 <release>
  return i;
}
    80004dfe:	854e                	mv	a0,s3
    80004e00:	60a6                	ld	ra,72(sp)
    80004e02:	6406                	ld	s0,64(sp)
    80004e04:	74e2                	ld	s1,56(sp)
    80004e06:	7942                	ld	s2,48(sp)
    80004e08:	79a2                	ld	s3,40(sp)
    80004e0a:	7a02                	ld	s4,32(sp)
    80004e0c:	6ae2                	ld	s5,24(sp)
    80004e0e:	6b42                	ld	s6,16(sp)
    80004e10:	6161                	addi	sp,sp,80
    80004e12:	8082                	ret
      release(&pi->lock);
    80004e14:	8526                	mv	a0,s1
    80004e16:	ffffc097          	auipc	ra,0xffffc
    80004e1a:	fce080e7          	jalr	-50(ra) # 80000de4 <release>
      return -1;
    80004e1e:	59fd                	li	s3,-1
    80004e20:	bff9                	j	80004dfe <piperead+0xc8>

0000000080004e22 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80004e22:	1141                	addi	sp,sp,-16
    80004e24:	e422                	sd	s0,8(sp)
    80004e26:	0800                	addi	s0,sp,16
    80004e28:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004e2a:	8905                	andi	a0,a0,1
    80004e2c:	c111                	beqz	a0,80004e30 <flags2perm+0xe>
      perm = PTE_X;
    80004e2e:	4521                	li	a0,8
    if(flags & 0x2)
    80004e30:	8b89                	andi	a5,a5,2
    80004e32:	c399                	beqz	a5,80004e38 <flags2perm+0x16>
      perm |= PTE_W;
    80004e34:	00456513          	ori	a0,a0,4
    return perm;
}
    80004e38:	6422                	ld	s0,8(sp)
    80004e3a:	0141                	addi	sp,sp,16
    80004e3c:	8082                	ret

0000000080004e3e <exec>:

int
exec(char *path, char **argv)
{
    80004e3e:	de010113          	addi	sp,sp,-544
    80004e42:	20113c23          	sd	ra,536(sp)
    80004e46:	20813823          	sd	s0,528(sp)
    80004e4a:	20913423          	sd	s1,520(sp)
    80004e4e:	21213023          	sd	s2,512(sp)
    80004e52:	ffce                	sd	s3,504(sp)
    80004e54:	fbd2                	sd	s4,496(sp)
    80004e56:	f7d6                	sd	s5,488(sp)
    80004e58:	f3da                	sd	s6,480(sp)
    80004e5a:	efde                	sd	s7,472(sp)
    80004e5c:	ebe2                	sd	s8,464(sp)
    80004e5e:	e7e6                	sd	s9,456(sp)
    80004e60:	e3ea                	sd	s10,448(sp)
    80004e62:	ff6e                	sd	s11,440(sp)
    80004e64:	1400                	addi	s0,sp,544
    80004e66:	892a                	mv	s2,a0
    80004e68:	dea43423          	sd	a0,-536(s0)
    80004e6c:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004e70:	ffffd097          	auipc	ra,0xffffd
    80004e74:	dc2080e7          	jalr	-574(ra) # 80001c32 <myproc>
    80004e78:	84aa                	mv	s1,a0

  begin_op();
    80004e7a:	fffff097          	auipc	ra,0xfffff
    80004e7e:	47e080e7          	jalr	1150(ra) # 800042f8 <begin_op>

  if((ip = namei(path)) == 0){
    80004e82:	854a                	mv	a0,s2
    80004e84:	fffff097          	auipc	ra,0xfffff
    80004e88:	254080e7          	jalr	596(ra) # 800040d8 <namei>
    80004e8c:	c93d                	beqz	a0,80004f02 <exec+0xc4>
    80004e8e:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004e90:	fffff097          	auipc	ra,0xfffff
    80004e94:	aa2080e7          	jalr	-1374(ra) # 80003932 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004e98:	04000713          	li	a4,64
    80004e9c:	4681                	li	a3,0
    80004e9e:	e5040613          	addi	a2,s0,-432
    80004ea2:	4581                	li	a1,0
    80004ea4:	8556                	mv	a0,s5
    80004ea6:	fffff097          	auipc	ra,0xfffff
    80004eaa:	d40080e7          	jalr	-704(ra) # 80003be6 <readi>
    80004eae:	04000793          	li	a5,64
    80004eb2:	00f51a63          	bne	a0,a5,80004ec6 <exec+0x88>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004eb6:	e5042703          	lw	a4,-432(s0)
    80004eba:	464c47b7          	lui	a5,0x464c4
    80004ebe:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004ec2:	04f70663          	beq	a4,a5,80004f0e <exec+0xd0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004ec6:	8556                	mv	a0,s5
    80004ec8:	fffff097          	auipc	ra,0xfffff
    80004ecc:	ccc080e7          	jalr	-820(ra) # 80003b94 <iunlockput>
    end_op();
    80004ed0:	fffff097          	auipc	ra,0xfffff
    80004ed4:	4a8080e7          	jalr	1192(ra) # 80004378 <end_op>
  }
  return -1;
    80004ed8:	557d                	li	a0,-1
}
    80004eda:	21813083          	ld	ra,536(sp)
    80004ede:	21013403          	ld	s0,528(sp)
    80004ee2:	20813483          	ld	s1,520(sp)
    80004ee6:	20013903          	ld	s2,512(sp)
    80004eea:	79fe                	ld	s3,504(sp)
    80004eec:	7a5e                	ld	s4,496(sp)
    80004eee:	7abe                	ld	s5,488(sp)
    80004ef0:	7b1e                	ld	s6,480(sp)
    80004ef2:	6bfe                	ld	s7,472(sp)
    80004ef4:	6c5e                	ld	s8,464(sp)
    80004ef6:	6cbe                	ld	s9,456(sp)
    80004ef8:	6d1e                	ld	s10,448(sp)
    80004efa:	7dfa                	ld	s11,440(sp)
    80004efc:	22010113          	addi	sp,sp,544
    80004f00:	8082                	ret
    end_op();
    80004f02:	fffff097          	auipc	ra,0xfffff
    80004f06:	476080e7          	jalr	1142(ra) # 80004378 <end_op>
    return -1;
    80004f0a:	557d                	li	a0,-1
    80004f0c:	b7f9                	j	80004eda <exec+0x9c>
  if((pagetable = proc_pagetable(p)) == 0)
    80004f0e:	8526                	mv	a0,s1
    80004f10:	ffffd097          	auipc	ra,0xffffd
    80004f14:	dea080e7          	jalr	-534(ra) # 80001cfa <proc_pagetable>
    80004f18:	8b2a                	mv	s6,a0
    80004f1a:	d555                	beqz	a0,80004ec6 <exec+0x88>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004f1c:	e7042783          	lw	a5,-400(s0)
    80004f20:	e8845703          	lhu	a4,-376(s0)
    80004f24:	c735                	beqz	a4,80004f90 <exec+0x152>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004f26:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004f28:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80004f2c:	6a05                	lui	s4,0x1
    80004f2e:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80004f32:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    80004f36:	6d85                	lui	s11,0x1
    80004f38:	7d7d                	lui	s10,0xfffff
    80004f3a:	a481                	j	8000517a <exec+0x33c>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004f3c:	00003517          	auipc	a0,0x3
    80004f40:	7dc50513          	addi	a0,a0,2012 # 80008718 <syscalls+0x280>
    80004f44:	ffffb097          	auipc	ra,0xffffb
    80004f48:	5fa080e7          	jalr	1530(ra) # 8000053e <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004f4c:	874a                	mv	a4,s2
    80004f4e:	009c86bb          	addw	a3,s9,s1
    80004f52:	4581                	li	a1,0
    80004f54:	8556                	mv	a0,s5
    80004f56:	fffff097          	auipc	ra,0xfffff
    80004f5a:	c90080e7          	jalr	-880(ra) # 80003be6 <readi>
    80004f5e:	2501                	sext.w	a0,a0
    80004f60:	1aa91a63          	bne	s2,a0,80005114 <exec+0x2d6>
  for(i = 0; i < sz; i += PGSIZE){
    80004f64:	009d84bb          	addw	s1,s11,s1
    80004f68:	013d09bb          	addw	s3,s10,s3
    80004f6c:	1f74f763          	bgeu	s1,s7,8000515a <exec+0x31c>
    pa = walkaddr(pagetable, va + i);
    80004f70:	02049593          	slli	a1,s1,0x20
    80004f74:	9181                	srli	a1,a1,0x20
    80004f76:	95e2                	add	a1,a1,s8
    80004f78:	855a                	mv	a0,s6
    80004f7a:	ffffc097          	auipc	ra,0xffffc
    80004f7e:	23c080e7          	jalr	572(ra) # 800011b6 <walkaddr>
    80004f82:	862a                	mv	a2,a0
    if(pa == 0)
    80004f84:	dd45                	beqz	a0,80004f3c <exec+0xfe>
      n = PGSIZE;
    80004f86:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80004f88:	fd49f2e3          	bgeu	s3,s4,80004f4c <exec+0x10e>
      n = sz - i;
    80004f8c:	894e                	mv	s2,s3
    80004f8e:	bf7d                	j	80004f4c <exec+0x10e>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004f90:	4901                	li	s2,0
  iunlockput(ip);
    80004f92:	8556                	mv	a0,s5
    80004f94:	fffff097          	auipc	ra,0xfffff
    80004f98:	c00080e7          	jalr	-1024(ra) # 80003b94 <iunlockput>
  end_op();
    80004f9c:	fffff097          	auipc	ra,0xfffff
    80004fa0:	3dc080e7          	jalr	988(ra) # 80004378 <end_op>
  p = myproc();
    80004fa4:	ffffd097          	auipc	ra,0xffffd
    80004fa8:	c8e080e7          	jalr	-882(ra) # 80001c32 <myproc>
    80004fac:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    80004fae:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004fb2:	6785                	lui	a5,0x1
    80004fb4:	17fd                	addi	a5,a5,-1
    80004fb6:	993e                	add	s2,s2,a5
    80004fb8:	77fd                	lui	a5,0xfffff
    80004fba:	00f977b3          	and	a5,s2,a5
    80004fbe:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004fc2:	4691                	li	a3,4
    80004fc4:	6609                	lui	a2,0x2
    80004fc6:	963e                	add	a2,a2,a5
    80004fc8:	85be                	mv	a1,a5
    80004fca:	855a                	mv	a0,s6
    80004fcc:	ffffc097          	auipc	ra,0xffffc
    80004fd0:	5c2080e7          	jalr	1474(ra) # 8000158e <uvmalloc>
    80004fd4:	8c2a                	mv	s8,a0
  ip = 0;
    80004fd6:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004fd8:	12050e63          	beqz	a0,80005114 <exec+0x2d6>
  uvmclear(pagetable, sz-2*PGSIZE);
    80004fdc:	75f9                	lui	a1,0xffffe
    80004fde:	95aa                	add	a1,a1,a0
    80004fe0:	855a                	mv	a0,s6
    80004fe2:	ffffc097          	auipc	ra,0xffffc
    80004fe6:	7d8080e7          	jalr	2008(ra) # 800017ba <uvmclear>
  stackbase = sp - PGSIZE;
    80004fea:	7afd                	lui	s5,0xfffff
    80004fec:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80004fee:	df043783          	ld	a5,-528(s0)
    80004ff2:	6388                	ld	a0,0(a5)
    80004ff4:	c925                	beqz	a0,80005064 <exec+0x226>
    80004ff6:	e9040993          	addi	s3,s0,-368
    80004ffa:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80004ffe:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80005000:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80005002:	ffffc097          	auipc	ra,0xffffc
    80005006:	fa6080e7          	jalr	-90(ra) # 80000fa8 <strlen>
    8000500a:	0015079b          	addiw	a5,a0,1
    8000500e:	40f90933          	sub	s2,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80005012:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    80005016:	13596663          	bltu	s2,s5,80005142 <exec+0x304>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    8000501a:	df043d83          	ld	s11,-528(s0)
    8000501e:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80005022:	8552                	mv	a0,s4
    80005024:	ffffc097          	auipc	ra,0xffffc
    80005028:	f84080e7          	jalr	-124(ra) # 80000fa8 <strlen>
    8000502c:	0015069b          	addiw	a3,a0,1
    80005030:	8652                	mv	a2,s4
    80005032:	85ca                	mv	a1,s2
    80005034:	855a                	mv	a0,s6
    80005036:	ffffd097          	auipc	ra,0xffffd
    8000503a:	84c080e7          	jalr	-1972(ra) # 80001882 <copyout>
    8000503e:	10054663          	bltz	a0,8000514a <exec+0x30c>
    ustack[argc] = sp;
    80005042:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80005046:	0485                	addi	s1,s1,1
    80005048:	008d8793          	addi	a5,s11,8
    8000504c:	def43823          	sd	a5,-528(s0)
    80005050:	008db503          	ld	a0,8(s11)
    80005054:	c911                	beqz	a0,80005068 <exec+0x22a>
    if(argc >= MAXARG)
    80005056:	09a1                	addi	s3,s3,8
    80005058:	fb3c95e3          	bne	s9,s3,80005002 <exec+0x1c4>
  sz = sz1;
    8000505c:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80005060:	4a81                	li	s5,0
    80005062:	a84d                	j	80005114 <exec+0x2d6>
  sp = sz;
    80005064:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80005066:	4481                	li	s1,0
  ustack[argc] = 0;
    80005068:	00349793          	slli	a5,s1,0x3
    8000506c:	f9040713          	addi	a4,s0,-112
    80005070:	97ba                	add	a5,a5,a4
    80005072:	f007b023          	sd	zero,-256(a5) # ffffffffffffef00 <end+0xffffffff7fdbd158>
  sp -= (argc+1) * sizeof(uint64);
    80005076:	00148693          	addi	a3,s1,1
    8000507a:	068e                	slli	a3,a3,0x3
    8000507c:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80005080:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80005084:	01597663          	bgeu	s2,s5,80005090 <exec+0x252>
  sz = sz1;
    80005088:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    8000508c:	4a81                	li	s5,0
    8000508e:	a059                	j	80005114 <exec+0x2d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80005090:	e9040613          	addi	a2,s0,-368
    80005094:	85ca                	mv	a1,s2
    80005096:	855a                	mv	a0,s6
    80005098:	ffffc097          	auipc	ra,0xffffc
    8000509c:	7ea080e7          	jalr	2026(ra) # 80001882 <copyout>
    800050a0:	0a054963          	bltz	a0,80005152 <exec+0x314>
  p->trapframe->a1 = sp;
    800050a4:	058bb783          	ld	a5,88(s7) # 1058 <_entry-0x7fffefa8>
    800050a8:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    800050ac:	de843783          	ld	a5,-536(s0)
    800050b0:	0007c703          	lbu	a4,0(a5)
    800050b4:	cf11                	beqz	a4,800050d0 <exec+0x292>
    800050b6:	0785                	addi	a5,a5,1
    if(*s == '/')
    800050b8:	02f00693          	li	a3,47
    800050bc:	a039                	j	800050ca <exec+0x28c>
      last = s+1;
    800050be:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    800050c2:	0785                	addi	a5,a5,1
    800050c4:	fff7c703          	lbu	a4,-1(a5)
    800050c8:	c701                	beqz	a4,800050d0 <exec+0x292>
    if(*s == '/')
    800050ca:	fed71ce3          	bne	a4,a3,800050c2 <exec+0x284>
    800050ce:	bfc5                	j	800050be <exec+0x280>
  safestrcpy(p->name, last, sizeof(p->name));
    800050d0:	4641                	li	a2,16
    800050d2:	de843583          	ld	a1,-536(s0)
    800050d6:	158b8513          	addi	a0,s7,344
    800050da:	ffffc097          	auipc	ra,0xffffc
    800050de:	e9c080e7          	jalr	-356(ra) # 80000f76 <safestrcpy>
  oldpagetable = p->pagetable;
    800050e2:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    800050e6:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    800050ea:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    800050ee:	058bb783          	ld	a5,88(s7)
    800050f2:	e6843703          	ld	a4,-408(s0)
    800050f6:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800050f8:	058bb783          	ld	a5,88(s7)
    800050fc:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80005100:	85ea                	mv	a1,s10
    80005102:	ffffd097          	auipc	ra,0xffffd
    80005106:	c94080e7          	jalr	-876(ra) # 80001d96 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    8000510a:	0004851b          	sext.w	a0,s1
    8000510e:	b3f1                	j	80004eda <exec+0x9c>
    80005110:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80005114:	df843583          	ld	a1,-520(s0)
    80005118:	855a                	mv	a0,s6
    8000511a:	ffffd097          	auipc	ra,0xffffd
    8000511e:	c7c080e7          	jalr	-900(ra) # 80001d96 <proc_freepagetable>
  if(ip){
    80005122:	da0a92e3          	bnez	s5,80004ec6 <exec+0x88>
  return -1;
    80005126:	557d                	li	a0,-1
    80005128:	bb4d                	j	80004eda <exec+0x9c>
    8000512a:	df243c23          	sd	s2,-520(s0)
    8000512e:	b7dd                	j	80005114 <exec+0x2d6>
    80005130:	df243c23          	sd	s2,-520(s0)
    80005134:	b7c5                	j	80005114 <exec+0x2d6>
    80005136:	df243c23          	sd	s2,-520(s0)
    8000513a:	bfe9                	j	80005114 <exec+0x2d6>
    8000513c:	df243c23          	sd	s2,-520(s0)
    80005140:	bfd1                	j	80005114 <exec+0x2d6>
  sz = sz1;
    80005142:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80005146:	4a81                	li	s5,0
    80005148:	b7f1                	j	80005114 <exec+0x2d6>
  sz = sz1;
    8000514a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    8000514e:	4a81                	li	s5,0
    80005150:	b7d1                	j	80005114 <exec+0x2d6>
  sz = sz1;
    80005152:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80005156:	4a81                	li	s5,0
    80005158:	bf75                	j	80005114 <exec+0x2d6>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    8000515a:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000515e:	e0843783          	ld	a5,-504(s0)
    80005162:	0017869b          	addiw	a3,a5,1
    80005166:	e0d43423          	sd	a3,-504(s0)
    8000516a:	e0043783          	ld	a5,-512(s0)
    8000516e:	0387879b          	addiw	a5,a5,56
    80005172:	e8845703          	lhu	a4,-376(s0)
    80005176:	e0e6dee3          	bge	a3,a4,80004f92 <exec+0x154>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000517a:	2781                	sext.w	a5,a5
    8000517c:	e0f43023          	sd	a5,-512(s0)
    80005180:	03800713          	li	a4,56
    80005184:	86be                	mv	a3,a5
    80005186:	e1840613          	addi	a2,s0,-488
    8000518a:	4581                	li	a1,0
    8000518c:	8556                	mv	a0,s5
    8000518e:	fffff097          	auipc	ra,0xfffff
    80005192:	a58080e7          	jalr	-1448(ra) # 80003be6 <readi>
    80005196:	03800793          	li	a5,56
    8000519a:	f6f51be3          	bne	a0,a5,80005110 <exec+0x2d2>
    if(ph.type != ELF_PROG_LOAD)
    8000519e:	e1842783          	lw	a5,-488(s0)
    800051a2:	4705                	li	a4,1
    800051a4:	fae79de3          	bne	a5,a4,8000515e <exec+0x320>
    if(ph.memsz < ph.filesz)
    800051a8:	e4043483          	ld	s1,-448(s0)
    800051ac:	e3843783          	ld	a5,-456(s0)
    800051b0:	f6f4ede3          	bltu	s1,a5,8000512a <exec+0x2ec>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    800051b4:	e2843783          	ld	a5,-472(s0)
    800051b8:	94be                	add	s1,s1,a5
    800051ba:	f6f4ebe3          	bltu	s1,a5,80005130 <exec+0x2f2>
    if(ph.vaddr % PGSIZE != 0)
    800051be:	de043703          	ld	a4,-544(s0)
    800051c2:	8ff9                	and	a5,a5,a4
    800051c4:	fbad                	bnez	a5,80005136 <exec+0x2f8>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    800051c6:	e1c42503          	lw	a0,-484(s0)
    800051ca:	00000097          	auipc	ra,0x0
    800051ce:	c58080e7          	jalr	-936(ra) # 80004e22 <flags2perm>
    800051d2:	86aa                	mv	a3,a0
    800051d4:	8626                	mv	a2,s1
    800051d6:	85ca                	mv	a1,s2
    800051d8:	855a                	mv	a0,s6
    800051da:	ffffc097          	auipc	ra,0xffffc
    800051de:	3b4080e7          	jalr	948(ra) # 8000158e <uvmalloc>
    800051e2:	dea43c23          	sd	a0,-520(s0)
    800051e6:	d939                	beqz	a0,8000513c <exec+0x2fe>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800051e8:	e2843c03          	ld	s8,-472(s0)
    800051ec:	e2042c83          	lw	s9,-480(s0)
    800051f0:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    800051f4:	f60b83e3          	beqz	s7,8000515a <exec+0x31c>
    800051f8:	89de                	mv	s3,s7
    800051fa:	4481                	li	s1,0
    800051fc:	bb95                	j	80004f70 <exec+0x132>

00000000800051fe <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    800051fe:	7179                	addi	sp,sp,-48
    80005200:	f406                	sd	ra,40(sp)
    80005202:	f022                	sd	s0,32(sp)
    80005204:	ec26                	sd	s1,24(sp)
    80005206:	e84a                	sd	s2,16(sp)
    80005208:	1800                	addi	s0,sp,48
    8000520a:	892e                	mv	s2,a1
    8000520c:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    8000520e:	fdc40593          	addi	a1,s0,-36
    80005212:	ffffe097          	auipc	ra,0xffffe
    80005216:	ba4080e7          	jalr	-1116(ra) # 80002db6 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    8000521a:	fdc42703          	lw	a4,-36(s0)
    8000521e:	47bd                	li	a5,15
    80005220:	02e7eb63          	bltu	a5,a4,80005256 <argfd+0x58>
    80005224:	ffffd097          	auipc	ra,0xffffd
    80005228:	a0e080e7          	jalr	-1522(ra) # 80001c32 <myproc>
    8000522c:	fdc42703          	lw	a4,-36(s0)
    80005230:	01a70793          	addi	a5,a4,26
    80005234:	078e                	slli	a5,a5,0x3
    80005236:	953e                	add	a0,a0,a5
    80005238:	611c                	ld	a5,0(a0)
    8000523a:	c385                	beqz	a5,8000525a <argfd+0x5c>
    return -1;
  if(pfd)
    8000523c:	00090463          	beqz	s2,80005244 <argfd+0x46>
    *pfd = fd;
    80005240:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80005244:	4501                	li	a0,0
  if(pf)
    80005246:	c091                	beqz	s1,8000524a <argfd+0x4c>
    *pf = f;
    80005248:	e09c                	sd	a5,0(s1)
}
    8000524a:	70a2                	ld	ra,40(sp)
    8000524c:	7402                	ld	s0,32(sp)
    8000524e:	64e2                	ld	s1,24(sp)
    80005250:	6942                	ld	s2,16(sp)
    80005252:	6145                	addi	sp,sp,48
    80005254:	8082                	ret
    return -1;
    80005256:	557d                	li	a0,-1
    80005258:	bfcd                	j	8000524a <argfd+0x4c>
    8000525a:	557d                	li	a0,-1
    8000525c:	b7fd                	j	8000524a <argfd+0x4c>

000000008000525e <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    8000525e:	1101                	addi	sp,sp,-32
    80005260:	ec06                	sd	ra,24(sp)
    80005262:	e822                	sd	s0,16(sp)
    80005264:	e426                	sd	s1,8(sp)
    80005266:	1000                	addi	s0,sp,32
    80005268:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    8000526a:	ffffd097          	auipc	ra,0xffffd
    8000526e:	9c8080e7          	jalr	-1592(ra) # 80001c32 <myproc>
    80005272:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80005274:	0d050793          	addi	a5,a0,208
    80005278:	4501                	li	a0,0
    8000527a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000527c:	6398                	ld	a4,0(a5)
    8000527e:	cb19                	beqz	a4,80005294 <fdalloc+0x36>
  for(fd = 0; fd < NOFILE; fd++){
    80005280:	2505                	addiw	a0,a0,1
    80005282:	07a1                	addi	a5,a5,8
    80005284:	fed51ce3          	bne	a0,a3,8000527c <fdalloc+0x1e>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80005288:	557d                	li	a0,-1
}
    8000528a:	60e2                	ld	ra,24(sp)
    8000528c:	6442                	ld	s0,16(sp)
    8000528e:	64a2                	ld	s1,8(sp)
    80005290:	6105                	addi	sp,sp,32
    80005292:	8082                	ret
      p->ofile[fd] = f;
    80005294:	01a50793          	addi	a5,a0,26
    80005298:	078e                	slli	a5,a5,0x3
    8000529a:	963e                	add	a2,a2,a5
    8000529c:	e204                	sd	s1,0(a2)
      return fd;
    8000529e:	b7f5                	j	8000528a <fdalloc+0x2c>

00000000800052a0 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    800052a0:	715d                	addi	sp,sp,-80
    800052a2:	e486                	sd	ra,72(sp)
    800052a4:	e0a2                	sd	s0,64(sp)
    800052a6:	fc26                	sd	s1,56(sp)
    800052a8:	f84a                	sd	s2,48(sp)
    800052aa:	f44e                	sd	s3,40(sp)
    800052ac:	f052                	sd	s4,32(sp)
    800052ae:	ec56                	sd	s5,24(sp)
    800052b0:	e85a                	sd	s6,16(sp)
    800052b2:	0880                	addi	s0,sp,80
    800052b4:	8b2e                	mv	s6,a1
    800052b6:	89b2                	mv	s3,a2
    800052b8:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    800052ba:	fb040593          	addi	a1,s0,-80
    800052be:	fffff097          	auipc	ra,0xfffff
    800052c2:	e38080e7          	jalr	-456(ra) # 800040f6 <nameiparent>
    800052c6:	84aa                	mv	s1,a0
    800052c8:	14050f63          	beqz	a0,80005426 <create+0x186>
    return 0;

  ilock(dp);
    800052cc:	ffffe097          	auipc	ra,0xffffe
    800052d0:	666080e7          	jalr	1638(ra) # 80003932 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800052d4:	4601                	li	a2,0
    800052d6:	fb040593          	addi	a1,s0,-80
    800052da:	8526                	mv	a0,s1
    800052dc:	fffff097          	auipc	ra,0xfffff
    800052e0:	b3a080e7          	jalr	-1222(ra) # 80003e16 <dirlookup>
    800052e4:	8aaa                	mv	s5,a0
    800052e6:	c931                	beqz	a0,8000533a <create+0x9a>
    iunlockput(dp);
    800052e8:	8526                	mv	a0,s1
    800052ea:	fffff097          	auipc	ra,0xfffff
    800052ee:	8aa080e7          	jalr	-1878(ra) # 80003b94 <iunlockput>
    ilock(ip);
    800052f2:	8556                	mv	a0,s5
    800052f4:	ffffe097          	auipc	ra,0xffffe
    800052f8:	63e080e7          	jalr	1598(ra) # 80003932 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    800052fc:	000b059b          	sext.w	a1,s6
    80005300:	4789                	li	a5,2
    80005302:	02f59563          	bne	a1,a5,8000532c <create+0x8c>
    80005306:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7fdbd29c>
    8000530a:	37f9                	addiw	a5,a5,-2
    8000530c:	17c2                	slli	a5,a5,0x30
    8000530e:	93c1                	srli	a5,a5,0x30
    80005310:	4705                	li	a4,1
    80005312:	00f76d63          	bltu	a4,a5,8000532c <create+0x8c>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80005316:	8556                	mv	a0,s5
    80005318:	60a6                	ld	ra,72(sp)
    8000531a:	6406                	ld	s0,64(sp)
    8000531c:	74e2                	ld	s1,56(sp)
    8000531e:	7942                	ld	s2,48(sp)
    80005320:	79a2                	ld	s3,40(sp)
    80005322:	7a02                	ld	s4,32(sp)
    80005324:	6ae2                	ld	s5,24(sp)
    80005326:	6b42                	ld	s6,16(sp)
    80005328:	6161                	addi	sp,sp,80
    8000532a:	8082                	ret
    iunlockput(ip);
    8000532c:	8556                	mv	a0,s5
    8000532e:	fffff097          	auipc	ra,0xfffff
    80005332:	866080e7          	jalr	-1946(ra) # 80003b94 <iunlockput>
    return 0;
    80005336:	4a81                	li	s5,0
    80005338:	bff9                	j	80005316 <create+0x76>
  if((ip = ialloc(dp->dev, type)) == 0){
    8000533a:	85da                	mv	a1,s6
    8000533c:	4088                	lw	a0,0(s1)
    8000533e:	ffffe097          	auipc	ra,0xffffe
    80005342:	458080e7          	jalr	1112(ra) # 80003796 <ialloc>
    80005346:	8a2a                	mv	s4,a0
    80005348:	c539                	beqz	a0,80005396 <create+0xf6>
  ilock(ip);
    8000534a:	ffffe097          	auipc	ra,0xffffe
    8000534e:	5e8080e7          	jalr	1512(ra) # 80003932 <ilock>
  ip->major = major;
    80005352:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80005356:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    8000535a:	4905                	li	s2,1
    8000535c:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80005360:	8552                	mv	a0,s4
    80005362:	ffffe097          	auipc	ra,0xffffe
    80005366:	506080e7          	jalr	1286(ra) # 80003868 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    8000536a:	000b059b          	sext.w	a1,s6
    8000536e:	03258b63          	beq	a1,s2,800053a4 <create+0x104>
  if(dirlink(dp, name, ip->inum) < 0)
    80005372:	004a2603          	lw	a2,4(s4)
    80005376:	fb040593          	addi	a1,s0,-80
    8000537a:	8526                	mv	a0,s1
    8000537c:	fffff097          	auipc	ra,0xfffff
    80005380:	caa080e7          	jalr	-854(ra) # 80004026 <dirlink>
    80005384:	06054f63          	bltz	a0,80005402 <create+0x162>
  iunlockput(dp);
    80005388:	8526                	mv	a0,s1
    8000538a:	fffff097          	auipc	ra,0xfffff
    8000538e:	80a080e7          	jalr	-2038(ra) # 80003b94 <iunlockput>
  return ip;
    80005392:	8ad2                	mv	s5,s4
    80005394:	b749                	j	80005316 <create+0x76>
    iunlockput(dp);
    80005396:	8526                	mv	a0,s1
    80005398:	ffffe097          	auipc	ra,0xffffe
    8000539c:	7fc080e7          	jalr	2044(ra) # 80003b94 <iunlockput>
    return 0;
    800053a0:	8ad2                	mv	s5,s4
    800053a2:	bf95                	j	80005316 <create+0x76>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    800053a4:	004a2603          	lw	a2,4(s4)
    800053a8:	00003597          	auipc	a1,0x3
    800053ac:	39058593          	addi	a1,a1,912 # 80008738 <syscalls+0x2a0>
    800053b0:	8552                	mv	a0,s4
    800053b2:	fffff097          	auipc	ra,0xfffff
    800053b6:	c74080e7          	jalr	-908(ra) # 80004026 <dirlink>
    800053ba:	04054463          	bltz	a0,80005402 <create+0x162>
    800053be:	40d0                	lw	a2,4(s1)
    800053c0:	00003597          	auipc	a1,0x3
    800053c4:	38058593          	addi	a1,a1,896 # 80008740 <syscalls+0x2a8>
    800053c8:	8552                	mv	a0,s4
    800053ca:	fffff097          	auipc	ra,0xfffff
    800053ce:	c5c080e7          	jalr	-932(ra) # 80004026 <dirlink>
    800053d2:	02054863          	bltz	a0,80005402 <create+0x162>
  if(dirlink(dp, name, ip->inum) < 0)
    800053d6:	004a2603          	lw	a2,4(s4)
    800053da:	fb040593          	addi	a1,s0,-80
    800053de:	8526                	mv	a0,s1
    800053e0:	fffff097          	auipc	ra,0xfffff
    800053e4:	c46080e7          	jalr	-954(ra) # 80004026 <dirlink>
    800053e8:	00054d63          	bltz	a0,80005402 <create+0x162>
    dp->nlink++;  // for ".."
    800053ec:	04a4d783          	lhu	a5,74(s1)
    800053f0:	2785                	addiw	a5,a5,1
    800053f2:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800053f6:	8526                	mv	a0,s1
    800053f8:	ffffe097          	auipc	ra,0xffffe
    800053fc:	470080e7          	jalr	1136(ra) # 80003868 <iupdate>
    80005400:	b761                	j	80005388 <create+0xe8>
  ip->nlink = 0;
    80005402:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80005406:	8552                	mv	a0,s4
    80005408:	ffffe097          	auipc	ra,0xffffe
    8000540c:	460080e7          	jalr	1120(ra) # 80003868 <iupdate>
  iunlockput(ip);
    80005410:	8552                	mv	a0,s4
    80005412:	ffffe097          	auipc	ra,0xffffe
    80005416:	782080e7          	jalr	1922(ra) # 80003b94 <iunlockput>
  iunlockput(dp);
    8000541a:	8526                	mv	a0,s1
    8000541c:	ffffe097          	auipc	ra,0xffffe
    80005420:	778080e7          	jalr	1912(ra) # 80003b94 <iunlockput>
  return 0;
    80005424:	bdcd                	j	80005316 <create+0x76>
    return 0;
    80005426:	8aaa                	mv	s5,a0
    80005428:	b5fd                	j	80005316 <create+0x76>

000000008000542a <sys_dup>:
{
    8000542a:	7179                	addi	sp,sp,-48
    8000542c:	f406                	sd	ra,40(sp)
    8000542e:	f022                	sd	s0,32(sp)
    80005430:	ec26                	sd	s1,24(sp)
    80005432:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80005434:	fd840613          	addi	a2,s0,-40
    80005438:	4581                	li	a1,0
    8000543a:	4501                	li	a0,0
    8000543c:	00000097          	auipc	ra,0x0
    80005440:	dc2080e7          	jalr	-574(ra) # 800051fe <argfd>
    return -1;
    80005444:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80005446:	02054363          	bltz	a0,8000546c <sys_dup+0x42>
  if((fd=fdalloc(f)) < 0)
    8000544a:	fd843503          	ld	a0,-40(s0)
    8000544e:	00000097          	auipc	ra,0x0
    80005452:	e10080e7          	jalr	-496(ra) # 8000525e <fdalloc>
    80005456:	84aa                	mv	s1,a0
    return -1;
    80005458:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    8000545a:	00054963          	bltz	a0,8000546c <sys_dup+0x42>
  filedup(f);
    8000545e:	fd843503          	ld	a0,-40(s0)
    80005462:	fffff097          	auipc	ra,0xfffff
    80005466:	310080e7          	jalr	784(ra) # 80004772 <filedup>
  return fd;
    8000546a:	87a6                	mv	a5,s1
}
    8000546c:	853e                	mv	a0,a5
    8000546e:	70a2                	ld	ra,40(sp)
    80005470:	7402                	ld	s0,32(sp)
    80005472:	64e2                	ld	s1,24(sp)
    80005474:	6145                	addi	sp,sp,48
    80005476:	8082                	ret

0000000080005478 <sys_read>:
{
    80005478:	7179                	addi	sp,sp,-48
    8000547a:	f406                	sd	ra,40(sp)
    8000547c:	f022                	sd	s0,32(sp)
    8000547e:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005480:	fd840593          	addi	a1,s0,-40
    80005484:	4505                	li	a0,1
    80005486:	ffffe097          	auipc	ra,0xffffe
    8000548a:	950080e7          	jalr	-1712(ra) # 80002dd6 <argaddr>
  argint(2, &n);
    8000548e:	fe440593          	addi	a1,s0,-28
    80005492:	4509                	li	a0,2
    80005494:	ffffe097          	auipc	ra,0xffffe
    80005498:	922080e7          	jalr	-1758(ra) # 80002db6 <argint>
  if(argfd(0, 0, &f) < 0)
    8000549c:	fe840613          	addi	a2,s0,-24
    800054a0:	4581                	li	a1,0
    800054a2:	4501                	li	a0,0
    800054a4:	00000097          	auipc	ra,0x0
    800054a8:	d5a080e7          	jalr	-678(ra) # 800051fe <argfd>
    800054ac:	87aa                	mv	a5,a0
    return -1;
    800054ae:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800054b0:	0007cc63          	bltz	a5,800054c8 <sys_read+0x50>
  return fileread(f, p, n);
    800054b4:	fe442603          	lw	a2,-28(s0)
    800054b8:	fd843583          	ld	a1,-40(s0)
    800054bc:	fe843503          	ld	a0,-24(s0)
    800054c0:	fffff097          	auipc	ra,0xfffff
    800054c4:	43e080e7          	jalr	1086(ra) # 800048fe <fileread>
}
    800054c8:	70a2                	ld	ra,40(sp)
    800054ca:	7402                	ld	s0,32(sp)
    800054cc:	6145                	addi	sp,sp,48
    800054ce:	8082                	ret

00000000800054d0 <sys_write>:
{
    800054d0:	7179                	addi	sp,sp,-48
    800054d2:	f406                	sd	ra,40(sp)
    800054d4:	f022                	sd	s0,32(sp)
    800054d6:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800054d8:	fd840593          	addi	a1,s0,-40
    800054dc:	4505                	li	a0,1
    800054de:	ffffe097          	auipc	ra,0xffffe
    800054e2:	8f8080e7          	jalr	-1800(ra) # 80002dd6 <argaddr>
  argint(2, &n);
    800054e6:	fe440593          	addi	a1,s0,-28
    800054ea:	4509                	li	a0,2
    800054ec:	ffffe097          	auipc	ra,0xffffe
    800054f0:	8ca080e7          	jalr	-1846(ra) # 80002db6 <argint>
  if(argfd(0, 0, &f) < 0)
    800054f4:	fe840613          	addi	a2,s0,-24
    800054f8:	4581                	li	a1,0
    800054fa:	4501                	li	a0,0
    800054fc:	00000097          	auipc	ra,0x0
    80005500:	d02080e7          	jalr	-766(ra) # 800051fe <argfd>
    80005504:	87aa                	mv	a5,a0
    return -1;
    80005506:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80005508:	0007cc63          	bltz	a5,80005520 <sys_write+0x50>
  return filewrite(f, p, n);
    8000550c:	fe442603          	lw	a2,-28(s0)
    80005510:	fd843583          	ld	a1,-40(s0)
    80005514:	fe843503          	ld	a0,-24(s0)
    80005518:	fffff097          	auipc	ra,0xfffff
    8000551c:	4a8080e7          	jalr	1192(ra) # 800049c0 <filewrite>
}
    80005520:	70a2                	ld	ra,40(sp)
    80005522:	7402                	ld	s0,32(sp)
    80005524:	6145                	addi	sp,sp,48
    80005526:	8082                	ret

0000000080005528 <sys_close>:
{
    80005528:	1101                	addi	sp,sp,-32
    8000552a:	ec06                	sd	ra,24(sp)
    8000552c:	e822                	sd	s0,16(sp)
    8000552e:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80005530:	fe040613          	addi	a2,s0,-32
    80005534:	fec40593          	addi	a1,s0,-20
    80005538:	4501                	li	a0,0
    8000553a:	00000097          	auipc	ra,0x0
    8000553e:	cc4080e7          	jalr	-828(ra) # 800051fe <argfd>
    return -1;
    80005542:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80005544:	02054463          	bltz	a0,8000556c <sys_close+0x44>
  myproc()->ofile[fd] = 0;
    80005548:	ffffc097          	auipc	ra,0xffffc
    8000554c:	6ea080e7          	jalr	1770(ra) # 80001c32 <myproc>
    80005550:	fec42783          	lw	a5,-20(s0)
    80005554:	07e9                	addi	a5,a5,26
    80005556:	078e                	slli	a5,a5,0x3
    80005558:	97aa                	add	a5,a5,a0
    8000555a:	0007b023          	sd	zero,0(a5)
  fileclose(f);
    8000555e:	fe043503          	ld	a0,-32(s0)
    80005562:	fffff097          	auipc	ra,0xfffff
    80005566:	262080e7          	jalr	610(ra) # 800047c4 <fileclose>
  return 0;
    8000556a:	4781                	li	a5,0
}
    8000556c:	853e                	mv	a0,a5
    8000556e:	60e2                	ld	ra,24(sp)
    80005570:	6442                	ld	s0,16(sp)
    80005572:	6105                	addi	sp,sp,32
    80005574:	8082                	ret

0000000080005576 <sys_fstat>:
{
    80005576:	1101                	addi	sp,sp,-32
    80005578:	ec06                	sd	ra,24(sp)
    8000557a:	e822                	sd	s0,16(sp)
    8000557c:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    8000557e:	fe040593          	addi	a1,s0,-32
    80005582:	4505                	li	a0,1
    80005584:	ffffe097          	auipc	ra,0xffffe
    80005588:	852080e7          	jalr	-1966(ra) # 80002dd6 <argaddr>
  if(argfd(0, 0, &f) < 0)
    8000558c:	fe840613          	addi	a2,s0,-24
    80005590:	4581                	li	a1,0
    80005592:	4501                	li	a0,0
    80005594:	00000097          	auipc	ra,0x0
    80005598:	c6a080e7          	jalr	-918(ra) # 800051fe <argfd>
    8000559c:	87aa                	mv	a5,a0
    return -1;
    8000559e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800055a0:	0007ca63          	bltz	a5,800055b4 <sys_fstat+0x3e>
  return filestat(f, st);
    800055a4:	fe043583          	ld	a1,-32(s0)
    800055a8:	fe843503          	ld	a0,-24(s0)
    800055ac:	fffff097          	auipc	ra,0xfffff
    800055b0:	2e0080e7          	jalr	736(ra) # 8000488c <filestat>
}
    800055b4:	60e2                	ld	ra,24(sp)
    800055b6:	6442                	ld	s0,16(sp)
    800055b8:	6105                	addi	sp,sp,32
    800055ba:	8082                	ret

00000000800055bc <sys_link>:
{
    800055bc:	7169                	addi	sp,sp,-304
    800055be:	f606                	sd	ra,296(sp)
    800055c0:	f222                	sd	s0,288(sp)
    800055c2:	ee26                	sd	s1,280(sp)
    800055c4:	ea4a                	sd	s2,272(sp)
    800055c6:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800055c8:	08000613          	li	a2,128
    800055cc:	ed040593          	addi	a1,s0,-304
    800055d0:	4501                	li	a0,0
    800055d2:	ffffe097          	auipc	ra,0xffffe
    800055d6:	824080e7          	jalr	-2012(ra) # 80002df6 <argstr>
    return -1;
    800055da:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800055dc:	10054e63          	bltz	a0,800056f8 <sys_link+0x13c>
    800055e0:	08000613          	li	a2,128
    800055e4:	f5040593          	addi	a1,s0,-176
    800055e8:	4505                	li	a0,1
    800055ea:	ffffe097          	auipc	ra,0xffffe
    800055ee:	80c080e7          	jalr	-2036(ra) # 80002df6 <argstr>
    return -1;
    800055f2:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800055f4:	10054263          	bltz	a0,800056f8 <sys_link+0x13c>
  begin_op();
    800055f8:	fffff097          	auipc	ra,0xfffff
    800055fc:	d00080e7          	jalr	-768(ra) # 800042f8 <begin_op>
  if((ip = namei(old)) == 0){
    80005600:	ed040513          	addi	a0,s0,-304
    80005604:	fffff097          	auipc	ra,0xfffff
    80005608:	ad4080e7          	jalr	-1324(ra) # 800040d8 <namei>
    8000560c:	84aa                	mv	s1,a0
    8000560e:	c551                	beqz	a0,8000569a <sys_link+0xde>
  ilock(ip);
    80005610:	ffffe097          	auipc	ra,0xffffe
    80005614:	322080e7          	jalr	802(ra) # 80003932 <ilock>
  if(ip->type == T_DIR){
    80005618:	04449703          	lh	a4,68(s1)
    8000561c:	4785                	li	a5,1
    8000561e:	08f70463          	beq	a4,a5,800056a6 <sys_link+0xea>
  ip->nlink++;
    80005622:	04a4d783          	lhu	a5,74(s1)
    80005626:	2785                	addiw	a5,a5,1
    80005628:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000562c:	8526                	mv	a0,s1
    8000562e:	ffffe097          	auipc	ra,0xffffe
    80005632:	23a080e7          	jalr	570(ra) # 80003868 <iupdate>
  iunlock(ip);
    80005636:	8526                	mv	a0,s1
    80005638:	ffffe097          	auipc	ra,0xffffe
    8000563c:	3bc080e7          	jalr	956(ra) # 800039f4 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80005640:	fd040593          	addi	a1,s0,-48
    80005644:	f5040513          	addi	a0,s0,-176
    80005648:	fffff097          	auipc	ra,0xfffff
    8000564c:	aae080e7          	jalr	-1362(ra) # 800040f6 <nameiparent>
    80005650:	892a                	mv	s2,a0
    80005652:	c935                	beqz	a0,800056c6 <sys_link+0x10a>
  ilock(dp);
    80005654:	ffffe097          	auipc	ra,0xffffe
    80005658:	2de080e7          	jalr	734(ra) # 80003932 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    8000565c:	00092703          	lw	a4,0(s2)
    80005660:	409c                	lw	a5,0(s1)
    80005662:	04f71d63          	bne	a4,a5,800056bc <sys_link+0x100>
    80005666:	40d0                	lw	a2,4(s1)
    80005668:	fd040593          	addi	a1,s0,-48
    8000566c:	854a                	mv	a0,s2
    8000566e:	fffff097          	auipc	ra,0xfffff
    80005672:	9b8080e7          	jalr	-1608(ra) # 80004026 <dirlink>
    80005676:	04054363          	bltz	a0,800056bc <sys_link+0x100>
  iunlockput(dp);
    8000567a:	854a                	mv	a0,s2
    8000567c:	ffffe097          	auipc	ra,0xffffe
    80005680:	518080e7          	jalr	1304(ra) # 80003b94 <iunlockput>
  iput(ip);
    80005684:	8526                	mv	a0,s1
    80005686:	ffffe097          	auipc	ra,0xffffe
    8000568a:	466080e7          	jalr	1126(ra) # 80003aec <iput>
  end_op();
    8000568e:	fffff097          	auipc	ra,0xfffff
    80005692:	cea080e7          	jalr	-790(ra) # 80004378 <end_op>
  return 0;
    80005696:	4781                	li	a5,0
    80005698:	a085                	j	800056f8 <sys_link+0x13c>
    end_op();
    8000569a:	fffff097          	auipc	ra,0xfffff
    8000569e:	cde080e7          	jalr	-802(ra) # 80004378 <end_op>
    return -1;
    800056a2:	57fd                	li	a5,-1
    800056a4:	a891                	j	800056f8 <sys_link+0x13c>
    iunlockput(ip);
    800056a6:	8526                	mv	a0,s1
    800056a8:	ffffe097          	auipc	ra,0xffffe
    800056ac:	4ec080e7          	jalr	1260(ra) # 80003b94 <iunlockput>
    end_op();
    800056b0:	fffff097          	auipc	ra,0xfffff
    800056b4:	cc8080e7          	jalr	-824(ra) # 80004378 <end_op>
    return -1;
    800056b8:	57fd                	li	a5,-1
    800056ba:	a83d                	j	800056f8 <sys_link+0x13c>
    iunlockput(dp);
    800056bc:	854a                	mv	a0,s2
    800056be:	ffffe097          	auipc	ra,0xffffe
    800056c2:	4d6080e7          	jalr	1238(ra) # 80003b94 <iunlockput>
  ilock(ip);
    800056c6:	8526                	mv	a0,s1
    800056c8:	ffffe097          	auipc	ra,0xffffe
    800056cc:	26a080e7          	jalr	618(ra) # 80003932 <ilock>
  ip->nlink--;
    800056d0:	04a4d783          	lhu	a5,74(s1)
    800056d4:	37fd                	addiw	a5,a5,-1
    800056d6:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800056da:	8526                	mv	a0,s1
    800056dc:	ffffe097          	auipc	ra,0xffffe
    800056e0:	18c080e7          	jalr	396(ra) # 80003868 <iupdate>
  iunlockput(ip);
    800056e4:	8526                	mv	a0,s1
    800056e6:	ffffe097          	auipc	ra,0xffffe
    800056ea:	4ae080e7          	jalr	1198(ra) # 80003b94 <iunlockput>
  end_op();
    800056ee:	fffff097          	auipc	ra,0xfffff
    800056f2:	c8a080e7          	jalr	-886(ra) # 80004378 <end_op>
  return -1;
    800056f6:	57fd                	li	a5,-1
}
    800056f8:	853e                	mv	a0,a5
    800056fa:	70b2                	ld	ra,296(sp)
    800056fc:	7412                	ld	s0,288(sp)
    800056fe:	64f2                	ld	s1,280(sp)
    80005700:	6952                	ld	s2,272(sp)
    80005702:	6155                	addi	sp,sp,304
    80005704:	8082                	ret

0000000080005706 <sys_unlink>:
{
    80005706:	7151                	addi	sp,sp,-240
    80005708:	f586                	sd	ra,232(sp)
    8000570a:	f1a2                	sd	s0,224(sp)
    8000570c:	eda6                	sd	s1,216(sp)
    8000570e:	e9ca                	sd	s2,208(sp)
    80005710:	e5ce                	sd	s3,200(sp)
    80005712:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80005714:	08000613          	li	a2,128
    80005718:	f3040593          	addi	a1,s0,-208
    8000571c:	4501                	li	a0,0
    8000571e:	ffffd097          	auipc	ra,0xffffd
    80005722:	6d8080e7          	jalr	1752(ra) # 80002df6 <argstr>
    80005726:	18054163          	bltz	a0,800058a8 <sys_unlink+0x1a2>
  begin_op();
    8000572a:	fffff097          	auipc	ra,0xfffff
    8000572e:	bce080e7          	jalr	-1074(ra) # 800042f8 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80005732:	fb040593          	addi	a1,s0,-80
    80005736:	f3040513          	addi	a0,s0,-208
    8000573a:	fffff097          	auipc	ra,0xfffff
    8000573e:	9bc080e7          	jalr	-1604(ra) # 800040f6 <nameiparent>
    80005742:	84aa                	mv	s1,a0
    80005744:	c979                	beqz	a0,8000581a <sys_unlink+0x114>
  ilock(dp);
    80005746:	ffffe097          	auipc	ra,0xffffe
    8000574a:	1ec080e7          	jalr	492(ra) # 80003932 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000574e:	00003597          	auipc	a1,0x3
    80005752:	fea58593          	addi	a1,a1,-22 # 80008738 <syscalls+0x2a0>
    80005756:	fb040513          	addi	a0,s0,-80
    8000575a:	ffffe097          	auipc	ra,0xffffe
    8000575e:	6a2080e7          	jalr	1698(ra) # 80003dfc <namecmp>
    80005762:	14050a63          	beqz	a0,800058b6 <sys_unlink+0x1b0>
    80005766:	00003597          	auipc	a1,0x3
    8000576a:	fda58593          	addi	a1,a1,-38 # 80008740 <syscalls+0x2a8>
    8000576e:	fb040513          	addi	a0,s0,-80
    80005772:	ffffe097          	auipc	ra,0xffffe
    80005776:	68a080e7          	jalr	1674(ra) # 80003dfc <namecmp>
    8000577a:	12050e63          	beqz	a0,800058b6 <sys_unlink+0x1b0>
  if((ip = dirlookup(dp, name, &off)) == 0)
    8000577e:	f2c40613          	addi	a2,s0,-212
    80005782:	fb040593          	addi	a1,s0,-80
    80005786:	8526                	mv	a0,s1
    80005788:	ffffe097          	auipc	ra,0xffffe
    8000578c:	68e080e7          	jalr	1678(ra) # 80003e16 <dirlookup>
    80005790:	892a                	mv	s2,a0
    80005792:	12050263          	beqz	a0,800058b6 <sys_unlink+0x1b0>
  ilock(ip);
    80005796:	ffffe097          	auipc	ra,0xffffe
    8000579a:	19c080e7          	jalr	412(ra) # 80003932 <ilock>
  if(ip->nlink < 1)
    8000579e:	04a91783          	lh	a5,74(s2)
    800057a2:	08f05263          	blez	a5,80005826 <sys_unlink+0x120>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800057a6:	04491703          	lh	a4,68(s2)
    800057aa:	4785                	li	a5,1
    800057ac:	08f70563          	beq	a4,a5,80005836 <sys_unlink+0x130>
  memset(&de, 0, sizeof(de));
    800057b0:	4641                	li	a2,16
    800057b2:	4581                	li	a1,0
    800057b4:	fc040513          	addi	a0,s0,-64
    800057b8:	ffffb097          	auipc	ra,0xffffb
    800057bc:	674080e7          	jalr	1652(ra) # 80000e2c <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800057c0:	4741                	li	a4,16
    800057c2:	f2c42683          	lw	a3,-212(s0)
    800057c6:	fc040613          	addi	a2,s0,-64
    800057ca:	4581                	li	a1,0
    800057cc:	8526                	mv	a0,s1
    800057ce:	ffffe097          	auipc	ra,0xffffe
    800057d2:	510080e7          	jalr	1296(ra) # 80003cde <writei>
    800057d6:	47c1                	li	a5,16
    800057d8:	0af51563          	bne	a0,a5,80005882 <sys_unlink+0x17c>
  if(ip->type == T_DIR){
    800057dc:	04491703          	lh	a4,68(s2)
    800057e0:	4785                	li	a5,1
    800057e2:	0af70863          	beq	a4,a5,80005892 <sys_unlink+0x18c>
  iunlockput(dp);
    800057e6:	8526                	mv	a0,s1
    800057e8:	ffffe097          	auipc	ra,0xffffe
    800057ec:	3ac080e7          	jalr	940(ra) # 80003b94 <iunlockput>
  ip->nlink--;
    800057f0:	04a95783          	lhu	a5,74(s2)
    800057f4:	37fd                	addiw	a5,a5,-1
    800057f6:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800057fa:	854a                	mv	a0,s2
    800057fc:	ffffe097          	auipc	ra,0xffffe
    80005800:	06c080e7          	jalr	108(ra) # 80003868 <iupdate>
  iunlockput(ip);
    80005804:	854a                	mv	a0,s2
    80005806:	ffffe097          	auipc	ra,0xffffe
    8000580a:	38e080e7          	jalr	910(ra) # 80003b94 <iunlockput>
  end_op();
    8000580e:	fffff097          	auipc	ra,0xfffff
    80005812:	b6a080e7          	jalr	-1174(ra) # 80004378 <end_op>
  return 0;
    80005816:	4501                	li	a0,0
    80005818:	a84d                	j	800058ca <sys_unlink+0x1c4>
    end_op();
    8000581a:	fffff097          	auipc	ra,0xfffff
    8000581e:	b5e080e7          	jalr	-1186(ra) # 80004378 <end_op>
    return -1;
    80005822:	557d                	li	a0,-1
    80005824:	a05d                	j	800058ca <sys_unlink+0x1c4>
    panic("unlink: nlink < 1");
    80005826:	00003517          	auipc	a0,0x3
    8000582a:	f2250513          	addi	a0,a0,-222 # 80008748 <syscalls+0x2b0>
    8000582e:	ffffb097          	auipc	ra,0xffffb
    80005832:	d10080e7          	jalr	-752(ra) # 8000053e <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005836:	04c92703          	lw	a4,76(s2)
    8000583a:	02000793          	li	a5,32
    8000583e:	f6e7f9e3          	bgeu	a5,a4,800057b0 <sys_unlink+0xaa>
    80005842:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005846:	4741                	li	a4,16
    80005848:	86ce                	mv	a3,s3
    8000584a:	f1840613          	addi	a2,s0,-232
    8000584e:	4581                	li	a1,0
    80005850:	854a                	mv	a0,s2
    80005852:	ffffe097          	auipc	ra,0xffffe
    80005856:	394080e7          	jalr	916(ra) # 80003be6 <readi>
    8000585a:	47c1                	li	a5,16
    8000585c:	00f51b63          	bne	a0,a5,80005872 <sys_unlink+0x16c>
    if(de.inum != 0)
    80005860:	f1845783          	lhu	a5,-232(s0)
    80005864:	e7a1                	bnez	a5,800058ac <sys_unlink+0x1a6>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005866:	29c1                	addiw	s3,s3,16
    80005868:	04c92783          	lw	a5,76(s2)
    8000586c:	fcf9ede3          	bltu	s3,a5,80005846 <sys_unlink+0x140>
    80005870:	b781                	j	800057b0 <sys_unlink+0xaa>
      panic("isdirempty: readi");
    80005872:	00003517          	auipc	a0,0x3
    80005876:	eee50513          	addi	a0,a0,-274 # 80008760 <syscalls+0x2c8>
    8000587a:	ffffb097          	auipc	ra,0xffffb
    8000587e:	cc4080e7          	jalr	-828(ra) # 8000053e <panic>
    panic("unlink: writei");
    80005882:	00003517          	auipc	a0,0x3
    80005886:	ef650513          	addi	a0,a0,-266 # 80008778 <syscalls+0x2e0>
    8000588a:	ffffb097          	auipc	ra,0xffffb
    8000588e:	cb4080e7          	jalr	-844(ra) # 8000053e <panic>
    dp->nlink--;
    80005892:	04a4d783          	lhu	a5,74(s1)
    80005896:	37fd                	addiw	a5,a5,-1
    80005898:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000589c:	8526                	mv	a0,s1
    8000589e:	ffffe097          	auipc	ra,0xffffe
    800058a2:	fca080e7          	jalr	-54(ra) # 80003868 <iupdate>
    800058a6:	b781                	j	800057e6 <sys_unlink+0xe0>
    return -1;
    800058a8:	557d                	li	a0,-1
    800058aa:	a005                	j	800058ca <sys_unlink+0x1c4>
    iunlockput(ip);
    800058ac:	854a                	mv	a0,s2
    800058ae:	ffffe097          	auipc	ra,0xffffe
    800058b2:	2e6080e7          	jalr	742(ra) # 80003b94 <iunlockput>
  iunlockput(dp);
    800058b6:	8526                	mv	a0,s1
    800058b8:	ffffe097          	auipc	ra,0xffffe
    800058bc:	2dc080e7          	jalr	732(ra) # 80003b94 <iunlockput>
  end_op();
    800058c0:	fffff097          	auipc	ra,0xfffff
    800058c4:	ab8080e7          	jalr	-1352(ra) # 80004378 <end_op>
  return -1;
    800058c8:	557d                	li	a0,-1
}
    800058ca:	70ae                	ld	ra,232(sp)
    800058cc:	740e                	ld	s0,224(sp)
    800058ce:	64ee                	ld	s1,216(sp)
    800058d0:	694e                	ld	s2,208(sp)
    800058d2:	69ae                	ld	s3,200(sp)
    800058d4:	616d                	addi	sp,sp,240
    800058d6:	8082                	ret

00000000800058d8 <sys_open>:

uint64
sys_open(void)
{
    800058d8:	7131                	addi	sp,sp,-192
    800058da:	fd06                	sd	ra,184(sp)
    800058dc:	f922                	sd	s0,176(sp)
    800058de:	f526                	sd	s1,168(sp)
    800058e0:	f14a                	sd	s2,160(sp)
    800058e2:	ed4e                	sd	s3,152(sp)
    800058e4:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800058e6:	f4c40593          	addi	a1,s0,-180
    800058ea:	4505                	li	a0,1
    800058ec:	ffffd097          	auipc	ra,0xffffd
    800058f0:	4ca080e7          	jalr	1226(ra) # 80002db6 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800058f4:	08000613          	li	a2,128
    800058f8:	f5040593          	addi	a1,s0,-176
    800058fc:	4501                	li	a0,0
    800058fe:	ffffd097          	auipc	ra,0xffffd
    80005902:	4f8080e7          	jalr	1272(ra) # 80002df6 <argstr>
    80005906:	87aa                	mv	a5,a0
    return -1;
    80005908:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000590a:	0a07c963          	bltz	a5,800059bc <sys_open+0xe4>

  begin_op();
    8000590e:	fffff097          	auipc	ra,0xfffff
    80005912:	9ea080e7          	jalr	-1558(ra) # 800042f8 <begin_op>

  if(omode & O_CREATE){
    80005916:	f4c42783          	lw	a5,-180(s0)
    8000591a:	2007f793          	andi	a5,a5,512
    8000591e:	cfc5                	beqz	a5,800059d6 <sys_open+0xfe>
    ip = create(path, T_FILE, 0, 0);
    80005920:	4681                	li	a3,0
    80005922:	4601                	li	a2,0
    80005924:	4589                	li	a1,2
    80005926:	f5040513          	addi	a0,s0,-176
    8000592a:	00000097          	auipc	ra,0x0
    8000592e:	976080e7          	jalr	-1674(ra) # 800052a0 <create>
    80005932:	84aa                	mv	s1,a0
    if(ip == 0){
    80005934:	c959                	beqz	a0,800059ca <sys_open+0xf2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80005936:	04449703          	lh	a4,68(s1)
    8000593a:	478d                	li	a5,3
    8000593c:	00f71763          	bne	a4,a5,8000594a <sys_open+0x72>
    80005940:	0464d703          	lhu	a4,70(s1)
    80005944:	47a5                	li	a5,9
    80005946:	0ce7ed63          	bltu	a5,a4,80005a20 <sys_open+0x148>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000594a:	fffff097          	auipc	ra,0xfffff
    8000594e:	dbe080e7          	jalr	-578(ra) # 80004708 <filealloc>
    80005952:	89aa                	mv	s3,a0
    80005954:	10050363          	beqz	a0,80005a5a <sys_open+0x182>
    80005958:	00000097          	auipc	ra,0x0
    8000595c:	906080e7          	jalr	-1786(ra) # 8000525e <fdalloc>
    80005960:	892a                	mv	s2,a0
    80005962:	0e054763          	bltz	a0,80005a50 <sys_open+0x178>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005966:	04449703          	lh	a4,68(s1)
    8000596a:	478d                	li	a5,3
    8000596c:	0cf70563          	beq	a4,a5,80005a36 <sys_open+0x15e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005970:	4789                	li	a5,2
    80005972:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80005976:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    8000597a:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    8000597e:	f4c42783          	lw	a5,-180(s0)
    80005982:	0017c713          	xori	a4,a5,1
    80005986:	8b05                	andi	a4,a4,1
    80005988:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000598c:	0037f713          	andi	a4,a5,3
    80005990:	00e03733          	snez	a4,a4
    80005994:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80005998:	4007f793          	andi	a5,a5,1024
    8000599c:	c791                	beqz	a5,800059a8 <sys_open+0xd0>
    8000599e:	04449703          	lh	a4,68(s1)
    800059a2:	4789                	li	a5,2
    800059a4:	0af70063          	beq	a4,a5,80005a44 <sys_open+0x16c>
    itrunc(ip);
  }

  iunlock(ip);
    800059a8:	8526                	mv	a0,s1
    800059aa:	ffffe097          	auipc	ra,0xffffe
    800059ae:	04a080e7          	jalr	74(ra) # 800039f4 <iunlock>
  end_op();
    800059b2:	fffff097          	auipc	ra,0xfffff
    800059b6:	9c6080e7          	jalr	-1594(ra) # 80004378 <end_op>

  return fd;
    800059ba:	854a                	mv	a0,s2
}
    800059bc:	70ea                	ld	ra,184(sp)
    800059be:	744a                	ld	s0,176(sp)
    800059c0:	74aa                	ld	s1,168(sp)
    800059c2:	790a                	ld	s2,160(sp)
    800059c4:	69ea                	ld	s3,152(sp)
    800059c6:	6129                	addi	sp,sp,192
    800059c8:	8082                	ret
      end_op();
    800059ca:	fffff097          	auipc	ra,0xfffff
    800059ce:	9ae080e7          	jalr	-1618(ra) # 80004378 <end_op>
      return -1;
    800059d2:	557d                	li	a0,-1
    800059d4:	b7e5                	j	800059bc <sys_open+0xe4>
    if((ip = namei(path)) == 0){
    800059d6:	f5040513          	addi	a0,s0,-176
    800059da:	ffffe097          	auipc	ra,0xffffe
    800059de:	6fe080e7          	jalr	1790(ra) # 800040d8 <namei>
    800059e2:	84aa                	mv	s1,a0
    800059e4:	c905                	beqz	a0,80005a14 <sys_open+0x13c>
    ilock(ip);
    800059e6:	ffffe097          	auipc	ra,0xffffe
    800059ea:	f4c080e7          	jalr	-180(ra) # 80003932 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800059ee:	04449703          	lh	a4,68(s1)
    800059f2:	4785                	li	a5,1
    800059f4:	f4f711e3          	bne	a4,a5,80005936 <sys_open+0x5e>
    800059f8:	f4c42783          	lw	a5,-180(s0)
    800059fc:	d7b9                	beqz	a5,8000594a <sys_open+0x72>
      iunlockput(ip);
    800059fe:	8526                	mv	a0,s1
    80005a00:	ffffe097          	auipc	ra,0xffffe
    80005a04:	194080e7          	jalr	404(ra) # 80003b94 <iunlockput>
      end_op();
    80005a08:	fffff097          	auipc	ra,0xfffff
    80005a0c:	970080e7          	jalr	-1680(ra) # 80004378 <end_op>
      return -1;
    80005a10:	557d                	li	a0,-1
    80005a12:	b76d                	j	800059bc <sys_open+0xe4>
      end_op();
    80005a14:	fffff097          	auipc	ra,0xfffff
    80005a18:	964080e7          	jalr	-1692(ra) # 80004378 <end_op>
      return -1;
    80005a1c:	557d                	li	a0,-1
    80005a1e:	bf79                	j	800059bc <sys_open+0xe4>
    iunlockput(ip);
    80005a20:	8526                	mv	a0,s1
    80005a22:	ffffe097          	auipc	ra,0xffffe
    80005a26:	172080e7          	jalr	370(ra) # 80003b94 <iunlockput>
    end_op();
    80005a2a:	fffff097          	auipc	ra,0xfffff
    80005a2e:	94e080e7          	jalr	-1714(ra) # 80004378 <end_op>
    return -1;
    80005a32:	557d                	li	a0,-1
    80005a34:	b761                	j	800059bc <sys_open+0xe4>
    f->type = FD_DEVICE;
    80005a36:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    80005a3a:	04649783          	lh	a5,70(s1)
    80005a3e:	02f99223          	sh	a5,36(s3)
    80005a42:	bf25                	j	8000597a <sys_open+0xa2>
    itrunc(ip);
    80005a44:	8526                	mv	a0,s1
    80005a46:	ffffe097          	auipc	ra,0xffffe
    80005a4a:	ffa080e7          	jalr	-6(ra) # 80003a40 <itrunc>
    80005a4e:	bfa9                	j	800059a8 <sys_open+0xd0>
      fileclose(f);
    80005a50:	854e                	mv	a0,s3
    80005a52:	fffff097          	auipc	ra,0xfffff
    80005a56:	d72080e7          	jalr	-654(ra) # 800047c4 <fileclose>
    iunlockput(ip);
    80005a5a:	8526                	mv	a0,s1
    80005a5c:	ffffe097          	auipc	ra,0xffffe
    80005a60:	138080e7          	jalr	312(ra) # 80003b94 <iunlockput>
    end_op();
    80005a64:	fffff097          	auipc	ra,0xfffff
    80005a68:	914080e7          	jalr	-1772(ra) # 80004378 <end_op>
    return -1;
    80005a6c:	557d                	li	a0,-1
    80005a6e:	b7b9                	j	800059bc <sys_open+0xe4>

0000000080005a70 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005a70:	7175                	addi	sp,sp,-144
    80005a72:	e506                	sd	ra,136(sp)
    80005a74:	e122                	sd	s0,128(sp)
    80005a76:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005a78:	fffff097          	auipc	ra,0xfffff
    80005a7c:	880080e7          	jalr	-1920(ra) # 800042f8 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005a80:	08000613          	li	a2,128
    80005a84:	f7040593          	addi	a1,s0,-144
    80005a88:	4501                	li	a0,0
    80005a8a:	ffffd097          	auipc	ra,0xffffd
    80005a8e:	36c080e7          	jalr	876(ra) # 80002df6 <argstr>
    80005a92:	02054963          	bltz	a0,80005ac4 <sys_mkdir+0x54>
    80005a96:	4681                	li	a3,0
    80005a98:	4601                	li	a2,0
    80005a9a:	4585                	li	a1,1
    80005a9c:	f7040513          	addi	a0,s0,-144
    80005aa0:	00000097          	auipc	ra,0x0
    80005aa4:	800080e7          	jalr	-2048(ra) # 800052a0 <create>
    80005aa8:	cd11                	beqz	a0,80005ac4 <sys_mkdir+0x54>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005aaa:	ffffe097          	auipc	ra,0xffffe
    80005aae:	0ea080e7          	jalr	234(ra) # 80003b94 <iunlockput>
  end_op();
    80005ab2:	fffff097          	auipc	ra,0xfffff
    80005ab6:	8c6080e7          	jalr	-1850(ra) # 80004378 <end_op>
  return 0;
    80005aba:	4501                	li	a0,0
}
    80005abc:	60aa                	ld	ra,136(sp)
    80005abe:	640a                	ld	s0,128(sp)
    80005ac0:	6149                	addi	sp,sp,144
    80005ac2:	8082                	ret
    end_op();
    80005ac4:	fffff097          	auipc	ra,0xfffff
    80005ac8:	8b4080e7          	jalr	-1868(ra) # 80004378 <end_op>
    return -1;
    80005acc:	557d                	li	a0,-1
    80005ace:	b7fd                	j	80005abc <sys_mkdir+0x4c>

0000000080005ad0 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005ad0:	7135                	addi	sp,sp,-160
    80005ad2:	ed06                	sd	ra,152(sp)
    80005ad4:	e922                	sd	s0,144(sp)
    80005ad6:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005ad8:	fffff097          	auipc	ra,0xfffff
    80005adc:	820080e7          	jalr	-2016(ra) # 800042f8 <begin_op>
  argint(1, &major);
    80005ae0:	f6c40593          	addi	a1,s0,-148
    80005ae4:	4505                	li	a0,1
    80005ae6:	ffffd097          	auipc	ra,0xffffd
    80005aea:	2d0080e7          	jalr	720(ra) # 80002db6 <argint>
  argint(2, &minor);
    80005aee:	f6840593          	addi	a1,s0,-152
    80005af2:	4509                	li	a0,2
    80005af4:	ffffd097          	auipc	ra,0xffffd
    80005af8:	2c2080e7          	jalr	706(ra) # 80002db6 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005afc:	08000613          	li	a2,128
    80005b00:	f7040593          	addi	a1,s0,-144
    80005b04:	4501                	li	a0,0
    80005b06:	ffffd097          	auipc	ra,0xffffd
    80005b0a:	2f0080e7          	jalr	752(ra) # 80002df6 <argstr>
    80005b0e:	02054b63          	bltz	a0,80005b44 <sys_mknod+0x74>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80005b12:	f6841683          	lh	a3,-152(s0)
    80005b16:	f6c41603          	lh	a2,-148(s0)
    80005b1a:	458d                	li	a1,3
    80005b1c:	f7040513          	addi	a0,s0,-144
    80005b20:	fffff097          	auipc	ra,0xfffff
    80005b24:	780080e7          	jalr	1920(ra) # 800052a0 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005b28:	cd11                	beqz	a0,80005b44 <sys_mknod+0x74>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005b2a:	ffffe097          	auipc	ra,0xffffe
    80005b2e:	06a080e7          	jalr	106(ra) # 80003b94 <iunlockput>
  end_op();
    80005b32:	fffff097          	auipc	ra,0xfffff
    80005b36:	846080e7          	jalr	-1978(ra) # 80004378 <end_op>
  return 0;
    80005b3a:	4501                	li	a0,0
}
    80005b3c:	60ea                	ld	ra,152(sp)
    80005b3e:	644a                	ld	s0,144(sp)
    80005b40:	610d                	addi	sp,sp,160
    80005b42:	8082                	ret
    end_op();
    80005b44:	fffff097          	auipc	ra,0xfffff
    80005b48:	834080e7          	jalr	-1996(ra) # 80004378 <end_op>
    return -1;
    80005b4c:	557d                	li	a0,-1
    80005b4e:	b7fd                	j	80005b3c <sys_mknod+0x6c>

0000000080005b50 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005b50:	7135                	addi	sp,sp,-160
    80005b52:	ed06                	sd	ra,152(sp)
    80005b54:	e922                	sd	s0,144(sp)
    80005b56:	e526                	sd	s1,136(sp)
    80005b58:	e14a                	sd	s2,128(sp)
    80005b5a:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005b5c:	ffffc097          	auipc	ra,0xffffc
    80005b60:	0d6080e7          	jalr	214(ra) # 80001c32 <myproc>
    80005b64:	892a                	mv	s2,a0
  
  begin_op();
    80005b66:	ffffe097          	auipc	ra,0xffffe
    80005b6a:	792080e7          	jalr	1938(ra) # 800042f8 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005b6e:	08000613          	li	a2,128
    80005b72:	f6040593          	addi	a1,s0,-160
    80005b76:	4501                	li	a0,0
    80005b78:	ffffd097          	auipc	ra,0xffffd
    80005b7c:	27e080e7          	jalr	638(ra) # 80002df6 <argstr>
    80005b80:	04054b63          	bltz	a0,80005bd6 <sys_chdir+0x86>
    80005b84:	f6040513          	addi	a0,s0,-160
    80005b88:	ffffe097          	auipc	ra,0xffffe
    80005b8c:	550080e7          	jalr	1360(ra) # 800040d8 <namei>
    80005b90:	84aa                	mv	s1,a0
    80005b92:	c131                	beqz	a0,80005bd6 <sys_chdir+0x86>
    end_op();
    return -1;
  }
  ilock(ip);
    80005b94:	ffffe097          	auipc	ra,0xffffe
    80005b98:	d9e080e7          	jalr	-610(ra) # 80003932 <ilock>
  if(ip->type != T_DIR){
    80005b9c:	04449703          	lh	a4,68(s1)
    80005ba0:	4785                	li	a5,1
    80005ba2:	04f71063          	bne	a4,a5,80005be2 <sys_chdir+0x92>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005ba6:	8526                	mv	a0,s1
    80005ba8:	ffffe097          	auipc	ra,0xffffe
    80005bac:	e4c080e7          	jalr	-436(ra) # 800039f4 <iunlock>
  iput(p->cwd);
    80005bb0:	15093503          	ld	a0,336(s2)
    80005bb4:	ffffe097          	auipc	ra,0xffffe
    80005bb8:	f38080e7          	jalr	-200(ra) # 80003aec <iput>
  end_op();
    80005bbc:	ffffe097          	auipc	ra,0xffffe
    80005bc0:	7bc080e7          	jalr	1980(ra) # 80004378 <end_op>
  p->cwd = ip;
    80005bc4:	14993823          	sd	s1,336(s2)
  return 0;
    80005bc8:	4501                	li	a0,0
}
    80005bca:	60ea                	ld	ra,152(sp)
    80005bcc:	644a                	ld	s0,144(sp)
    80005bce:	64aa                	ld	s1,136(sp)
    80005bd0:	690a                	ld	s2,128(sp)
    80005bd2:	610d                	addi	sp,sp,160
    80005bd4:	8082                	ret
    end_op();
    80005bd6:	ffffe097          	auipc	ra,0xffffe
    80005bda:	7a2080e7          	jalr	1954(ra) # 80004378 <end_op>
    return -1;
    80005bde:	557d                	li	a0,-1
    80005be0:	b7ed                	j	80005bca <sys_chdir+0x7a>
    iunlockput(ip);
    80005be2:	8526                	mv	a0,s1
    80005be4:	ffffe097          	auipc	ra,0xffffe
    80005be8:	fb0080e7          	jalr	-80(ra) # 80003b94 <iunlockput>
    end_op();
    80005bec:	ffffe097          	auipc	ra,0xffffe
    80005bf0:	78c080e7          	jalr	1932(ra) # 80004378 <end_op>
    return -1;
    80005bf4:	557d                	li	a0,-1
    80005bf6:	bfd1                	j	80005bca <sys_chdir+0x7a>

0000000080005bf8 <sys_exec>:

uint64
sys_exec(void)
{
    80005bf8:	7145                	addi	sp,sp,-464
    80005bfa:	e786                	sd	ra,456(sp)
    80005bfc:	e3a2                	sd	s0,448(sp)
    80005bfe:	ff26                	sd	s1,440(sp)
    80005c00:	fb4a                	sd	s2,432(sp)
    80005c02:	f74e                	sd	s3,424(sp)
    80005c04:	f352                	sd	s4,416(sp)
    80005c06:	ef56                	sd	s5,408(sp)
    80005c08:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005c0a:	e3840593          	addi	a1,s0,-456
    80005c0e:	4505                	li	a0,1
    80005c10:	ffffd097          	auipc	ra,0xffffd
    80005c14:	1c6080e7          	jalr	454(ra) # 80002dd6 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005c18:	08000613          	li	a2,128
    80005c1c:	f4040593          	addi	a1,s0,-192
    80005c20:	4501                	li	a0,0
    80005c22:	ffffd097          	auipc	ra,0xffffd
    80005c26:	1d4080e7          	jalr	468(ra) # 80002df6 <argstr>
    80005c2a:	87aa                	mv	a5,a0
    return -1;
    80005c2c:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005c2e:	0c07c263          	bltz	a5,80005cf2 <sys_exec+0xfa>
  }
  memset(argv, 0, sizeof(argv));
    80005c32:	10000613          	li	a2,256
    80005c36:	4581                	li	a1,0
    80005c38:	e4040513          	addi	a0,s0,-448
    80005c3c:	ffffb097          	auipc	ra,0xffffb
    80005c40:	1f0080e7          	jalr	496(ra) # 80000e2c <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005c44:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80005c48:	89a6                	mv	s3,s1
    80005c4a:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005c4c:	02000a13          	li	s4,32
    80005c50:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005c54:	00391793          	slli	a5,s2,0x3
    80005c58:	e3040593          	addi	a1,s0,-464
    80005c5c:	e3843503          	ld	a0,-456(s0)
    80005c60:	953e                	add	a0,a0,a5
    80005c62:	ffffd097          	auipc	ra,0xffffd
    80005c66:	0b6080e7          	jalr	182(ra) # 80002d18 <fetchaddr>
    80005c6a:	02054a63          	bltz	a0,80005c9e <sys_exec+0xa6>
      goto bad;
    }
    if(uarg == 0){
    80005c6e:	e3043783          	ld	a5,-464(s0)
    80005c72:	c3b9                	beqz	a5,80005cb8 <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005c74:	ffffb097          	auipc	ra,0xffffb
    80005c78:	f9e080e7          	jalr	-98(ra) # 80000c12 <kalloc>
    80005c7c:	85aa                	mv	a1,a0
    80005c7e:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005c82:	cd11                	beqz	a0,80005c9e <sys_exec+0xa6>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005c84:	6605                	lui	a2,0x1
    80005c86:	e3043503          	ld	a0,-464(s0)
    80005c8a:	ffffd097          	auipc	ra,0xffffd
    80005c8e:	0e0080e7          	jalr	224(ra) # 80002d6a <fetchstr>
    80005c92:	00054663          	bltz	a0,80005c9e <sys_exec+0xa6>
    if(i >= NELEM(argv)){
    80005c96:	0905                	addi	s2,s2,1
    80005c98:	09a1                	addi	s3,s3,8
    80005c9a:	fb491be3          	bne	s2,s4,80005c50 <sys_exec+0x58>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c9e:	10048913          	addi	s2,s1,256
    80005ca2:	6088                	ld	a0,0(s1)
    80005ca4:	c531                	beqz	a0,80005cf0 <sys_exec+0xf8>
    kfree(argv[i]);
    80005ca6:	ffffb097          	auipc	ra,0xffffb
    80005caa:	e58080e7          	jalr	-424(ra) # 80000afe <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005cae:	04a1                	addi	s1,s1,8
    80005cb0:	ff2499e3          	bne	s1,s2,80005ca2 <sys_exec+0xaa>
  return -1;
    80005cb4:	557d                	li	a0,-1
    80005cb6:	a835                	j	80005cf2 <sys_exec+0xfa>
      argv[i] = 0;
    80005cb8:	0a8e                	slli	s5,s5,0x3
    80005cba:	fc040793          	addi	a5,s0,-64
    80005cbe:	9abe                	add	s5,s5,a5
    80005cc0:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    80005cc4:	e4040593          	addi	a1,s0,-448
    80005cc8:	f4040513          	addi	a0,s0,-192
    80005ccc:	fffff097          	auipc	ra,0xfffff
    80005cd0:	172080e7          	jalr	370(ra) # 80004e3e <exec>
    80005cd4:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005cd6:	10048993          	addi	s3,s1,256
    80005cda:	6088                	ld	a0,0(s1)
    80005cdc:	c901                	beqz	a0,80005cec <sys_exec+0xf4>
    kfree(argv[i]);
    80005cde:	ffffb097          	auipc	ra,0xffffb
    80005ce2:	e20080e7          	jalr	-480(ra) # 80000afe <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005ce6:	04a1                	addi	s1,s1,8
    80005ce8:	ff3499e3          	bne	s1,s3,80005cda <sys_exec+0xe2>
  return ret;
    80005cec:	854a                	mv	a0,s2
    80005cee:	a011                	j	80005cf2 <sys_exec+0xfa>
  return -1;
    80005cf0:	557d                	li	a0,-1
}
    80005cf2:	60be                	ld	ra,456(sp)
    80005cf4:	641e                	ld	s0,448(sp)
    80005cf6:	74fa                	ld	s1,440(sp)
    80005cf8:	795a                	ld	s2,432(sp)
    80005cfa:	79ba                	ld	s3,424(sp)
    80005cfc:	7a1a                	ld	s4,416(sp)
    80005cfe:	6afa                	ld	s5,408(sp)
    80005d00:	6179                	addi	sp,sp,464
    80005d02:	8082                	ret

0000000080005d04 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005d04:	7139                	addi	sp,sp,-64
    80005d06:	fc06                	sd	ra,56(sp)
    80005d08:	f822                	sd	s0,48(sp)
    80005d0a:	f426                	sd	s1,40(sp)
    80005d0c:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005d0e:	ffffc097          	auipc	ra,0xffffc
    80005d12:	f24080e7          	jalr	-220(ra) # 80001c32 <myproc>
    80005d16:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005d18:	fd840593          	addi	a1,s0,-40
    80005d1c:	4501                	li	a0,0
    80005d1e:	ffffd097          	auipc	ra,0xffffd
    80005d22:	0b8080e7          	jalr	184(ra) # 80002dd6 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005d26:	fc840593          	addi	a1,s0,-56
    80005d2a:	fd040513          	addi	a0,s0,-48
    80005d2e:	fffff097          	auipc	ra,0xfffff
    80005d32:	dc6080e7          	jalr	-570(ra) # 80004af4 <pipealloc>
    return -1;
    80005d36:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005d38:	0c054463          	bltz	a0,80005e00 <sys_pipe+0xfc>
  fd0 = -1;
    80005d3c:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005d40:	fd043503          	ld	a0,-48(s0)
    80005d44:	fffff097          	auipc	ra,0xfffff
    80005d48:	51a080e7          	jalr	1306(ra) # 8000525e <fdalloc>
    80005d4c:	fca42223          	sw	a0,-60(s0)
    80005d50:	08054b63          	bltz	a0,80005de6 <sys_pipe+0xe2>
    80005d54:	fc843503          	ld	a0,-56(s0)
    80005d58:	fffff097          	auipc	ra,0xfffff
    80005d5c:	506080e7          	jalr	1286(ra) # 8000525e <fdalloc>
    80005d60:	fca42023          	sw	a0,-64(s0)
    80005d64:	06054863          	bltz	a0,80005dd4 <sys_pipe+0xd0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005d68:	4691                	li	a3,4
    80005d6a:	fc440613          	addi	a2,s0,-60
    80005d6e:	fd843583          	ld	a1,-40(s0)
    80005d72:	68a8                	ld	a0,80(s1)
    80005d74:	ffffc097          	auipc	ra,0xffffc
    80005d78:	b0e080e7          	jalr	-1266(ra) # 80001882 <copyout>
    80005d7c:	02054063          	bltz	a0,80005d9c <sys_pipe+0x98>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005d80:	4691                	li	a3,4
    80005d82:	fc040613          	addi	a2,s0,-64
    80005d86:	fd843583          	ld	a1,-40(s0)
    80005d8a:	0591                	addi	a1,a1,4
    80005d8c:	68a8                	ld	a0,80(s1)
    80005d8e:	ffffc097          	auipc	ra,0xffffc
    80005d92:	af4080e7          	jalr	-1292(ra) # 80001882 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005d96:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005d98:	06055463          	bgez	a0,80005e00 <sys_pipe+0xfc>
    p->ofile[fd0] = 0;
    80005d9c:	fc442783          	lw	a5,-60(s0)
    80005da0:	07e9                	addi	a5,a5,26
    80005da2:	078e                	slli	a5,a5,0x3
    80005da4:	97a6                	add	a5,a5,s1
    80005da6:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005daa:	fc042503          	lw	a0,-64(s0)
    80005dae:	0569                	addi	a0,a0,26
    80005db0:	050e                	slli	a0,a0,0x3
    80005db2:	94aa                	add	s1,s1,a0
    80005db4:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005db8:	fd043503          	ld	a0,-48(s0)
    80005dbc:	fffff097          	auipc	ra,0xfffff
    80005dc0:	a08080e7          	jalr	-1528(ra) # 800047c4 <fileclose>
    fileclose(wf);
    80005dc4:	fc843503          	ld	a0,-56(s0)
    80005dc8:	fffff097          	auipc	ra,0xfffff
    80005dcc:	9fc080e7          	jalr	-1540(ra) # 800047c4 <fileclose>
    return -1;
    80005dd0:	57fd                	li	a5,-1
    80005dd2:	a03d                	j	80005e00 <sys_pipe+0xfc>
    if(fd0 >= 0)
    80005dd4:	fc442783          	lw	a5,-60(s0)
    80005dd8:	0007c763          	bltz	a5,80005de6 <sys_pipe+0xe2>
      p->ofile[fd0] = 0;
    80005ddc:	07e9                	addi	a5,a5,26
    80005dde:	078e                	slli	a5,a5,0x3
    80005de0:	94be                	add	s1,s1,a5
    80005de2:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005de6:	fd043503          	ld	a0,-48(s0)
    80005dea:	fffff097          	auipc	ra,0xfffff
    80005dee:	9da080e7          	jalr	-1574(ra) # 800047c4 <fileclose>
    fileclose(wf);
    80005df2:	fc843503          	ld	a0,-56(s0)
    80005df6:	fffff097          	auipc	ra,0xfffff
    80005dfa:	9ce080e7          	jalr	-1586(ra) # 800047c4 <fileclose>
    return -1;
    80005dfe:	57fd                	li	a5,-1
}
    80005e00:	853e                	mv	a0,a5
    80005e02:	70e2                	ld	ra,56(sp)
    80005e04:	7442                	ld	s0,48(sp)
    80005e06:	74a2                	ld	s1,40(sp)
    80005e08:	6121                	addi	sp,sp,64
    80005e0a:	8082                	ret
    80005e0c:	0000                	unimp
	...

0000000080005e10 <kernelvec>:
    80005e10:	7111                	addi	sp,sp,-256
    80005e12:	e006                	sd	ra,0(sp)
    80005e14:	e40a                	sd	sp,8(sp)
    80005e16:	e80e                	sd	gp,16(sp)
    80005e18:	ec12                	sd	tp,24(sp)
    80005e1a:	f016                	sd	t0,32(sp)
    80005e1c:	f41a                	sd	t1,40(sp)
    80005e1e:	f81e                	sd	t2,48(sp)
    80005e20:	e4aa                	sd	a0,72(sp)
    80005e22:	e8ae                	sd	a1,80(sp)
    80005e24:	ecb2                	sd	a2,88(sp)
    80005e26:	f0b6                	sd	a3,96(sp)
    80005e28:	f4ba                	sd	a4,104(sp)
    80005e2a:	f8be                	sd	a5,112(sp)
    80005e2c:	fcc2                	sd	a6,120(sp)
    80005e2e:	e146                	sd	a7,128(sp)
    80005e30:	edf2                	sd	t3,216(sp)
    80005e32:	f1f6                	sd	t4,224(sp)
    80005e34:	f5fa                	sd	t5,232(sp)
    80005e36:	f9fe                	sd	t6,240(sp)
    80005e38:	dadfc0ef          	jal	ra,80002be4 <kerneltrap>
    80005e3c:	6082                	ld	ra,0(sp)
    80005e3e:	6122                	ld	sp,8(sp)
    80005e40:	61c2                	ld	gp,16(sp)
    80005e42:	7282                	ld	t0,32(sp)
    80005e44:	7322                	ld	t1,40(sp)
    80005e46:	73c2                	ld	t2,48(sp)
    80005e48:	6526                	ld	a0,72(sp)
    80005e4a:	65c6                	ld	a1,80(sp)
    80005e4c:	6666                	ld	a2,88(sp)
    80005e4e:	7686                	ld	a3,96(sp)
    80005e50:	7726                	ld	a4,104(sp)
    80005e52:	77c6                	ld	a5,112(sp)
    80005e54:	7866                	ld	a6,120(sp)
    80005e56:	688a                	ld	a7,128(sp)
    80005e58:	6e6e                	ld	t3,216(sp)
    80005e5a:	7e8e                	ld	t4,224(sp)
    80005e5c:	7f2e                	ld	t5,232(sp)
    80005e5e:	7fce                	ld	t6,240(sp)
    80005e60:	6111                	addi	sp,sp,256
    80005e62:	10200073          	sret
    80005e66:	00000013          	nop
    80005e6a:	00000013          	nop
    80005e6e:	0001                	nop

0000000080005e70 <timervec>:
    80005e70:	34051573          	csrrw	a0,mscratch,a0
    80005e74:	e10c                	sd	a1,0(a0)
    80005e76:	e510                	sd	a2,8(a0)
    80005e78:	e914                	sd	a3,16(a0)
    80005e7a:	6d0c                	ld	a1,24(a0)
    80005e7c:	7110                	ld	a2,32(a0)
    80005e7e:	6194                	ld	a3,0(a1)
    80005e80:	96b2                	add	a3,a3,a2
    80005e82:	e194                	sd	a3,0(a1)
    80005e84:	4589                	li	a1,2
    80005e86:	14459073          	csrw	sip,a1
    80005e8a:	6914                	ld	a3,16(a0)
    80005e8c:	6510                	ld	a2,8(a0)
    80005e8e:	610c                	ld	a1,0(a0)
    80005e90:	34051573          	csrrw	a0,mscratch,a0
    80005e94:	30200073          	mret
	...

0000000080005e9a <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80005e9a:	1141                	addi	sp,sp,-16
    80005e9c:	e422                	sd	s0,8(sp)
    80005e9e:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005ea0:	0c0007b7          	lui	a5,0xc000
    80005ea4:	4705                	li	a4,1
    80005ea6:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80005ea8:	c3d8                	sw	a4,4(a5)
}
    80005eaa:	6422                	ld	s0,8(sp)
    80005eac:	0141                	addi	sp,sp,16
    80005eae:	8082                	ret

0000000080005eb0 <plicinithart>:

void
plicinithart(void)
{
    80005eb0:	1141                	addi	sp,sp,-16
    80005eb2:	e406                	sd	ra,8(sp)
    80005eb4:	e022                	sd	s0,0(sp)
    80005eb6:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005eb8:	ffffc097          	auipc	ra,0xffffc
    80005ebc:	d4e080e7          	jalr	-690(ra) # 80001c06 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005ec0:	0085171b          	slliw	a4,a0,0x8
    80005ec4:	0c0027b7          	lui	a5,0xc002
    80005ec8:	97ba                	add	a5,a5,a4
    80005eca:	40200713          	li	a4,1026
    80005ece:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005ed2:	00d5151b          	slliw	a0,a0,0xd
    80005ed6:	0c2017b7          	lui	a5,0xc201
    80005eda:	953e                	add	a0,a0,a5
    80005edc:	00052023          	sw	zero,0(a0)
}
    80005ee0:	60a2                	ld	ra,8(sp)
    80005ee2:	6402                	ld	s0,0(sp)
    80005ee4:	0141                	addi	sp,sp,16
    80005ee6:	8082                	ret

0000000080005ee8 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005ee8:	1141                	addi	sp,sp,-16
    80005eea:	e406                	sd	ra,8(sp)
    80005eec:	e022                	sd	s0,0(sp)
    80005eee:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005ef0:	ffffc097          	auipc	ra,0xffffc
    80005ef4:	d16080e7          	jalr	-746(ra) # 80001c06 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005ef8:	00d5179b          	slliw	a5,a0,0xd
    80005efc:	0c201537          	lui	a0,0xc201
    80005f00:	953e                	add	a0,a0,a5
  return irq;
}
    80005f02:	4148                	lw	a0,4(a0)
    80005f04:	60a2                	ld	ra,8(sp)
    80005f06:	6402                	ld	s0,0(sp)
    80005f08:	0141                	addi	sp,sp,16
    80005f0a:	8082                	ret

0000000080005f0c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005f0c:	1101                	addi	sp,sp,-32
    80005f0e:	ec06                	sd	ra,24(sp)
    80005f10:	e822                	sd	s0,16(sp)
    80005f12:	e426                	sd	s1,8(sp)
    80005f14:	1000                	addi	s0,sp,32
    80005f16:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005f18:	ffffc097          	auipc	ra,0xffffc
    80005f1c:	cee080e7          	jalr	-786(ra) # 80001c06 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005f20:	00d5151b          	slliw	a0,a0,0xd
    80005f24:	0c2017b7          	lui	a5,0xc201
    80005f28:	97aa                	add	a5,a5,a0
    80005f2a:	c3c4                	sw	s1,4(a5)
}
    80005f2c:	60e2                	ld	ra,24(sp)
    80005f2e:	6442                	ld	s0,16(sp)
    80005f30:	64a2                	ld	s1,8(sp)
    80005f32:	6105                	addi	sp,sp,32
    80005f34:	8082                	ret

0000000080005f36 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005f36:	1141                	addi	sp,sp,-16
    80005f38:	e406                	sd	ra,8(sp)
    80005f3a:	e022                	sd	s0,0(sp)
    80005f3c:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80005f3e:	479d                	li	a5,7
    80005f40:	04a7cc63          	blt	a5,a0,80005f98 <free_desc+0x62>
    panic("free_desc 1");
  if(disk.free[i])
    80005f44:	0023c797          	auipc	a5,0x23c
    80005f48:	d2478793          	addi	a5,a5,-732 # 80241c68 <disk>
    80005f4c:	97aa                	add	a5,a5,a0
    80005f4e:	0187c783          	lbu	a5,24(a5)
    80005f52:	ebb9                	bnez	a5,80005fa8 <free_desc+0x72>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005f54:	00451613          	slli	a2,a0,0x4
    80005f58:	0023c797          	auipc	a5,0x23c
    80005f5c:	d1078793          	addi	a5,a5,-752 # 80241c68 <disk>
    80005f60:	6394                	ld	a3,0(a5)
    80005f62:	96b2                	add	a3,a3,a2
    80005f64:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    80005f68:	6398                	ld	a4,0(a5)
    80005f6a:	9732                	add	a4,a4,a2
    80005f6c:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005f70:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005f74:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005f78:	953e                	add	a0,a0,a5
    80005f7a:	4785                	li	a5,1
    80005f7c:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    80005f80:	0023c517          	auipc	a0,0x23c
    80005f84:	d0050513          	addi	a0,a0,-768 # 80241c80 <disk+0x18>
    80005f88:	ffffc097          	auipc	ra,0xffffc
    80005f8c:	3ba080e7          	jalr	954(ra) # 80002342 <wakeup>
}
    80005f90:	60a2                	ld	ra,8(sp)
    80005f92:	6402                	ld	s0,0(sp)
    80005f94:	0141                	addi	sp,sp,16
    80005f96:	8082                	ret
    panic("free_desc 1");
    80005f98:	00002517          	auipc	a0,0x2
    80005f9c:	7f050513          	addi	a0,a0,2032 # 80008788 <syscalls+0x2f0>
    80005fa0:	ffffa097          	auipc	ra,0xffffa
    80005fa4:	59e080e7          	jalr	1438(ra) # 8000053e <panic>
    panic("free_desc 2");
    80005fa8:	00002517          	auipc	a0,0x2
    80005fac:	7f050513          	addi	a0,a0,2032 # 80008798 <syscalls+0x300>
    80005fb0:	ffffa097          	auipc	ra,0xffffa
    80005fb4:	58e080e7          	jalr	1422(ra) # 8000053e <panic>

0000000080005fb8 <virtio_disk_init>:
{
    80005fb8:	1101                	addi	sp,sp,-32
    80005fba:	ec06                	sd	ra,24(sp)
    80005fbc:	e822                	sd	s0,16(sp)
    80005fbe:	e426                	sd	s1,8(sp)
    80005fc0:	e04a                	sd	s2,0(sp)
    80005fc2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005fc4:	00002597          	auipc	a1,0x2
    80005fc8:	7e458593          	addi	a1,a1,2020 # 800087a8 <syscalls+0x310>
    80005fcc:	0023c517          	auipc	a0,0x23c
    80005fd0:	dc450513          	addi	a0,a0,-572 # 80241d90 <disk+0x128>
    80005fd4:	ffffb097          	auipc	ra,0xffffb
    80005fd8:	ccc080e7          	jalr	-820(ra) # 80000ca0 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005fdc:	100017b7          	lui	a5,0x10001
    80005fe0:	4398                	lw	a4,0(a5)
    80005fe2:	2701                	sext.w	a4,a4
    80005fe4:	747277b7          	lui	a5,0x74727
    80005fe8:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005fec:	14f71c63          	bne	a4,a5,80006144 <virtio_disk_init+0x18c>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005ff0:	100017b7          	lui	a5,0x10001
    80005ff4:	43dc                	lw	a5,4(a5)
    80005ff6:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005ff8:	4709                	li	a4,2
    80005ffa:	14e79563          	bne	a5,a4,80006144 <virtio_disk_init+0x18c>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005ffe:	100017b7          	lui	a5,0x10001
    80006002:	479c                	lw	a5,8(a5)
    80006004:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80006006:	12e79f63          	bne	a5,a4,80006144 <virtio_disk_init+0x18c>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    8000600a:	100017b7          	lui	a5,0x10001
    8000600e:	47d8                	lw	a4,12(a5)
    80006010:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80006012:	554d47b7          	lui	a5,0x554d4
    80006016:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    8000601a:	12f71563          	bne	a4,a5,80006144 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000601e:	100017b7          	lui	a5,0x10001
    80006022:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80006026:	4705                	li	a4,1
    80006028:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000602a:	470d                	li	a4,3
    8000602c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000602e:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80006030:	c7ffe737          	lui	a4,0xc7ffe
    80006034:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47dbc9b7>
    80006038:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000603a:	2701                	sext.w	a4,a4
    8000603c:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000603e:	472d                	li	a4,11
    80006040:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    80006042:	5bbc                	lw	a5,112(a5)
    80006044:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80006048:	8ba1                	andi	a5,a5,8
    8000604a:	10078563          	beqz	a5,80006154 <virtio_disk_init+0x19c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000604e:	100017b7          	lui	a5,0x10001
    80006052:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80006056:	43fc                	lw	a5,68(a5)
    80006058:	2781                	sext.w	a5,a5
    8000605a:	10079563          	bnez	a5,80006164 <virtio_disk_init+0x1ac>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    8000605e:	100017b7          	lui	a5,0x10001
    80006062:	5bdc                	lw	a5,52(a5)
    80006064:	2781                	sext.w	a5,a5
  if(max == 0)
    80006066:	10078763          	beqz	a5,80006174 <virtio_disk_init+0x1bc>
  if(max < NUM)
    8000606a:	471d                	li	a4,7
    8000606c:	10f77c63          	bgeu	a4,a5,80006184 <virtio_disk_init+0x1cc>
  disk.desc = kalloc();
    80006070:	ffffb097          	auipc	ra,0xffffb
    80006074:	ba2080e7          	jalr	-1118(ra) # 80000c12 <kalloc>
    80006078:	0023c497          	auipc	s1,0x23c
    8000607c:	bf048493          	addi	s1,s1,-1040 # 80241c68 <disk>
    80006080:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80006082:	ffffb097          	auipc	ra,0xffffb
    80006086:	b90080e7          	jalr	-1136(ra) # 80000c12 <kalloc>
    8000608a:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000608c:	ffffb097          	auipc	ra,0xffffb
    80006090:	b86080e7          	jalr	-1146(ra) # 80000c12 <kalloc>
    80006094:	87aa                	mv	a5,a0
    80006096:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80006098:	6088                	ld	a0,0(s1)
    8000609a:	cd6d                	beqz	a0,80006194 <virtio_disk_init+0x1dc>
    8000609c:	0023c717          	auipc	a4,0x23c
    800060a0:	bd473703          	ld	a4,-1068(a4) # 80241c70 <disk+0x8>
    800060a4:	cb65                	beqz	a4,80006194 <virtio_disk_init+0x1dc>
    800060a6:	c7fd                	beqz	a5,80006194 <virtio_disk_init+0x1dc>
  memset(disk.desc, 0, PGSIZE);
    800060a8:	6605                	lui	a2,0x1
    800060aa:	4581                	li	a1,0
    800060ac:	ffffb097          	auipc	ra,0xffffb
    800060b0:	d80080e7          	jalr	-640(ra) # 80000e2c <memset>
  memset(disk.avail, 0, PGSIZE);
    800060b4:	0023c497          	auipc	s1,0x23c
    800060b8:	bb448493          	addi	s1,s1,-1100 # 80241c68 <disk>
    800060bc:	6605                	lui	a2,0x1
    800060be:	4581                	li	a1,0
    800060c0:	6488                	ld	a0,8(s1)
    800060c2:	ffffb097          	auipc	ra,0xffffb
    800060c6:	d6a080e7          	jalr	-662(ra) # 80000e2c <memset>
  memset(disk.used, 0, PGSIZE);
    800060ca:	6605                	lui	a2,0x1
    800060cc:	4581                	li	a1,0
    800060ce:	6888                	ld	a0,16(s1)
    800060d0:	ffffb097          	auipc	ra,0xffffb
    800060d4:	d5c080e7          	jalr	-676(ra) # 80000e2c <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800060d8:	100017b7          	lui	a5,0x10001
    800060dc:	4721                	li	a4,8
    800060de:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800060e0:	4098                	lw	a4,0(s1)
    800060e2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800060e6:	40d8                	lw	a4,4(s1)
    800060e8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800060ec:	6498                	ld	a4,8(s1)
    800060ee:	0007069b          	sext.w	a3,a4
    800060f2:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800060f6:	9701                	srai	a4,a4,0x20
    800060f8:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800060fc:	6898                	ld	a4,16(s1)
    800060fe:	0007069b          	sext.w	a3,a4
    80006102:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80006106:	9701                	srai	a4,a4,0x20
    80006108:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    8000610c:	4705                	li	a4,1
    8000610e:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80006110:	00e48c23          	sb	a4,24(s1)
    80006114:	00e48ca3          	sb	a4,25(s1)
    80006118:	00e48d23          	sb	a4,26(s1)
    8000611c:	00e48da3          	sb	a4,27(s1)
    80006120:	00e48e23          	sb	a4,28(s1)
    80006124:	00e48ea3          	sb	a4,29(s1)
    80006128:	00e48f23          	sb	a4,30(s1)
    8000612c:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80006130:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80006134:	0727a823          	sw	s2,112(a5)
}
    80006138:	60e2                	ld	ra,24(sp)
    8000613a:	6442                	ld	s0,16(sp)
    8000613c:	64a2                	ld	s1,8(sp)
    8000613e:	6902                	ld	s2,0(sp)
    80006140:	6105                	addi	sp,sp,32
    80006142:	8082                	ret
    panic("could not find virtio disk");
    80006144:	00002517          	auipc	a0,0x2
    80006148:	67450513          	addi	a0,a0,1652 # 800087b8 <syscalls+0x320>
    8000614c:	ffffa097          	auipc	ra,0xffffa
    80006150:	3f2080e7          	jalr	1010(ra) # 8000053e <panic>
    panic("virtio disk FEATURES_OK unset");
    80006154:	00002517          	auipc	a0,0x2
    80006158:	68450513          	addi	a0,a0,1668 # 800087d8 <syscalls+0x340>
    8000615c:	ffffa097          	auipc	ra,0xffffa
    80006160:	3e2080e7          	jalr	994(ra) # 8000053e <panic>
    panic("virtio disk should not be ready");
    80006164:	00002517          	auipc	a0,0x2
    80006168:	69450513          	addi	a0,a0,1684 # 800087f8 <syscalls+0x360>
    8000616c:	ffffa097          	auipc	ra,0xffffa
    80006170:	3d2080e7          	jalr	978(ra) # 8000053e <panic>
    panic("virtio disk has no queue 0");
    80006174:	00002517          	auipc	a0,0x2
    80006178:	6a450513          	addi	a0,a0,1700 # 80008818 <syscalls+0x380>
    8000617c:	ffffa097          	auipc	ra,0xffffa
    80006180:	3c2080e7          	jalr	962(ra) # 8000053e <panic>
    panic("virtio disk max queue too short");
    80006184:	00002517          	auipc	a0,0x2
    80006188:	6b450513          	addi	a0,a0,1716 # 80008838 <syscalls+0x3a0>
    8000618c:	ffffa097          	auipc	ra,0xffffa
    80006190:	3b2080e7          	jalr	946(ra) # 8000053e <panic>
    panic("virtio disk kalloc");
    80006194:	00002517          	auipc	a0,0x2
    80006198:	6c450513          	addi	a0,a0,1732 # 80008858 <syscalls+0x3c0>
    8000619c:	ffffa097          	auipc	ra,0xffffa
    800061a0:	3a2080e7          	jalr	930(ra) # 8000053e <panic>

00000000800061a4 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800061a4:	7119                	addi	sp,sp,-128
    800061a6:	fc86                	sd	ra,120(sp)
    800061a8:	f8a2                	sd	s0,112(sp)
    800061aa:	f4a6                	sd	s1,104(sp)
    800061ac:	f0ca                	sd	s2,96(sp)
    800061ae:	ecce                	sd	s3,88(sp)
    800061b0:	e8d2                	sd	s4,80(sp)
    800061b2:	e4d6                	sd	s5,72(sp)
    800061b4:	e0da                	sd	s6,64(sp)
    800061b6:	fc5e                	sd	s7,56(sp)
    800061b8:	f862                	sd	s8,48(sp)
    800061ba:	f466                	sd	s9,40(sp)
    800061bc:	f06a                	sd	s10,32(sp)
    800061be:	ec6e                	sd	s11,24(sp)
    800061c0:	0100                	addi	s0,sp,128
    800061c2:	8aaa                	mv	s5,a0
    800061c4:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800061c6:	00c52d03          	lw	s10,12(a0)
    800061ca:	001d1d1b          	slliw	s10,s10,0x1
    800061ce:	1d02                	slli	s10,s10,0x20
    800061d0:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    800061d4:	0023c517          	auipc	a0,0x23c
    800061d8:	bbc50513          	addi	a0,a0,-1092 # 80241d90 <disk+0x128>
    800061dc:	ffffb097          	auipc	ra,0xffffb
    800061e0:	b54080e7          	jalr	-1196(ra) # 80000d30 <acquire>
  for(int i = 0; i < 3; i++){
    800061e4:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    800061e6:	44a1                	li	s1,8
      disk.free[i] = 0;
    800061e8:	0023cb97          	auipc	s7,0x23c
    800061ec:	a80b8b93          	addi	s7,s7,-1408 # 80241c68 <disk>
  for(int i = 0; i < 3; i++){
    800061f0:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800061f2:	0023cc97          	auipc	s9,0x23c
    800061f6:	b9ec8c93          	addi	s9,s9,-1122 # 80241d90 <disk+0x128>
    800061fa:	a08d                	j	8000625c <virtio_disk_rw+0xb8>
      disk.free[i] = 0;
    800061fc:	00fb8733          	add	a4,s7,a5
    80006200:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80006204:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80006206:	0207c563          	bltz	a5,80006230 <virtio_disk_rw+0x8c>
  for(int i = 0; i < 3; i++){
    8000620a:	2905                	addiw	s2,s2,1
    8000620c:	0611                	addi	a2,a2,4
    8000620e:	05690c63          	beq	s2,s6,80006266 <virtio_disk_rw+0xc2>
    idx[i] = alloc_desc();
    80006212:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80006214:	0023c717          	auipc	a4,0x23c
    80006218:	a5470713          	addi	a4,a4,-1452 # 80241c68 <disk>
    8000621c:	87ce                	mv	a5,s3
    if(disk.free[i]){
    8000621e:	01874683          	lbu	a3,24(a4)
    80006222:	fee9                	bnez	a3,800061fc <virtio_disk_rw+0x58>
  for(int i = 0; i < NUM; i++){
    80006224:	2785                	addiw	a5,a5,1
    80006226:	0705                	addi	a4,a4,1
    80006228:	fe979be3          	bne	a5,s1,8000621e <virtio_disk_rw+0x7a>
    idx[i] = alloc_desc();
    8000622c:	57fd                	li	a5,-1
    8000622e:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80006230:	01205d63          	blez	s2,8000624a <virtio_disk_rw+0xa6>
    80006234:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    80006236:	000a2503          	lw	a0,0(s4)
    8000623a:	00000097          	auipc	ra,0x0
    8000623e:	cfc080e7          	jalr	-772(ra) # 80005f36 <free_desc>
      for(int j = 0; j < i; j++)
    80006242:	2d85                	addiw	s11,s11,1
    80006244:	0a11                	addi	s4,s4,4
    80006246:	ffb918e3          	bne	s2,s11,80006236 <virtio_disk_rw+0x92>
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000624a:	85e6                	mv	a1,s9
    8000624c:	0023c517          	auipc	a0,0x23c
    80006250:	a3450513          	addi	a0,a0,-1484 # 80241c80 <disk+0x18>
    80006254:	ffffc097          	auipc	ra,0xffffc
    80006258:	08a080e7          	jalr	138(ra) # 800022de <sleep>
  for(int i = 0; i < 3; i++){
    8000625c:	f8040a13          	addi	s4,s0,-128
{
    80006260:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    80006262:	894e                	mv	s2,s3
    80006264:	b77d                	j	80006212 <virtio_disk_rw+0x6e>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80006266:	f8042583          	lw	a1,-128(s0)
    8000626a:	00a58793          	addi	a5,a1,10
    8000626e:	0792                	slli	a5,a5,0x4

  if(write)
    80006270:	0023c617          	auipc	a2,0x23c
    80006274:	9f860613          	addi	a2,a2,-1544 # 80241c68 <disk>
    80006278:	00f60733          	add	a4,a2,a5
    8000627c:	018036b3          	snez	a3,s8
    80006280:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80006282:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80006286:	01a73823          	sd	s10,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    8000628a:	f6078693          	addi	a3,a5,-160
    8000628e:	6218                	ld	a4,0(a2)
    80006290:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80006292:	00878513          	addi	a0,a5,8
    80006296:	9532                	add	a0,a0,a2
  disk.desc[idx[0]].addr = (uint64) buf0;
    80006298:	e308                	sd	a0,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    8000629a:	6208                	ld	a0,0(a2)
    8000629c:	96aa                	add	a3,a3,a0
    8000629e:	4741                	li	a4,16
    800062a0:	c698                	sw	a4,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800062a2:	4705                	li	a4,1
    800062a4:	00e69623          	sh	a4,12(a3)
  disk.desc[idx[0]].next = idx[1];
    800062a8:	f8442703          	lw	a4,-124(s0)
    800062ac:	00e69723          	sh	a4,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800062b0:	0712                	slli	a4,a4,0x4
    800062b2:	953a                	add	a0,a0,a4
    800062b4:	058a8693          	addi	a3,s5,88
    800062b8:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    800062ba:	6208                	ld	a0,0(a2)
    800062bc:	972a                	add	a4,a4,a0
    800062be:	40000693          	li	a3,1024
    800062c2:	c714                	sw	a3,8(a4)
  if(write)
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    800062c4:	001c3c13          	seqz	s8,s8
    800062c8:	0c06                	slli	s8,s8,0x1
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800062ca:	001c6c13          	ori	s8,s8,1
    800062ce:	01871623          	sh	s8,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800062d2:	f8842603          	lw	a2,-120(s0)
    800062d6:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800062da:	0023c697          	auipc	a3,0x23c
    800062de:	98e68693          	addi	a3,a3,-1650 # 80241c68 <disk>
    800062e2:	00258713          	addi	a4,a1,2
    800062e6:	0712                	slli	a4,a4,0x4
    800062e8:	9736                	add	a4,a4,a3
    800062ea:	587d                	li	a6,-1
    800062ec:	01070823          	sb	a6,16(a4)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800062f0:	0612                	slli	a2,a2,0x4
    800062f2:	9532                	add	a0,a0,a2
    800062f4:	f9078793          	addi	a5,a5,-112
    800062f8:	97b6                	add	a5,a5,a3
    800062fa:	e11c                	sd	a5,0(a0)
  disk.desc[idx[2]].len = 1;
    800062fc:	629c                	ld	a5,0(a3)
    800062fe:	97b2                	add	a5,a5,a2
    80006300:	4605                	li	a2,1
    80006302:	c790                	sw	a2,8(a5)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80006304:	4509                	li	a0,2
    80006306:	00a79623          	sh	a0,12(a5)
  disk.desc[idx[2]].next = 0;
    8000630a:	00079723          	sh	zero,14(a5)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000630e:	00caa223          	sw	a2,4(s5)
  disk.info[idx[0]].b = b;
    80006312:	01573423          	sd	s5,8(a4)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80006316:	6698                	ld	a4,8(a3)
    80006318:	00275783          	lhu	a5,2(a4)
    8000631c:	8b9d                	andi	a5,a5,7
    8000631e:	0786                	slli	a5,a5,0x1
    80006320:	97ba                	add	a5,a5,a4
    80006322:	00b79223          	sh	a1,4(a5)

  __sync_synchronize();
    80006326:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    8000632a:	6698                	ld	a4,8(a3)
    8000632c:	00275783          	lhu	a5,2(a4)
    80006330:	2785                	addiw	a5,a5,1
    80006332:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80006336:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    8000633a:	100017b7          	lui	a5,0x10001
    8000633e:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80006342:	004aa783          	lw	a5,4(s5)
    80006346:	02c79163          	bne	a5,a2,80006368 <virtio_disk_rw+0x1c4>
    sleep(b, &disk.vdisk_lock);
    8000634a:	0023c917          	auipc	s2,0x23c
    8000634e:	a4690913          	addi	s2,s2,-1466 # 80241d90 <disk+0x128>
  while(b->disk == 1) {
    80006352:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80006354:	85ca                	mv	a1,s2
    80006356:	8556                	mv	a0,s5
    80006358:	ffffc097          	auipc	ra,0xffffc
    8000635c:	f86080e7          	jalr	-122(ra) # 800022de <sleep>
  while(b->disk == 1) {
    80006360:	004aa783          	lw	a5,4(s5)
    80006364:	fe9788e3          	beq	a5,s1,80006354 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    80006368:	f8042903          	lw	s2,-128(s0)
    8000636c:	00290793          	addi	a5,s2,2
    80006370:	00479713          	slli	a4,a5,0x4
    80006374:	0023c797          	auipc	a5,0x23c
    80006378:	8f478793          	addi	a5,a5,-1804 # 80241c68 <disk>
    8000637c:	97ba                	add	a5,a5,a4
    8000637e:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80006382:	0023c997          	auipc	s3,0x23c
    80006386:	8e698993          	addi	s3,s3,-1818 # 80241c68 <disk>
    8000638a:	00491713          	slli	a4,s2,0x4
    8000638e:	0009b783          	ld	a5,0(s3)
    80006392:	97ba                	add	a5,a5,a4
    80006394:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80006398:	854a                	mv	a0,s2
    8000639a:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    8000639e:	00000097          	auipc	ra,0x0
    800063a2:	b98080e7          	jalr	-1128(ra) # 80005f36 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800063a6:	8885                	andi	s1,s1,1
    800063a8:	f0ed                	bnez	s1,8000638a <virtio_disk_rw+0x1e6>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800063aa:	0023c517          	auipc	a0,0x23c
    800063ae:	9e650513          	addi	a0,a0,-1562 # 80241d90 <disk+0x128>
    800063b2:	ffffb097          	auipc	ra,0xffffb
    800063b6:	a32080e7          	jalr	-1486(ra) # 80000de4 <release>
}
    800063ba:	70e6                	ld	ra,120(sp)
    800063bc:	7446                	ld	s0,112(sp)
    800063be:	74a6                	ld	s1,104(sp)
    800063c0:	7906                	ld	s2,96(sp)
    800063c2:	69e6                	ld	s3,88(sp)
    800063c4:	6a46                	ld	s4,80(sp)
    800063c6:	6aa6                	ld	s5,72(sp)
    800063c8:	6b06                	ld	s6,64(sp)
    800063ca:	7be2                	ld	s7,56(sp)
    800063cc:	7c42                	ld	s8,48(sp)
    800063ce:	7ca2                	ld	s9,40(sp)
    800063d0:	7d02                	ld	s10,32(sp)
    800063d2:	6de2                	ld	s11,24(sp)
    800063d4:	6109                	addi	sp,sp,128
    800063d6:	8082                	ret

00000000800063d8 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    800063d8:	1101                	addi	sp,sp,-32
    800063da:	ec06                	sd	ra,24(sp)
    800063dc:	e822                	sd	s0,16(sp)
    800063de:	e426                	sd	s1,8(sp)
    800063e0:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800063e2:	0023c497          	auipc	s1,0x23c
    800063e6:	88648493          	addi	s1,s1,-1914 # 80241c68 <disk>
    800063ea:	0023c517          	auipc	a0,0x23c
    800063ee:	9a650513          	addi	a0,a0,-1626 # 80241d90 <disk+0x128>
    800063f2:	ffffb097          	auipc	ra,0xffffb
    800063f6:	93e080e7          	jalr	-1730(ra) # 80000d30 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800063fa:	10001737          	lui	a4,0x10001
    800063fe:	533c                	lw	a5,96(a4)
    80006400:	8b8d                	andi	a5,a5,3
    80006402:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80006404:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80006408:	689c                	ld	a5,16(s1)
    8000640a:	0204d703          	lhu	a4,32(s1)
    8000640e:	0027d783          	lhu	a5,2(a5)
    80006412:	04f70863          	beq	a4,a5,80006462 <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80006416:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    8000641a:	6898                	ld	a4,16(s1)
    8000641c:	0204d783          	lhu	a5,32(s1)
    80006420:	8b9d                	andi	a5,a5,7
    80006422:	078e                	slli	a5,a5,0x3
    80006424:	97ba                	add	a5,a5,a4
    80006426:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80006428:	00278713          	addi	a4,a5,2
    8000642c:	0712                	slli	a4,a4,0x4
    8000642e:	9726                	add	a4,a4,s1
    80006430:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80006434:	e721                	bnez	a4,8000647c <virtio_disk_intr+0xa4>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80006436:	0789                	addi	a5,a5,2
    80006438:	0792                	slli	a5,a5,0x4
    8000643a:	97a6                	add	a5,a5,s1
    8000643c:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    8000643e:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80006442:	ffffc097          	auipc	ra,0xffffc
    80006446:	f00080e7          	jalr	-256(ra) # 80002342 <wakeup>

    disk.used_idx += 1;
    8000644a:	0204d783          	lhu	a5,32(s1)
    8000644e:	2785                	addiw	a5,a5,1
    80006450:	17c2                	slli	a5,a5,0x30
    80006452:	93c1                	srli	a5,a5,0x30
    80006454:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80006458:	6898                	ld	a4,16(s1)
    8000645a:	00275703          	lhu	a4,2(a4)
    8000645e:	faf71ce3          	bne	a4,a5,80006416 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80006462:	0023c517          	auipc	a0,0x23c
    80006466:	92e50513          	addi	a0,a0,-1746 # 80241d90 <disk+0x128>
    8000646a:	ffffb097          	auipc	ra,0xffffb
    8000646e:	97a080e7          	jalr	-1670(ra) # 80000de4 <release>
}
    80006472:	60e2                	ld	ra,24(sp)
    80006474:	6442                	ld	s0,16(sp)
    80006476:	64a2                	ld	s1,8(sp)
    80006478:	6105                	addi	sp,sp,32
    8000647a:	8082                	ret
      panic("virtio_disk_intr status");
    8000647c:	00002517          	auipc	a0,0x2
    80006480:	3f450513          	addi	a0,a0,1012 # 80008870 <syscalls+0x3d8>
    80006484:	ffffa097          	auipc	ra,0xffffa
    80006488:	0ba080e7          	jalr	186(ra) # 8000053e <panic>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
