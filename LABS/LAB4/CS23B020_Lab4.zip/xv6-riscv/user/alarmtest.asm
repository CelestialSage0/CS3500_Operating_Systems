
user/_alarmtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <periodic>:

volatile static int count;

void
periodic()
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  count = count + 1;
   8:	00001797          	auipc	a5,0x1
   c:	ff87a783          	lw	a5,-8(a5) # 1000 <count>
  10:	2785                	addiw	a5,a5,1
  12:	00001717          	auipc	a4,0x1
  16:	fef72723          	sw	a5,-18(a4) # 1000 <count>
  printf("alarm!\n");
  1a:	00001517          	auipc	a0,0x1
  1e:	bf650513          	addi	a0,a0,-1034 # c10 <malloc+0xec>
  22:	249000ef          	jal	ra,a6a <printf>
  sigreturn();
  26:	6b6000ef          	jal	ra,6dc <sigreturn>
}
  2a:	60a2                	ld	ra,8(sp)
  2c:	6402                	ld	s0,0(sp)
  2e:	0141                	addi	sp,sp,16
  30:	8082                	ret

0000000000000032 <slow_handler>:
  }
}

void
slow_handler()
{
  32:	1101                	addi	sp,sp,-32
  34:	ec06                	sd	ra,24(sp)
  36:	e822                	sd	s0,16(sp)
  38:	e426                	sd	s1,8(sp)
  3a:	1000                	addi	s0,sp,32
  count++;
  3c:	00001497          	auipc	s1,0x1
  40:	fc448493          	addi	s1,s1,-60 # 1000 <count>
  44:	00001797          	auipc	a5,0x1
  48:	fbc7a783          	lw	a5,-68(a5) # 1000 <count>
  4c:	2785                	addiw	a5,a5,1
  4e:	c09c                	sw	a5,0(s1)
  printf("alarm!\n");
  50:	00001517          	auipc	a0,0x1
  54:	bc050513          	addi	a0,a0,-1088 # c10 <malloc+0xec>
  58:	213000ef          	jal	ra,a6a <printf>
  if (count > 1) {
  5c:	4098                	lw	a4,0(s1)
  5e:	2701                	sext.w	a4,a4
  60:	4685                	li	a3,1
  62:	1dcd67b7          	lui	a5,0x1dcd6
  66:	50078793          	addi	a5,a5,1280 # 1dcd6500 <base+0x1dcd54f0>
  6a:	02e6c063          	blt	a3,a4,8a <slow_handler+0x58>
    printf("test2 failed: alarm handler called more than once\n");
    exit(1);
  }
  for (int i = 0; i < 1000*500000; i++) {
    asm volatile("nop"); // avoid compiler optimizing away loop
  6e:	0001                	nop
  for (int i = 0; i < 1000*500000; i++) {
  70:	37fd                	addiw	a5,a5,-1
  72:	fff5                	bnez	a5,6e <slow_handler+0x3c>
  }
  sigalarm(0, 0);
  74:	4581                	li	a1,0
  76:	4501                	li	a0,0
  78:	65c000ef          	jal	ra,6d4 <sigalarm>
  sigreturn();
  7c:	660000ef          	jal	ra,6dc <sigreturn>
}
  80:	60e2                	ld	ra,24(sp)
  82:	6442                	ld	s0,16(sp)
  84:	64a2                	ld	s1,8(sp)
  86:	6105                	addi	sp,sp,32
  88:	8082                	ret
    printf("test2 failed: alarm handler called more than once\n");
  8a:	00001517          	auipc	a0,0x1
  8e:	b8e50513          	addi	a0,a0,-1138 # c18 <malloc+0xf4>
  92:	1d9000ef          	jal	ra,a6a <printf>
    exit(1);
  96:	4505                	li	a0,1
  98:	594000ef          	jal	ra,62c <exit>

000000000000009c <dummy_handler>:
//
// dummy alarm handler; after running immediately uninstall
// itself and finish signal handling
void
dummy_handler()
{
  9c:	1141                	addi	sp,sp,-16
  9e:	e406                	sd	ra,8(sp)
  a0:	e022                	sd	s0,0(sp)
  a2:	0800                	addi	s0,sp,16
  sigalarm(0, 0);
  a4:	4581                	li	a1,0
  a6:	4501                	li	a0,0
  a8:	62c000ef          	jal	ra,6d4 <sigalarm>
  sigreturn();
  ac:	630000ef          	jal	ra,6dc <sigreturn>
}
  b0:	60a2                	ld	ra,8(sp)
  b2:	6402                	ld	s0,0(sp)
  b4:	0141                	addi	sp,sp,16
  b6:	8082                	ret

00000000000000b8 <test0>:
{
  b8:	7139                	addi	sp,sp,-64
  ba:	fc06                	sd	ra,56(sp)
  bc:	f822                	sd	s0,48(sp)
  be:	f426                	sd	s1,40(sp)
  c0:	f04a                	sd	s2,32(sp)
  c2:	ec4e                	sd	s3,24(sp)
  c4:	e852                	sd	s4,16(sp)
  c6:	e456                	sd	s5,8(sp)
  c8:	0080                	addi	s0,sp,64
  printf("test0 start\n");
  ca:	00001517          	auipc	a0,0x1
  ce:	b8650513          	addi	a0,a0,-1146 # c50 <malloc+0x12c>
  d2:	199000ef          	jal	ra,a6a <printf>
  count = 0;
  d6:	00001797          	auipc	a5,0x1
  da:	f207a523          	sw	zero,-214(a5) # 1000 <count>
  sigalarm(2, periodic);
  de:	00000597          	auipc	a1,0x0
  e2:	f2258593          	addi	a1,a1,-222 # 0 <periodic>
  e6:	4509                	li	a0,2
  e8:	5ec000ef          	jal	ra,6d4 <sigalarm>
  for(i = 0; i < 1000*500000; i++){
  ec:	4481                	li	s1,0
    if((i % 1000000) == 0)
  ee:	000f4937          	lui	s2,0xf4
  f2:	2409091b          	addiw	s2,s2,576
      write(2, ".", 1);
  f6:	00001a97          	auipc	s5,0x1
  fa:	b6aa8a93          	addi	s5,s5,-1174 # c60 <malloc+0x13c>
    if(count > 0)
  fe:	00001a17          	auipc	s4,0x1
 102:	f02a0a13          	addi	s4,s4,-254 # 1000 <count>
  for(i = 0; i < 1000*500000; i++){
 106:	1dcd69b7          	lui	s3,0x1dcd6
 10a:	50098993          	addi	s3,s3,1280 # 1dcd6500 <base+0x1dcd54f0>
 10e:	a809                	j	120 <test0+0x68>
    if(count > 0)
 110:	000a2783          	lw	a5,0(s4)
 114:	2781                	sext.w	a5,a5
 116:	00f04e63          	bgtz	a5,132 <test0+0x7a>
  for(i = 0; i < 1000*500000; i++){
 11a:	2485                	addiw	s1,s1,1
 11c:	01348b63          	beq	s1,s3,132 <test0+0x7a>
    if((i % 1000000) == 0)
 120:	0324e7bb          	remw	a5,s1,s2
 124:	f7f5                	bnez	a5,110 <test0+0x58>
      write(2, ".", 1);
 126:	4605                	li	a2,1
 128:	85d6                	mv	a1,s5
 12a:	4509                	li	a0,2
 12c:	520000ef          	jal	ra,64c <write>
 130:	b7c5                	j	110 <test0+0x58>
  sigalarm(0, 0);
 132:	4581                	li	a1,0
 134:	4501                	li	a0,0
 136:	59e000ef          	jal	ra,6d4 <sigalarm>
  if(count > 0){
 13a:	00001797          	auipc	a5,0x1
 13e:	ec67a783          	lw	a5,-314(a5) # 1000 <count>
 142:	02f05163          	blez	a5,164 <test0+0xac>
    printf("test0 passed\n");
 146:	00001517          	auipc	a0,0x1
 14a:	b2250513          	addi	a0,a0,-1246 # c68 <malloc+0x144>
 14e:	11d000ef          	jal	ra,a6a <printf>
}
 152:	70e2                	ld	ra,56(sp)
 154:	7442                	ld	s0,48(sp)
 156:	74a2                	ld	s1,40(sp)
 158:	7902                	ld	s2,32(sp)
 15a:	69e2                	ld	s3,24(sp)
 15c:	6a42                	ld	s4,16(sp)
 15e:	6aa2                	ld	s5,8(sp)
 160:	6121                	addi	sp,sp,64
 162:	8082                	ret
    printf("\ntest0 failed: the kernel never called the alarm handler\n");
 164:	00001517          	auipc	a0,0x1
 168:	b1450513          	addi	a0,a0,-1260 # c78 <malloc+0x154>
 16c:	0ff000ef          	jal	ra,a6a <printf>
}
 170:	b7cd                	j	152 <test0+0x9a>

0000000000000172 <foo>:
void __attribute__ ((noinline)) foo(int i, int *j) {
 172:	1101                	addi	sp,sp,-32
 174:	ec06                	sd	ra,24(sp)
 176:	e822                	sd	s0,16(sp)
 178:	e426                	sd	s1,8(sp)
 17a:	1000                	addi	s0,sp,32
 17c:	84ae                	mv	s1,a1
  if((i % 2500000) == 0) {
 17e:	002627b7          	lui	a5,0x262
 182:	5a07879b          	addiw	a5,a5,1440
 186:	02f5653b          	remw	a0,a0,a5
 18a:	c909                	beqz	a0,19c <foo+0x2a>
  *j += 1;
 18c:	409c                	lw	a5,0(s1)
 18e:	2785                	addiw	a5,a5,1
 190:	c09c                	sw	a5,0(s1)
}
 192:	60e2                	ld	ra,24(sp)
 194:	6442                	ld	s0,16(sp)
 196:	64a2                	ld	s1,8(sp)
 198:	6105                	addi	sp,sp,32
 19a:	8082                	ret
    write(2, ".", 1);
 19c:	4605                	li	a2,1
 19e:	00001597          	auipc	a1,0x1
 1a2:	ac258593          	addi	a1,a1,-1342 # c60 <malloc+0x13c>
 1a6:	4509                	li	a0,2
 1a8:	4a4000ef          	jal	ra,64c <write>
 1ac:	b7c5                	j	18c <foo+0x1a>

00000000000001ae <test1>:
{
 1ae:	7139                	addi	sp,sp,-64
 1b0:	fc06                	sd	ra,56(sp)
 1b2:	f822                	sd	s0,48(sp)
 1b4:	f426                	sd	s1,40(sp)
 1b6:	f04a                	sd	s2,32(sp)
 1b8:	ec4e                	sd	s3,24(sp)
 1ba:	e852                	sd	s4,16(sp)
 1bc:	0080                	addi	s0,sp,64
  printf("test1 start\n");
 1be:	00001517          	auipc	a0,0x1
 1c2:	afa50513          	addi	a0,a0,-1286 # cb8 <malloc+0x194>
 1c6:	0a5000ef          	jal	ra,a6a <printf>
  count = 0;
 1ca:	00001797          	auipc	a5,0x1
 1ce:	e207ab23          	sw	zero,-458(a5) # 1000 <count>
  j = 0;
 1d2:	fc042623          	sw	zero,-52(s0)
  sigalarm(2, periodic);
 1d6:	00000597          	auipc	a1,0x0
 1da:	e2a58593          	addi	a1,a1,-470 # 0 <periodic>
 1de:	4509                	li	a0,2
 1e0:	4f4000ef          	jal	ra,6d4 <sigalarm>
  for(i = 0; i < 500000000; i++){
 1e4:	4481                	li	s1,0
    if(count >= 10)
 1e6:	00001a17          	auipc	s4,0x1
 1ea:	e1aa0a13          	addi	s4,s4,-486 # 1000 <count>
 1ee:	49a5                	li	s3,9
  for(i = 0; i < 500000000; i++){
 1f0:	1dcd6937          	lui	s2,0x1dcd6
 1f4:	50090913          	addi	s2,s2,1280 # 1dcd6500 <base+0x1dcd54f0>
    if(count >= 10)
 1f8:	000a2783          	lw	a5,0(s4)
 1fc:	2781                	sext.w	a5,a5
 1fe:	00f9ca63          	blt	s3,a5,212 <test1+0x64>
    foo(i, &j);
 202:	fcc40593          	addi	a1,s0,-52
 206:	8526                	mv	a0,s1
 208:	f6bff0ef          	jal	ra,172 <foo>
  for(i = 0; i < 500000000; i++){
 20c:	2485                	addiw	s1,s1,1
 20e:	ff2495e3          	bne	s1,s2,1f8 <test1+0x4a>
  if(count < 10){
 212:	00001717          	auipc	a4,0x1
 216:	dee72703          	lw	a4,-530(a4) # 1000 <count>
 21a:	47a5                	li	a5,9
 21c:	02e7d463          	bge	a5,a4,244 <test1+0x96>
  } else if(i != j){
 220:	fcc42783          	lw	a5,-52(s0)
 224:	02978763          	beq	a5,s1,252 <test1+0xa4>
    printf("\ntest1 failed: foo() executed fewer times than it was called\n");
 228:	00001517          	auipc	a0,0x1
 22c:	ad050513          	addi	a0,a0,-1328 # cf8 <malloc+0x1d4>
 230:	03b000ef          	jal	ra,a6a <printf>
}
 234:	70e2                	ld	ra,56(sp)
 236:	7442                	ld	s0,48(sp)
 238:	74a2                	ld	s1,40(sp)
 23a:	7902                	ld	s2,32(sp)
 23c:	69e2                	ld	s3,24(sp)
 23e:	6a42                	ld	s4,16(sp)
 240:	6121                	addi	sp,sp,64
 242:	8082                	ret
    printf("\ntest1 failed: too few calls to the handler\n");
 244:	00001517          	auipc	a0,0x1
 248:	a8450513          	addi	a0,a0,-1404 # cc8 <malloc+0x1a4>
 24c:	01f000ef          	jal	ra,a6a <printf>
 250:	b7d5                	j	234 <test1+0x86>
    printf("test1 passed\n");
 252:	00001517          	auipc	a0,0x1
 256:	ae650513          	addi	a0,a0,-1306 # d38 <malloc+0x214>
 25a:	011000ef          	jal	ra,a6a <printf>
}
 25e:	bfd9                	j	234 <test1+0x86>

0000000000000260 <test2>:
{
 260:	715d                	addi	sp,sp,-80
 262:	e486                	sd	ra,72(sp)
 264:	e0a2                	sd	s0,64(sp)
 266:	fc26                	sd	s1,56(sp)
 268:	f84a                	sd	s2,48(sp)
 26a:	f44e                	sd	s3,40(sp)
 26c:	f052                	sd	s4,32(sp)
 26e:	ec56                	sd	s5,24(sp)
 270:	0880                	addi	s0,sp,80
  printf("test2 start\n");
 272:	00001517          	auipc	a0,0x1
 276:	ad650513          	addi	a0,a0,-1322 # d48 <malloc+0x224>
 27a:	7f0000ef          	jal	ra,a6a <printf>
  if ((pid = fork()) < 0) {
 27e:	3a6000ef          	jal	ra,624 <fork>
 282:	04054063          	bltz	a0,2c2 <test2+0x62>
 286:	84aa                	mv	s1,a0
  if (pid == 0) {
 288:	e139                	bnez	a0,2ce <test2+0x6e>
    count = 0;
 28a:	00001797          	auipc	a5,0x1
 28e:	d607ab23          	sw	zero,-650(a5) # 1000 <count>
    sigalarm(2, slow_handler);
 292:	00000597          	auipc	a1,0x0
 296:	da058593          	addi	a1,a1,-608 # 32 <slow_handler>
 29a:	4509                	li	a0,2
 29c:	438000ef          	jal	ra,6d4 <sigalarm>
      if((i % 1000000) == 0)
 2a0:	000f4937          	lui	s2,0xf4
 2a4:	2409091b          	addiw	s2,s2,576
        write(2, ".", 1);
 2a8:	00001a97          	auipc	s5,0x1
 2ac:	9b8a8a93          	addi	s5,s5,-1608 # c60 <malloc+0x13c>
      if(count > 0)
 2b0:	00001a17          	auipc	s4,0x1
 2b4:	d50a0a13          	addi	s4,s4,-688 # 1000 <count>
    for(i = 0; i < 1000*500000; i++){
 2b8:	1dcd69b7          	lui	s3,0x1dcd6
 2bc:	50098993          	addi	s3,s3,1280 # 1dcd6500 <base+0x1dcd54f0>
 2c0:	a83d                	j	2fe <test2+0x9e>
    printf("test2: fork failed\n");
 2c2:	00001517          	auipc	a0,0x1
 2c6:	a9650513          	addi	a0,a0,-1386 # d58 <malloc+0x234>
 2ca:	7a0000ef          	jal	ra,a6a <printf>
  wait(&status);
 2ce:	fbc40513          	addi	a0,s0,-68
 2d2:	362000ef          	jal	ra,634 <wait>
  if (status == 0) {
 2d6:	fbc42783          	lw	a5,-68(s0)
 2da:	cfa1                	beqz	a5,332 <test2+0xd2>
}
 2dc:	60a6                	ld	ra,72(sp)
 2de:	6406                	ld	s0,64(sp)
 2e0:	74e2                	ld	s1,56(sp)
 2e2:	7942                	ld	s2,48(sp)
 2e4:	79a2                	ld	s3,40(sp)
 2e6:	7a02                	ld	s4,32(sp)
 2e8:	6ae2                	ld	s5,24(sp)
 2ea:	6161                	addi	sp,sp,80
 2ec:	8082                	ret
      if(count > 0)
 2ee:	000a2783          	lw	a5,0(s4)
 2f2:	2781                	sext.w	a5,a5
 2f4:	00f04e63          	bgtz	a5,310 <test2+0xb0>
    for(i = 0; i < 1000*500000; i++){
 2f8:	2485                	addiw	s1,s1,1
 2fa:	01348b63          	beq	s1,s3,310 <test2+0xb0>
      if((i % 1000000) == 0)
 2fe:	0324e7bb          	remw	a5,s1,s2
 302:	f7f5                	bnez	a5,2ee <test2+0x8e>
        write(2, ".", 1);
 304:	4605                	li	a2,1
 306:	85d6                	mv	a1,s5
 308:	4509                	li	a0,2
 30a:	342000ef          	jal	ra,64c <write>
 30e:	b7c5                	j	2ee <test2+0x8e>
    if (count == 0) {
 310:	00001797          	auipc	a5,0x1
 314:	cf07a783          	lw	a5,-784(a5) # 1000 <count>
 318:	eb91                	bnez	a5,32c <test2+0xcc>
      printf("\ntest2 failed: alarm not called\n");
 31a:	00001517          	auipc	a0,0x1
 31e:	a5650513          	addi	a0,a0,-1450 # d70 <malloc+0x24c>
 322:	748000ef          	jal	ra,a6a <printf>
      exit(1);
 326:	4505                	li	a0,1
 328:	304000ef          	jal	ra,62c <exit>
    exit(0);
 32c:	4501                	li	a0,0
 32e:	2fe000ef          	jal	ra,62c <exit>
    printf("test2 passed\n");
 332:	00001517          	auipc	a0,0x1
 336:	a6650513          	addi	a0,a0,-1434 # d98 <malloc+0x274>
 33a:	730000ef          	jal	ra,a6a <printf>
}
 33e:	bf79                	j	2dc <test2+0x7c>

0000000000000340 <test3>:
//
// tests that the return from sys_sigreturn() does not
// modify the a0 register
void
test3()
{
 340:	1141                	addi	sp,sp,-16
 342:	e406                	sd	ra,8(sp)
 344:	e022                	sd	s0,0(sp)
 346:	0800                	addi	s0,sp,16
  uint64 a0;

  sigalarm(1, dummy_handler);
 348:	00000597          	auipc	a1,0x0
 34c:	d5458593          	addi	a1,a1,-684 # 9c <dummy_handler>
 350:	4505                	li	a0,1
 352:	382000ef          	jal	ra,6d4 <sigalarm>
  printf("test3 start\n");
 356:	00001517          	auipc	a0,0x1
 35a:	a5250513          	addi	a0,a0,-1454 # da8 <malloc+0x284>
 35e:	70c000ef          	jal	ra,a6a <printf>

  asm volatile("lui a5, 0");
 362:	000007b7          	lui	a5,0x0
  asm volatile("addi a0, a5, 0xac" : : : "a0");
 366:	0ac78513          	addi	a0,a5,172 # ac <dummy_handler+0x10>
 36a:	1dcd67b7          	lui	a5,0x1dcd6
 36e:	50078793          	addi	a5,a5,1280 # 1dcd6500 <base+0x1dcd54f0>
  for(int i = 0; i < 500000000; i++)
 372:	37fd                	addiw	a5,a5,-1
 374:	fffd                	bnez	a5,372 <test3+0x32>
    ;
  asm volatile("mv %0, a0" : "=r" (a0) );
 376:	872a                	mv	a4,a0

  if(a0 != 0xac)
 378:	0ac00793          	li	a5,172
 37c:	00f70c63          	beq	a4,a5,394 <test3+0x54>
    printf("test3 failed: register a0 changed\n");
 380:	00001517          	auipc	a0,0x1
 384:	a3850513          	addi	a0,a0,-1480 # db8 <malloc+0x294>
 388:	6e2000ef          	jal	ra,a6a <printf>
  else
    printf("test3 passed\n");
}
 38c:	60a2                	ld	ra,8(sp)
 38e:	6402                	ld	s0,0(sp)
 390:	0141                	addi	sp,sp,16
 392:	8082                	ret
    printf("test3 passed\n");
 394:	00001517          	auipc	a0,0x1
 398:	a4c50513          	addi	a0,a0,-1460 # de0 <malloc+0x2bc>
 39c:	6ce000ef          	jal	ra,a6a <printf>
}
 3a0:	b7f5                	j	38c <test3+0x4c>

00000000000003a2 <main>:
{
 3a2:	1141                	addi	sp,sp,-16
 3a4:	e406                	sd	ra,8(sp)
 3a6:	e022                	sd	s0,0(sp)
 3a8:	0800                	addi	s0,sp,16
  test0();
 3aa:	d0fff0ef          	jal	ra,b8 <test0>
  test1();
 3ae:	e01ff0ef          	jal	ra,1ae <test1>
  test2();
 3b2:	eafff0ef          	jal	ra,260 <test2>
  test3();
 3b6:	f8bff0ef          	jal	ra,340 <test3>
  exit(0);
 3ba:	4501                	li	a0,0
 3bc:	270000ef          	jal	ra,62c <exit>

00000000000003c0 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 3c0:	1141                	addi	sp,sp,-16
 3c2:	e406                	sd	ra,8(sp)
 3c4:	e022                	sd	s0,0(sp)
 3c6:	0800                	addi	s0,sp,16
  extern int main();
  main();
 3c8:	fdbff0ef          	jal	ra,3a2 <main>
  exit(0);
 3cc:	4501                	li	a0,0
 3ce:	25e000ef          	jal	ra,62c <exit>

00000000000003d2 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 3d2:	1141                	addi	sp,sp,-16
 3d4:	e422                	sd	s0,8(sp)
 3d6:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 3d8:	87aa                	mv	a5,a0
 3da:	0585                	addi	a1,a1,1
 3dc:	0785                	addi	a5,a5,1
 3de:	fff5c703          	lbu	a4,-1(a1)
 3e2:	fee78fa3          	sb	a4,-1(a5)
 3e6:	fb75                	bnez	a4,3da <strcpy+0x8>
    ;
  return os;
}
 3e8:	6422                	ld	s0,8(sp)
 3ea:	0141                	addi	sp,sp,16
 3ec:	8082                	ret

00000000000003ee <strcmp>:

int
strcmp(const char *p, const char *q)
{
 3ee:	1141                	addi	sp,sp,-16
 3f0:	e422                	sd	s0,8(sp)
 3f2:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 3f4:	00054783          	lbu	a5,0(a0)
 3f8:	cb91                	beqz	a5,40c <strcmp+0x1e>
 3fa:	0005c703          	lbu	a4,0(a1)
 3fe:	00f71763          	bne	a4,a5,40c <strcmp+0x1e>
    p++, q++;
 402:	0505                	addi	a0,a0,1
 404:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 406:	00054783          	lbu	a5,0(a0)
 40a:	fbe5                	bnez	a5,3fa <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 40c:	0005c503          	lbu	a0,0(a1)
}
 410:	40a7853b          	subw	a0,a5,a0
 414:	6422                	ld	s0,8(sp)
 416:	0141                	addi	sp,sp,16
 418:	8082                	ret

000000000000041a <strlen>:

uint
strlen(const char *s)
{
 41a:	1141                	addi	sp,sp,-16
 41c:	e422                	sd	s0,8(sp)
 41e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 420:	00054783          	lbu	a5,0(a0)
 424:	cf91                	beqz	a5,440 <strlen+0x26>
 426:	0505                	addi	a0,a0,1
 428:	87aa                	mv	a5,a0
 42a:	4685                	li	a3,1
 42c:	9e89                	subw	a3,a3,a0
 42e:	00f6853b          	addw	a0,a3,a5
 432:	0785                	addi	a5,a5,1
 434:	fff7c703          	lbu	a4,-1(a5)
 438:	fb7d                	bnez	a4,42e <strlen+0x14>
    ;
  return n;
}
 43a:	6422                	ld	s0,8(sp)
 43c:	0141                	addi	sp,sp,16
 43e:	8082                	ret
  for(n = 0; s[n]; n++)
 440:	4501                	li	a0,0
 442:	bfe5                	j	43a <strlen+0x20>

0000000000000444 <memset>:

void*
memset(void *dst, int c, uint n)
{
 444:	1141                	addi	sp,sp,-16
 446:	e422                	sd	s0,8(sp)
 448:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 44a:	ca19                	beqz	a2,460 <memset+0x1c>
 44c:	87aa                	mv	a5,a0
 44e:	1602                	slli	a2,a2,0x20
 450:	9201                	srli	a2,a2,0x20
 452:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 456:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 45a:	0785                	addi	a5,a5,1
 45c:	fee79de3          	bne	a5,a4,456 <memset+0x12>
  }
  return dst;
}
 460:	6422                	ld	s0,8(sp)
 462:	0141                	addi	sp,sp,16
 464:	8082                	ret

0000000000000466 <strchr>:

char*
strchr(const char *s, char c)
{
 466:	1141                	addi	sp,sp,-16
 468:	e422                	sd	s0,8(sp)
 46a:	0800                	addi	s0,sp,16
  for(; *s; s++)
 46c:	00054783          	lbu	a5,0(a0)
 470:	cb99                	beqz	a5,486 <strchr+0x20>
    if(*s == c)
 472:	00f58763          	beq	a1,a5,480 <strchr+0x1a>
  for(; *s; s++)
 476:	0505                	addi	a0,a0,1
 478:	00054783          	lbu	a5,0(a0)
 47c:	fbfd                	bnez	a5,472 <strchr+0xc>
      return (char*)s;
  return 0;
 47e:	4501                	li	a0,0
}
 480:	6422                	ld	s0,8(sp)
 482:	0141                	addi	sp,sp,16
 484:	8082                	ret
  return 0;
 486:	4501                	li	a0,0
 488:	bfe5                	j	480 <strchr+0x1a>

000000000000048a <gets>:

char*
gets(char *buf, int max)
{
 48a:	711d                	addi	sp,sp,-96
 48c:	ec86                	sd	ra,88(sp)
 48e:	e8a2                	sd	s0,80(sp)
 490:	e4a6                	sd	s1,72(sp)
 492:	e0ca                	sd	s2,64(sp)
 494:	fc4e                	sd	s3,56(sp)
 496:	f852                	sd	s4,48(sp)
 498:	f456                	sd	s5,40(sp)
 49a:	f05a                	sd	s6,32(sp)
 49c:	ec5e                	sd	s7,24(sp)
 49e:	1080                	addi	s0,sp,96
 4a0:	8baa                	mv	s7,a0
 4a2:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 4a4:	892a                	mv	s2,a0
 4a6:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 4a8:	4aa9                	li	s5,10
 4aa:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 4ac:	89a6                	mv	s3,s1
 4ae:	2485                	addiw	s1,s1,1
 4b0:	0344d663          	bge	s1,s4,4dc <gets+0x52>
    cc = read(0, &c, 1);
 4b4:	4605                	li	a2,1
 4b6:	faf40593          	addi	a1,s0,-81
 4ba:	4501                	li	a0,0
 4bc:	188000ef          	jal	ra,644 <read>
    if(cc < 1)
 4c0:	00a05e63          	blez	a0,4dc <gets+0x52>
    buf[i++] = c;
 4c4:	faf44783          	lbu	a5,-81(s0)
 4c8:	00f90023          	sb	a5,0(s2) # f4000 <base+0xf2ff0>
    if(c == '\n' || c == '\r')
 4cc:	01578763          	beq	a5,s5,4da <gets+0x50>
 4d0:	0905                	addi	s2,s2,1
 4d2:	fd679de3          	bne	a5,s6,4ac <gets+0x22>
  for(i=0; i+1 < max; ){
 4d6:	89a6                	mv	s3,s1
 4d8:	a011                	j	4dc <gets+0x52>
 4da:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 4dc:	99de                	add	s3,s3,s7
 4de:	00098023          	sb	zero,0(s3)
  return buf;
}
 4e2:	855e                	mv	a0,s7
 4e4:	60e6                	ld	ra,88(sp)
 4e6:	6446                	ld	s0,80(sp)
 4e8:	64a6                	ld	s1,72(sp)
 4ea:	6906                	ld	s2,64(sp)
 4ec:	79e2                	ld	s3,56(sp)
 4ee:	7a42                	ld	s4,48(sp)
 4f0:	7aa2                	ld	s5,40(sp)
 4f2:	7b02                	ld	s6,32(sp)
 4f4:	6be2                	ld	s7,24(sp)
 4f6:	6125                	addi	sp,sp,96
 4f8:	8082                	ret

00000000000004fa <stat>:

int
stat(const char *n, struct stat *st)
{
 4fa:	1101                	addi	sp,sp,-32
 4fc:	ec06                	sd	ra,24(sp)
 4fe:	e822                	sd	s0,16(sp)
 500:	e426                	sd	s1,8(sp)
 502:	e04a                	sd	s2,0(sp)
 504:	1000                	addi	s0,sp,32
 506:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 508:	4581                	li	a1,0
 50a:	162000ef          	jal	ra,66c <open>
  if(fd < 0)
 50e:	02054163          	bltz	a0,530 <stat+0x36>
 512:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 514:	85ca                	mv	a1,s2
 516:	16e000ef          	jal	ra,684 <fstat>
 51a:	892a                	mv	s2,a0
  close(fd);
 51c:	8526                	mv	a0,s1
 51e:	136000ef          	jal	ra,654 <close>
  return r;
}
 522:	854a                	mv	a0,s2
 524:	60e2                	ld	ra,24(sp)
 526:	6442                	ld	s0,16(sp)
 528:	64a2                	ld	s1,8(sp)
 52a:	6902                	ld	s2,0(sp)
 52c:	6105                	addi	sp,sp,32
 52e:	8082                	ret
    return -1;
 530:	597d                	li	s2,-1
 532:	bfc5                	j	522 <stat+0x28>

0000000000000534 <atoi>:

int
atoi(const char *s)
{
 534:	1141                	addi	sp,sp,-16
 536:	e422                	sd	s0,8(sp)
 538:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 53a:	00054603          	lbu	a2,0(a0)
 53e:	fd06079b          	addiw	a5,a2,-48
 542:	0ff7f793          	zext.b	a5,a5
 546:	4725                	li	a4,9
 548:	02f76963          	bltu	a4,a5,57a <atoi+0x46>
 54c:	86aa                	mv	a3,a0
  n = 0;
 54e:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 550:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 552:	0685                	addi	a3,a3,1
 554:	0025179b          	slliw	a5,a0,0x2
 558:	9fa9                	addw	a5,a5,a0
 55a:	0017979b          	slliw	a5,a5,0x1
 55e:	9fb1                	addw	a5,a5,a2
 560:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 564:	0006c603          	lbu	a2,0(a3)
 568:	fd06071b          	addiw	a4,a2,-48
 56c:	0ff77713          	zext.b	a4,a4
 570:	fee5f1e3          	bgeu	a1,a4,552 <atoi+0x1e>
  return n;
}
 574:	6422                	ld	s0,8(sp)
 576:	0141                	addi	sp,sp,16
 578:	8082                	ret
  n = 0;
 57a:	4501                	li	a0,0
 57c:	bfe5                	j	574 <atoi+0x40>

000000000000057e <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 57e:	1141                	addi	sp,sp,-16
 580:	e422                	sd	s0,8(sp)
 582:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 584:	02b57463          	bgeu	a0,a1,5ac <memmove+0x2e>
    while(n-- > 0)
 588:	00c05f63          	blez	a2,5a6 <memmove+0x28>
 58c:	1602                	slli	a2,a2,0x20
 58e:	9201                	srli	a2,a2,0x20
 590:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 594:	872a                	mv	a4,a0
      *dst++ = *src++;
 596:	0585                	addi	a1,a1,1
 598:	0705                	addi	a4,a4,1
 59a:	fff5c683          	lbu	a3,-1(a1)
 59e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 5a2:	fee79ae3          	bne	a5,a4,596 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 5a6:	6422                	ld	s0,8(sp)
 5a8:	0141                	addi	sp,sp,16
 5aa:	8082                	ret
    dst += n;
 5ac:	00c50733          	add	a4,a0,a2
    src += n;
 5b0:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 5b2:	fec05ae3          	blez	a2,5a6 <memmove+0x28>
 5b6:	fff6079b          	addiw	a5,a2,-1
 5ba:	1782                	slli	a5,a5,0x20
 5bc:	9381                	srli	a5,a5,0x20
 5be:	fff7c793          	not	a5,a5
 5c2:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 5c4:	15fd                	addi	a1,a1,-1
 5c6:	177d                	addi	a4,a4,-1
 5c8:	0005c683          	lbu	a3,0(a1)
 5cc:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 5d0:	fee79ae3          	bne	a5,a4,5c4 <memmove+0x46>
 5d4:	bfc9                	j	5a6 <memmove+0x28>

00000000000005d6 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 5d6:	1141                	addi	sp,sp,-16
 5d8:	e422                	sd	s0,8(sp)
 5da:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 5dc:	ca05                	beqz	a2,60c <memcmp+0x36>
 5de:	fff6069b          	addiw	a3,a2,-1
 5e2:	1682                	slli	a3,a3,0x20
 5e4:	9281                	srli	a3,a3,0x20
 5e6:	0685                	addi	a3,a3,1
 5e8:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 5ea:	00054783          	lbu	a5,0(a0)
 5ee:	0005c703          	lbu	a4,0(a1)
 5f2:	00e79863          	bne	a5,a4,602 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 5f6:	0505                	addi	a0,a0,1
    p2++;
 5f8:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 5fa:	fed518e3          	bne	a0,a3,5ea <memcmp+0x14>
  }
  return 0;
 5fe:	4501                	li	a0,0
 600:	a019                	j	606 <memcmp+0x30>
      return *p1 - *p2;
 602:	40e7853b          	subw	a0,a5,a4
}
 606:	6422                	ld	s0,8(sp)
 608:	0141                	addi	sp,sp,16
 60a:	8082                	ret
  return 0;
 60c:	4501                	li	a0,0
 60e:	bfe5                	j	606 <memcmp+0x30>

0000000000000610 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 610:	1141                	addi	sp,sp,-16
 612:	e406                	sd	ra,8(sp)
 614:	e022                	sd	s0,0(sp)
 616:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 618:	f67ff0ef          	jal	ra,57e <memmove>
}
 61c:	60a2                	ld	ra,8(sp)
 61e:	6402                	ld	s0,0(sp)
 620:	0141                	addi	sp,sp,16
 622:	8082                	ret

0000000000000624 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 624:	4885                	li	a7,1
 ecall
 626:	00000073          	ecall
 ret
 62a:	8082                	ret

000000000000062c <exit>:
.global exit
exit:
 li a7, SYS_exit
 62c:	4889                	li	a7,2
 ecall
 62e:	00000073          	ecall
 ret
 632:	8082                	ret

0000000000000634 <wait>:
.global wait
wait:
 li a7, SYS_wait
 634:	488d                	li	a7,3
 ecall
 636:	00000073          	ecall
 ret
 63a:	8082                	ret

000000000000063c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 63c:	4891                	li	a7,4
 ecall
 63e:	00000073          	ecall
 ret
 642:	8082                	ret

0000000000000644 <read>:
.global read
read:
 li a7, SYS_read
 644:	4895                	li	a7,5
 ecall
 646:	00000073          	ecall
 ret
 64a:	8082                	ret

000000000000064c <write>:
.global write
write:
 li a7, SYS_write
 64c:	48c1                	li	a7,16
 ecall
 64e:	00000073          	ecall
 ret
 652:	8082                	ret

0000000000000654 <close>:
.global close
close:
 li a7, SYS_close
 654:	48d5                	li	a7,21
 ecall
 656:	00000073          	ecall
 ret
 65a:	8082                	ret

000000000000065c <kill>:
.global kill
kill:
 li a7, SYS_kill
 65c:	4899                	li	a7,6
 ecall
 65e:	00000073          	ecall
 ret
 662:	8082                	ret

0000000000000664 <exec>:
.global exec
exec:
 li a7, SYS_exec
 664:	489d                	li	a7,7
 ecall
 666:	00000073          	ecall
 ret
 66a:	8082                	ret

000000000000066c <open>:
.global open
open:
 li a7, SYS_open
 66c:	48bd                	li	a7,15
 ecall
 66e:	00000073          	ecall
 ret
 672:	8082                	ret

0000000000000674 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 674:	48c5                	li	a7,17
 ecall
 676:	00000073          	ecall
 ret
 67a:	8082                	ret

000000000000067c <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 67c:	48c9                	li	a7,18
 ecall
 67e:	00000073          	ecall
 ret
 682:	8082                	ret

0000000000000684 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 684:	48a1                	li	a7,8
 ecall
 686:	00000073          	ecall
 ret
 68a:	8082                	ret

000000000000068c <link>:
.global link
link:
 li a7, SYS_link
 68c:	48cd                	li	a7,19
 ecall
 68e:	00000073          	ecall
 ret
 692:	8082                	ret

0000000000000694 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 694:	48d1                	li	a7,20
 ecall
 696:	00000073          	ecall
 ret
 69a:	8082                	ret

000000000000069c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 69c:	48a5                	li	a7,9
 ecall
 69e:	00000073          	ecall
 ret
 6a2:	8082                	ret

00000000000006a4 <dup>:
.global dup
dup:
 li a7, SYS_dup
 6a4:	48a9                	li	a7,10
 ecall
 6a6:	00000073          	ecall
 ret
 6aa:	8082                	ret

00000000000006ac <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 6ac:	48ad                	li	a7,11
 ecall
 6ae:	00000073          	ecall
 ret
 6b2:	8082                	ret

00000000000006b4 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 6b4:	48b1                	li	a7,12
 ecall
 6b6:	00000073          	ecall
 ret
 6ba:	8082                	ret

00000000000006bc <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 6bc:	48b5                	li	a7,13
 ecall
 6be:	00000073          	ecall
 ret
 6c2:	8082                	ret

00000000000006c4 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 6c4:	48b9                	li	a7,14
 ecall
 6c6:	00000073          	ecall
 ret
 6ca:	8082                	ret

00000000000006cc <trace>:
.global trace
trace:
 li a7, SYS_trace
 6cc:	48d9                	li	a7,22
 ecall
 6ce:	00000073          	ecall
 ret
 6d2:	8082                	ret

00000000000006d4 <sigalarm>:
.global sigalarm
sigalarm:
 li a7, SYS_sigalarm
 6d4:	48dd                	li	a7,23
 ecall
 6d6:	00000073          	ecall
 ret
 6da:	8082                	ret

00000000000006dc <sigreturn>:
.global sigreturn
sigreturn:
 li a7, SYS_sigreturn
 6dc:	48e1                	li	a7,24
 ecall
 6de:	00000073          	ecall
 ret
 6e2:	8082                	ret

00000000000006e4 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 6e4:	1101                	addi	sp,sp,-32
 6e6:	ec06                	sd	ra,24(sp)
 6e8:	e822                	sd	s0,16(sp)
 6ea:	1000                	addi	s0,sp,32
 6ec:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 6f0:	4605                	li	a2,1
 6f2:	fef40593          	addi	a1,s0,-17
 6f6:	f57ff0ef          	jal	ra,64c <write>
}
 6fa:	60e2                	ld	ra,24(sp)
 6fc:	6442                	ld	s0,16(sp)
 6fe:	6105                	addi	sp,sp,32
 700:	8082                	ret

0000000000000702 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 702:	715d                	addi	sp,sp,-80
 704:	e486                	sd	ra,72(sp)
 706:	e0a2                	sd	s0,64(sp)
 708:	fc26                	sd	s1,56(sp)
 70a:	f84a                	sd	s2,48(sp)
 70c:	f44e                	sd	s3,40(sp)
 70e:	0880                	addi	s0,sp,80
 710:	84aa                	mv	s1,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 712:	c299                	beqz	a3,718 <printint+0x16>
 714:	0805c663          	bltz	a1,7a0 <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 718:	2581                	sext.w	a1,a1
  neg = 0;
 71a:	4881                	li	a7,0
 71c:	fb840693          	addi	a3,s0,-72
  }

  i = 0;
 720:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 722:	2601                	sext.w	a2,a2
 724:	00000517          	auipc	a0,0x0
 728:	6d450513          	addi	a0,a0,1748 # df8 <digits>
 72c:	883a                	mv	a6,a4
 72e:	2705                	addiw	a4,a4,1
 730:	02c5f7bb          	remuw	a5,a1,a2
 734:	1782                	slli	a5,a5,0x20
 736:	9381                	srli	a5,a5,0x20
 738:	97aa                	add	a5,a5,a0
 73a:	0007c783          	lbu	a5,0(a5)
 73e:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 742:	0005879b          	sext.w	a5,a1
 746:	02c5d5bb          	divuw	a1,a1,a2
 74a:	0685                	addi	a3,a3,1
 74c:	fec7f0e3          	bgeu	a5,a2,72c <printint+0x2a>
  if(neg)
 750:	00088b63          	beqz	a7,766 <printint+0x64>
    buf[i++] = '-';
 754:	fd040793          	addi	a5,s0,-48
 758:	973e                	add	a4,a4,a5
 75a:	02d00793          	li	a5,45
 75e:	fef70423          	sb	a5,-24(a4)
 762:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 766:	02e05663          	blez	a4,792 <printint+0x90>
 76a:	fb840793          	addi	a5,s0,-72
 76e:	00e78933          	add	s2,a5,a4
 772:	fff78993          	addi	s3,a5,-1
 776:	99ba                	add	s3,s3,a4
 778:	377d                	addiw	a4,a4,-1
 77a:	1702                	slli	a4,a4,0x20
 77c:	9301                	srli	a4,a4,0x20
 77e:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 782:	fff94583          	lbu	a1,-1(s2)
 786:	8526                	mv	a0,s1
 788:	f5dff0ef          	jal	ra,6e4 <putc>
  while(--i >= 0)
 78c:	197d                	addi	s2,s2,-1
 78e:	ff391ae3          	bne	s2,s3,782 <printint+0x80>
}
 792:	60a6                	ld	ra,72(sp)
 794:	6406                	ld	s0,64(sp)
 796:	74e2                	ld	s1,56(sp)
 798:	7942                	ld	s2,48(sp)
 79a:	79a2                	ld	s3,40(sp)
 79c:	6161                	addi	sp,sp,80
 79e:	8082                	ret
    x = -xx;
 7a0:	40b005bb          	negw	a1,a1
    neg = 1;
 7a4:	4885                	li	a7,1
    x = -xx;
 7a6:	bf9d                	j	71c <printint+0x1a>

00000000000007a8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 7a8:	7119                	addi	sp,sp,-128
 7aa:	fc86                	sd	ra,120(sp)
 7ac:	f8a2                	sd	s0,112(sp)
 7ae:	f4a6                	sd	s1,104(sp)
 7b0:	f0ca                	sd	s2,96(sp)
 7b2:	ecce                	sd	s3,88(sp)
 7b4:	e8d2                	sd	s4,80(sp)
 7b6:	e4d6                	sd	s5,72(sp)
 7b8:	e0da                	sd	s6,64(sp)
 7ba:	fc5e                	sd	s7,56(sp)
 7bc:	f862                	sd	s8,48(sp)
 7be:	f466                	sd	s9,40(sp)
 7c0:	f06a                	sd	s10,32(sp)
 7c2:	ec6e                	sd	s11,24(sp)
 7c4:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 7c6:	0005c903          	lbu	s2,0(a1)
 7ca:	24090c63          	beqz	s2,a22 <vprintf+0x27a>
 7ce:	8b2a                	mv	s6,a0
 7d0:	8a2e                	mv	s4,a1
 7d2:	8bb2                	mv	s7,a2
  state = 0;
 7d4:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 7d6:	4481                	li	s1,0
 7d8:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 7da:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 7de:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 7e2:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 7e6:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7ea:	00000c97          	auipc	s9,0x0
 7ee:	60ec8c93          	addi	s9,s9,1550 # df8 <digits>
 7f2:	a005                	j	812 <vprintf+0x6a>
        putc(fd, c0);
 7f4:	85ca                	mv	a1,s2
 7f6:	855a                	mv	a0,s6
 7f8:	eedff0ef          	jal	ra,6e4 <putc>
 7fc:	a019                	j	802 <vprintf+0x5a>
    } else if(state == '%'){
 7fe:	03598263          	beq	s3,s5,822 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 802:	2485                	addiw	s1,s1,1
 804:	8726                	mv	a4,s1
 806:	009a07b3          	add	a5,s4,s1
 80a:	0007c903          	lbu	s2,0(a5)
 80e:	20090a63          	beqz	s2,a22 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 812:	0009079b          	sext.w	a5,s2
    if(state == 0){
 816:	fe0994e3          	bnez	s3,7fe <vprintf+0x56>
      if(c0 == '%'){
 81a:	fd579de3          	bne	a5,s5,7f4 <vprintf+0x4c>
        state = '%';
 81e:	89be                	mv	s3,a5
 820:	b7cd                	j	802 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 822:	c3c1                	beqz	a5,8a2 <vprintf+0xfa>
 824:	00ea06b3          	add	a3,s4,a4
 828:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 82c:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 82e:	c681                	beqz	a3,836 <vprintf+0x8e>
 830:	9752                	add	a4,a4,s4
 832:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 836:	03878e63          	beq	a5,s8,872 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 83a:	05a78863          	beq	a5,s10,88a <vprintf+0xe2>
      } else if(c0 == 'u'){
 83e:	0db78b63          	beq	a5,s11,914 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 842:	07800713          	li	a4,120
 846:	10e78d63          	beq	a5,a4,960 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 84a:	07000713          	li	a4,112
 84e:	14e78263          	beq	a5,a4,992 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 852:	06300713          	li	a4,99
 856:	16e78f63          	beq	a5,a4,9d4 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 85a:	07300713          	li	a4,115
 85e:	18e78563          	beq	a5,a4,9e8 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 862:	05579063          	bne	a5,s5,8a2 <vprintf+0xfa>
        putc(fd, '%');
 866:	85d6                	mv	a1,s5
 868:	855a                	mv	a0,s6
 86a:	e7bff0ef          	jal	ra,6e4 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 86e:	4981                	li	s3,0
 870:	bf49                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 872:	008b8913          	addi	s2,s7,8
 876:	4685                	li	a3,1
 878:	4629                	li	a2,10
 87a:	000ba583          	lw	a1,0(s7)
 87e:	855a                	mv	a0,s6
 880:	e83ff0ef          	jal	ra,702 <printint>
 884:	8bca                	mv	s7,s2
      state = 0;
 886:	4981                	li	s3,0
 888:	bfad                	j	802 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 88a:	03868663          	beq	a3,s8,8b6 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 88e:	05a68163          	beq	a3,s10,8d0 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 892:	09b68d63          	beq	a3,s11,92c <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 896:	03a68f63          	beq	a3,s10,8d4 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 89a:	07800793          	li	a5,120
 89e:	0cf68d63          	beq	a3,a5,978 <vprintf+0x1d0>
        putc(fd, '%');
 8a2:	85d6                	mv	a1,s5
 8a4:	855a                	mv	a0,s6
 8a6:	e3fff0ef          	jal	ra,6e4 <putc>
        putc(fd, c0);
 8aa:	85ca                	mv	a1,s2
 8ac:	855a                	mv	a0,s6
 8ae:	e37ff0ef          	jal	ra,6e4 <putc>
      state = 0;
 8b2:	4981                	li	s3,0
 8b4:	b7b9                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8b6:	008b8913          	addi	s2,s7,8
 8ba:	4685                	li	a3,1
 8bc:	4629                	li	a2,10
 8be:	000bb583          	ld	a1,0(s7)
 8c2:	855a                	mv	a0,s6
 8c4:	e3fff0ef          	jal	ra,702 <printint>
        i += 1;
 8c8:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 8ca:	8bca                	mv	s7,s2
      state = 0;
 8cc:	4981                	li	s3,0
        i += 1;
 8ce:	bf15                	j	802 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8d0:	03860563          	beq	a2,s8,8fa <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 8d4:	07b60963          	beq	a2,s11,946 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 8d8:	07800793          	li	a5,120
 8dc:	fcf613e3          	bne	a2,a5,8a2 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8e0:	008b8913          	addi	s2,s7,8
 8e4:	4681                	li	a3,0
 8e6:	4641                	li	a2,16
 8e8:	000bb583          	ld	a1,0(s7)
 8ec:	855a                	mv	a0,s6
 8ee:	e15ff0ef          	jal	ra,702 <printint>
        i += 2;
 8f2:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 8f4:	8bca                	mv	s7,s2
      state = 0;
 8f6:	4981                	li	s3,0
        i += 2;
 8f8:	b729                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8fa:	008b8913          	addi	s2,s7,8
 8fe:	4685                	li	a3,1
 900:	4629                	li	a2,10
 902:	000bb583          	ld	a1,0(s7)
 906:	855a                	mv	a0,s6
 908:	dfbff0ef          	jal	ra,702 <printint>
        i += 2;
 90c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 90e:	8bca                	mv	s7,s2
      state = 0;
 910:	4981                	li	s3,0
        i += 2;
 912:	bdc5                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 914:	008b8913          	addi	s2,s7,8
 918:	4681                	li	a3,0
 91a:	4629                	li	a2,10
 91c:	000be583          	lwu	a1,0(s7)
 920:	855a                	mv	a0,s6
 922:	de1ff0ef          	jal	ra,702 <printint>
 926:	8bca                	mv	s7,s2
      state = 0;
 928:	4981                	li	s3,0
 92a:	bde1                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 92c:	008b8913          	addi	s2,s7,8
 930:	4681                	li	a3,0
 932:	4629                	li	a2,10
 934:	000bb583          	ld	a1,0(s7)
 938:	855a                	mv	a0,s6
 93a:	dc9ff0ef          	jal	ra,702 <printint>
        i += 1;
 93e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 940:	8bca                	mv	s7,s2
      state = 0;
 942:	4981                	li	s3,0
        i += 1;
 944:	bd7d                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 946:	008b8913          	addi	s2,s7,8
 94a:	4681                	li	a3,0
 94c:	4629                	li	a2,10
 94e:	000bb583          	ld	a1,0(s7)
 952:	855a                	mv	a0,s6
 954:	dafff0ef          	jal	ra,702 <printint>
        i += 2;
 958:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 95a:	8bca                	mv	s7,s2
      state = 0;
 95c:	4981                	li	s3,0
        i += 2;
 95e:	b555                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 960:	008b8913          	addi	s2,s7,8
 964:	4681                	li	a3,0
 966:	4641                	li	a2,16
 968:	000be583          	lwu	a1,0(s7)
 96c:	855a                	mv	a0,s6
 96e:	d95ff0ef          	jal	ra,702 <printint>
 972:	8bca                	mv	s7,s2
      state = 0;
 974:	4981                	li	s3,0
 976:	b571                	j	802 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 978:	008b8913          	addi	s2,s7,8
 97c:	4681                	li	a3,0
 97e:	4641                	li	a2,16
 980:	000bb583          	ld	a1,0(s7)
 984:	855a                	mv	a0,s6
 986:	d7dff0ef          	jal	ra,702 <printint>
        i += 1;
 98a:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 98c:	8bca                	mv	s7,s2
      state = 0;
 98e:	4981                	li	s3,0
        i += 1;
 990:	bd8d                	j	802 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 992:	008b8793          	addi	a5,s7,8
 996:	f8f43423          	sd	a5,-120(s0)
 99a:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 99e:	03000593          	li	a1,48
 9a2:	855a                	mv	a0,s6
 9a4:	d41ff0ef          	jal	ra,6e4 <putc>
  putc(fd, 'x');
 9a8:	07800593          	li	a1,120
 9ac:	855a                	mv	a0,s6
 9ae:	d37ff0ef          	jal	ra,6e4 <putc>
 9b2:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 9b4:	03c9d793          	srli	a5,s3,0x3c
 9b8:	97e6                	add	a5,a5,s9
 9ba:	0007c583          	lbu	a1,0(a5)
 9be:	855a                	mv	a0,s6
 9c0:	d25ff0ef          	jal	ra,6e4 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 9c4:	0992                	slli	s3,s3,0x4
 9c6:	397d                	addiw	s2,s2,-1
 9c8:	fe0916e3          	bnez	s2,9b4 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 9cc:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 9d0:	4981                	li	s3,0
 9d2:	bd05                	j	802 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 9d4:	008b8913          	addi	s2,s7,8
 9d8:	000bc583          	lbu	a1,0(s7)
 9dc:	855a                	mv	a0,s6
 9de:	d07ff0ef          	jal	ra,6e4 <putc>
 9e2:	8bca                	mv	s7,s2
      state = 0;
 9e4:	4981                	li	s3,0
 9e6:	bd31                	j	802 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 9e8:	008b8993          	addi	s3,s7,8
 9ec:	000bb903          	ld	s2,0(s7)
 9f0:	00090f63          	beqz	s2,a0e <vprintf+0x266>
        for(; *s; s++)
 9f4:	00094583          	lbu	a1,0(s2)
 9f8:	c195                	beqz	a1,a1c <vprintf+0x274>
          putc(fd, *s);
 9fa:	855a                	mv	a0,s6
 9fc:	ce9ff0ef          	jal	ra,6e4 <putc>
        for(; *s; s++)
 a00:	0905                	addi	s2,s2,1
 a02:	00094583          	lbu	a1,0(s2)
 a06:	f9f5                	bnez	a1,9fa <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 a08:	8bce                	mv	s7,s3
      state = 0;
 a0a:	4981                	li	s3,0
 a0c:	bbdd                	j	802 <vprintf+0x5a>
          s = "(null)";
 a0e:	00000917          	auipc	s2,0x0
 a12:	3e290913          	addi	s2,s2,994 # df0 <malloc+0x2cc>
        for(; *s; s++)
 a16:	02800593          	li	a1,40
 a1a:	b7c5                	j	9fa <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 a1c:	8bce                	mv	s7,s3
      state = 0;
 a1e:	4981                	li	s3,0
 a20:	b3cd                	j	802 <vprintf+0x5a>
    }
  }
}
 a22:	70e6                	ld	ra,120(sp)
 a24:	7446                	ld	s0,112(sp)
 a26:	74a6                	ld	s1,104(sp)
 a28:	7906                	ld	s2,96(sp)
 a2a:	69e6                	ld	s3,88(sp)
 a2c:	6a46                	ld	s4,80(sp)
 a2e:	6aa6                	ld	s5,72(sp)
 a30:	6b06                	ld	s6,64(sp)
 a32:	7be2                	ld	s7,56(sp)
 a34:	7c42                	ld	s8,48(sp)
 a36:	7ca2                	ld	s9,40(sp)
 a38:	7d02                	ld	s10,32(sp)
 a3a:	6de2                	ld	s11,24(sp)
 a3c:	6109                	addi	sp,sp,128
 a3e:	8082                	ret

0000000000000a40 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 a40:	715d                	addi	sp,sp,-80
 a42:	ec06                	sd	ra,24(sp)
 a44:	e822                	sd	s0,16(sp)
 a46:	1000                	addi	s0,sp,32
 a48:	e010                	sd	a2,0(s0)
 a4a:	e414                	sd	a3,8(s0)
 a4c:	e818                	sd	a4,16(s0)
 a4e:	ec1c                	sd	a5,24(s0)
 a50:	03043023          	sd	a6,32(s0)
 a54:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 a58:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 a5c:	8622                	mv	a2,s0
 a5e:	d4bff0ef          	jal	ra,7a8 <vprintf>
}
 a62:	60e2                	ld	ra,24(sp)
 a64:	6442                	ld	s0,16(sp)
 a66:	6161                	addi	sp,sp,80
 a68:	8082                	ret

0000000000000a6a <printf>:

void
printf(const char *fmt, ...)
{
 a6a:	711d                	addi	sp,sp,-96
 a6c:	ec06                	sd	ra,24(sp)
 a6e:	e822                	sd	s0,16(sp)
 a70:	1000                	addi	s0,sp,32
 a72:	e40c                	sd	a1,8(s0)
 a74:	e810                	sd	a2,16(s0)
 a76:	ec14                	sd	a3,24(s0)
 a78:	f018                	sd	a4,32(s0)
 a7a:	f41c                	sd	a5,40(s0)
 a7c:	03043823          	sd	a6,48(s0)
 a80:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 a84:	00840613          	addi	a2,s0,8
 a88:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a8c:	85aa                	mv	a1,a0
 a8e:	4505                	li	a0,1
 a90:	d19ff0ef          	jal	ra,7a8 <vprintf>
}
 a94:	60e2                	ld	ra,24(sp)
 a96:	6442                	ld	s0,16(sp)
 a98:	6125                	addi	sp,sp,96
 a9a:	8082                	ret

0000000000000a9c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a9c:	1141                	addi	sp,sp,-16
 a9e:	e422                	sd	s0,8(sp)
 aa0:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 aa2:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 aa6:	00000797          	auipc	a5,0x0
 aaa:	5627b783          	ld	a5,1378(a5) # 1008 <freep>
 aae:	a805                	j	ade <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 ab0:	4618                	lw	a4,8(a2)
 ab2:	9db9                	addw	a1,a1,a4
 ab4:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 ab8:	6398                	ld	a4,0(a5)
 aba:	6318                	ld	a4,0(a4)
 abc:	fee53823          	sd	a4,-16(a0)
 ac0:	a091                	j	b04 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 ac2:	ff852703          	lw	a4,-8(a0)
 ac6:	9e39                	addw	a2,a2,a4
 ac8:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 aca:	ff053703          	ld	a4,-16(a0)
 ace:	e398                	sd	a4,0(a5)
 ad0:	a099                	j	b16 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ad2:	6398                	ld	a4,0(a5)
 ad4:	00e7e463          	bltu	a5,a4,adc <free+0x40>
 ad8:	00e6ea63          	bltu	a3,a4,aec <free+0x50>
{
 adc:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ade:	fed7fae3          	bgeu	a5,a3,ad2 <free+0x36>
 ae2:	6398                	ld	a4,0(a5)
 ae4:	00e6e463          	bltu	a3,a4,aec <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ae8:	fee7eae3          	bltu	a5,a4,adc <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 aec:	ff852583          	lw	a1,-8(a0)
 af0:	6390                	ld	a2,0(a5)
 af2:	02059813          	slli	a6,a1,0x20
 af6:	01c85713          	srli	a4,a6,0x1c
 afa:	9736                	add	a4,a4,a3
 afc:	fae60ae3          	beq	a2,a4,ab0 <free+0x14>
    bp->s.ptr = p->s.ptr;
 b00:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 b04:	4790                	lw	a2,8(a5)
 b06:	02061593          	slli	a1,a2,0x20
 b0a:	01c5d713          	srli	a4,a1,0x1c
 b0e:	973e                	add	a4,a4,a5
 b10:	fae689e3          	beq	a3,a4,ac2 <free+0x26>
  } else
    p->s.ptr = bp;
 b14:	e394                	sd	a3,0(a5)
  freep = p;
 b16:	00000717          	auipc	a4,0x0
 b1a:	4ef73923          	sd	a5,1266(a4) # 1008 <freep>
}
 b1e:	6422                	ld	s0,8(sp)
 b20:	0141                	addi	sp,sp,16
 b22:	8082                	ret

0000000000000b24 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 b24:	7139                	addi	sp,sp,-64
 b26:	fc06                	sd	ra,56(sp)
 b28:	f822                	sd	s0,48(sp)
 b2a:	f426                	sd	s1,40(sp)
 b2c:	f04a                	sd	s2,32(sp)
 b2e:	ec4e                	sd	s3,24(sp)
 b30:	e852                	sd	s4,16(sp)
 b32:	e456                	sd	s5,8(sp)
 b34:	e05a                	sd	s6,0(sp)
 b36:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 b38:	02051493          	slli	s1,a0,0x20
 b3c:	9081                	srli	s1,s1,0x20
 b3e:	04bd                	addi	s1,s1,15
 b40:	8091                	srli	s1,s1,0x4
 b42:	0014899b          	addiw	s3,s1,1
 b46:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 b48:	00000517          	auipc	a0,0x0
 b4c:	4c053503          	ld	a0,1216(a0) # 1008 <freep>
 b50:	c515                	beqz	a0,b7c <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b52:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b54:	4798                	lw	a4,8(a5)
 b56:	02977f63          	bgeu	a4,s1,b94 <malloc+0x70>
 b5a:	8a4e                	mv	s4,s3
 b5c:	0009871b          	sext.w	a4,s3
 b60:	6685                	lui	a3,0x1
 b62:	00d77363          	bgeu	a4,a3,b68 <malloc+0x44>
 b66:	6a05                	lui	s4,0x1
 b68:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 b6c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 b70:	00000917          	auipc	s2,0x0
 b74:	49890913          	addi	s2,s2,1176 # 1008 <freep>
  if(p == (char*)-1)
 b78:	5afd                	li	s5,-1
 b7a:	a885                	j	bea <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 b7c:	00000797          	auipc	a5,0x0
 b80:	49478793          	addi	a5,a5,1172 # 1010 <base>
 b84:	00000717          	auipc	a4,0x0
 b88:	48f73223          	sd	a5,1156(a4) # 1008 <freep>
 b8c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b8e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b92:	b7e1                	j	b5a <malloc+0x36>
      if(p->s.size == nunits)
 b94:	02e48c63          	beq	s1,a4,bcc <malloc+0xa8>
        p->s.size -= nunits;
 b98:	4137073b          	subw	a4,a4,s3
 b9c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b9e:	02071693          	slli	a3,a4,0x20
 ba2:	01c6d713          	srli	a4,a3,0x1c
 ba6:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 ba8:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 bac:	00000717          	auipc	a4,0x0
 bb0:	44a73e23          	sd	a0,1116(a4) # 1008 <freep>
      return (void*)(p + 1);
 bb4:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 bb8:	70e2                	ld	ra,56(sp)
 bba:	7442                	ld	s0,48(sp)
 bbc:	74a2                	ld	s1,40(sp)
 bbe:	7902                	ld	s2,32(sp)
 bc0:	69e2                	ld	s3,24(sp)
 bc2:	6a42                	ld	s4,16(sp)
 bc4:	6aa2                	ld	s5,8(sp)
 bc6:	6b02                	ld	s6,0(sp)
 bc8:	6121                	addi	sp,sp,64
 bca:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 bcc:	6398                	ld	a4,0(a5)
 bce:	e118                	sd	a4,0(a0)
 bd0:	bff1                	j	bac <malloc+0x88>
  hp->s.size = nu;
 bd2:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 bd6:	0541                	addi	a0,a0,16
 bd8:	ec5ff0ef          	jal	ra,a9c <free>
  return freep;
 bdc:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 be0:	dd61                	beqz	a0,bb8 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 be2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 be4:	4798                	lw	a4,8(a5)
 be6:	fa9777e3          	bgeu	a4,s1,b94 <malloc+0x70>
    if(p == freep)
 bea:	00093703          	ld	a4,0(s2)
 bee:	853e                	mv	a0,a5
 bf0:	fef719e3          	bne	a4,a5,be2 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 bf4:	8552                	mv	a0,s4
 bf6:	abfff0ef          	jal	ra,6b4 <sbrk>
  if(p == (char*)-1)
 bfa:	fd551ce3          	bne	a0,s5,bd2 <malloc+0xae>
        return 0;
 bfe:	4501                	li	a0,0
 c00:	bf65                	j	bb8 <malloc+0x94>
