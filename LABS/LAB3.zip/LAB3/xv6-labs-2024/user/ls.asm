
user/_ls:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <fmtname>:
#include "kernel/fs.h"
#include "kernel/fcntl.h"

char*
fmtname(char *path)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	1800                	addi	s0,sp,48
   e:	84aa                	mv	s1,a0
  static char buf[DIRSIZ+1];
  char *p;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
  10:	2ae000ef          	jal	ra,2be <strlen>
  14:	02051793          	slli	a5,a0,0x20
  18:	9381                	srli	a5,a5,0x20
  1a:	97a6                	add	a5,a5,s1
  1c:	02f00693          	li	a3,47
  20:	0097e963          	bltu	a5,s1,32 <fmtname+0x32>
  24:	0007c703          	lbu	a4,0(a5)
  28:	00d70563          	beq	a4,a3,32 <fmtname+0x32>
  2c:	17fd                	addi	a5,a5,-1
  2e:	fe97fbe3          	bgeu	a5,s1,24 <fmtname+0x24>
    ;
  p++;
  32:	00178493          	addi	s1,a5,1

  // Return blank-padded name.
  if(strlen(p) >= DIRSIZ)
  36:	8526                	mv	a0,s1
  38:	286000ef          	jal	ra,2be <strlen>
  3c:	2501                	sext.w	a0,a0
  3e:	47b5                	li	a5,13
  40:	00a7fa63          	bgeu	a5,a0,54 <fmtname+0x54>
    return p;
  memmove(buf, p, strlen(p));
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  return buf;
}
  44:	8526                	mv	a0,s1
  46:	70a2                	ld	ra,40(sp)
  48:	7402                	ld	s0,32(sp)
  4a:	64e2                	ld	s1,24(sp)
  4c:	6942                	ld	s2,16(sp)
  4e:	69a2                	ld	s3,8(sp)
  50:	6145                	addi	sp,sp,48
  52:	8082                	ret
  memmove(buf, p, strlen(p));
  54:	8526                	mv	a0,s1
  56:	268000ef          	jal	ra,2be <strlen>
  5a:	00001997          	auipc	s3,0x1
  5e:	fb698993          	addi	s3,s3,-74 # 1010 <buf.0>
  62:	0005061b          	sext.w	a2,a0
  66:	85a6                	mv	a1,s1
  68:	854e                	mv	a0,s3
  6a:	3b8000ef          	jal	ra,422 <memmove>
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  6e:	8526                	mv	a0,s1
  70:	24e000ef          	jal	ra,2be <strlen>
  74:	0005091b          	sext.w	s2,a0
  78:	8526                	mv	a0,s1
  7a:	244000ef          	jal	ra,2be <strlen>
  7e:	1902                	slli	s2,s2,0x20
  80:	02095913          	srli	s2,s2,0x20
  84:	4639                	li	a2,14
  86:	9e09                	subw	a2,a2,a0
  88:	02000593          	li	a1,32
  8c:	01298533          	add	a0,s3,s2
  90:	258000ef          	jal	ra,2e8 <memset>
  return buf;
  94:	84ce                	mv	s1,s3
  96:	b77d                	j	44 <fmtname+0x44>

0000000000000098 <ls>:

void
ls(char *path)
{
  98:	d9010113          	addi	sp,sp,-624
  9c:	26113423          	sd	ra,616(sp)
  a0:	26813023          	sd	s0,608(sp)
  a4:	24913c23          	sd	s1,600(sp)
  a8:	25213823          	sd	s2,592(sp)
  ac:	25313423          	sd	s3,584(sp)
  b0:	25413023          	sd	s4,576(sp)
  b4:	23513c23          	sd	s5,568(sp)
  b8:	1c80                	addi	s0,sp,624
  ba:	892a                	mv	s2,a0
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;

  if((fd = open(path, O_RDONLY)) < 0){
  bc:	4581                	li	a1,0
  be:	468000ef          	jal	ra,526 <open>
  c2:	06054963          	bltz	a0,134 <ls+0x9c>
  c6:	84aa                	mv	s1,a0
    fprintf(2, "ls: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){
  c8:	d9840593          	addi	a1,s0,-616
  cc:	472000ef          	jal	ra,53e <fstat>
  d0:	06054b63          	bltz	a0,146 <ls+0xae>
    fprintf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }

  switch(st.type){
  d4:	da041783          	lh	a5,-608(s0)
  d8:	0007869b          	sext.w	a3,a5
  dc:	4705                	li	a4,1
  de:	08e68063          	beq	a3,a4,15e <ls+0xc6>
  e2:	37f9                	addiw	a5,a5,-2
  e4:	17c2                	slli	a5,a5,0x30
  e6:	93c1                	srli	a5,a5,0x30
  e8:	02f76263          	bltu	a4,a5,10c <ls+0x74>
  case T_DEVICE:
  case T_FILE:
    printf("%s %d %d %d\n", fmtname(path), st.type, st.ino, (int) st.size);
  ec:	854a                	mv	a0,s2
  ee:	f13ff0ef          	jal	ra,0 <fmtname>
  f2:	85aa                	mv	a1,a0
  f4:	da842703          	lw	a4,-600(s0)
  f8:	d9c42683          	lw	a3,-612(s0)
  fc:	da041603          	lh	a2,-608(s0)
 100:	00001517          	auipc	a0,0x1
 104:	a0050513          	addi	a0,a0,-1536 # b00 <malloc+0x116>
 108:	029000ef          	jal	ra,930 <printf>
      }
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
    }
    break;
  }
  close(fd);
 10c:	8526                	mv	a0,s1
 10e:	400000ef          	jal	ra,50e <close>
}
 112:	26813083          	ld	ra,616(sp)
 116:	26013403          	ld	s0,608(sp)
 11a:	25813483          	ld	s1,600(sp)
 11e:	25013903          	ld	s2,592(sp)
 122:	24813983          	ld	s3,584(sp)
 126:	24013a03          	ld	s4,576(sp)
 12a:	23813a83          	ld	s5,568(sp)
 12e:	27010113          	addi	sp,sp,624
 132:	8082                	ret
    fprintf(2, "ls: cannot open %s\n", path);
 134:	864a                	mv	a2,s2
 136:	00001597          	auipc	a1,0x1
 13a:	99a58593          	addi	a1,a1,-1638 # ad0 <malloc+0xe6>
 13e:	4509                	li	a0,2
 140:	7c6000ef          	jal	ra,906 <fprintf>
    return;
 144:	b7f9                	j	112 <ls+0x7a>
    fprintf(2, "ls: cannot stat %s\n", path);
 146:	864a                	mv	a2,s2
 148:	00001597          	auipc	a1,0x1
 14c:	9a058593          	addi	a1,a1,-1632 # ae8 <malloc+0xfe>
 150:	4509                	li	a0,2
 152:	7b4000ef          	jal	ra,906 <fprintf>
    close(fd);
 156:	8526                	mv	a0,s1
 158:	3b6000ef          	jal	ra,50e <close>
    return;
 15c:	bf5d                	j	112 <ls+0x7a>
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 15e:	854a                	mv	a0,s2
 160:	15e000ef          	jal	ra,2be <strlen>
 164:	2541                	addiw	a0,a0,16
 166:	20000793          	li	a5,512
 16a:	00a7f963          	bgeu	a5,a0,17c <ls+0xe4>
      printf("ls: path too long\n");
 16e:	00001517          	auipc	a0,0x1
 172:	9a250513          	addi	a0,a0,-1630 # b10 <malloc+0x126>
 176:	7ba000ef          	jal	ra,930 <printf>
      break;
 17a:	bf49                	j	10c <ls+0x74>
    strcpy(buf, path);
 17c:	85ca                	mv	a1,s2
 17e:	dc040513          	addi	a0,s0,-576
 182:	0f4000ef          	jal	ra,276 <strcpy>
    p = buf+strlen(buf);
 186:	dc040513          	addi	a0,s0,-576
 18a:	134000ef          	jal	ra,2be <strlen>
 18e:	02051913          	slli	s2,a0,0x20
 192:	02095913          	srli	s2,s2,0x20
 196:	dc040793          	addi	a5,s0,-576
 19a:	993e                	add	s2,s2,a5
    *p++ = '/';
 19c:	00190993          	addi	s3,s2,1
 1a0:	02f00793          	li	a5,47
 1a4:	00f90023          	sb	a5,0(s2)
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
 1a8:	00001a17          	auipc	s4,0x1
 1ac:	958a0a13          	addi	s4,s4,-1704 # b00 <malloc+0x116>
        printf("ls: cannot stat %s\n", buf);
 1b0:	00001a97          	auipc	s5,0x1
 1b4:	938a8a93          	addi	s5,s5,-1736 # ae8 <malloc+0xfe>
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 1b8:	a031                	j	1c4 <ls+0x12c>
        printf("ls: cannot stat %s\n", buf);
 1ba:	dc040593          	addi	a1,s0,-576
 1be:	8556                	mv	a0,s5
 1c0:	770000ef          	jal	ra,930 <printf>
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 1c4:	4641                	li	a2,16
 1c6:	db040593          	addi	a1,s0,-592
 1ca:	8526                	mv	a0,s1
 1cc:	332000ef          	jal	ra,4fe <read>
 1d0:	47c1                	li	a5,16
 1d2:	f2f51de3          	bne	a0,a5,10c <ls+0x74>
      if(de.inum == 0)
 1d6:	db045783          	lhu	a5,-592(s0)
 1da:	d7ed                	beqz	a5,1c4 <ls+0x12c>
      memmove(p, de.name, DIRSIZ);
 1dc:	4639                	li	a2,14
 1de:	db240593          	addi	a1,s0,-590
 1e2:	854e                	mv	a0,s3
 1e4:	23e000ef          	jal	ra,422 <memmove>
      p[DIRSIZ] = 0;
 1e8:	000907a3          	sb	zero,15(s2)
      if(stat(buf, &st) < 0){
 1ec:	d9840593          	addi	a1,s0,-616
 1f0:	dc040513          	addi	a0,s0,-576
 1f4:	1aa000ef          	jal	ra,39e <stat>
 1f8:	fc0541e3          	bltz	a0,1ba <ls+0x122>
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
 1fc:	dc040513          	addi	a0,s0,-576
 200:	e01ff0ef          	jal	ra,0 <fmtname>
 204:	85aa                	mv	a1,a0
 206:	da842703          	lw	a4,-600(s0)
 20a:	d9c42683          	lw	a3,-612(s0)
 20e:	da041603          	lh	a2,-608(s0)
 212:	8552                	mv	a0,s4
 214:	71c000ef          	jal	ra,930 <printf>
 218:	b775                	j	1c4 <ls+0x12c>

000000000000021a <main>:

int
main(int argc, char *argv[])
{
 21a:	1101                	addi	sp,sp,-32
 21c:	ec06                	sd	ra,24(sp)
 21e:	e822                	sd	s0,16(sp)
 220:	e426                	sd	s1,8(sp)
 222:	e04a                	sd	s2,0(sp)
 224:	1000                	addi	s0,sp,32
  int i;

  if(argc < 2){
 226:	4785                	li	a5,1
 228:	02a7d563          	bge	a5,a0,252 <main+0x38>
 22c:	00858493          	addi	s1,a1,8
 230:	ffe5091b          	addiw	s2,a0,-2
 234:	02091793          	slli	a5,s2,0x20
 238:	01d7d913          	srli	s2,a5,0x1d
 23c:	05c1                	addi	a1,a1,16
 23e:	992e                	add	s2,s2,a1
    ls(".");
    exit(0);
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
 240:	6088                	ld	a0,0(s1)
 242:	e57ff0ef          	jal	ra,98 <ls>
  for(i=1; i<argc; i++)
 246:	04a1                	addi	s1,s1,8
 248:	ff249ce3          	bne	s1,s2,240 <main+0x26>
  exit(0);
 24c:	4501                	li	a0,0
 24e:	298000ef          	jal	ra,4e6 <exit>
    ls(".");
 252:	00001517          	auipc	a0,0x1
 256:	8d650513          	addi	a0,a0,-1834 # b28 <malloc+0x13e>
 25a:	e3fff0ef          	jal	ra,98 <ls>
    exit(0);
 25e:	4501                	li	a0,0
 260:	286000ef          	jal	ra,4e6 <exit>

0000000000000264 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 264:	1141                	addi	sp,sp,-16
 266:	e406                	sd	ra,8(sp)
 268:	e022                	sd	s0,0(sp)
 26a:	0800                	addi	s0,sp,16
  extern int main();
  main();
 26c:	fafff0ef          	jal	ra,21a <main>
  exit(0);
 270:	4501                	li	a0,0
 272:	274000ef          	jal	ra,4e6 <exit>

0000000000000276 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 276:	1141                	addi	sp,sp,-16
 278:	e422                	sd	s0,8(sp)
 27a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 27c:	87aa                	mv	a5,a0
 27e:	0585                	addi	a1,a1,1
 280:	0785                	addi	a5,a5,1
 282:	fff5c703          	lbu	a4,-1(a1)
 286:	fee78fa3          	sb	a4,-1(a5)
 28a:	fb75                	bnez	a4,27e <strcpy+0x8>
    ;
  return os;
}
 28c:	6422                	ld	s0,8(sp)
 28e:	0141                	addi	sp,sp,16
 290:	8082                	ret

0000000000000292 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 292:	1141                	addi	sp,sp,-16
 294:	e422                	sd	s0,8(sp)
 296:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 298:	00054783          	lbu	a5,0(a0)
 29c:	cb91                	beqz	a5,2b0 <strcmp+0x1e>
 29e:	0005c703          	lbu	a4,0(a1)
 2a2:	00f71763          	bne	a4,a5,2b0 <strcmp+0x1e>
    p++, q++;
 2a6:	0505                	addi	a0,a0,1
 2a8:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2aa:	00054783          	lbu	a5,0(a0)
 2ae:	fbe5                	bnez	a5,29e <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 2b0:	0005c503          	lbu	a0,0(a1)
}
 2b4:	40a7853b          	subw	a0,a5,a0
 2b8:	6422                	ld	s0,8(sp)
 2ba:	0141                	addi	sp,sp,16
 2bc:	8082                	ret

00000000000002be <strlen>:

uint
strlen(const char *s)
{
 2be:	1141                	addi	sp,sp,-16
 2c0:	e422                	sd	s0,8(sp)
 2c2:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2c4:	00054783          	lbu	a5,0(a0)
 2c8:	cf91                	beqz	a5,2e4 <strlen+0x26>
 2ca:	0505                	addi	a0,a0,1
 2cc:	87aa                	mv	a5,a0
 2ce:	4685                	li	a3,1
 2d0:	9e89                	subw	a3,a3,a0
 2d2:	00f6853b          	addw	a0,a3,a5
 2d6:	0785                	addi	a5,a5,1
 2d8:	fff7c703          	lbu	a4,-1(a5)
 2dc:	fb7d                	bnez	a4,2d2 <strlen+0x14>
    ;
  return n;
}
 2de:	6422                	ld	s0,8(sp)
 2e0:	0141                	addi	sp,sp,16
 2e2:	8082                	ret
  for(n = 0; s[n]; n++)
 2e4:	4501                	li	a0,0
 2e6:	bfe5                	j	2de <strlen+0x20>

00000000000002e8 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2e8:	1141                	addi	sp,sp,-16
 2ea:	e422                	sd	s0,8(sp)
 2ec:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2ee:	ca19                	beqz	a2,304 <memset+0x1c>
 2f0:	87aa                	mv	a5,a0
 2f2:	1602                	slli	a2,a2,0x20
 2f4:	9201                	srli	a2,a2,0x20
 2f6:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2fa:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2fe:	0785                	addi	a5,a5,1
 300:	fee79de3          	bne	a5,a4,2fa <memset+0x12>
  }
  return dst;
}
 304:	6422                	ld	s0,8(sp)
 306:	0141                	addi	sp,sp,16
 308:	8082                	ret

000000000000030a <strchr>:

char*
strchr(const char *s, char c)
{
 30a:	1141                	addi	sp,sp,-16
 30c:	e422                	sd	s0,8(sp)
 30e:	0800                	addi	s0,sp,16
  for(; *s; s++)
 310:	00054783          	lbu	a5,0(a0)
 314:	cb99                	beqz	a5,32a <strchr+0x20>
    if(*s == c)
 316:	00f58763          	beq	a1,a5,324 <strchr+0x1a>
  for(; *s; s++)
 31a:	0505                	addi	a0,a0,1
 31c:	00054783          	lbu	a5,0(a0)
 320:	fbfd                	bnez	a5,316 <strchr+0xc>
      return (char*)s;
  return 0;
 322:	4501                	li	a0,0
}
 324:	6422                	ld	s0,8(sp)
 326:	0141                	addi	sp,sp,16
 328:	8082                	ret
  return 0;
 32a:	4501                	li	a0,0
 32c:	bfe5                	j	324 <strchr+0x1a>

000000000000032e <gets>:

char*
gets(char *buf, int max)
{
 32e:	711d                	addi	sp,sp,-96
 330:	ec86                	sd	ra,88(sp)
 332:	e8a2                	sd	s0,80(sp)
 334:	e4a6                	sd	s1,72(sp)
 336:	e0ca                	sd	s2,64(sp)
 338:	fc4e                	sd	s3,56(sp)
 33a:	f852                	sd	s4,48(sp)
 33c:	f456                	sd	s5,40(sp)
 33e:	f05a                	sd	s6,32(sp)
 340:	ec5e                	sd	s7,24(sp)
 342:	1080                	addi	s0,sp,96
 344:	8baa                	mv	s7,a0
 346:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 348:	892a                	mv	s2,a0
 34a:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 34c:	4aa9                	li	s5,10
 34e:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 350:	89a6                	mv	s3,s1
 352:	2485                	addiw	s1,s1,1
 354:	0344d663          	bge	s1,s4,380 <gets+0x52>
    cc = read(0, &c, 1);
 358:	4605                	li	a2,1
 35a:	faf40593          	addi	a1,s0,-81
 35e:	4501                	li	a0,0
 360:	19e000ef          	jal	ra,4fe <read>
    if(cc < 1)
 364:	00a05e63          	blez	a0,380 <gets+0x52>
    buf[i++] = c;
 368:	faf44783          	lbu	a5,-81(s0)
 36c:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 370:	01578763          	beq	a5,s5,37e <gets+0x50>
 374:	0905                	addi	s2,s2,1
 376:	fd679de3          	bne	a5,s6,350 <gets+0x22>
  for(i=0; i+1 < max; ){
 37a:	89a6                	mv	s3,s1
 37c:	a011                	j	380 <gets+0x52>
 37e:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 380:	99de                	add	s3,s3,s7
 382:	00098023          	sb	zero,0(s3)
  return buf;
}
 386:	855e                	mv	a0,s7
 388:	60e6                	ld	ra,88(sp)
 38a:	6446                	ld	s0,80(sp)
 38c:	64a6                	ld	s1,72(sp)
 38e:	6906                	ld	s2,64(sp)
 390:	79e2                	ld	s3,56(sp)
 392:	7a42                	ld	s4,48(sp)
 394:	7aa2                	ld	s5,40(sp)
 396:	7b02                	ld	s6,32(sp)
 398:	6be2                	ld	s7,24(sp)
 39a:	6125                	addi	sp,sp,96
 39c:	8082                	ret

000000000000039e <stat>:

int
stat(const char *n, struct stat *st)
{
 39e:	1101                	addi	sp,sp,-32
 3a0:	ec06                	sd	ra,24(sp)
 3a2:	e822                	sd	s0,16(sp)
 3a4:	e426                	sd	s1,8(sp)
 3a6:	e04a                	sd	s2,0(sp)
 3a8:	1000                	addi	s0,sp,32
 3aa:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3ac:	4581                	li	a1,0
 3ae:	178000ef          	jal	ra,526 <open>
  if(fd < 0)
 3b2:	02054163          	bltz	a0,3d4 <stat+0x36>
 3b6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3b8:	85ca                	mv	a1,s2
 3ba:	184000ef          	jal	ra,53e <fstat>
 3be:	892a                	mv	s2,a0
  close(fd);
 3c0:	8526                	mv	a0,s1
 3c2:	14c000ef          	jal	ra,50e <close>
  return r;
}
 3c6:	854a                	mv	a0,s2
 3c8:	60e2                	ld	ra,24(sp)
 3ca:	6442                	ld	s0,16(sp)
 3cc:	64a2                	ld	s1,8(sp)
 3ce:	6902                	ld	s2,0(sp)
 3d0:	6105                	addi	sp,sp,32
 3d2:	8082                	ret
    return -1;
 3d4:	597d                	li	s2,-1
 3d6:	bfc5                	j	3c6 <stat+0x28>

00000000000003d8 <atoi>:

int
atoi(const char *s)
{
 3d8:	1141                	addi	sp,sp,-16
 3da:	e422                	sd	s0,8(sp)
 3dc:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3de:	00054603          	lbu	a2,0(a0)
 3e2:	fd06079b          	addiw	a5,a2,-48
 3e6:	0ff7f793          	zext.b	a5,a5
 3ea:	4725                	li	a4,9
 3ec:	02f76963          	bltu	a4,a5,41e <atoi+0x46>
 3f0:	86aa                	mv	a3,a0
  n = 0;
 3f2:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 3f4:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 3f6:	0685                	addi	a3,a3,1
 3f8:	0025179b          	slliw	a5,a0,0x2
 3fc:	9fa9                	addw	a5,a5,a0
 3fe:	0017979b          	slliw	a5,a5,0x1
 402:	9fb1                	addw	a5,a5,a2
 404:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 408:	0006c603          	lbu	a2,0(a3)
 40c:	fd06071b          	addiw	a4,a2,-48
 410:	0ff77713          	zext.b	a4,a4
 414:	fee5f1e3          	bgeu	a1,a4,3f6 <atoi+0x1e>
  return n;
}
 418:	6422                	ld	s0,8(sp)
 41a:	0141                	addi	sp,sp,16
 41c:	8082                	ret
  n = 0;
 41e:	4501                	li	a0,0
 420:	bfe5                	j	418 <atoi+0x40>

0000000000000422 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 422:	1141                	addi	sp,sp,-16
 424:	e422                	sd	s0,8(sp)
 426:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 428:	02b57463          	bgeu	a0,a1,450 <memmove+0x2e>
    while(n-- > 0)
 42c:	00c05f63          	blez	a2,44a <memmove+0x28>
 430:	1602                	slli	a2,a2,0x20
 432:	9201                	srli	a2,a2,0x20
 434:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 438:	872a                	mv	a4,a0
      *dst++ = *src++;
 43a:	0585                	addi	a1,a1,1
 43c:	0705                	addi	a4,a4,1
 43e:	fff5c683          	lbu	a3,-1(a1)
 442:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 446:	fee79ae3          	bne	a5,a4,43a <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 44a:	6422                	ld	s0,8(sp)
 44c:	0141                	addi	sp,sp,16
 44e:	8082                	ret
    dst += n;
 450:	00c50733          	add	a4,a0,a2
    src += n;
 454:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 456:	fec05ae3          	blez	a2,44a <memmove+0x28>
 45a:	fff6079b          	addiw	a5,a2,-1
 45e:	1782                	slli	a5,a5,0x20
 460:	9381                	srli	a5,a5,0x20
 462:	fff7c793          	not	a5,a5
 466:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 468:	15fd                	addi	a1,a1,-1
 46a:	177d                	addi	a4,a4,-1
 46c:	0005c683          	lbu	a3,0(a1)
 470:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 474:	fee79ae3          	bne	a5,a4,468 <memmove+0x46>
 478:	bfc9                	j	44a <memmove+0x28>

000000000000047a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 47a:	1141                	addi	sp,sp,-16
 47c:	e422                	sd	s0,8(sp)
 47e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 480:	ca05                	beqz	a2,4b0 <memcmp+0x36>
 482:	fff6069b          	addiw	a3,a2,-1
 486:	1682                	slli	a3,a3,0x20
 488:	9281                	srli	a3,a3,0x20
 48a:	0685                	addi	a3,a3,1
 48c:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 48e:	00054783          	lbu	a5,0(a0)
 492:	0005c703          	lbu	a4,0(a1)
 496:	00e79863          	bne	a5,a4,4a6 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 49a:	0505                	addi	a0,a0,1
    p2++;
 49c:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 49e:	fed518e3          	bne	a0,a3,48e <memcmp+0x14>
  }
  return 0;
 4a2:	4501                	li	a0,0
 4a4:	a019                	j	4aa <memcmp+0x30>
      return *p1 - *p2;
 4a6:	40e7853b          	subw	a0,a5,a4
}
 4aa:	6422                	ld	s0,8(sp)
 4ac:	0141                	addi	sp,sp,16
 4ae:	8082                	ret
  return 0;
 4b0:	4501                	li	a0,0
 4b2:	bfe5                	j	4aa <memcmp+0x30>

00000000000004b4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4b4:	1141                	addi	sp,sp,-16
 4b6:	e406                	sd	ra,8(sp)
 4b8:	e022                	sd	s0,0(sp)
 4ba:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4bc:	f67ff0ef          	jal	ra,422 <memmove>
}
 4c0:	60a2                	ld	ra,8(sp)
 4c2:	6402                	ld	s0,0(sp)
 4c4:	0141                	addi	sp,sp,16
 4c6:	8082                	ret

00000000000004c8 <ugetpid>:

#ifdef LAB_PGTBL
int
ugetpid(void)
{
 4c8:	1141                	addi	sp,sp,-16
 4ca:	e422                	sd	s0,8(sp)
 4cc:	0800                	addi	s0,sp,16
  struct usyscall *u = (struct usyscall *)USYSCALL;
  return u->pid;
 4ce:	040007b7          	lui	a5,0x4000
}
 4d2:	17f5                	addi	a5,a5,-3
 4d4:	07b2                	slli	a5,a5,0xc
 4d6:	4388                	lw	a0,0(a5)
 4d8:	6422                	ld	s0,8(sp)
 4da:	0141                	addi	sp,sp,16
 4dc:	8082                	ret

00000000000004de <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4de:	4885                	li	a7,1
 ecall
 4e0:	00000073          	ecall
 ret
 4e4:	8082                	ret

00000000000004e6 <exit>:
.global exit
exit:
 li a7, SYS_exit
 4e6:	4889                	li	a7,2
 ecall
 4e8:	00000073          	ecall
 ret
 4ec:	8082                	ret

00000000000004ee <wait>:
.global wait
wait:
 li a7, SYS_wait
 4ee:	488d                	li	a7,3
 ecall
 4f0:	00000073          	ecall
 ret
 4f4:	8082                	ret

00000000000004f6 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4f6:	4891                	li	a7,4
 ecall
 4f8:	00000073          	ecall
 ret
 4fc:	8082                	ret

00000000000004fe <read>:
.global read
read:
 li a7, SYS_read
 4fe:	4895                	li	a7,5
 ecall
 500:	00000073          	ecall
 ret
 504:	8082                	ret

0000000000000506 <write>:
.global write
write:
 li a7, SYS_write
 506:	48c1                	li	a7,16
 ecall
 508:	00000073          	ecall
 ret
 50c:	8082                	ret

000000000000050e <close>:
.global close
close:
 li a7, SYS_close
 50e:	48d5                	li	a7,21
 ecall
 510:	00000073          	ecall
 ret
 514:	8082                	ret

0000000000000516 <kill>:
.global kill
kill:
 li a7, SYS_kill
 516:	4899                	li	a7,6
 ecall
 518:	00000073          	ecall
 ret
 51c:	8082                	ret

000000000000051e <exec>:
.global exec
exec:
 li a7, SYS_exec
 51e:	489d                	li	a7,7
 ecall
 520:	00000073          	ecall
 ret
 524:	8082                	ret

0000000000000526 <open>:
.global open
open:
 li a7, SYS_open
 526:	48bd                	li	a7,15
 ecall
 528:	00000073          	ecall
 ret
 52c:	8082                	ret

000000000000052e <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 52e:	48c5                	li	a7,17
 ecall
 530:	00000073          	ecall
 ret
 534:	8082                	ret

0000000000000536 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 536:	48c9                	li	a7,18
 ecall
 538:	00000073          	ecall
 ret
 53c:	8082                	ret

000000000000053e <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 53e:	48a1                	li	a7,8
 ecall
 540:	00000073          	ecall
 ret
 544:	8082                	ret

0000000000000546 <link>:
.global link
link:
 li a7, SYS_link
 546:	48cd                	li	a7,19
 ecall
 548:	00000073          	ecall
 ret
 54c:	8082                	ret

000000000000054e <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 54e:	48d1                	li	a7,20
 ecall
 550:	00000073          	ecall
 ret
 554:	8082                	ret

0000000000000556 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 556:	48a5                	li	a7,9
 ecall
 558:	00000073          	ecall
 ret
 55c:	8082                	ret

000000000000055e <dup>:
.global dup
dup:
 li a7, SYS_dup
 55e:	48a9                	li	a7,10
 ecall
 560:	00000073          	ecall
 ret
 564:	8082                	ret

0000000000000566 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 566:	48ad                	li	a7,11
 ecall
 568:	00000073          	ecall
 ret
 56c:	8082                	ret

000000000000056e <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 56e:	48b1                	li	a7,12
 ecall
 570:	00000073          	ecall
 ret
 574:	8082                	ret

0000000000000576 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 576:	48b5                	li	a7,13
 ecall
 578:	00000073          	ecall
 ret
 57c:	8082                	ret

000000000000057e <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 57e:	48b9                	li	a7,14
 ecall
 580:	00000073          	ecall
 ret
 584:	8082                	ret

0000000000000586 <bind>:
.global bind
bind:
 li a7, SYS_bind
 586:	48f5                	li	a7,29
 ecall
 588:	00000073          	ecall
 ret
 58c:	8082                	ret

000000000000058e <unbind>:
.global unbind
unbind:
 li a7, SYS_unbind
 58e:	48f9                	li	a7,30
 ecall
 590:	00000073          	ecall
 ret
 594:	8082                	ret

0000000000000596 <send>:
.global send
send:
 li a7, SYS_send
 596:	48fd                	li	a7,31
 ecall
 598:	00000073          	ecall
 ret
 59c:	8082                	ret

000000000000059e <recv>:
.global recv
recv:
 li a7, SYS_recv
 59e:	02000893          	li	a7,32
 ecall
 5a2:	00000073          	ecall
 ret
 5a6:	8082                	ret

00000000000005a8 <pgpte>:
.global pgpte
pgpte:
 li a7, SYS_pgpte
 5a8:	02100893          	li	a7,33
 ecall
 5ac:	00000073          	ecall
 ret
 5b0:	8082                	ret

00000000000005b2 <kpgtbl>:
.global kpgtbl
kpgtbl:
 li a7, SYS_kpgtbl
 5b2:	02200893          	li	a7,34
 ecall
 5b6:	00000073          	ecall
 ret
 5ba:	8082                	ret

00000000000005bc <pgaccess>:
.global pgaccess
pgaccess:
 li a7, SYS_pgaccess
 5bc:	02300893          	li	a7,35
 ecall
 5c0:	00000073          	ecall
 ret
 5c4:	8082                	ret

00000000000005c6 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5c6:	1101                	addi	sp,sp,-32
 5c8:	ec06                	sd	ra,24(sp)
 5ca:	e822                	sd	s0,16(sp)
 5cc:	1000                	addi	s0,sp,32
 5ce:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5d2:	4605                	li	a2,1
 5d4:	fef40593          	addi	a1,s0,-17
 5d8:	f2fff0ef          	jal	ra,506 <write>
}
 5dc:	60e2                	ld	ra,24(sp)
 5de:	6442                	ld	s0,16(sp)
 5e0:	6105                	addi	sp,sp,32
 5e2:	8082                	ret

00000000000005e4 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 5e4:	7139                	addi	sp,sp,-64
 5e6:	fc06                	sd	ra,56(sp)
 5e8:	f822                	sd	s0,48(sp)
 5ea:	f426                	sd	s1,40(sp)
 5ec:	f04a                	sd	s2,32(sp)
 5ee:	ec4e                	sd	s3,24(sp)
 5f0:	0080                	addi	s0,sp,64
 5f2:	84aa                	mv	s1,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 5f4:	c299                	beqz	a3,5fa <printint+0x16>
 5f6:	0805c663          	bltz	a1,682 <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 5fa:	2581                	sext.w	a1,a1
  neg = 0;
 5fc:	4881                	li	a7,0
 5fe:	fc040693          	addi	a3,s0,-64
  }

  i = 0;
 602:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 604:	2601                	sext.w	a2,a2
 606:	00000517          	auipc	a0,0x0
 60a:	53250513          	addi	a0,a0,1330 # b38 <digits>
 60e:	883a                	mv	a6,a4
 610:	2705                	addiw	a4,a4,1
 612:	02c5f7bb          	remuw	a5,a1,a2
 616:	1782                	slli	a5,a5,0x20
 618:	9381                	srli	a5,a5,0x20
 61a:	97aa                	add	a5,a5,a0
 61c:	0007c783          	lbu	a5,0(a5) # 4000000 <base+0x3ffefe0>
 620:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 624:	0005879b          	sext.w	a5,a1
 628:	02c5d5bb          	divuw	a1,a1,a2
 62c:	0685                	addi	a3,a3,1
 62e:	fec7f0e3          	bgeu	a5,a2,60e <printint+0x2a>
  if(neg)
 632:	00088b63          	beqz	a7,648 <printint+0x64>
    buf[i++] = '-';
 636:	fd040793          	addi	a5,s0,-48
 63a:	973e                	add	a4,a4,a5
 63c:	02d00793          	li	a5,45
 640:	fef70823          	sb	a5,-16(a4)
 644:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 648:	02e05663          	blez	a4,674 <printint+0x90>
 64c:	fc040793          	addi	a5,s0,-64
 650:	00e78933          	add	s2,a5,a4
 654:	fff78993          	addi	s3,a5,-1
 658:	99ba                	add	s3,s3,a4
 65a:	377d                	addiw	a4,a4,-1
 65c:	1702                	slli	a4,a4,0x20
 65e:	9301                	srli	a4,a4,0x20
 660:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 664:	fff94583          	lbu	a1,-1(s2)
 668:	8526                	mv	a0,s1
 66a:	f5dff0ef          	jal	ra,5c6 <putc>
  while(--i >= 0)
 66e:	197d                	addi	s2,s2,-1
 670:	ff391ae3          	bne	s2,s3,664 <printint+0x80>
}
 674:	70e2                	ld	ra,56(sp)
 676:	7442                	ld	s0,48(sp)
 678:	74a2                	ld	s1,40(sp)
 67a:	7902                	ld	s2,32(sp)
 67c:	69e2                	ld	s3,24(sp)
 67e:	6121                	addi	sp,sp,64
 680:	8082                	ret
    x = -xx;
 682:	40b005bb          	negw	a1,a1
    neg = 1;
 686:	4885                	li	a7,1
    x = -xx;
 688:	bf9d                	j	5fe <printint+0x1a>

000000000000068a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 68a:	7119                	addi	sp,sp,-128
 68c:	fc86                	sd	ra,120(sp)
 68e:	f8a2                	sd	s0,112(sp)
 690:	f4a6                	sd	s1,104(sp)
 692:	f0ca                	sd	s2,96(sp)
 694:	ecce                	sd	s3,88(sp)
 696:	e8d2                	sd	s4,80(sp)
 698:	e4d6                	sd	s5,72(sp)
 69a:	e0da                	sd	s6,64(sp)
 69c:	fc5e                	sd	s7,56(sp)
 69e:	f862                	sd	s8,48(sp)
 6a0:	f466                	sd	s9,40(sp)
 6a2:	f06a                	sd	s10,32(sp)
 6a4:	ec6e                	sd	s11,24(sp)
 6a6:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6a8:	0005c903          	lbu	s2,0(a1)
 6ac:	22090e63          	beqz	s2,8e8 <vprintf+0x25e>
 6b0:	8b2a                	mv	s6,a0
 6b2:	8a2e                	mv	s4,a1
 6b4:	8bb2                	mv	s7,a2
  state = 0;
 6b6:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6b8:	4481                	li	s1,0
 6ba:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6bc:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6c0:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 6c4:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 6c8:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6cc:	00000c97          	auipc	s9,0x0
 6d0:	46cc8c93          	addi	s9,s9,1132 # b38 <digits>
 6d4:	a005                	j	6f4 <vprintf+0x6a>
        putc(fd, c0);
 6d6:	85ca                	mv	a1,s2
 6d8:	855a                	mv	a0,s6
 6da:	eedff0ef          	jal	ra,5c6 <putc>
 6de:	a019                	j	6e4 <vprintf+0x5a>
    } else if(state == '%'){
 6e0:	03598263          	beq	s3,s5,704 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 6e4:	2485                	addiw	s1,s1,1
 6e6:	8726                	mv	a4,s1
 6e8:	009a07b3          	add	a5,s4,s1
 6ec:	0007c903          	lbu	s2,0(a5)
 6f0:	1e090c63          	beqz	s2,8e8 <vprintf+0x25e>
    c0 = fmt[i] & 0xff;
 6f4:	0009079b          	sext.w	a5,s2
    if(state == 0){
 6f8:	fe0994e3          	bnez	s3,6e0 <vprintf+0x56>
      if(c0 == '%'){
 6fc:	fd579de3          	bne	a5,s5,6d6 <vprintf+0x4c>
        state = '%';
 700:	89be                	mv	s3,a5
 702:	b7cd                	j	6e4 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 704:	cfa5                	beqz	a5,77c <vprintf+0xf2>
 706:	00ea06b3          	add	a3,s4,a4
 70a:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 70e:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 710:	c681                	beqz	a3,718 <vprintf+0x8e>
 712:	9752                	add	a4,a4,s4
 714:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 718:	03878a63          	beq	a5,s8,74c <vprintf+0xc2>
      } else if(c0 == 'l' && c1 == 'd'){
 71c:	05a78463          	beq	a5,s10,764 <vprintf+0xda>
      } else if(c0 == 'u'){
 720:	0db78763          	beq	a5,s11,7ee <vprintf+0x164>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 724:	07800713          	li	a4,120
 728:	10e78963          	beq	a5,a4,83a <vprintf+0x1b0>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 72c:	07000713          	li	a4,112
 730:	12e78e63          	beq	a5,a4,86c <vprintf+0x1e2>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 734:	07300713          	li	a4,115
 738:	16e78b63          	beq	a5,a4,8ae <vprintf+0x224>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 73c:	05579063          	bne	a5,s5,77c <vprintf+0xf2>
        putc(fd, '%');
 740:	85d6                	mv	a1,s5
 742:	855a                	mv	a0,s6
 744:	e83ff0ef          	jal	ra,5c6 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 748:	4981                	li	s3,0
 74a:	bf69                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 74c:	008b8913          	addi	s2,s7,8
 750:	4685                	li	a3,1
 752:	4629                	li	a2,10
 754:	000ba583          	lw	a1,0(s7)
 758:	855a                	mv	a0,s6
 75a:	e8bff0ef          	jal	ra,5e4 <printint>
 75e:	8bca                	mv	s7,s2
      state = 0;
 760:	4981                	li	s3,0
 762:	b749                	j	6e4 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 764:	03868663          	beq	a3,s8,790 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 768:	05a68163          	beq	a3,s10,7aa <vprintf+0x120>
      } else if(c0 == 'l' && c1 == 'u'){
 76c:	09b68d63          	beq	a3,s11,806 <vprintf+0x17c>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 770:	03a68f63          	beq	a3,s10,7ae <vprintf+0x124>
      } else if(c0 == 'l' && c1 == 'x'){
 774:	07800793          	li	a5,120
 778:	0cf68d63          	beq	a3,a5,852 <vprintf+0x1c8>
        putc(fd, '%');
 77c:	85d6                	mv	a1,s5
 77e:	855a                	mv	a0,s6
 780:	e47ff0ef          	jal	ra,5c6 <putc>
        putc(fd, c0);
 784:	85ca                	mv	a1,s2
 786:	855a                	mv	a0,s6
 788:	e3fff0ef          	jal	ra,5c6 <putc>
      state = 0;
 78c:	4981                	li	s3,0
 78e:	bf99                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 790:	008b8913          	addi	s2,s7,8
 794:	4685                	li	a3,1
 796:	4629                	li	a2,10
 798:	000ba583          	lw	a1,0(s7)
 79c:	855a                	mv	a0,s6
 79e:	e47ff0ef          	jal	ra,5e4 <printint>
        i += 1;
 7a2:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 7a4:	8bca                	mv	s7,s2
      state = 0;
 7a6:	4981                	li	s3,0
        i += 1;
 7a8:	bf35                	j	6e4 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7aa:	03860563          	beq	a2,s8,7d4 <vprintf+0x14a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7ae:	07b60963          	beq	a2,s11,820 <vprintf+0x196>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 7b2:	07800793          	li	a5,120
 7b6:	fcf613e3          	bne	a2,a5,77c <vprintf+0xf2>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ba:	008b8913          	addi	s2,s7,8
 7be:	4681                	li	a3,0
 7c0:	4641                	li	a2,16
 7c2:	000ba583          	lw	a1,0(s7)
 7c6:	855a                	mv	a0,s6
 7c8:	e1dff0ef          	jal	ra,5e4 <printint>
        i += 2;
 7cc:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ce:	8bca                	mv	s7,s2
      state = 0;
 7d0:	4981                	li	s3,0
        i += 2;
 7d2:	bf09                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 7d4:	008b8913          	addi	s2,s7,8
 7d8:	4685                	li	a3,1
 7da:	4629                	li	a2,10
 7dc:	000ba583          	lw	a1,0(s7)
 7e0:	855a                	mv	a0,s6
 7e2:	e03ff0ef          	jal	ra,5e4 <printint>
        i += 2;
 7e6:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 7e8:	8bca                	mv	s7,s2
      state = 0;
 7ea:	4981                	li	s3,0
        i += 2;
 7ec:	bde5                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 0);
 7ee:	008b8913          	addi	s2,s7,8
 7f2:	4681                	li	a3,0
 7f4:	4629                	li	a2,10
 7f6:	000ba583          	lw	a1,0(s7)
 7fa:	855a                	mv	a0,s6
 7fc:	de9ff0ef          	jal	ra,5e4 <printint>
 800:	8bca                	mv	s7,s2
      state = 0;
 802:	4981                	li	s3,0
 804:	b5c5                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 806:	008b8913          	addi	s2,s7,8
 80a:	4681                	li	a3,0
 80c:	4629                	li	a2,10
 80e:	000ba583          	lw	a1,0(s7)
 812:	855a                	mv	a0,s6
 814:	dd1ff0ef          	jal	ra,5e4 <printint>
        i += 1;
 818:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 81a:	8bca                	mv	s7,s2
      state = 0;
 81c:	4981                	li	s3,0
        i += 1;
 81e:	b5d9                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 820:	008b8913          	addi	s2,s7,8
 824:	4681                	li	a3,0
 826:	4629                	li	a2,10
 828:	000ba583          	lw	a1,0(s7)
 82c:	855a                	mv	a0,s6
 82e:	db7ff0ef          	jal	ra,5e4 <printint>
        i += 2;
 832:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 834:	8bca                	mv	s7,s2
      state = 0;
 836:	4981                	li	s3,0
        i += 2;
 838:	b575                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 16, 0);
 83a:	008b8913          	addi	s2,s7,8
 83e:	4681                	li	a3,0
 840:	4641                	li	a2,16
 842:	000ba583          	lw	a1,0(s7)
 846:	855a                	mv	a0,s6
 848:	d9dff0ef          	jal	ra,5e4 <printint>
 84c:	8bca                	mv	s7,s2
      state = 0;
 84e:	4981                	li	s3,0
 850:	bd51                	j	6e4 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 852:	008b8913          	addi	s2,s7,8
 856:	4681                	li	a3,0
 858:	4641                	li	a2,16
 85a:	000ba583          	lw	a1,0(s7)
 85e:	855a                	mv	a0,s6
 860:	d85ff0ef          	jal	ra,5e4 <printint>
        i += 1;
 864:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 866:	8bca                	mv	s7,s2
      state = 0;
 868:	4981                	li	s3,0
        i += 1;
 86a:	bdad                	j	6e4 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 86c:	008b8793          	addi	a5,s7,8
 870:	f8f43423          	sd	a5,-120(s0)
 874:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 878:	03000593          	li	a1,48
 87c:	855a                	mv	a0,s6
 87e:	d49ff0ef          	jal	ra,5c6 <putc>
  putc(fd, 'x');
 882:	07800593          	li	a1,120
 886:	855a                	mv	a0,s6
 888:	d3fff0ef          	jal	ra,5c6 <putc>
 88c:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 88e:	03c9d793          	srli	a5,s3,0x3c
 892:	97e6                	add	a5,a5,s9
 894:	0007c583          	lbu	a1,0(a5)
 898:	855a                	mv	a0,s6
 89a:	d2dff0ef          	jal	ra,5c6 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 89e:	0992                	slli	s3,s3,0x4
 8a0:	397d                	addiw	s2,s2,-1
 8a2:	fe0916e3          	bnez	s2,88e <vprintf+0x204>
        printptr(fd, va_arg(ap, uint64));
 8a6:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 8aa:	4981                	li	s3,0
 8ac:	bd25                	j	6e4 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 8ae:	008b8993          	addi	s3,s7,8
 8b2:	000bb903          	ld	s2,0(s7)
 8b6:	00090f63          	beqz	s2,8d4 <vprintf+0x24a>
        for(; *s; s++)
 8ba:	00094583          	lbu	a1,0(s2)
 8be:	c195                	beqz	a1,8e2 <vprintf+0x258>
          putc(fd, *s);
 8c0:	855a                	mv	a0,s6
 8c2:	d05ff0ef          	jal	ra,5c6 <putc>
        for(; *s; s++)
 8c6:	0905                	addi	s2,s2,1
 8c8:	00094583          	lbu	a1,0(s2)
 8cc:	f9f5                	bnez	a1,8c0 <vprintf+0x236>
        if((s = va_arg(ap, char*)) == 0)
 8ce:	8bce                	mv	s7,s3
      state = 0;
 8d0:	4981                	li	s3,0
 8d2:	bd09                	j	6e4 <vprintf+0x5a>
          s = "(null)";
 8d4:	00000917          	auipc	s2,0x0
 8d8:	25c90913          	addi	s2,s2,604 # b30 <malloc+0x146>
        for(; *s; s++)
 8dc:	02800593          	li	a1,40
 8e0:	b7c5                	j	8c0 <vprintf+0x236>
        if((s = va_arg(ap, char*)) == 0)
 8e2:	8bce                	mv	s7,s3
      state = 0;
 8e4:	4981                	li	s3,0
 8e6:	bbfd                	j	6e4 <vprintf+0x5a>
    }
  }
}
 8e8:	70e6                	ld	ra,120(sp)
 8ea:	7446                	ld	s0,112(sp)
 8ec:	74a6                	ld	s1,104(sp)
 8ee:	7906                	ld	s2,96(sp)
 8f0:	69e6                	ld	s3,88(sp)
 8f2:	6a46                	ld	s4,80(sp)
 8f4:	6aa6                	ld	s5,72(sp)
 8f6:	6b06                	ld	s6,64(sp)
 8f8:	7be2                	ld	s7,56(sp)
 8fa:	7c42                	ld	s8,48(sp)
 8fc:	7ca2                	ld	s9,40(sp)
 8fe:	7d02                	ld	s10,32(sp)
 900:	6de2                	ld	s11,24(sp)
 902:	6109                	addi	sp,sp,128
 904:	8082                	ret

0000000000000906 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 906:	715d                	addi	sp,sp,-80
 908:	ec06                	sd	ra,24(sp)
 90a:	e822                	sd	s0,16(sp)
 90c:	1000                	addi	s0,sp,32
 90e:	e010                	sd	a2,0(s0)
 910:	e414                	sd	a3,8(s0)
 912:	e818                	sd	a4,16(s0)
 914:	ec1c                	sd	a5,24(s0)
 916:	03043023          	sd	a6,32(s0)
 91a:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 91e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 922:	8622                	mv	a2,s0
 924:	d67ff0ef          	jal	ra,68a <vprintf>
}
 928:	60e2                	ld	ra,24(sp)
 92a:	6442                	ld	s0,16(sp)
 92c:	6161                	addi	sp,sp,80
 92e:	8082                	ret

0000000000000930 <printf>:

void
printf(const char *fmt, ...)
{
 930:	711d                	addi	sp,sp,-96
 932:	ec06                	sd	ra,24(sp)
 934:	e822                	sd	s0,16(sp)
 936:	1000                	addi	s0,sp,32
 938:	e40c                	sd	a1,8(s0)
 93a:	e810                	sd	a2,16(s0)
 93c:	ec14                	sd	a3,24(s0)
 93e:	f018                	sd	a4,32(s0)
 940:	f41c                	sd	a5,40(s0)
 942:	03043823          	sd	a6,48(s0)
 946:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 94a:	00840613          	addi	a2,s0,8
 94e:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 952:	85aa                	mv	a1,a0
 954:	4505                	li	a0,1
 956:	d35ff0ef          	jal	ra,68a <vprintf>
}
 95a:	60e2                	ld	ra,24(sp)
 95c:	6442                	ld	s0,16(sp)
 95e:	6125                	addi	sp,sp,96
 960:	8082                	ret

0000000000000962 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 962:	1141                	addi	sp,sp,-16
 964:	e422                	sd	s0,8(sp)
 966:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 968:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 96c:	00000797          	auipc	a5,0x0
 970:	6947b783          	ld	a5,1684(a5) # 1000 <freep>
 974:	a805                	j	9a4 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 976:	4618                	lw	a4,8(a2)
 978:	9db9                	addw	a1,a1,a4
 97a:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 97e:	6398                	ld	a4,0(a5)
 980:	6318                	ld	a4,0(a4)
 982:	fee53823          	sd	a4,-16(a0)
 986:	a091                	j	9ca <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 988:	ff852703          	lw	a4,-8(a0)
 98c:	9e39                	addw	a2,a2,a4
 98e:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 990:	ff053703          	ld	a4,-16(a0)
 994:	e398                	sd	a4,0(a5)
 996:	a099                	j	9dc <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 998:	6398                	ld	a4,0(a5)
 99a:	00e7e463          	bltu	a5,a4,9a2 <free+0x40>
 99e:	00e6ea63          	bltu	a3,a4,9b2 <free+0x50>
{
 9a2:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9a4:	fed7fae3          	bgeu	a5,a3,998 <free+0x36>
 9a8:	6398                	ld	a4,0(a5)
 9aa:	00e6e463          	bltu	a3,a4,9b2 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9ae:	fee7eae3          	bltu	a5,a4,9a2 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 9b2:	ff852583          	lw	a1,-8(a0)
 9b6:	6390                	ld	a2,0(a5)
 9b8:	02059813          	slli	a6,a1,0x20
 9bc:	01c85713          	srli	a4,a6,0x1c
 9c0:	9736                	add	a4,a4,a3
 9c2:	fae60ae3          	beq	a2,a4,976 <free+0x14>
    bp->s.ptr = p->s.ptr;
 9c6:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 9ca:	4790                	lw	a2,8(a5)
 9cc:	02061593          	slli	a1,a2,0x20
 9d0:	01c5d713          	srli	a4,a1,0x1c
 9d4:	973e                	add	a4,a4,a5
 9d6:	fae689e3          	beq	a3,a4,988 <free+0x26>
  } else
    p->s.ptr = bp;
 9da:	e394                	sd	a3,0(a5)
  freep = p;
 9dc:	00000717          	auipc	a4,0x0
 9e0:	62f73223          	sd	a5,1572(a4) # 1000 <freep>
}
 9e4:	6422                	ld	s0,8(sp)
 9e6:	0141                	addi	sp,sp,16
 9e8:	8082                	ret

00000000000009ea <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 9ea:	7139                	addi	sp,sp,-64
 9ec:	fc06                	sd	ra,56(sp)
 9ee:	f822                	sd	s0,48(sp)
 9f0:	f426                	sd	s1,40(sp)
 9f2:	f04a                	sd	s2,32(sp)
 9f4:	ec4e                	sd	s3,24(sp)
 9f6:	e852                	sd	s4,16(sp)
 9f8:	e456                	sd	s5,8(sp)
 9fa:	e05a                	sd	s6,0(sp)
 9fc:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 9fe:	02051493          	slli	s1,a0,0x20
 a02:	9081                	srli	s1,s1,0x20
 a04:	04bd                	addi	s1,s1,15
 a06:	8091                	srli	s1,s1,0x4
 a08:	0014899b          	addiw	s3,s1,1
 a0c:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 a0e:	00000517          	auipc	a0,0x0
 a12:	5f253503          	ld	a0,1522(a0) # 1000 <freep>
 a16:	c515                	beqz	a0,a42 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a18:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a1a:	4798                	lw	a4,8(a5)
 a1c:	02977f63          	bgeu	a4,s1,a5a <malloc+0x70>
 a20:	8a4e                	mv	s4,s3
 a22:	0009871b          	sext.w	a4,s3
 a26:	6685                	lui	a3,0x1
 a28:	00d77363          	bgeu	a4,a3,a2e <malloc+0x44>
 a2c:	6a05                	lui	s4,0x1
 a2e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a32:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a36:	00000917          	auipc	s2,0x0
 a3a:	5ca90913          	addi	s2,s2,1482 # 1000 <freep>
  if(p == (char*)-1)
 a3e:	5afd                	li	s5,-1
 a40:	a885                	j	ab0 <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 a42:	00000797          	auipc	a5,0x0
 a46:	5de78793          	addi	a5,a5,1502 # 1020 <base>
 a4a:	00000717          	auipc	a4,0x0
 a4e:	5af73b23          	sd	a5,1462(a4) # 1000 <freep>
 a52:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a54:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a58:	b7e1                	j	a20 <malloc+0x36>
      if(p->s.size == nunits)
 a5a:	02e48c63          	beq	s1,a4,a92 <malloc+0xa8>
        p->s.size -= nunits;
 a5e:	4137073b          	subw	a4,a4,s3
 a62:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a64:	02071693          	slli	a3,a4,0x20
 a68:	01c6d713          	srli	a4,a3,0x1c
 a6c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a6e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a72:	00000717          	auipc	a4,0x0
 a76:	58a73723          	sd	a0,1422(a4) # 1000 <freep>
      return (void*)(p + 1);
 a7a:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 a7e:	70e2                	ld	ra,56(sp)
 a80:	7442                	ld	s0,48(sp)
 a82:	74a2                	ld	s1,40(sp)
 a84:	7902                	ld	s2,32(sp)
 a86:	69e2                	ld	s3,24(sp)
 a88:	6a42                	ld	s4,16(sp)
 a8a:	6aa2                	ld	s5,8(sp)
 a8c:	6b02                	ld	s6,0(sp)
 a8e:	6121                	addi	sp,sp,64
 a90:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 a92:	6398                	ld	a4,0(a5)
 a94:	e118                	sd	a4,0(a0)
 a96:	bff1                	j	a72 <malloc+0x88>
  hp->s.size = nu;
 a98:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a9c:	0541                	addi	a0,a0,16
 a9e:	ec5ff0ef          	jal	ra,962 <free>
  return freep;
 aa2:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 aa6:	dd61                	beqz	a0,a7e <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 aa8:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 aaa:	4798                	lw	a4,8(a5)
 aac:	fa9777e3          	bgeu	a4,s1,a5a <malloc+0x70>
    if(p == freep)
 ab0:	00093703          	ld	a4,0(s2)
 ab4:	853e                	mv	a0,a5
 ab6:	fef719e3          	bne	a4,a5,aa8 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 aba:	8552                	mv	a0,s4
 abc:	ab3ff0ef          	jal	ra,56e <sbrk>
  if(p == (char*)-1)
 ac0:	fd551ce3          	bne	a0,s5,a98 <malloc+0xae>
        return 0;
 ac4:	4501                	li	a0,0
 ac6:	bf65                	j	a7e <malloc+0x94>
