#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "e1000_dev.h"
#include "net.h"

#define TX_RING_SIZE 16
static struct tx_desc tx_ring[TX_RING_SIZE] __attribute__((aligned(16)));
static char *tx_bufs[TX_RING_SIZE];

#define RX_RING_SIZE 16
static struct rx_desc rx_ring[RX_RING_SIZE] __attribute__((aligned(16)));
static char *rx_bufs[RX_RING_SIZE];

// remember where the e1000's registers live.
static volatile uint32 *regs;

struct spinlock e1000_lock;

// called by pci_init().
// xregs is the memory address at which the
// e1000's registers are mapped.
void
e1000_init(uint32 *xregs)
{
  int i;

  initlock(&e1000_lock, "e1000");

  regs = xregs;

  // Reset the device
  regs[E1000_IMS] = 0; // disable interrupts
  regs[E1000_CTL] |= E1000_CTL_RST;
  regs[E1000_IMS] = 0; // redisable interrupts
  __sync_synchronize();

  // [E1000 14.5] Transmit initialization
  memset(tx_ring, 0, sizeof(tx_ring));
  for (i = 0; i < TX_RING_SIZE; i++) {
    tx_ring[i].status = E1000_TXD_STAT_DD;
    tx_bufs[i] = 0;
  }
  regs[E1000_TDBAL] = (uint64) tx_ring;
  if(sizeof(tx_ring) % 128 != 0)
    panic("e1000");
  regs[E1000_TDLEN] = sizeof(tx_ring);
  regs[E1000_TDH] = regs[E1000_TDT] = 0;
  
  // [E1000 14.4] Receive initialization
  memset(rx_ring, 0, sizeof(rx_ring));
  for (i = 0; i < RX_RING_SIZE; i++) {
    rx_bufs[i] = kalloc();
    if (!rx_bufs[i])
      panic("e1000");
    rx_ring[i].addr = (uint64) rx_bufs[i];
  }
  regs[E1000_RDBAL] = (uint64) rx_ring;
  if(sizeof(rx_ring) % 128 != 0)
    panic("e1000");
  regs[E1000_RDH] = 0;
  regs[E1000_RDT] = RX_RING_SIZE - 1;
  regs[E1000_RDLEN] = sizeof(rx_ring);

  // filter by qemu's MAC address, 52:54:00:12:34:56
  regs[E1000_RA] = 0x12005452;
  regs[E1000_RA+1] = 0x5634 | (1<<31);
  // multicast table
  for (int i = 0; i < 4096/32; i++)
    regs[E1000_MTA + i] = 0;

  // transmitter control bits.
  regs[E1000_TCTL] = E1000_TCTL_EN |  // enable
    E1000_TCTL_PSP |                  // pad short packets
    (0x10 << E1000_TCTL_CT_SHIFT) |   // collision stuff
    (0x40 << E1000_TCTL_COLD_SHIFT);
  regs[E1000_TIPG] = 10 | (8<<10) | (6<<20); // inter-pkt gap

  // receiver control bits.
  regs[E1000_RCTL] = E1000_RCTL_EN | // enable receiver
    E1000_RCTL_BAM |                 // enable broadcast
    E1000_RCTL_SZ_2048 |             // 2048-byte rx buffers
    E1000_RCTL_SECRC;                // strip CRC
  
  // ask e1000 for receive interrupts.
  regs[E1000_RDTR] = 0; // interrupt after every received packet (no timer)
  regs[E1000_RADV] = 0; // interrupt after every packet (no timer)
  regs[E1000_IMS] = (1 << 7); // RXDW -- Receiver Descriptor Write Back
}

int
e1000_transmit(char *buf, int len)
{
  //
  // Your code here.
  //
  // buf contains an ethernet frame; program it into
  // the TX descriptor ring so that the e1000 sends it. Stash
  // a pointer so that it can be freed after send completes.
  acquire(&e1000_lock);
  
  uint32 tdt = regs[E1000_TDT];
  struct tx_desc *desc = &tx_ring[tdt];
  
  // Check if the descriptor is ready for transmission
  if (!(desc->status & E1000_TXD_STAT_DD)) {
    release(&e1000_lock);
    return -1;
  }
  
  // Free the previous buffer if it exists
  if (tx_bufs[tdt]) {
    kfree(tx_bufs[tdt]);
  }
  
  // Allocate and copy the packet data
  char *new_buf = kalloc();
  if (!new_buf) {
    release(&e1000_lock);
    return -1;
  }
  
  memmove(new_buf, buf, len);
  tx_bufs[tdt] = new_buf;
  
  // Set up the transmit descriptor
  desc->addr = (uint64)new_buf;
  desc->length = len;
  desc->cmd = E1000_TXD_CMD_RS | E1000_TXD_CMD_EOP;
  desc->status = 0; // Clear DD bit
  
  // Memory barrier to ensure descriptor is written
  __sync_synchronize();
  
  // Update the transmit descriptor tail
  regs[E1000_TDT] = (tdt + 1) % TX_RING_SIZE;
  
  release(&e1000_lock);
  
  // Free the original buffer that was passed to us
  kfree(buf);
  
  return 0;
}

static void
e1000_recv(void)
{
  //
  // Your code here.
  //
  // Check for packets that have arrived from the e1000
  // Create and deliver a buf for each packet (using net_rx()).
  //
  // Process all available received packets
  while (1) {
    acquire(&e1000_lock);
    
    uint32 rdt = regs[E1000_RDT];
    uint32 next_idx = (rdt + 1) % RX_RING_SIZE;
    struct rx_desc *desc = &rx_ring[next_idx];
    
    // Check if we have a received packet
    if (!(desc->status & E1000_RXD_STAT_DD)) {
      release(&e1000_lock);
      break;
    }
    
    // We have a packet - extract the buffer and length
    char *buf = rx_bufs[next_idx];
    int len = desc->length;
    
    // Allocate a new buffer for the descriptor
    char *new_buf = kalloc();
    if (!new_buf) {
      // If we can't allocate, drop the packet but rearm descriptor
      desc->status = 0;
      regs[E1000_RDT] = next_idx;
      release(&e1000_lock);
      break;
    }
    
    // Reinitialize the descriptor with the new buffer
    rx_bufs[next_idx] = new_buf;
    desc->addr = (uint64)new_buf;
    desc->status = 0; // Clear DD bit to rearm
    
    // Update RDT
    regs[E1000_RDT] = next_idx;
    
    release(&e1000_lock);
    
    // Check packet type to handle the memory leak in ip_rx
    struct eth *eth = (struct eth *)buf;
    
    if (len >= sizeof(struct eth) + sizeof(struct ip) &&
        ntohs(eth->type) == ETHTYPE_IP) {
      // For IP packets: ip_rx doesn't free the buffer, so we need to handle this
      // Create a copy and free the original buffer
      char *ip_buf_copy = kalloc();
      if (ip_buf_copy) {
        memmove(ip_buf_copy, buf, len);
        net_rx(ip_buf_copy, len);
      }
      kfree(buf); // Always free the original buffer
    } else {
      // For ARP and other packets: net_rx will handle freeing properly
      net_rx(buf, len);
    }
  }
}

void
e1000_intr(void)
{
  // tell the e1000 we've seen this interrupt;
  // without this the e1000 won't raise any
  // further interrupts.
  regs[E1000_ICR] = 0xffffffff;

  e1000_recv();
}
