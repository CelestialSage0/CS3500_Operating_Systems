
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00019117          	auipc	sp,0x19
    80000004:	de010113          	addi	sp,sp,-544 # 80018de0 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	61b040ef          	jal	ra,80004e30 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    8000001c:	1101                	addi	sp,sp,-32
    8000001e:	ec06                	sd	ra,24(sp)
    80000020:	e822                	sd	s0,16(sp)
    80000022:	e426                	sd	s1,8(sp)
    80000024:	e04a                	sd	s2,0(sp)
    80000026:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000028:	03451793          	slli	a5,a0,0x34
    8000002c:	e7a9                	bnez	a5,80000076 <kfree+0x5a>
    8000002e:	84aa                	mv	s1,a0
    80000030:	00021797          	auipc	a5,0x21
    80000034:	eb078793          	addi	a5,a5,-336 # 80020ee0 <end>
    80000038:	02f56f63          	bltu	a0,a5,80000076 <kfree+0x5a>
    8000003c:	47c5                	li	a5,17
    8000003e:	07ee                	slli	a5,a5,0x1b
    80000040:	02f57b63          	bgeu	a0,a5,80000076 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000044:	6605                	lui	a2,0x1
    80000046:	4585                	li	a1,1
    80000048:	104000ef          	jal	ra,8000014c <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    8000004c:	00008917          	auipc	s2,0x8
    80000050:	96490913          	addi	s2,s2,-1692 # 800079b0 <kmem>
    80000054:	854a                	mv	a0,s2
    80000056:	7e4050ef          	jal	ra,8000583a <acquire>
  r->next = kmem.freelist;
    8000005a:	01893783          	ld	a5,24(s2)
    8000005e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000060:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000064:	854a                	mv	a0,s2
    80000066:	06d050ef          	jal	ra,800058d2 <release>
}
    8000006a:	60e2                	ld	ra,24(sp)
    8000006c:	6442                	ld	s0,16(sp)
    8000006e:	64a2                	ld	s1,8(sp)
    80000070:	6902                	ld	s2,0(sp)
    80000072:	6105                	addi	sp,sp,32
    80000074:	8082                	ret
    panic("kfree");
    80000076:	00007517          	auipc	a0,0x7
    8000007a:	f9a50513          	addi	a0,a0,-102 # 80007010 <etext+0x10>
    8000007e:	4a8050ef          	jal	ra,80005526 <panic>

0000000080000082 <freerange>:
{
    80000082:	7179                	addi	sp,sp,-48
    80000084:	f406                	sd	ra,40(sp)
    80000086:	f022                	sd	s0,32(sp)
    80000088:	ec26                	sd	s1,24(sp)
    8000008a:	e84a                	sd	s2,16(sp)
    8000008c:	e44e                	sd	s3,8(sp)
    8000008e:	e052                	sd	s4,0(sp)
    80000090:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000092:	6785                	lui	a5,0x1
    80000094:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000098:	94aa                	add	s1,s1,a0
    8000009a:	757d                	lui	a0,0xfffff
    8000009c:	8ce9                	and	s1,s1,a0
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    8000009e:	94be                	add	s1,s1,a5
    800000a0:	0095ec63          	bltu	a1,s1,800000b8 <freerange+0x36>
    800000a4:	892e                	mv	s2,a1
    kfree(p);
    800000a6:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000a8:	6985                	lui	s3,0x1
    kfree(p);
    800000aa:	01448533          	add	a0,s1,s4
    800000ae:	f6fff0ef          	jal	ra,8000001c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    800000b2:	94ce                	add	s1,s1,s3
    800000b4:	fe997be3          	bgeu	s2,s1,800000aa <freerange+0x28>
}
    800000b8:	70a2                	ld	ra,40(sp)
    800000ba:	7402                	ld	s0,32(sp)
    800000bc:	64e2                	ld	s1,24(sp)
    800000be:	6942                	ld	s2,16(sp)
    800000c0:	69a2                	ld	s3,8(sp)
    800000c2:	6a02                	ld	s4,0(sp)
    800000c4:	6145                	addi	sp,sp,48
    800000c6:	8082                	ret

00000000800000c8 <kinit>:
{
    800000c8:	1141                	addi	sp,sp,-16
    800000ca:	e406                	sd	ra,8(sp)
    800000cc:	e022                	sd	s0,0(sp)
    800000ce:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    800000d0:	00007597          	auipc	a1,0x7
    800000d4:	f4858593          	addi	a1,a1,-184 # 80007018 <etext+0x18>
    800000d8:	00008517          	auipc	a0,0x8
    800000dc:	8d850513          	addi	a0,a0,-1832 # 800079b0 <kmem>
    800000e0:	6da050ef          	jal	ra,800057ba <initlock>
  freerange(end, (void*)PHYSTOP);
    800000e4:	45c5                	li	a1,17
    800000e6:	05ee                	slli	a1,a1,0x1b
    800000e8:	00021517          	auipc	a0,0x21
    800000ec:	df850513          	addi	a0,a0,-520 # 80020ee0 <end>
    800000f0:	f93ff0ef          	jal	ra,80000082 <freerange>
}
    800000f4:	60a2                	ld	ra,8(sp)
    800000f6:	6402                	ld	s0,0(sp)
    800000f8:	0141                	addi	sp,sp,16
    800000fa:	8082                	ret

00000000800000fc <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    800000fc:	1101                	addi	sp,sp,-32
    800000fe:	ec06                	sd	ra,24(sp)
    80000100:	e822                	sd	s0,16(sp)
    80000102:	e426                	sd	s1,8(sp)
    80000104:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000106:	00008497          	auipc	s1,0x8
    8000010a:	8aa48493          	addi	s1,s1,-1878 # 800079b0 <kmem>
    8000010e:	8526                	mv	a0,s1
    80000110:	72a050ef          	jal	ra,8000583a <acquire>
  r = kmem.freelist;
    80000114:	6c84                	ld	s1,24(s1)
  if(r)
    80000116:	c485                	beqz	s1,8000013e <kalloc+0x42>
    kmem.freelist = r->next;
    80000118:	609c                	ld	a5,0(s1)
    8000011a:	00008517          	auipc	a0,0x8
    8000011e:	89650513          	addi	a0,a0,-1898 # 800079b0 <kmem>
    80000122:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000124:	7ae050ef          	jal	ra,800058d2 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000128:	6605                	lui	a2,0x1
    8000012a:	4595                	li	a1,5
    8000012c:	8526                	mv	a0,s1
    8000012e:	01e000ef          	jal	ra,8000014c <memset>
  return (void*)r;
}
    80000132:	8526                	mv	a0,s1
    80000134:	60e2                	ld	ra,24(sp)
    80000136:	6442                	ld	s0,16(sp)
    80000138:	64a2                	ld	s1,8(sp)
    8000013a:	6105                	addi	sp,sp,32
    8000013c:	8082                	ret
  release(&kmem.lock);
    8000013e:	00008517          	auipc	a0,0x8
    80000142:	87250513          	addi	a0,a0,-1934 # 800079b0 <kmem>
    80000146:	78c050ef          	jal	ra,800058d2 <release>
  if(r)
    8000014a:	b7e5                	j	80000132 <kalloc+0x36>

000000008000014c <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    8000014c:	1141                	addi	sp,sp,-16
    8000014e:	e422                	sd	s0,8(sp)
    80000150:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000152:	ca19                	beqz	a2,80000168 <memset+0x1c>
    80000154:	87aa                	mv	a5,a0
    80000156:	1602                	slli	a2,a2,0x20
    80000158:	9201                	srli	a2,a2,0x20
    8000015a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    8000015e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000162:	0785                	addi	a5,a5,1
    80000164:	fee79de3          	bne	a5,a4,8000015e <memset+0x12>
  }
  return dst;
}
    80000168:	6422                	ld	s0,8(sp)
    8000016a:	0141                	addi	sp,sp,16
    8000016c:	8082                	ret

000000008000016e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    8000016e:	1141                	addi	sp,sp,-16
    80000170:	e422                	sd	s0,8(sp)
    80000172:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000174:	ca05                	beqz	a2,800001a4 <memcmp+0x36>
    80000176:	fff6069b          	addiw	a3,a2,-1
    8000017a:	1682                	slli	a3,a3,0x20
    8000017c:	9281                	srli	a3,a3,0x20
    8000017e:	0685                	addi	a3,a3,1
    80000180:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000182:	00054783          	lbu	a5,0(a0)
    80000186:	0005c703          	lbu	a4,0(a1)
    8000018a:	00e79863          	bne	a5,a4,8000019a <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    8000018e:	0505                	addi	a0,a0,1
    80000190:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000192:	fed518e3          	bne	a0,a3,80000182 <memcmp+0x14>
  }

  return 0;
    80000196:	4501                	li	a0,0
    80000198:	a019                	j	8000019e <memcmp+0x30>
      return *s1 - *s2;
    8000019a:	40e7853b          	subw	a0,a5,a4
}
    8000019e:	6422                	ld	s0,8(sp)
    800001a0:	0141                	addi	sp,sp,16
    800001a2:	8082                	ret
  return 0;
    800001a4:	4501                	li	a0,0
    800001a6:	bfe5                	j	8000019e <memcmp+0x30>

00000000800001a8 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    800001a8:	1141                	addi	sp,sp,-16
    800001aa:	e422                	sd	s0,8(sp)
    800001ac:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    800001ae:	c205                	beqz	a2,800001ce <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    800001b0:	02a5e263          	bltu	a1,a0,800001d4 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    800001b4:	1602                	slli	a2,a2,0x20
    800001b6:	9201                	srli	a2,a2,0x20
    800001b8:	00c587b3          	add	a5,a1,a2
{
    800001bc:	872a                	mv	a4,a0
      *d++ = *s++;
    800001be:	0585                	addi	a1,a1,1
    800001c0:	0705                	addi	a4,a4,1
    800001c2:	fff5c683          	lbu	a3,-1(a1)
    800001c6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    800001ca:	fef59ae3          	bne	a1,a5,800001be <memmove+0x16>

  return dst;
}
    800001ce:	6422                	ld	s0,8(sp)
    800001d0:	0141                	addi	sp,sp,16
    800001d2:	8082                	ret
  if(s < d && s + n > d){
    800001d4:	02061693          	slli	a3,a2,0x20
    800001d8:	9281                	srli	a3,a3,0x20
    800001da:	00d58733          	add	a4,a1,a3
    800001de:	fce57be3          	bgeu	a0,a4,800001b4 <memmove+0xc>
    d += n;
    800001e2:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    800001e4:	fff6079b          	addiw	a5,a2,-1
    800001e8:	1782                	slli	a5,a5,0x20
    800001ea:	9381                	srli	a5,a5,0x20
    800001ec:	fff7c793          	not	a5,a5
    800001f0:	97ba                	add	a5,a5,a4
      *--d = *--s;
    800001f2:	177d                	addi	a4,a4,-1
    800001f4:	16fd                	addi	a3,a3,-1
    800001f6:	00074603          	lbu	a2,0(a4)
    800001fa:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    800001fe:	fee79ae3          	bne	a5,a4,800001f2 <memmove+0x4a>
    80000202:	b7f1                	j	800001ce <memmove+0x26>

0000000080000204 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000204:	1141                	addi	sp,sp,-16
    80000206:	e406                	sd	ra,8(sp)
    80000208:	e022                	sd	s0,0(sp)
    8000020a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    8000020c:	f9dff0ef          	jal	ra,800001a8 <memmove>
}
    80000210:	60a2                	ld	ra,8(sp)
    80000212:	6402                	ld	s0,0(sp)
    80000214:	0141                	addi	sp,sp,16
    80000216:	8082                	ret

0000000080000218 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000218:	1141                	addi	sp,sp,-16
    8000021a:	e422                	sd	s0,8(sp)
    8000021c:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    8000021e:	ce11                	beqz	a2,8000023a <strncmp+0x22>
    80000220:	00054783          	lbu	a5,0(a0)
    80000224:	cf89                	beqz	a5,8000023e <strncmp+0x26>
    80000226:	0005c703          	lbu	a4,0(a1)
    8000022a:	00f71a63          	bne	a4,a5,8000023e <strncmp+0x26>
    n--, p++, q++;
    8000022e:	367d                	addiw	a2,a2,-1
    80000230:	0505                	addi	a0,a0,1
    80000232:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000234:	f675                	bnez	a2,80000220 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000236:	4501                	li	a0,0
    80000238:	a809                	j	8000024a <strncmp+0x32>
    8000023a:	4501                	li	a0,0
    8000023c:	a039                	j	8000024a <strncmp+0x32>
  if(n == 0)
    8000023e:	ca09                	beqz	a2,80000250 <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000240:	00054503          	lbu	a0,0(a0)
    80000244:	0005c783          	lbu	a5,0(a1)
    80000248:	9d1d                	subw	a0,a0,a5
}
    8000024a:	6422                	ld	s0,8(sp)
    8000024c:	0141                	addi	sp,sp,16
    8000024e:	8082                	ret
    return 0;
    80000250:	4501                	li	a0,0
    80000252:	bfe5                	j	8000024a <strncmp+0x32>

0000000080000254 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000254:	1141                	addi	sp,sp,-16
    80000256:	e422                	sd	s0,8(sp)
    80000258:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    8000025a:	872a                	mv	a4,a0
    8000025c:	8832                	mv	a6,a2
    8000025e:	367d                	addiw	a2,a2,-1
    80000260:	01005963          	blez	a6,80000272 <strncpy+0x1e>
    80000264:	0705                	addi	a4,a4,1
    80000266:	0005c783          	lbu	a5,0(a1)
    8000026a:	fef70fa3          	sb	a5,-1(a4)
    8000026e:	0585                	addi	a1,a1,1
    80000270:	f7f5                	bnez	a5,8000025c <strncpy+0x8>
    ;
  while(n-- > 0)
    80000272:	86ba                	mv	a3,a4
    80000274:	00c05c63          	blez	a2,8000028c <strncpy+0x38>
    *s++ = 0;
    80000278:	0685                	addi	a3,a3,1
    8000027a:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    8000027e:	fff6c793          	not	a5,a3
    80000282:	9fb9                	addw	a5,a5,a4
    80000284:	010787bb          	addw	a5,a5,a6
    80000288:	fef048e3          	bgtz	a5,80000278 <strncpy+0x24>
  return os;
}
    8000028c:	6422                	ld	s0,8(sp)
    8000028e:	0141                	addi	sp,sp,16
    80000290:	8082                	ret

0000000080000292 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000292:	1141                	addi	sp,sp,-16
    80000294:	e422                	sd	s0,8(sp)
    80000296:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000298:	02c05363          	blez	a2,800002be <safestrcpy+0x2c>
    8000029c:	fff6069b          	addiw	a3,a2,-1
    800002a0:	1682                	slli	a3,a3,0x20
    800002a2:	9281                	srli	a3,a3,0x20
    800002a4:	96ae                	add	a3,a3,a1
    800002a6:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    800002a8:	00d58963          	beq	a1,a3,800002ba <safestrcpy+0x28>
    800002ac:	0585                	addi	a1,a1,1
    800002ae:	0785                	addi	a5,a5,1
    800002b0:	fff5c703          	lbu	a4,-1(a1)
    800002b4:	fee78fa3          	sb	a4,-1(a5)
    800002b8:	fb65                	bnez	a4,800002a8 <safestrcpy+0x16>
    ;
  *s = 0;
    800002ba:	00078023          	sb	zero,0(a5)
  return os;
}
    800002be:	6422                	ld	s0,8(sp)
    800002c0:	0141                	addi	sp,sp,16
    800002c2:	8082                	ret

00000000800002c4 <strlen>:

int
strlen(const char *s)
{
    800002c4:	1141                	addi	sp,sp,-16
    800002c6:	e422                	sd	s0,8(sp)
    800002c8:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    800002ca:	00054783          	lbu	a5,0(a0)
    800002ce:	cf91                	beqz	a5,800002ea <strlen+0x26>
    800002d0:	0505                	addi	a0,a0,1
    800002d2:	87aa                	mv	a5,a0
    800002d4:	4685                	li	a3,1
    800002d6:	9e89                	subw	a3,a3,a0
    800002d8:	00f6853b          	addw	a0,a3,a5
    800002dc:	0785                	addi	a5,a5,1
    800002de:	fff7c703          	lbu	a4,-1(a5)
    800002e2:	fb7d                	bnez	a4,800002d8 <strlen+0x14>
    ;
  return n;
}
    800002e4:	6422                	ld	s0,8(sp)
    800002e6:	0141                	addi	sp,sp,16
    800002e8:	8082                	ret
  for(n = 0; s[n]; n++)
    800002ea:	4501                	li	a0,0
    800002ec:	bfe5                	j	800002e4 <strlen+0x20>

00000000800002ee <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    800002ee:	1141                	addi	sp,sp,-16
    800002f0:	e406                	sd	ra,8(sp)
    800002f2:	e022                	sd	s0,0(sp)
    800002f4:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800002f6:	2fd000ef          	jal	ra,80000df2 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    800002fa:	00007717          	auipc	a4,0x7
    800002fe:	68670713          	addi	a4,a4,1670 # 80007980 <started>
  if(cpuid() == 0){
    80000302:	c51d                	beqz	a0,80000330 <main+0x42>
    while(started == 0)
    80000304:	431c                	lw	a5,0(a4)
    80000306:	2781                	sext.w	a5,a5
    80000308:	dff5                	beqz	a5,80000304 <main+0x16>
      ;
    __sync_synchronize();
    8000030a:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    8000030e:	2e5000ef          	jal	ra,80000df2 <cpuid>
    80000312:	85aa                	mv	a1,a0
    80000314:	00007517          	auipc	a0,0x7
    80000318:	d2450513          	addi	a0,a0,-732 # 80007038 <etext+0x38>
    8000031c:	757040ef          	jal	ra,80005272 <printf>
    kvminithart();    // turn on paging
    80000320:	080000ef          	jal	ra,800003a0 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000324:	688010ef          	jal	ra,800019ac <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000328:	55c040ef          	jal	ra,80004884 <plicinithart>
  }

  scheduler();        
    8000032c:	7c5000ef          	jal	ra,800012f0 <scheduler>
    consoleinit();
    80000330:	66b040ef          	jal	ra,8000519a <consoleinit>
    printfinit();
    80000334:	22c050ef          	jal	ra,80005560 <printfinit>
    printf("\n");
    80000338:	00007517          	auipc	a0,0x7
    8000033c:	d1050513          	addi	a0,a0,-752 # 80007048 <etext+0x48>
    80000340:	733040ef          	jal	ra,80005272 <printf>
    printf("xv6 kernel is booting\n");
    80000344:	00007517          	auipc	a0,0x7
    80000348:	cdc50513          	addi	a0,a0,-804 # 80007020 <etext+0x20>
    8000034c:	727040ef          	jal	ra,80005272 <printf>
    printf("\n");
    80000350:	00007517          	auipc	a0,0x7
    80000354:	cf850513          	addi	a0,a0,-776 # 80007048 <etext+0x48>
    80000358:	71b040ef          	jal	ra,80005272 <printf>
    kinit();         // physical page allocator
    8000035c:	d6dff0ef          	jal	ra,800000c8 <kinit>
    kvminit();       // create kernel page table
    80000360:	2d2000ef          	jal	ra,80000632 <kvminit>
    kvminithart();   // turn on paging
    80000364:	03c000ef          	jal	ra,800003a0 <kvminithart>
    procinit();      // process table
    80000368:	1e5000ef          	jal	ra,80000d4c <procinit>
    trapinit();      // trap vectors
    8000036c:	61c010ef          	jal	ra,80001988 <trapinit>
    trapinithart();  // install kernel trap vector
    80000370:	63c010ef          	jal	ra,800019ac <trapinithart>
    plicinit();      // set up interrupt controller
    80000374:	4fa040ef          	jal	ra,8000486e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000378:	50c040ef          	jal	ra,80004884 <plicinithart>
    binit();         // buffer cache
    8000037c:	583010ef          	jal	ra,800020fe <binit>
    iinit();         // inode table
    80000380:	364020ef          	jal	ra,800026e4 <iinit>
    fileinit();      // file table
    80000384:	102030ef          	jal	ra,80003486 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000388:	5ec040ef          	jal	ra,80004974 <virtio_disk_init>
    userinit();      // first user process
    8000038c:	59b000ef          	jal	ra,80001126 <userinit>
    __sync_synchronize();
    80000390:	0ff0000f          	fence
    started = 1;
    80000394:	4785                	li	a5,1
    80000396:	00007717          	auipc	a4,0x7
    8000039a:	5ef72523          	sw	a5,1514(a4) # 80007980 <started>
    8000039e:	b779                	j	8000032c <main+0x3e>

00000000800003a0 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    800003a0:	1141                	addi	sp,sp,-16
    800003a2:	e422                	sd	s0,8(sp)
    800003a4:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    800003a6:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    800003aa:	00007797          	auipc	a5,0x7
    800003ae:	5de7b783          	ld	a5,1502(a5) # 80007988 <kernel_pagetable>
    800003b2:	83b1                	srli	a5,a5,0xc
    800003b4:	577d                	li	a4,-1
    800003b6:	177e                	slli	a4,a4,0x3f
    800003b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    800003ba:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    800003be:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    800003c2:	6422                	ld	s0,8(sp)
    800003c4:	0141                	addi	sp,sp,16
    800003c6:	8082                	ret

00000000800003c8 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    800003c8:	7139                	addi	sp,sp,-64
    800003ca:	fc06                	sd	ra,56(sp)
    800003cc:	f822                	sd	s0,48(sp)
    800003ce:	f426                	sd	s1,40(sp)
    800003d0:	f04a                	sd	s2,32(sp)
    800003d2:	ec4e                	sd	s3,24(sp)
    800003d4:	e852                	sd	s4,16(sp)
    800003d6:	e456                	sd	s5,8(sp)
    800003d8:	e05a                	sd	s6,0(sp)
    800003da:	0080                	addi	s0,sp,64
    800003dc:	892a                	mv	s2,a0
    800003de:	89ae                	mv	s3,a1
    800003e0:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    800003e2:	57fd                	li	a5,-1
    800003e4:	83e9                	srli	a5,a5,0x1a
    800003e6:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    800003e8:	4b31                	li	s6,12
  if(va >= MAXVA)
    800003ea:	02b7fb63          	bgeu	a5,a1,80000420 <walk+0x58>
    panic("walk");
    800003ee:	00007517          	auipc	a0,0x7
    800003f2:	c6250513          	addi	a0,a0,-926 # 80007050 <etext+0x50>
    800003f6:	130050ef          	jal	ra,80005526 <panic>
      if(PTE_LEAF(*pte)) {
        return pte;
      }
#endif
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    800003fa:	060a8463          	beqz	s5,80000462 <walk+0x9a>
    800003fe:	cffff0ef          	jal	ra,800000fc <kalloc>
    80000402:	892a                	mv	s2,a0
    80000404:	c12d                	beqz	a0,80000466 <walk+0x9e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000406:	6605                	lui	a2,0x1
    80000408:	4581                	li	a1,0
    8000040a:	d43ff0ef          	jal	ra,8000014c <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000040e:	00c95793          	srli	a5,s2,0xc
    80000412:	07aa                	slli	a5,a5,0xa
    80000414:	0017e793          	ori	a5,a5,1
    80000418:	e09c                	sd	a5,0(s1)
  for(int level = 2; level > 0; level--) {
    8000041a:	3a5d                	addiw	s4,s4,-9
    8000041c:	036a0263          	beq	s4,s6,80000440 <walk+0x78>
    pte_t *pte = &pagetable[PX(level, va)];
    80000420:	0149d4b3          	srl	s1,s3,s4
    80000424:	1ff4f493          	andi	s1,s1,511
    80000428:	048e                	slli	s1,s1,0x3
    8000042a:	94ca                	add	s1,s1,s2
    if(*pte & PTE_V) {
    8000042c:	609c                	ld	a5,0(s1)
    8000042e:	0017f713          	andi	a4,a5,1
    80000432:	d761                	beqz	a4,800003fa <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000434:	00a7d913          	srli	s2,a5,0xa
    80000438:	0932                	slli	s2,s2,0xc
      if(PTE_LEAF(*pte)) {
    8000043a:	8bb9                	andi	a5,a5,14
    8000043c:	dff9                	beqz	a5,8000041a <walk+0x52>
    8000043e:	a039                	j	8000044c <walk+0x84>
    }
  }
  return &pagetable[PX(0, va)];
    80000440:	00c9d493          	srli	s1,s3,0xc
    80000444:	1ff4f493          	andi	s1,s1,511
    80000448:	048e                	slli	s1,s1,0x3
    8000044a:	94ca                	add	s1,s1,s2
}
    8000044c:	8526                	mv	a0,s1
    8000044e:	70e2                	ld	ra,56(sp)
    80000450:	7442                	ld	s0,48(sp)
    80000452:	74a2                	ld	s1,40(sp)
    80000454:	7902                	ld	s2,32(sp)
    80000456:	69e2                	ld	s3,24(sp)
    80000458:	6a42                	ld	s4,16(sp)
    8000045a:	6aa2                	ld	s5,8(sp)
    8000045c:	6b02                	ld	s6,0(sp)
    8000045e:	6121                	addi	sp,sp,64
    80000460:	8082                	ret
        return 0;
    80000462:	4481                	li	s1,0
    80000464:	b7e5                	j	8000044c <walk+0x84>
    80000466:	84aa                	mv	s1,a0
    80000468:	b7d5                	j	8000044c <walk+0x84>

000000008000046a <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000046a:	57fd                	li	a5,-1
    8000046c:	83e9                	srli	a5,a5,0x1a
    8000046e:	00b7f463          	bgeu	a5,a1,80000476 <walkaddr+0xc>
    return 0;
    80000472:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000474:	8082                	ret
{
    80000476:	1141                	addi	sp,sp,-16
    80000478:	e406                	sd	ra,8(sp)
    8000047a:	e022                	sd	s0,0(sp)
    8000047c:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000047e:	4601                	li	a2,0
    80000480:	f49ff0ef          	jal	ra,800003c8 <walk>
  if(pte == 0)
    80000484:	c105                	beqz	a0,800004a4 <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000486:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000488:	0117f693          	andi	a3,a5,17
    8000048c:	4745                	li	a4,17
    return 0;
    8000048e:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000490:	00e68663          	beq	a3,a4,8000049c <walkaddr+0x32>
}
    80000494:	60a2                	ld	ra,8(sp)
    80000496:	6402                	ld	s0,0(sp)
    80000498:	0141                	addi	sp,sp,16
    8000049a:	8082                	ret
  pa = PTE2PA(*pte);
    8000049c:	00a7d513          	srli	a0,a5,0xa
    800004a0:	0532                	slli	a0,a0,0xc
  return pa;
    800004a2:	bfcd                	j	80000494 <walkaddr+0x2a>
    return 0;
    800004a4:	4501                	li	a0,0
    800004a6:	b7fd                	j	80000494 <walkaddr+0x2a>

00000000800004a8 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800004a8:	715d                	addi	sp,sp,-80
    800004aa:	e486                	sd	ra,72(sp)
    800004ac:	e0a2                	sd	s0,64(sp)
    800004ae:	fc26                	sd	s1,56(sp)
    800004b0:	f84a                	sd	s2,48(sp)
    800004b2:	f44e                	sd	s3,40(sp)
    800004b4:	f052                	sd	s4,32(sp)
    800004b6:	ec56                	sd	s5,24(sp)
    800004b8:	e85a                	sd	s6,16(sp)
    800004ba:	e45e                	sd	s7,8(sp)
    800004bc:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800004be:	03459793          	slli	a5,a1,0x34
    800004c2:	e7a9                	bnez	a5,8000050c <mappages+0x64>
    800004c4:	8aaa                	mv	s5,a0
    800004c6:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800004c8:	03461793          	slli	a5,a2,0x34
    800004cc:	e7b1                	bnez	a5,80000518 <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    800004ce:	ca39                	beqz	a2,80000524 <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800004d0:	79fd                	lui	s3,0xfffff
    800004d2:	964e                	add	a2,a2,s3
    800004d4:	00b609b3          	add	s3,a2,a1
  a = va;
    800004d8:	892e                	mv	s2,a1
    800004da:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800004de:	6b85                	lui	s7,0x1
    800004e0:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    800004e4:	4605                	li	a2,1
    800004e6:	85ca                	mv	a1,s2
    800004e8:	8556                	mv	a0,s5
    800004ea:	edfff0ef          	jal	ra,800003c8 <walk>
    800004ee:	c539                	beqz	a0,8000053c <mappages+0x94>
    if(*pte & PTE_V)
    800004f0:	611c                	ld	a5,0(a0)
    800004f2:	8b85                	andi	a5,a5,1
    800004f4:	ef95                	bnez	a5,80000530 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800004f6:	80b1                	srli	s1,s1,0xc
    800004f8:	04aa                	slli	s1,s1,0xa
    800004fa:	0164e4b3          	or	s1,s1,s6
    800004fe:	0014e493          	ori	s1,s1,1
    80000502:	e104                	sd	s1,0(a0)
    if(a == last)
    80000504:	05390863          	beq	s2,s3,80000554 <mappages+0xac>
    a += PGSIZE;
    80000508:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    8000050a:	bfd9                	j	800004e0 <mappages+0x38>
    panic("mappages: va not aligned");
    8000050c:	00007517          	auipc	a0,0x7
    80000510:	b4c50513          	addi	a0,a0,-1204 # 80007058 <etext+0x58>
    80000514:	012050ef          	jal	ra,80005526 <panic>
    panic("mappages: size not aligned");
    80000518:	00007517          	auipc	a0,0x7
    8000051c:	b6050513          	addi	a0,a0,-1184 # 80007078 <etext+0x78>
    80000520:	006050ef          	jal	ra,80005526 <panic>
    panic("mappages: size");
    80000524:	00007517          	auipc	a0,0x7
    80000528:	b7450513          	addi	a0,a0,-1164 # 80007098 <etext+0x98>
    8000052c:	7fb040ef          	jal	ra,80005526 <panic>
      panic("mappages: remap");
    80000530:	00007517          	auipc	a0,0x7
    80000534:	b7850513          	addi	a0,a0,-1160 # 800070a8 <etext+0xa8>
    80000538:	7ef040ef          	jal	ra,80005526 <panic>
      return -1;
    8000053c:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000053e:	60a6                	ld	ra,72(sp)
    80000540:	6406                	ld	s0,64(sp)
    80000542:	74e2                	ld	s1,56(sp)
    80000544:	7942                	ld	s2,48(sp)
    80000546:	79a2                	ld	s3,40(sp)
    80000548:	7a02                	ld	s4,32(sp)
    8000054a:	6ae2                	ld	s5,24(sp)
    8000054c:	6b42                	ld	s6,16(sp)
    8000054e:	6ba2                	ld	s7,8(sp)
    80000550:	6161                	addi	sp,sp,80
    80000552:	8082                	ret
  return 0;
    80000554:	4501                	li	a0,0
    80000556:	b7e5                	j	8000053e <mappages+0x96>

0000000080000558 <kvmmap>:
{
    80000558:	1141                	addi	sp,sp,-16
    8000055a:	e406                	sd	ra,8(sp)
    8000055c:	e022                	sd	s0,0(sp)
    8000055e:	0800                	addi	s0,sp,16
    80000560:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80000562:	86b2                	mv	a3,a2
    80000564:	863e                	mv	a2,a5
    80000566:	f43ff0ef          	jal	ra,800004a8 <mappages>
    8000056a:	e509                	bnez	a0,80000574 <kvmmap+0x1c>
}
    8000056c:	60a2                	ld	ra,8(sp)
    8000056e:	6402                	ld	s0,0(sp)
    80000570:	0141                	addi	sp,sp,16
    80000572:	8082                	ret
    panic("kvmmap");
    80000574:	00007517          	auipc	a0,0x7
    80000578:	b4450513          	addi	a0,a0,-1212 # 800070b8 <etext+0xb8>
    8000057c:	7ab040ef          	jal	ra,80005526 <panic>

0000000080000580 <kvmmake>:
{
    80000580:	1101                	addi	sp,sp,-32
    80000582:	ec06                	sd	ra,24(sp)
    80000584:	e822                	sd	s0,16(sp)
    80000586:	e426                	sd	s1,8(sp)
    80000588:	e04a                	sd	s2,0(sp)
    8000058a:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000058c:	b71ff0ef          	jal	ra,800000fc <kalloc>
    80000590:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80000592:	6605                	lui	a2,0x1
    80000594:	4581                	li	a1,0
    80000596:	bb7ff0ef          	jal	ra,8000014c <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000059a:	4719                	li	a4,6
    8000059c:	6685                	lui	a3,0x1
    8000059e:	10000637          	lui	a2,0x10000
    800005a2:	100005b7          	lui	a1,0x10000
    800005a6:	8526                	mv	a0,s1
    800005a8:	fb1ff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800005ac:	4719                	li	a4,6
    800005ae:	6685                	lui	a3,0x1
    800005b0:	10001637          	lui	a2,0x10001
    800005b4:	100015b7          	lui	a1,0x10001
    800005b8:	8526                	mv	a0,s1
    800005ba:	f9fff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800005be:	4719                	li	a4,6
    800005c0:	040006b7          	lui	a3,0x4000
    800005c4:	0c000637          	lui	a2,0xc000
    800005c8:	0c0005b7          	lui	a1,0xc000
    800005cc:	8526                	mv	a0,s1
    800005ce:	f8bff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800005d2:	00007917          	auipc	s2,0x7
    800005d6:	a2e90913          	addi	s2,s2,-1490 # 80007000 <etext>
    800005da:	4729                	li	a4,10
    800005dc:	80007697          	auipc	a3,0x80007
    800005e0:	a2468693          	addi	a3,a3,-1500 # 7000 <_entry-0x7fff9000>
    800005e4:	4605                	li	a2,1
    800005e6:	067e                	slli	a2,a2,0x1f
    800005e8:	85b2                	mv	a1,a2
    800005ea:	8526                	mv	a0,s1
    800005ec:	f6dff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800005f0:	4719                	li	a4,6
    800005f2:	46c5                	li	a3,17
    800005f4:	06ee                	slli	a3,a3,0x1b
    800005f6:	412686b3          	sub	a3,a3,s2
    800005fa:	864a                	mv	a2,s2
    800005fc:	85ca                	mv	a1,s2
    800005fe:	8526                	mv	a0,s1
    80000600:	f59ff0ef          	jal	ra,80000558 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80000604:	4729                	li	a4,10
    80000606:	6685                	lui	a3,0x1
    80000608:	00006617          	auipc	a2,0x6
    8000060c:	9f860613          	addi	a2,a2,-1544 # 80006000 <_trampoline>
    80000610:	040005b7          	lui	a1,0x4000
    80000614:	15fd                	addi	a1,a1,-1
    80000616:	05b2                	slli	a1,a1,0xc
    80000618:	8526                	mv	a0,s1
    8000061a:	f3fff0ef          	jal	ra,80000558 <kvmmap>
  proc_mapstacks(kpgtbl);
    8000061e:	8526                	mv	a0,s1
    80000620:	6a4000ef          	jal	ra,80000cc4 <proc_mapstacks>
}
    80000624:	8526                	mv	a0,s1
    80000626:	60e2                	ld	ra,24(sp)
    80000628:	6442                	ld	s0,16(sp)
    8000062a:	64a2                	ld	s1,8(sp)
    8000062c:	6902                	ld	s2,0(sp)
    8000062e:	6105                	addi	sp,sp,32
    80000630:	8082                	ret

0000000080000632 <kvminit>:
{
    80000632:	1141                	addi	sp,sp,-16
    80000634:	e406                	sd	ra,8(sp)
    80000636:	e022                	sd	s0,0(sp)
    80000638:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000063a:	f47ff0ef          	jal	ra,80000580 <kvmmake>
    8000063e:	00007797          	auipc	a5,0x7
    80000642:	34a7b523          	sd	a0,842(a5) # 80007988 <kernel_pagetable>
}
    80000646:	60a2                	ld	ra,8(sp)
    80000648:	6402                	ld	s0,0(sp)
    8000064a:	0141                	addi	sp,sp,16
    8000064c:	8082                	ret

000000008000064e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000064e:	715d                	addi	sp,sp,-80
    80000650:	e486                	sd	ra,72(sp)
    80000652:	e0a2                	sd	s0,64(sp)
    80000654:	fc26                	sd	s1,56(sp)
    80000656:	f84a                	sd	s2,48(sp)
    80000658:	f44e                	sd	s3,40(sp)
    8000065a:	f052                	sd	s4,32(sp)
    8000065c:	ec56                	sd	s5,24(sp)
    8000065e:	e85a                	sd	s6,16(sp)
    80000660:	e45e                	sd	s7,8(sp)
    80000662:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;
  int sz;

  if((va % PGSIZE) != 0)
    80000664:	03459793          	slli	a5,a1,0x34
    80000668:	e795                	bnez	a5,80000694 <uvmunmap+0x46>
    8000066a:	8a2a                	mv	s4,a0
    8000066c:	892e                	mv	s2,a1
    8000066e:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000670:	0632                	slli	a2,a2,0xc
    80000672:	00b609b3          	add	s3,a2,a1
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0) {
      printf("va=%ld pte=%ld\n", a, *pte);
      panic("uvmunmap: not mapped");
    }
    if(PTE_FLAGS(*pte) == PTE_V)
    80000676:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += sz){
    80000678:	6b05                	lui	s6,0x1
    8000067a:	0735e163          	bltu	a1,s3,800006dc <uvmunmap+0x8e>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    8000067e:	60a6                	ld	ra,72(sp)
    80000680:	6406                	ld	s0,64(sp)
    80000682:	74e2                	ld	s1,56(sp)
    80000684:	7942                	ld	s2,48(sp)
    80000686:	79a2                	ld	s3,40(sp)
    80000688:	7a02                	ld	s4,32(sp)
    8000068a:	6ae2                	ld	s5,24(sp)
    8000068c:	6b42                	ld	s6,16(sp)
    8000068e:	6ba2                	ld	s7,8(sp)
    80000690:	6161                	addi	sp,sp,80
    80000692:	8082                	ret
    panic("uvmunmap: not aligned");
    80000694:	00007517          	auipc	a0,0x7
    80000698:	a2c50513          	addi	a0,a0,-1492 # 800070c0 <etext+0xc0>
    8000069c:	68b040ef          	jal	ra,80005526 <panic>
      panic("uvmunmap: walk");
    800006a0:	00007517          	auipc	a0,0x7
    800006a4:	a3850513          	addi	a0,a0,-1480 # 800070d8 <etext+0xd8>
    800006a8:	67f040ef          	jal	ra,80005526 <panic>
      printf("va=%ld pte=%ld\n", a, *pte);
    800006ac:	85ca                	mv	a1,s2
    800006ae:	00007517          	auipc	a0,0x7
    800006b2:	a3a50513          	addi	a0,a0,-1478 # 800070e8 <etext+0xe8>
    800006b6:	3bd040ef          	jal	ra,80005272 <printf>
      panic("uvmunmap: not mapped");
    800006ba:	00007517          	auipc	a0,0x7
    800006be:	a3e50513          	addi	a0,a0,-1474 # 800070f8 <etext+0xf8>
    800006c2:	665040ef          	jal	ra,80005526 <panic>
      panic("uvmunmap: not a leaf");
    800006c6:	00007517          	auipc	a0,0x7
    800006ca:	a4a50513          	addi	a0,a0,-1462 # 80007110 <etext+0x110>
    800006ce:	659040ef          	jal	ra,80005526 <panic>
    *pte = 0;
    800006d2:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += sz){
    800006d6:	995a                	add	s2,s2,s6
    800006d8:	fb3973e3          	bgeu	s2,s3,8000067e <uvmunmap+0x30>
    if((pte = walk(pagetable, a, 0)) == 0)
    800006dc:	4601                	li	a2,0
    800006de:	85ca                	mv	a1,s2
    800006e0:	8552                	mv	a0,s4
    800006e2:	ce7ff0ef          	jal	ra,800003c8 <walk>
    800006e6:	84aa                	mv	s1,a0
    800006e8:	dd45                	beqz	a0,800006a0 <uvmunmap+0x52>
    if((*pte & PTE_V) == 0) {
    800006ea:	6110                	ld	a2,0(a0)
    800006ec:	00167793          	andi	a5,a2,1
    800006f0:	dfd5                	beqz	a5,800006ac <uvmunmap+0x5e>
    if(PTE_FLAGS(*pte) == PTE_V)
    800006f2:	3ff67793          	andi	a5,a2,1023
    800006f6:	fd7788e3          	beq	a5,s7,800006c6 <uvmunmap+0x78>
    if(do_free){
    800006fa:	fc0a8ce3          	beqz	s5,800006d2 <uvmunmap+0x84>
      uint64 pa = PTE2PA(*pte);
    800006fe:	8229                	srli	a2,a2,0xa
      kfree((void*)pa);
    80000700:	00c61513          	slli	a0,a2,0xc
    80000704:	919ff0ef          	jal	ra,8000001c <kfree>
    80000708:	b7e9                	j	800006d2 <uvmunmap+0x84>

000000008000070a <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000070a:	1101                	addi	sp,sp,-32
    8000070c:	ec06                	sd	ra,24(sp)
    8000070e:	e822                	sd	s0,16(sp)
    80000710:	e426                	sd	s1,8(sp)
    80000712:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80000714:	9e9ff0ef          	jal	ra,800000fc <kalloc>
    80000718:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000071a:	c509                	beqz	a0,80000724 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000071c:	6605                	lui	a2,0x1
    8000071e:	4581                	li	a1,0
    80000720:	a2dff0ef          	jal	ra,8000014c <memset>
  return pagetable;
}
    80000724:	8526                	mv	a0,s1
    80000726:	60e2                	ld	ra,24(sp)
    80000728:	6442                	ld	s0,16(sp)
    8000072a:	64a2                	ld	s1,8(sp)
    8000072c:	6105                	addi	sp,sp,32
    8000072e:	8082                	ret

0000000080000730 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80000730:	7179                	addi	sp,sp,-48
    80000732:	f406                	sd	ra,40(sp)
    80000734:	f022                	sd	s0,32(sp)
    80000736:	ec26                	sd	s1,24(sp)
    80000738:	e84a                	sd	s2,16(sp)
    8000073a:	e44e                	sd	s3,8(sp)
    8000073c:	e052                	sd	s4,0(sp)
    8000073e:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80000740:	6785                	lui	a5,0x1
    80000742:	04f67063          	bgeu	a2,a5,80000782 <uvmfirst+0x52>
    80000746:	8a2a                	mv	s4,a0
    80000748:	89ae                	mv	s3,a1
    8000074a:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    8000074c:	9b1ff0ef          	jal	ra,800000fc <kalloc>
    80000750:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80000752:	6605                	lui	a2,0x1
    80000754:	4581                	li	a1,0
    80000756:	9f7ff0ef          	jal	ra,8000014c <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    8000075a:	4779                	li	a4,30
    8000075c:	86ca                	mv	a3,s2
    8000075e:	6605                	lui	a2,0x1
    80000760:	4581                	li	a1,0
    80000762:	8552                	mv	a0,s4
    80000764:	d45ff0ef          	jal	ra,800004a8 <mappages>
  memmove(mem, src, sz);
    80000768:	8626                	mv	a2,s1
    8000076a:	85ce                	mv	a1,s3
    8000076c:	854a                	mv	a0,s2
    8000076e:	a3bff0ef          	jal	ra,800001a8 <memmove>
}
    80000772:	70a2                	ld	ra,40(sp)
    80000774:	7402                	ld	s0,32(sp)
    80000776:	64e2                	ld	s1,24(sp)
    80000778:	6942                	ld	s2,16(sp)
    8000077a:	69a2                	ld	s3,8(sp)
    8000077c:	6a02                	ld	s4,0(sp)
    8000077e:	6145                	addi	sp,sp,48
    80000780:	8082                	ret
    panic("uvmfirst: more than a page");
    80000782:	00007517          	auipc	a0,0x7
    80000786:	9a650513          	addi	a0,a0,-1626 # 80007128 <etext+0x128>
    8000078a:	59d040ef          	jal	ra,80005526 <panic>

000000008000078e <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000078e:	1101                	addi	sp,sp,-32
    80000790:	ec06                	sd	ra,24(sp)
    80000792:	e822                	sd	s0,16(sp)
    80000794:	e426                	sd	s1,8(sp)
    80000796:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80000798:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000079a:	00b67d63          	bgeu	a2,a1,800007b4 <uvmdealloc+0x26>
    8000079e:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800007a0:	6785                	lui	a5,0x1
    800007a2:	17fd                	addi	a5,a5,-1
    800007a4:	00f60733          	add	a4,a2,a5
    800007a8:	767d                	lui	a2,0xfffff
    800007aa:	8f71                	and	a4,a4,a2
    800007ac:	97ae                	add	a5,a5,a1
    800007ae:	8ff1                	and	a5,a5,a2
    800007b0:	00f76863          	bltu	a4,a5,800007c0 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800007b4:	8526                	mv	a0,s1
    800007b6:	60e2                	ld	ra,24(sp)
    800007b8:	6442                	ld	s0,16(sp)
    800007ba:	64a2                	ld	s1,8(sp)
    800007bc:	6105                	addi	sp,sp,32
    800007be:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800007c0:	8f99                	sub	a5,a5,a4
    800007c2:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800007c4:	4685                	li	a3,1
    800007c6:	0007861b          	sext.w	a2,a5
    800007ca:	85ba                	mv	a1,a4
    800007cc:	e83ff0ef          	jal	ra,8000064e <uvmunmap>
    800007d0:	b7d5                	j	800007b4 <uvmdealloc+0x26>

00000000800007d2 <uvmalloc>:
  if(newsz < oldsz)
    800007d2:	08b66963          	bltu	a2,a1,80000864 <uvmalloc+0x92>
{
    800007d6:	7139                	addi	sp,sp,-64
    800007d8:	fc06                	sd	ra,56(sp)
    800007da:	f822                	sd	s0,48(sp)
    800007dc:	f426                	sd	s1,40(sp)
    800007de:	f04a                	sd	s2,32(sp)
    800007e0:	ec4e                	sd	s3,24(sp)
    800007e2:	e852                	sd	s4,16(sp)
    800007e4:	e456                	sd	s5,8(sp)
    800007e6:	e05a                	sd	s6,0(sp)
    800007e8:	0080                	addi	s0,sp,64
    800007ea:	8aaa                	mv	s5,a0
    800007ec:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800007ee:	6985                	lui	s3,0x1
    800007f0:	19fd                	addi	s3,s3,-1
    800007f2:	95ce                	add	a1,a1,s3
    800007f4:	79fd                	lui	s3,0xfffff
    800007f6:	0135f9b3          	and	s3,a1,s3
  for(a = oldsz; a < newsz; a += sz){
    800007fa:	06c9f763          	bgeu	s3,a2,80000868 <uvmalloc+0x96>
    800007fe:	894e                	mv	s2,s3
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000800:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80000804:	8f9ff0ef          	jal	ra,800000fc <kalloc>
    80000808:	84aa                	mv	s1,a0
    if(mem == 0){
    8000080a:	c11d                	beqz	a0,80000830 <uvmalloc+0x5e>
    memset(mem, 0, sz);
    8000080c:	6605                	lui	a2,0x1
    8000080e:	4581                	li	a1,0
    80000810:	93dff0ef          	jal	ra,8000014c <memset>
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80000814:	875a                	mv	a4,s6
    80000816:	86a6                	mv	a3,s1
    80000818:	6605                	lui	a2,0x1
    8000081a:	85ca                	mv	a1,s2
    8000081c:	8556                	mv	a0,s5
    8000081e:	c8bff0ef          	jal	ra,800004a8 <mappages>
    80000822:	e51d                	bnez	a0,80000850 <uvmalloc+0x7e>
  for(a = oldsz; a < newsz; a += sz){
    80000824:	6785                	lui	a5,0x1
    80000826:	993e                	add	s2,s2,a5
    80000828:	fd496ee3          	bltu	s2,s4,80000804 <uvmalloc+0x32>
  return newsz;
    8000082c:	8552                	mv	a0,s4
    8000082e:	a039                	j	8000083c <uvmalloc+0x6a>
      uvmdealloc(pagetable, a, oldsz);
    80000830:	864e                	mv	a2,s3
    80000832:	85ca                	mv	a1,s2
    80000834:	8556                	mv	a0,s5
    80000836:	f59ff0ef          	jal	ra,8000078e <uvmdealloc>
      return 0;
    8000083a:	4501                	li	a0,0
}
    8000083c:	70e2                	ld	ra,56(sp)
    8000083e:	7442                	ld	s0,48(sp)
    80000840:	74a2                	ld	s1,40(sp)
    80000842:	7902                	ld	s2,32(sp)
    80000844:	69e2                	ld	s3,24(sp)
    80000846:	6a42                	ld	s4,16(sp)
    80000848:	6aa2                	ld	s5,8(sp)
    8000084a:	6b02                	ld	s6,0(sp)
    8000084c:	6121                	addi	sp,sp,64
    8000084e:	8082                	ret
      kfree(mem);
    80000850:	8526                	mv	a0,s1
    80000852:	fcaff0ef          	jal	ra,8000001c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80000856:	864e                	mv	a2,s3
    80000858:	85ca                	mv	a1,s2
    8000085a:	8556                	mv	a0,s5
    8000085c:	f33ff0ef          	jal	ra,8000078e <uvmdealloc>
      return 0;
    80000860:	4501                	li	a0,0
    80000862:	bfe9                	j	8000083c <uvmalloc+0x6a>
    return oldsz;
    80000864:	852e                	mv	a0,a1
}
    80000866:	8082                	ret
  return newsz;
    80000868:	8532                	mv	a0,a2
    8000086a:	bfc9                	j	8000083c <uvmalloc+0x6a>

000000008000086c <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000086c:	7179                	addi	sp,sp,-48
    8000086e:	f406                	sd	ra,40(sp)
    80000870:	f022                	sd	s0,32(sp)
    80000872:	ec26                	sd	s1,24(sp)
    80000874:	e84a                	sd	s2,16(sp)
    80000876:	e44e                	sd	s3,8(sp)
    80000878:	e052                	sd	s4,0(sp)
    8000087a:	1800                	addi	s0,sp,48
    8000087c:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000087e:	84aa                	mv	s1,a0
    80000880:	6905                	lui	s2,0x1
    80000882:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000884:	4985                	li	s3,1
    80000886:	a811                	j	8000089a <freewalk+0x2e>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80000888:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    8000088a:	0532                	slli	a0,a0,0xc
    8000088c:	fe1ff0ef          	jal	ra,8000086c <freewalk>
      pagetable[i] = 0;
    80000890:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80000894:	04a1                	addi	s1,s1,8
    80000896:	01248f63          	beq	s1,s2,800008b4 <freewalk+0x48>
    pte_t pte = pagetable[i];
    8000089a:	6088                	ld	a0,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000089c:	00f57793          	andi	a5,a0,15
    800008a0:	ff3784e3          	beq	a5,s3,80000888 <freewalk+0x1c>
    } else if(pte & PTE_V){
    800008a4:	8905                	andi	a0,a0,1
    800008a6:	d57d                	beqz	a0,80000894 <freewalk+0x28>
      panic("freewalk: leaf");
    800008a8:	00007517          	auipc	a0,0x7
    800008ac:	8a050513          	addi	a0,a0,-1888 # 80007148 <etext+0x148>
    800008b0:	477040ef          	jal	ra,80005526 <panic>
    }
  }
  kfree((void*)pagetable);
    800008b4:	8552                	mv	a0,s4
    800008b6:	f66ff0ef          	jal	ra,8000001c <kfree>
}
    800008ba:	70a2                	ld	ra,40(sp)
    800008bc:	7402                	ld	s0,32(sp)
    800008be:	64e2                	ld	s1,24(sp)
    800008c0:	6942                	ld	s2,16(sp)
    800008c2:	69a2                	ld	s3,8(sp)
    800008c4:	6a02                	ld	s4,0(sp)
    800008c6:	6145                	addi	sp,sp,48
    800008c8:	8082                	ret

00000000800008ca <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800008ca:	1101                	addi	sp,sp,-32
    800008cc:	ec06                	sd	ra,24(sp)
    800008ce:	e822                	sd	s0,16(sp)
    800008d0:	e426                	sd	s1,8(sp)
    800008d2:	1000                	addi	s0,sp,32
    800008d4:	84aa                	mv	s1,a0
  if(sz > 0)
    800008d6:	e989                	bnez	a1,800008e8 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800008d8:	8526                	mv	a0,s1
    800008da:	f93ff0ef          	jal	ra,8000086c <freewalk>
}
    800008de:	60e2                	ld	ra,24(sp)
    800008e0:	6442                	ld	s0,16(sp)
    800008e2:	64a2                	ld	s1,8(sp)
    800008e4:	6105                	addi	sp,sp,32
    800008e6:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800008e8:	6605                	lui	a2,0x1
    800008ea:	167d                	addi	a2,a2,-1
    800008ec:	962e                	add	a2,a2,a1
    800008ee:	4685                	li	a3,1
    800008f0:	8231                	srli	a2,a2,0xc
    800008f2:	4581                	li	a1,0
    800008f4:	d5bff0ef          	jal	ra,8000064e <uvmunmap>
    800008f8:	b7c5                	j	800008d8 <uvmfree+0xe>

00000000800008fa <uvmcopy>:
  uint64 pa, i;
  uint flags;
  char *mem;
  int szinc;

  for(i = 0; i < sz; i += szinc){
    800008fa:	c65d                	beqz	a2,800009a8 <uvmcopy+0xae>
{
    800008fc:	715d                	addi	sp,sp,-80
    800008fe:	e486                	sd	ra,72(sp)
    80000900:	e0a2                	sd	s0,64(sp)
    80000902:	fc26                	sd	s1,56(sp)
    80000904:	f84a                	sd	s2,48(sp)
    80000906:	f44e                	sd	s3,40(sp)
    80000908:	f052                	sd	s4,32(sp)
    8000090a:	ec56                	sd	s5,24(sp)
    8000090c:	e85a                	sd	s6,16(sp)
    8000090e:	e45e                	sd	s7,8(sp)
    80000910:	0880                	addi	s0,sp,80
    80000912:	8b2a                	mv	s6,a0
    80000914:	8aae                	mv	s5,a1
    80000916:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += szinc){
    80000918:	4981                	li	s3,0
    szinc = PGSIZE;
    szinc = PGSIZE;
    if((pte = walk(old, i, 0)) == 0)
    8000091a:	4601                	li	a2,0
    8000091c:	85ce                	mv	a1,s3
    8000091e:	855a                	mv	a0,s6
    80000920:	aa9ff0ef          	jal	ra,800003c8 <walk>
    80000924:	c121                	beqz	a0,80000964 <uvmcopy+0x6a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    80000926:	6118                	ld	a4,0(a0)
    80000928:	00177793          	andi	a5,a4,1
    8000092c:	c3b1                	beqz	a5,80000970 <uvmcopy+0x76>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    8000092e:	00a75593          	srli	a1,a4,0xa
    80000932:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80000936:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    8000093a:	fc2ff0ef          	jal	ra,800000fc <kalloc>
    8000093e:	892a                	mv	s2,a0
    80000940:	c129                	beqz	a0,80000982 <uvmcopy+0x88>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80000942:	6605                	lui	a2,0x1
    80000944:	85de                	mv	a1,s7
    80000946:	863ff0ef          	jal	ra,800001a8 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    8000094a:	8726                	mv	a4,s1
    8000094c:	86ca                	mv	a3,s2
    8000094e:	6605                	lui	a2,0x1
    80000950:	85ce                	mv	a1,s3
    80000952:	8556                	mv	a0,s5
    80000954:	b55ff0ef          	jal	ra,800004a8 <mappages>
    80000958:	e115                	bnez	a0,8000097c <uvmcopy+0x82>
  for(i = 0; i < sz; i += szinc){
    8000095a:	6785                	lui	a5,0x1
    8000095c:	99be                	add	s3,s3,a5
    8000095e:	fb49eee3          	bltu	s3,s4,8000091a <uvmcopy+0x20>
    80000962:	a805                	j	80000992 <uvmcopy+0x98>
      panic("uvmcopy: pte should exist");
    80000964:	00006517          	auipc	a0,0x6
    80000968:	7f450513          	addi	a0,a0,2036 # 80007158 <etext+0x158>
    8000096c:	3bb040ef          	jal	ra,80005526 <panic>
      panic("uvmcopy: page not present");
    80000970:	00007517          	auipc	a0,0x7
    80000974:	80850513          	addi	a0,a0,-2040 # 80007178 <etext+0x178>
    80000978:	3af040ef          	jal	ra,80005526 <panic>
      kfree(mem);
    8000097c:	854a                	mv	a0,s2
    8000097e:	e9eff0ef          	jal	ra,8000001c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80000982:	4685                	li	a3,1
    80000984:	00c9d613          	srli	a2,s3,0xc
    80000988:	4581                	li	a1,0
    8000098a:	8556                	mv	a0,s5
    8000098c:	cc3ff0ef          	jal	ra,8000064e <uvmunmap>
  return -1;
    80000990:	557d                	li	a0,-1
}
    80000992:	60a6                	ld	ra,72(sp)
    80000994:	6406                	ld	s0,64(sp)
    80000996:	74e2                	ld	s1,56(sp)
    80000998:	7942                	ld	s2,48(sp)
    8000099a:	79a2                	ld	s3,40(sp)
    8000099c:	7a02                	ld	s4,32(sp)
    8000099e:	6ae2                	ld	s5,24(sp)
    800009a0:	6b42                	ld	s6,16(sp)
    800009a2:	6ba2                	ld	s7,8(sp)
    800009a4:	6161                	addi	sp,sp,80
    800009a6:	8082                	ret
  return 0;
    800009a8:	4501                	li	a0,0
}
    800009aa:	8082                	ret

00000000800009ac <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800009ac:	1141                	addi	sp,sp,-16
    800009ae:	e406                	sd	ra,8(sp)
    800009b0:	e022                	sd	s0,0(sp)
    800009b2:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800009b4:	4601                	li	a2,0
    800009b6:	a13ff0ef          	jal	ra,800003c8 <walk>
  if(pte == 0)
    800009ba:	c901                	beqz	a0,800009ca <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800009bc:	611c                	ld	a5,0(a0)
    800009be:	9bbd                	andi	a5,a5,-17
    800009c0:	e11c                	sd	a5,0(a0)
}
    800009c2:	60a2                	ld	ra,8(sp)
    800009c4:	6402                	ld	s0,0(sp)
    800009c6:	0141                	addi	sp,sp,16
    800009c8:	8082                	ret
    panic("uvmclear");
    800009ca:	00006517          	auipc	a0,0x6
    800009ce:	7ce50513          	addi	a0,a0,1998 # 80007198 <etext+0x198>
    800009d2:	355040ef          	jal	ra,80005526 <panic>

00000000800009d6 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    800009d6:	c6c1                	beqz	a3,80000a5e <copyout+0x88>
{
    800009d8:	711d                	addi	sp,sp,-96
    800009da:	ec86                	sd	ra,88(sp)
    800009dc:	e8a2                	sd	s0,80(sp)
    800009de:	e4a6                	sd	s1,72(sp)
    800009e0:	e0ca                	sd	s2,64(sp)
    800009e2:	fc4e                	sd	s3,56(sp)
    800009e4:	f852                	sd	s4,48(sp)
    800009e6:	f456                	sd	s5,40(sp)
    800009e8:	f05a                	sd	s6,32(sp)
    800009ea:	ec5e                	sd	s7,24(sp)
    800009ec:	e862                	sd	s8,16(sp)
    800009ee:	e466                	sd	s9,8(sp)
    800009f0:	1080                	addi	s0,sp,96
    800009f2:	8b2a                	mv	s6,a0
    800009f4:	8a2e                	mv	s4,a1
    800009f6:	8ab2                	mv	s5,a2
    800009f8:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    800009fa:	74fd                	lui	s1,0xfffff
    800009fc:	8ced                	and	s1,s1,a1
    if (va0 >= MAXVA)
    800009fe:	57fd                	li	a5,-1
    80000a00:	83e9                	srli	a5,a5,0x1a
    80000a02:	0697e063          	bltu	a5,s1,80000a62 <copyout+0x8c>
    80000a06:	6c05                	lui	s8,0x1
    80000a08:	8bbe                	mv	s7,a5
    80000a0a:	a015                	j	80000a2e <copyout+0x58>
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80000a0c:	409a04b3          	sub	s1,s4,s1
    80000a10:	0009061b          	sext.w	a2,s2
    80000a14:	85d6                	mv	a1,s5
    80000a16:	9526                	add	a0,a0,s1
    80000a18:	f90ff0ef          	jal	ra,800001a8 <memmove>

    len -= n;
    80000a1c:	412989b3          	sub	s3,s3,s2
    src += n;
    80000a20:	9aca                	add	s5,s5,s2
  while(len > 0){
    80000a22:	02098c63          	beqz	s3,80000a5a <copyout+0x84>
    if (va0 >= MAXVA)
    80000a26:	059be063          	bltu	s7,s9,80000a66 <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    80000a2a:	84e6                	mv	s1,s9
    dstva = va0 + PGSIZE;
    80000a2c:	8a66                	mv	s4,s9
    if((pte = walk(pagetable, va0, 0)) == 0) {
    80000a2e:	4601                	li	a2,0
    80000a30:	85a6                	mv	a1,s1
    80000a32:	855a                	mv	a0,s6
    80000a34:	995ff0ef          	jal	ra,800003c8 <walk>
    80000a38:	c90d                	beqz	a0,80000a6a <copyout+0x94>
    if((*pte & PTE_W) == 0)
    80000a3a:	611c                	ld	a5,0(a0)
    80000a3c:	8b91                	andi	a5,a5,4
    80000a3e:	c7a1                	beqz	a5,80000a86 <copyout+0xb0>
    pa0 = walkaddr(pagetable, va0);
    80000a40:	85a6                	mv	a1,s1
    80000a42:	855a                	mv	a0,s6
    80000a44:	a27ff0ef          	jal	ra,8000046a <walkaddr>
    if(pa0 == 0)
    80000a48:	c129                	beqz	a0,80000a8a <copyout+0xb4>
    n = PGSIZE - (dstva - va0);
    80000a4a:	01848cb3          	add	s9,s1,s8
    80000a4e:	414c8933          	sub	s2,s9,s4
    if(n > len)
    80000a52:	fb29fde3          	bgeu	s3,s2,80000a0c <copyout+0x36>
    80000a56:	894e                	mv	s2,s3
    80000a58:	bf55                	j	80000a0c <copyout+0x36>
  }
  return 0;
    80000a5a:	4501                	li	a0,0
    80000a5c:	a801                	j	80000a6c <copyout+0x96>
    80000a5e:	4501                	li	a0,0
}
    80000a60:	8082                	ret
      return -1;
    80000a62:	557d                	li	a0,-1
    80000a64:	a021                	j	80000a6c <copyout+0x96>
    80000a66:	557d                	li	a0,-1
    80000a68:	a011                	j	80000a6c <copyout+0x96>
      return -1;
    80000a6a:	557d                	li	a0,-1
}
    80000a6c:	60e6                	ld	ra,88(sp)
    80000a6e:	6446                	ld	s0,80(sp)
    80000a70:	64a6                	ld	s1,72(sp)
    80000a72:	6906                	ld	s2,64(sp)
    80000a74:	79e2                	ld	s3,56(sp)
    80000a76:	7a42                	ld	s4,48(sp)
    80000a78:	7aa2                	ld	s5,40(sp)
    80000a7a:	7b02                	ld	s6,32(sp)
    80000a7c:	6be2                	ld	s7,24(sp)
    80000a7e:	6c42                	ld	s8,16(sp)
    80000a80:	6ca2                	ld	s9,8(sp)
    80000a82:	6125                	addi	sp,sp,96
    80000a84:	8082                	ret
      return -1;
    80000a86:	557d                	li	a0,-1
    80000a88:	b7d5                	j	80000a6c <copyout+0x96>
      return -1;
    80000a8a:	557d                	li	a0,-1
    80000a8c:	b7c5                	j	80000a6c <copyout+0x96>

0000000080000a8e <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;
  
  while(len > 0){
    80000a8e:	c6a5                	beqz	a3,80000af6 <copyin+0x68>
{
    80000a90:	715d                	addi	sp,sp,-80
    80000a92:	e486                	sd	ra,72(sp)
    80000a94:	e0a2                	sd	s0,64(sp)
    80000a96:	fc26                	sd	s1,56(sp)
    80000a98:	f84a                	sd	s2,48(sp)
    80000a9a:	f44e                	sd	s3,40(sp)
    80000a9c:	f052                	sd	s4,32(sp)
    80000a9e:	ec56                	sd	s5,24(sp)
    80000aa0:	e85a                	sd	s6,16(sp)
    80000aa2:	e45e                	sd	s7,8(sp)
    80000aa4:	e062                	sd	s8,0(sp)
    80000aa6:	0880                	addi	s0,sp,80
    80000aa8:	8b2a                	mv	s6,a0
    80000aaa:	8a2e                	mv	s4,a1
    80000aac:	8c32                	mv	s8,a2
    80000aae:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80000ab0:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000ab2:	6a85                	lui	s5,0x1
    80000ab4:	a00d                	j	80000ad6 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80000ab6:	018505b3          	add	a1,a0,s8
    80000aba:	0004861b          	sext.w	a2,s1
    80000abe:	412585b3          	sub	a1,a1,s2
    80000ac2:	8552                	mv	a0,s4
    80000ac4:	ee4ff0ef          	jal	ra,800001a8 <memmove>

    len -= n;
    80000ac8:	409989b3          	sub	s3,s3,s1
    dst += n;
    80000acc:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    80000ace:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80000ad2:	02098063          	beqz	s3,80000af2 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    80000ad6:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80000ada:	85ca                	mv	a1,s2
    80000adc:	855a                	mv	a0,s6
    80000ade:	98dff0ef          	jal	ra,8000046a <walkaddr>
    if(pa0 == 0)
    80000ae2:	cd01                	beqz	a0,80000afa <copyin+0x6c>
    n = PGSIZE - (srcva - va0);
    80000ae4:	418904b3          	sub	s1,s2,s8
    80000ae8:	94d6                	add	s1,s1,s5
    if(n > len)
    80000aea:	fc99f6e3          	bgeu	s3,s1,80000ab6 <copyin+0x28>
    80000aee:	84ce                	mv	s1,s3
    80000af0:	b7d9                	j	80000ab6 <copyin+0x28>
  }
  return 0;
    80000af2:	4501                	li	a0,0
    80000af4:	a021                	j	80000afc <copyin+0x6e>
    80000af6:	4501                	li	a0,0
}
    80000af8:	8082                	ret
      return -1;
    80000afa:	557d                	li	a0,-1
}
    80000afc:	60a6                	ld	ra,72(sp)
    80000afe:	6406                	ld	s0,64(sp)
    80000b00:	74e2                	ld	s1,56(sp)
    80000b02:	7942                	ld	s2,48(sp)
    80000b04:	79a2                	ld	s3,40(sp)
    80000b06:	7a02                	ld	s4,32(sp)
    80000b08:	6ae2                	ld	s5,24(sp)
    80000b0a:	6b42                	ld	s6,16(sp)
    80000b0c:	6ba2                	ld	s7,8(sp)
    80000b0e:	6c02                	ld	s8,0(sp)
    80000b10:	6161                	addi	sp,sp,80
    80000b12:	8082                	ret

0000000080000b14 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80000b14:	c2d5                	beqz	a3,80000bb8 <copyinstr+0xa4>
{
    80000b16:	715d                	addi	sp,sp,-80
    80000b18:	e486                	sd	ra,72(sp)
    80000b1a:	e0a2                	sd	s0,64(sp)
    80000b1c:	fc26                	sd	s1,56(sp)
    80000b1e:	f84a                	sd	s2,48(sp)
    80000b20:	f44e                	sd	s3,40(sp)
    80000b22:	f052                	sd	s4,32(sp)
    80000b24:	ec56                	sd	s5,24(sp)
    80000b26:	e85a                	sd	s6,16(sp)
    80000b28:	e45e                	sd	s7,8(sp)
    80000b2a:	0880                	addi	s0,sp,80
    80000b2c:	8a2a                	mv	s4,a0
    80000b2e:	8b2e                	mv	s6,a1
    80000b30:	8bb2                	mv	s7,a2
    80000b32:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    80000b34:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80000b36:	6985                	lui	s3,0x1
    80000b38:	a035                	j	80000b64 <copyinstr+0x50>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80000b3a:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80000b3e:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80000b40:	0017b793          	seqz	a5,a5
    80000b44:	40f00533          	neg	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80000b48:	60a6                	ld	ra,72(sp)
    80000b4a:	6406                	ld	s0,64(sp)
    80000b4c:	74e2                	ld	s1,56(sp)
    80000b4e:	7942                	ld	s2,48(sp)
    80000b50:	79a2                	ld	s3,40(sp)
    80000b52:	7a02                	ld	s4,32(sp)
    80000b54:	6ae2                	ld	s5,24(sp)
    80000b56:	6b42                	ld	s6,16(sp)
    80000b58:	6ba2                	ld	s7,8(sp)
    80000b5a:	6161                	addi	sp,sp,80
    80000b5c:	8082                	ret
    srcva = va0 + PGSIZE;
    80000b5e:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    80000b62:	c4b9                	beqz	s1,80000bb0 <copyinstr+0x9c>
    va0 = PGROUNDDOWN(srcva);
    80000b64:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    80000b68:	85ca                	mv	a1,s2
    80000b6a:	8552                	mv	a0,s4
    80000b6c:	8ffff0ef          	jal	ra,8000046a <walkaddr>
    if(pa0 == 0)
    80000b70:	c131                	beqz	a0,80000bb4 <copyinstr+0xa0>
    n = PGSIZE - (srcva - va0);
    80000b72:	41790833          	sub	a6,s2,s7
    80000b76:	984e                	add	a6,a6,s3
    if(n > max)
    80000b78:	0104f363          	bgeu	s1,a6,80000b7e <copyinstr+0x6a>
    80000b7c:	8826                	mv	a6,s1
    char *p = (char *) (pa0 + (srcva - va0));
    80000b7e:	955e                	add	a0,a0,s7
    80000b80:	41250533          	sub	a0,a0,s2
    while(n > 0){
    80000b84:	fc080de3          	beqz	a6,80000b5e <copyinstr+0x4a>
    80000b88:	985a                	add	a6,a6,s6
    80000b8a:	87da                	mv	a5,s6
      if(*p == '\0'){
    80000b8c:	41650633          	sub	a2,a0,s6
    80000b90:	14fd                	addi	s1,s1,-1
    80000b92:	9b26                	add	s6,s6,s1
    80000b94:	00f60733          	add	a4,a2,a5
    80000b98:	00074703          	lbu	a4,0(a4)
    80000b9c:	df59                	beqz	a4,80000b3a <copyinstr+0x26>
        *dst = *p;
    80000b9e:	00e78023          	sb	a4,0(a5)
      --max;
    80000ba2:	40fb04b3          	sub	s1,s6,a5
      dst++;
    80000ba6:	0785                	addi	a5,a5,1
    while(n > 0){
    80000ba8:	ff0796e3          	bne	a5,a6,80000b94 <copyinstr+0x80>
      dst++;
    80000bac:	8b42                	mv	s6,a6
    80000bae:	bf45                	j	80000b5e <copyinstr+0x4a>
    80000bb0:	4781                	li	a5,0
    80000bb2:	b779                	j	80000b40 <copyinstr+0x2c>
      return -1;
    80000bb4:	557d                	li	a0,-1
    80000bb6:	bf49                	j	80000b48 <copyinstr+0x34>
  int got_null = 0;
    80000bb8:	4781                	li	a5,0
  if(got_null){
    80000bba:	0017b793          	seqz	a5,a5
    80000bbe:	40f00533          	neg	a0,a5
}
    80000bc2:	8082                	ret

0000000080000bc4 <_vmprint>:


#ifdef LAB_PGTBL
void
_vmprint(pagetable_t pt, int level) {
    80000bc4:	7159                	addi	sp,sp,-112
    80000bc6:	f486                	sd	ra,104(sp)
    80000bc8:	f0a2                	sd	s0,96(sp)
    80000bca:	eca6                	sd	s1,88(sp)
    80000bcc:	e8ca                	sd	s2,80(sp)
    80000bce:	e4ce                	sd	s3,72(sp)
    80000bd0:	e0d2                	sd	s4,64(sp)
    80000bd2:	fc56                	sd	s5,56(sp)
    80000bd4:	f85a                	sd	s6,48(sp)
    80000bd6:	f45e                	sd	s7,40(sp)
    80000bd8:	f062                	sd	s8,32(sp)
    80000bda:	ec66                	sd	s9,24(sp)
    80000bdc:	e86a                	sd	s10,16(sp)
    80000bde:	e46e                	sd	s11,8(sp)
    80000be0:	1880                	addi	s0,sp,112
    80000be2:	8aae                	mv	s5,a1
    for(int i = 0; i < 512; i++){
    80000be4:	8a2a                	mv	s4,a0
    80000be6:	4981                	li	s3,0
      uint64 child = PTE2PA(pte);
      for(int j = 0; j < level; j++){
        printf("..");
        if(j < level-1) printf(" ");
      }
      printf("%d: pte %p pa %p\n", i, (void *)pte, (void *)child);
    80000be8:	00006d17          	auipc	s10,0x6
    80000bec:	5d0d0d13          	addi	s10,s10,1488 # 800071b8 <etext+0x1b8>

      if((pte & (PTE_R|PTE_W|PTE_X)) == 0){
        _vmprint((pagetable_t)child, level+1);
    80000bf0:	00158d9b          	addiw	s11,a1,1
        printf("..");
    80000bf4:	00006b97          	auipc	s7,0x6
    80000bf8:	5b4b8b93          	addi	s7,s7,1460 # 800071a8 <etext+0x1a8>
        if(j < level-1) printf(" ");
    80000bfc:	fff58b1b          	addiw	s6,a1,-1
    80000c00:	00006c97          	auipc	s9,0x6
    80000c04:	5b0c8c93          	addi	s9,s9,1456 # 800071b0 <etext+0x1b0>
    80000c08:	a82d                	j	80000c42 <_vmprint+0x7e>
      for(int j = 0; j < level; j++){
    80000c0a:	2485                	addiw	s1,s1,1
    80000c0c:	009a8b63          	beq	s5,s1,80000c22 <_vmprint+0x5e>
        printf("..");
    80000c10:	855e                	mv	a0,s7
    80000c12:	660040ef          	jal	ra,80005272 <printf>
        if(j < level-1) printf(" ");
    80000c16:	ff64dae3          	bge	s1,s6,80000c0a <_vmprint+0x46>
    80000c1a:	8566                	mv	a0,s9
    80000c1c:	656040ef          	jal	ra,80005272 <printf>
    80000c20:	b7ed                	j	80000c0a <_vmprint+0x46>
      printf("%d: pte %p pa %p\n", i, (void *)pte, (void *)child);
    80000c22:	86e2                	mv	a3,s8
    80000c24:	864a                	mv	a2,s2
    80000c26:	85ce                	mv	a1,s3
    80000c28:	856a                	mv	a0,s10
    80000c2a:	648040ef          	jal	ra,80005272 <printf>
      if((pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80000c2e:	00e97913          	andi	s2,s2,14
    80000c32:	02090463          	beqz	s2,80000c5a <_vmprint+0x96>
    for(int i = 0; i < 512; i++){
    80000c36:	2985                	addiw	s3,s3,1
    80000c38:	0a21                	addi	s4,s4,8
    80000c3a:	20000793          	li	a5,512
    80000c3e:	02f98363          	beq	s3,a5,80000c64 <_vmprint+0xa0>
    pte_t pte = pt[i];
    80000c42:	000a3903          	ld	s2,0(s4) # fffffffffffff000 <end+0xffffffff7ffde120>
    if(pte & PTE_V){
    80000c46:	00197793          	andi	a5,s2,1
    80000c4a:	d7f5                	beqz	a5,80000c36 <_vmprint+0x72>
      uint64 child = PTE2PA(pte);
    80000c4c:	00a95c13          	srli	s8,s2,0xa
    80000c50:	0c32                	slli	s8,s8,0xc
      for(int j = 0; j < level; j++){
    80000c52:	fd5058e3          	blez	s5,80000c22 <_vmprint+0x5e>
    80000c56:	4481                	li	s1,0
    80000c58:	bf65                	j	80000c10 <_vmprint+0x4c>
        _vmprint((pagetable_t)child, level+1);
    80000c5a:	85ee                	mv	a1,s11
    80000c5c:	8562                	mv	a0,s8
    80000c5e:	f67ff0ef          	jal	ra,80000bc4 <_vmprint>
    80000c62:	bfd1                	j	80000c36 <_vmprint+0x72>
      }
    }
  }
}
    80000c64:	70a6                	ld	ra,104(sp)
    80000c66:	7406                	ld	s0,96(sp)
    80000c68:	64e6                	ld	s1,88(sp)
    80000c6a:	6946                	ld	s2,80(sp)
    80000c6c:	69a6                	ld	s3,72(sp)
    80000c6e:	6a06                	ld	s4,64(sp)
    80000c70:	7ae2                	ld	s5,56(sp)
    80000c72:	7b42                	ld	s6,48(sp)
    80000c74:	7ba2                	ld	s7,40(sp)
    80000c76:	7c02                	ld	s8,32(sp)
    80000c78:	6ce2                	ld	s9,24(sp)
    80000c7a:	6d42                	ld	s10,16(sp)
    80000c7c:	6da2                	ld	s11,8(sp)
    80000c7e:	6165                	addi	sp,sp,112
    80000c80:	8082                	ret

0000000080000c82 <vmprint>:
void
vmprint(pagetable_t pagetable) {
    80000c82:	1101                	addi	sp,sp,-32
    80000c84:	ec06                	sd	ra,24(sp)
    80000c86:	e822                	sd	s0,16(sp)
    80000c88:	e426                	sd	s1,8(sp)
    80000c8a:	1000                	addi	s0,sp,32
    80000c8c:	84aa                	mv	s1,a0
  // your code here
  printf("page table %p\n", pagetable);
    80000c8e:	85aa                	mv	a1,a0
    80000c90:	00006517          	auipc	a0,0x6
    80000c94:	54050513          	addi	a0,a0,1344 # 800071d0 <etext+0x1d0>
    80000c98:	5da040ef          	jal	ra,80005272 <printf>
  _vmprint(pagetable, 1);
    80000c9c:	4585                	li	a1,1
    80000c9e:	8526                	mv	a0,s1
    80000ca0:	f25ff0ef          	jal	ra,80000bc4 <_vmprint>
}
    80000ca4:	60e2                	ld	ra,24(sp)
    80000ca6:	6442                	ld	s0,16(sp)
    80000ca8:	64a2                	ld	s1,8(sp)
    80000caa:	6105                	addi	sp,sp,32
    80000cac:	8082                	ret

0000000080000cae <pgpte>:



#ifdef LAB_PGTBL
pte_t*
pgpte(pagetable_t pagetable, uint64 va) {
    80000cae:	1141                	addi	sp,sp,-16
    80000cb0:	e406                	sd	ra,8(sp)
    80000cb2:	e022                	sd	s0,0(sp)
    80000cb4:	0800                	addi	s0,sp,16
  return walk(pagetable, va, 0);
    80000cb6:	4601                	li	a2,0
    80000cb8:	f10ff0ef          	jal	ra,800003c8 <walk>
}
    80000cbc:	60a2                	ld	ra,8(sp)
    80000cbe:	6402                	ld	s0,0(sp)
    80000cc0:	0141                	addi	sp,sp,16
    80000cc2:	8082                	ret

0000000080000cc4 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80000cc4:	7139                	addi	sp,sp,-64
    80000cc6:	fc06                	sd	ra,56(sp)
    80000cc8:	f822                	sd	s0,48(sp)
    80000cca:	f426                	sd	s1,40(sp)
    80000ccc:	f04a                	sd	s2,32(sp)
    80000cce:	ec4e                	sd	s3,24(sp)
    80000cd0:	e852                	sd	s4,16(sp)
    80000cd2:	e456                	sd	s5,8(sp)
    80000cd4:	e05a                	sd	s6,0(sp)
    80000cd6:	0080                	addi	s0,sp,64
    80000cd8:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cda:	00007497          	auipc	s1,0x7
    80000cde:	12648493          	addi	s1,s1,294 # 80007e00 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80000ce2:	8b26                	mv	s6,s1
    80000ce4:	00006a97          	auipc	s5,0x6
    80000ce8:	31ca8a93          	addi	s5,s5,796 # 80007000 <etext>
    80000cec:	01000937          	lui	s2,0x1000
    80000cf0:	197d                	addi	s2,s2,-1
    80000cf2:	093a                	slli	s2,s2,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000cf4:	0000da17          	auipc	s4,0xd
    80000cf8:	d0ca0a13          	addi	s4,s4,-756 # 8000da00 <tickslock>
    char *pa = kalloc();
    80000cfc:	c00ff0ef          	jal	ra,800000fc <kalloc>
    80000d00:	862a                	mv	a2,a0
    if(pa == 0)
    80000d02:	cd1d                	beqz	a0,80000d40 <proc_mapstacks+0x7c>
    uint64 va = KSTACK((int) (p - proc));
    80000d04:	416485b3          	sub	a1,s1,s6
    80000d08:	8591                	srai	a1,a1,0x4
    80000d0a:	000ab783          	ld	a5,0(s5)
    80000d0e:	02f585b3          	mul	a1,a1,a5
    80000d12:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80000d16:	4719                	li	a4,6
    80000d18:	6685                	lui	a3,0x1
    80000d1a:	40b905b3          	sub	a1,s2,a1
    80000d1e:	854e                	mv	a0,s3
    80000d20:	839ff0ef          	jal	ra,80000558 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d24:	17048493          	addi	s1,s1,368
    80000d28:	fd449ae3          	bne	s1,s4,80000cfc <proc_mapstacks+0x38>
  }
}
    80000d2c:	70e2                	ld	ra,56(sp)
    80000d2e:	7442                	ld	s0,48(sp)
    80000d30:	74a2                	ld	s1,40(sp)
    80000d32:	7902                	ld	s2,32(sp)
    80000d34:	69e2                	ld	s3,24(sp)
    80000d36:	6a42                	ld	s4,16(sp)
    80000d38:	6aa2                	ld	s5,8(sp)
    80000d3a:	6b02                	ld	s6,0(sp)
    80000d3c:	6121                	addi	sp,sp,64
    80000d3e:	8082                	ret
      panic("kalloc");
    80000d40:	00006517          	auipc	a0,0x6
    80000d44:	4a050513          	addi	a0,a0,1184 # 800071e0 <etext+0x1e0>
    80000d48:	7de040ef          	jal	ra,80005526 <panic>

0000000080000d4c <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80000d4c:	7139                	addi	sp,sp,-64
    80000d4e:	fc06                	sd	ra,56(sp)
    80000d50:	f822                	sd	s0,48(sp)
    80000d52:	f426                	sd	s1,40(sp)
    80000d54:	f04a                	sd	s2,32(sp)
    80000d56:	ec4e                	sd	s3,24(sp)
    80000d58:	e852                	sd	s4,16(sp)
    80000d5a:	e456                	sd	s5,8(sp)
    80000d5c:	e05a                	sd	s6,0(sp)
    80000d5e:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80000d60:	00006597          	auipc	a1,0x6
    80000d64:	48858593          	addi	a1,a1,1160 # 800071e8 <etext+0x1e8>
    80000d68:	00007517          	auipc	a0,0x7
    80000d6c:	c6850513          	addi	a0,a0,-920 # 800079d0 <pid_lock>
    80000d70:	24b040ef          	jal	ra,800057ba <initlock>
  initlock(&wait_lock, "wait_lock");
    80000d74:	00006597          	auipc	a1,0x6
    80000d78:	47c58593          	addi	a1,a1,1148 # 800071f0 <etext+0x1f0>
    80000d7c:	00007517          	auipc	a0,0x7
    80000d80:	c6c50513          	addi	a0,a0,-916 # 800079e8 <wait_lock>
    80000d84:	237040ef          	jal	ra,800057ba <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80000d88:	00007497          	auipc	s1,0x7
    80000d8c:	07848493          	addi	s1,s1,120 # 80007e00 <proc>
      initlock(&p->lock, "proc");
    80000d90:	00006b17          	auipc	s6,0x6
    80000d94:	470b0b13          	addi	s6,s6,1136 # 80007200 <etext+0x200>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80000d98:	8aa6                	mv	s5,s1
    80000d9a:	00006a17          	auipc	s4,0x6
    80000d9e:	266a0a13          	addi	s4,s4,614 # 80007000 <etext>
    80000da2:	01000937          	lui	s2,0x1000
    80000da6:	197d                	addi	s2,s2,-1
    80000da8:	093a                	slli	s2,s2,0xe
  for(p = proc; p < &proc[NPROC]; p++) {
    80000daa:	0000d997          	auipc	s3,0xd
    80000dae:	c5698993          	addi	s3,s3,-938 # 8000da00 <tickslock>
      initlock(&p->lock, "proc");
    80000db2:	85da                	mv	a1,s6
    80000db4:	8526                	mv	a0,s1
    80000db6:	205040ef          	jal	ra,800057ba <initlock>
      p->state = UNUSED;
    80000dba:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80000dbe:	415487b3          	sub	a5,s1,s5
    80000dc2:	8791                	srai	a5,a5,0x4
    80000dc4:	000a3703          	ld	a4,0(s4)
    80000dc8:	02e787b3          	mul	a5,a5,a4
    80000dcc:	00d7979b          	slliw	a5,a5,0xd
    80000dd0:	40f907b3          	sub	a5,s2,a5
    80000dd4:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80000dd6:	17048493          	addi	s1,s1,368
    80000dda:	fd349ce3          	bne	s1,s3,80000db2 <procinit+0x66>
  }
}
    80000dde:	70e2                	ld	ra,56(sp)
    80000de0:	7442                	ld	s0,48(sp)
    80000de2:	74a2                	ld	s1,40(sp)
    80000de4:	7902                	ld	s2,32(sp)
    80000de6:	69e2                	ld	s3,24(sp)
    80000de8:	6a42                	ld	s4,16(sp)
    80000dea:	6aa2                	ld	s5,8(sp)
    80000dec:	6b02                	ld	s6,0(sp)
    80000dee:	6121                	addi	sp,sp,64
    80000df0:	8082                	ret

0000000080000df2 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80000df2:	1141                	addi	sp,sp,-16
    80000df4:	e422                	sd	s0,8(sp)
    80000df6:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80000df8:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80000dfa:	2501                	sext.w	a0,a0
    80000dfc:	6422                	ld	s0,8(sp)
    80000dfe:	0141                	addi	sp,sp,16
    80000e00:	8082                	ret

0000000080000e02 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80000e02:	1141                	addi	sp,sp,-16
    80000e04:	e422                	sd	s0,8(sp)
    80000e06:	0800                	addi	s0,sp,16
    80000e08:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80000e0a:	2781                	sext.w	a5,a5
    80000e0c:	079e                	slli	a5,a5,0x7
  return c;
}
    80000e0e:	00007517          	auipc	a0,0x7
    80000e12:	bf250513          	addi	a0,a0,-1038 # 80007a00 <cpus>
    80000e16:	953e                	add	a0,a0,a5
    80000e18:	6422                	ld	s0,8(sp)
    80000e1a:	0141                	addi	sp,sp,16
    80000e1c:	8082                	ret

0000000080000e1e <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80000e1e:	1101                	addi	sp,sp,-32
    80000e20:	ec06                	sd	ra,24(sp)
    80000e22:	e822                	sd	s0,16(sp)
    80000e24:	e426                	sd	s1,8(sp)
    80000e26:	1000                	addi	s0,sp,32
  push_off();
    80000e28:	1d3040ef          	jal	ra,800057fa <push_off>
    80000e2c:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80000e2e:	2781                	sext.w	a5,a5
    80000e30:	079e                	slli	a5,a5,0x7
    80000e32:	00007717          	auipc	a4,0x7
    80000e36:	b9e70713          	addi	a4,a4,-1122 # 800079d0 <pid_lock>
    80000e3a:	97ba                	add	a5,a5,a4
    80000e3c:	7b84                	ld	s1,48(a5)
  pop_off();
    80000e3e:	241040ef          	jal	ra,8000587e <pop_off>
  return p;
}
    80000e42:	8526                	mv	a0,s1
    80000e44:	60e2                	ld	ra,24(sp)
    80000e46:	6442                	ld	s0,16(sp)
    80000e48:	64a2                	ld	s1,8(sp)
    80000e4a:	6105                	addi	sp,sp,32
    80000e4c:	8082                	ret

0000000080000e4e <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80000e4e:	1141                	addi	sp,sp,-16
    80000e50:	e406                	sd	ra,8(sp)
    80000e52:	e022                	sd	s0,0(sp)
    80000e54:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80000e56:	fc9ff0ef          	jal	ra,80000e1e <myproc>
    80000e5a:	279040ef          	jal	ra,800058d2 <release>

  if (first) {
    80000e5e:	00007797          	auipc	a5,0x7
    80000e62:	ad27a783          	lw	a5,-1326(a5) # 80007930 <first.1>
    80000e66:	e799                	bnez	a5,80000e74 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80000e68:	35d000ef          	jal	ra,800019c4 <usertrapret>
}
    80000e6c:	60a2                	ld	ra,8(sp)
    80000e6e:	6402                	ld	s0,0(sp)
    80000e70:	0141                	addi	sp,sp,16
    80000e72:	8082                	ret
    fsinit(ROOTDEV);
    80000e74:	4505                	li	a0,1
    80000e76:	003010ef          	jal	ra,80002678 <fsinit>
    first = 0;
    80000e7a:	00007797          	auipc	a5,0x7
    80000e7e:	aa07ab23          	sw	zero,-1354(a5) # 80007930 <first.1>
    __sync_synchronize();
    80000e82:	0ff0000f          	fence
    80000e86:	b7cd                	j	80000e68 <forkret+0x1a>

0000000080000e88 <allocpid>:
{
    80000e88:	1101                	addi	sp,sp,-32
    80000e8a:	ec06                	sd	ra,24(sp)
    80000e8c:	e822                	sd	s0,16(sp)
    80000e8e:	e426                	sd	s1,8(sp)
    80000e90:	e04a                	sd	s2,0(sp)
    80000e92:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80000e94:	00007917          	auipc	s2,0x7
    80000e98:	b3c90913          	addi	s2,s2,-1220 # 800079d0 <pid_lock>
    80000e9c:	854a                	mv	a0,s2
    80000e9e:	19d040ef          	jal	ra,8000583a <acquire>
  pid = nextpid;
    80000ea2:	00007797          	auipc	a5,0x7
    80000ea6:	a9278793          	addi	a5,a5,-1390 # 80007934 <nextpid>
    80000eaa:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80000eac:	0014871b          	addiw	a4,s1,1
    80000eb0:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80000eb2:	854a                	mv	a0,s2
    80000eb4:	21f040ef          	jal	ra,800058d2 <release>
}
    80000eb8:	8526                	mv	a0,s1
    80000eba:	60e2                	ld	ra,24(sp)
    80000ebc:	6442                	ld	s0,16(sp)
    80000ebe:	64a2                	ld	s1,8(sp)
    80000ec0:	6902                	ld	s2,0(sp)
    80000ec2:	6105                	addi	sp,sp,32
    80000ec4:	8082                	ret

0000000080000ec6 <proc_pagetable>:
{
    80000ec6:	1101                	addi	sp,sp,-32
    80000ec8:	ec06                	sd	ra,24(sp)
    80000eca:	e822                	sd	s0,16(sp)
    80000ecc:	e426                	sd	s1,8(sp)
    80000ece:	e04a                	sd	s2,0(sp)
    80000ed0:	1000                	addi	s0,sp,32
    80000ed2:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80000ed4:	837ff0ef          	jal	ra,8000070a <uvmcreate>
    80000ed8:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80000eda:	c929                	beqz	a0,80000f2c <proc_pagetable+0x66>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80000edc:	4729                	li	a4,10
    80000ede:	00005697          	auipc	a3,0x5
    80000ee2:	12268693          	addi	a3,a3,290 # 80006000 <_trampoline>
    80000ee6:	6605                	lui	a2,0x1
    80000ee8:	040005b7          	lui	a1,0x4000
    80000eec:	15fd                	addi	a1,a1,-1
    80000eee:	05b2                	slli	a1,a1,0xc
    80000ef0:	db8ff0ef          	jal	ra,800004a8 <mappages>
    80000ef4:	04054363          	bltz	a0,80000f3a <proc_pagetable+0x74>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80000ef8:	4719                	li	a4,6
    80000efa:	05893683          	ld	a3,88(s2)
    80000efe:	6605                	lui	a2,0x1
    80000f00:	020005b7          	lui	a1,0x2000
    80000f04:	15fd                	addi	a1,a1,-1
    80000f06:	05b6                	slli	a1,a1,0xd
    80000f08:	8526                	mv	a0,s1
    80000f0a:	d9eff0ef          	jal	ra,800004a8 <mappages>
    80000f0e:	02054c63          	bltz	a0,80000f46 <proc_pagetable+0x80>
  if(mappages(pagetable, USYSCALL, PGSIZE,
    80000f12:	4749                	li	a4,18
    80000f14:	16893683          	ld	a3,360(s2)
    80000f18:	6605                	lui	a2,0x1
    80000f1a:	040005b7          	lui	a1,0x4000
    80000f1e:	15f5                	addi	a1,a1,-3
    80000f20:	05b2                	slli	a1,a1,0xc
    80000f22:	8526                	mv	a0,s1
    80000f24:	d84ff0ef          	jal	ra,800004a8 <mappages>
    80000f28:	02054e63          	bltz	a0,80000f64 <proc_pagetable+0x9e>
}
    80000f2c:	8526                	mv	a0,s1
    80000f2e:	60e2                	ld	ra,24(sp)
    80000f30:	6442                	ld	s0,16(sp)
    80000f32:	64a2                	ld	s1,8(sp)
    80000f34:	6902                	ld	s2,0(sp)
    80000f36:	6105                	addi	sp,sp,32
    80000f38:	8082                	ret
    uvmfree(pagetable, 0);
    80000f3a:	4581                	li	a1,0
    80000f3c:	8526                	mv	a0,s1
    80000f3e:	98dff0ef          	jal	ra,800008ca <uvmfree>
    return 0;
    80000f42:	4481                	li	s1,0
    80000f44:	b7e5                	j	80000f2c <proc_pagetable+0x66>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000f46:	4681                	li	a3,0
    80000f48:	4605                	li	a2,1
    80000f4a:	040005b7          	lui	a1,0x4000
    80000f4e:	15fd                	addi	a1,a1,-1
    80000f50:	05b2                	slli	a1,a1,0xc
    80000f52:	8526                	mv	a0,s1
    80000f54:	efaff0ef          	jal	ra,8000064e <uvmunmap>
    uvmfree(pagetable, 0);
    80000f58:	4581                	li	a1,0
    80000f5a:	8526                	mv	a0,s1
    80000f5c:	96fff0ef          	jal	ra,800008ca <uvmfree>
    return 0;
    80000f60:	4481                	li	s1,0
    80000f62:	b7e9                	j	80000f2c <proc_pagetable+0x66>
    uvmunmap(pagetable, USYSCALL, 1, 0);
    80000f64:	4681                	li	a3,0
    80000f66:	4605                	li	a2,1
    80000f68:	04000937          	lui	s2,0x4000
    80000f6c:	ffd90593          	addi	a1,s2,-3 # 3fffffd <_entry-0x7c000003>
    80000f70:	05b2                	slli	a1,a1,0xc
    80000f72:	8526                	mv	a0,s1
    80000f74:	edaff0ef          	jal	ra,8000064e <uvmunmap>
    uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000f78:	4681                	li	a3,0
    80000f7a:	4605                	li	a2,1
    80000f7c:	020005b7          	lui	a1,0x2000
    80000f80:	15fd                	addi	a1,a1,-1
    80000f82:	05b6                	slli	a1,a1,0xd
    80000f84:	8526                	mv	a0,s1
    80000f86:	ec8ff0ef          	jal	ra,8000064e <uvmunmap>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000f8a:	4681                	li	a3,0
    80000f8c:	4605                	li	a2,1
    80000f8e:	fff90593          	addi	a1,s2,-1
    80000f92:	05b2                	slli	a1,a1,0xc
    80000f94:	8526                	mv	a0,s1
    80000f96:	eb8ff0ef          	jal	ra,8000064e <uvmunmap>
    uvmfree(pagetable, 0);
    80000f9a:	4581                	li	a1,0
    80000f9c:	8526                	mv	a0,s1
    80000f9e:	92dff0ef          	jal	ra,800008ca <uvmfree>
    return 0;
    80000fa2:	4481                	li	s1,0
    80000fa4:	b761                	j	80000f2c <proc_pagetable+0x66>

0000000080000fa6 <proc_freepagetable>:
{
    80000fa6:	7179                	addi	sp,sp,-48
    80000fa8:	f406                	sd	ra,40(sp)
    80000faa:	f022                	sd	s0,32(sp)
    80000fac:	ec26                	sd	s1,24(sp)
    80000fae:	e84a                	sd	s2,16(sp)
    80000fb0:	e44e                	sd	s3,8(sp)
    80000fb2:	1800                	addi	s0,sp,48
    80000fb4:	84aa                	mv	s1,a0
    80000fb6:	89ae                	mv	s3,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80000fb8:	4681                	li	a3,0
    80000fba:	4605                	li	a2,1
    80000fbc:	04000937          	lui	s2,0x4000
    80000fc0:	fff90593          	addi	a1,s2,-1 # 3ffffff <_entry-0x7c000001>
    80000fc4:	05b2                	slli	a1,a1,0xc
    80000fc6:	e88ff0ef          	jal	ra,8000064e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80000fca:	4681                	li	a3,0
    80000fcc:	4605                	li	a2,1
    80000fce:	020005b7          	lui	a1,0x2000
    80000fd2:	15fd                	addi	a1,a1,-1
    80000fd4:	05b6                	slli	a1,a1,0xd
    80000fd6:	8526                	mv	a0,s1
    80000fd8:	e76ff0ef          	jal	ra,8000064e <uvmunmap>
  uvmunmap(pagetable, USYSCALL, 1, 0); 
    80000fdc:	4681                	li	a3,0
    80000fde:	4605                	li	a2,1
    80000fe0:	1975                	addi	s2,s2,-3
    80000fe2:	00c91593          	slli	a1,s2,0xc
    80000fe6:	8526                	mv	a0,s1
    80000fe8:	e66ff0ef          	jal	ra,8000064e <uvmunmap>
  uvmfree(pagetable, sz);
    80000fec:	85ce                	mv	a1,s3
    80000fee:	8526                	mv	a0,s1
    80000ff0:	8dbff0ef          	jal	ra,800008ca <uvmfree>
}
    80000ff4:	70a2                	ld	ra,40(sp)
    80000ff6:	7402                	ld	s0,32(sp)
    80000ff8:	64e2                	ld	s1,24(sp)
    80000ffa:	6942                	ld	s2,16(sp)
    80000ffc:	69a2                	ld	s3,8(sp)
    80000ffe:	6145                	addi	sp,sp,48
    80001000:	8082                	ret

0000000080001002 <freeproc>:
{
    80001002:	1101                	addi	sp,sp,-32
    80001004:	ec06                	sd	ra,24(sp)
    80001006:	e822                	sd	s0,16(sp)
    80001008:	e426                	sd	s1,8(sp)
    8000100a:	1000                	addi	s0,sp,32
    8000100c:	84aa                	mv	s1,a0
  if(p->trapframe)
    8000100e:	6d28                	ld	a0,88(a0)
    80001010:	c119                	beqz	a0,80001016 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001012:	80aff0ef          	jal	ra,8000001c <kfree>
  p->trapframe = 0;
    80001016:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    8000101a:	68a8                	ld	a0,80(s1)
    8000101c:	c501                	beqz	a0,80001024 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    8000101e:	64ac                	ld	a1,72(s1)
    80001020:	f87ff0ef          	jal	ra,80000fa6 <proc_freepagetable>
  if(p->usyscall)
    80001024:	1684b503          	ld	a0,360(s1)
    80001028:	c119                	beqz	a0,8000102e <freeproc+0x2c>
     kfree((void *)p->usyscall);
    8000102a:	ff3fe0ef          	jal	ra,8000001c <kfree>
  p->usyscall = 0;
    8000102e:	1604b423          	sd	zero,360(s1)
  p->pagetable = 0;
    80001032:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001036:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    8000103a:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    8000103e:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001042:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001046:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    8000104a:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    8000104e:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001052:	0004ac23          	sw	zero,24(s1)
}
    80001056:	60e2                	ld	ra,24(sp)
    80001058:	6442                	ld	s0,16(sp)
    8000105a:	64a2                	ld	s1,8(sp)
    8000105c:	6105                	addi	sp,sp,32
    8000105e:	8082                	ret

0000000080001060 <allocproc>:
{
    80001060:	1101                	addi	sp,sp,-32
    80001062:	ec06                	sd	ra,24(sp)
    80001064:	e822                	sd	s0,16(sp)
    80001066:	e426                	sd	s1,8(sp)
    80001068:	e04a                	sd	s2,0(sp)
    8000106a:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    8000106c:	00007497          	auipc	s1,0x7
    80001070:	d9448493          	addi	s1,s1,-620 # 80007e00 <proc>
    80001074:	0000d917          	auipc	s2,0xd
    80001078:	98c90913          	addi	s2,s2,-1652 # 8000da00 <tickslock>
    acquire(&p->lock);
    8000107c:	8526                	mv	a0,s1
    8000107e:	7bc040ef          	jal	ra,8000583a <acquire>
    if(p->state == UNUSED) {
    80001082:	4c9c                	lw	a5,24(s1)
    80001084:	cb91                	beqz	a5,80001098 <allocproc+0x38>
      release(&p->lock);
    80001086:	8526                	mv	a0,s1
    80001088:	04b040ef          	jal	ra,800058d2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000108c:	17048493          	addi	s1,s1,368
    80001090:	ff2496e3          	bne	s1,s2,8000107c <allocproc+0x1c>
  return 0;
    80001094:	4481                	li	s1,0
    80001096:	a889                	j	800010e8 <allocproc+0x88>
  p->pid = allocpid();
    80001098:	df1ff0ef          	jal	ra,80000e88 <allocpid>
    8000109c:	d888                	sw	a0,48(s1)
  p->state = USED;
    8000109e:	4785                	li	a5,1
    800010a0:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    800010a2:	85aff0ef          	jal	ra,800000fc <kalloc>
    800010a6:	892a                	mv	s2,a0
    800010a8:	eca8                	sd	a0,88(s1)
    800010aa:	c531                	beqz	a0,800010f6 <allocproc+0x96>
  if((p->usyscall = (struct usyscall *)kalloc()) == 0){
    800010ac:	850ff0ef          	jal	ra,800000fc <kalloc>
    800010b0:	892a                	mv	s2,a0
    800010b2:	16a4b423          	sd	a0,360(s1)
    800010b6:	c921                	beqz	a0,80001106 <allocproc+0xa6>
  p->usyscall->pid = p->pid;
    800010b8:	589c                	lw	a5,48(s1)
    800010ba:	c11c                	sw	a5,0(a0)
  p->pagetable = proc_pagetable(p);
    800010bc:	8526                	mv	a0,s1
    800010be:	e09ff0ef          	jal	ra,80000ec6 <proc_pagetable>
    800010c2:	892a                	mv	s2,a0
    800010c4:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    800010c6:	c921                	beqz	a0,80001116 <allocproc+0xb6>
  memset(&p->context, 0, sizeof(p->context));
    800010c8:	07000613          	li	a2,112
    800010cc:	4581                	li	a1,0
    800010ce:	06048513          	addi	a0,s1,96
    800010d2:	87aff0ef          	jal	ra,8000014c <memset>
  p->context.ra = (uint64)forkret;
    800010d6:	00000797          	auipc	a5,0x0
    800010da:	d7878793          	addi	a5,a5,-648 # 80000e4e <forkret>
    800010de:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    800010e0:	60bc                	ld	a5,64(s1)
    800010e2:	6705                	lui	a4,0x1
    800010e4:	97ba                	add	a5,a5,a4
    800010e6:	f4bc                	sd	a5,104(s1)
}
    800010e8:	8526                	mv	a0,s1
    800010ea:	60e2                	ld	ra,24(sp)
    800010ec:	6442                	ld	s0,16(sp)
    800010ee:	64a2                	ld	s1,8(sp)
    800010f0:	6902                	ld	s2,0(sp)
    800010f2:	6105                	addi	sp,sp,32
    800010f4:	8082                	ret
    freeproc(p);
    800010f6:	8526                	mv	a0,s1
    800010f8:	f0bff0ef          	jal	ra,80001002 <freeproc>
    release(&p->lock);
    800010fc:	8526                	mv	a0,s1
    800010fe:	7d4040ef          	jal	ra,800058d2 <release>
    return 0;
    80001102:	84ca                	mv	s1,s2
    80001104:	b7d5                	j	800010e8 <allocproc+0x88>
    freeproc(p);
    80001106:	8526                	mv	a0,s1
    80001108:	efbff0ef          	jal	ra,80001002 <freeproc>
    release(&p->lock);
    8000110c:	8526                	mv	a0,s1
    8000110e:	7c4040ef          	jal	ra,800058d2 <release>
    return 0;
    80001112:	84ca                	mv	s1,s2
    80001114:	bfd1                	j	800010e8 <allocproc+0x88>
    freeproc(p);
    80001116:	8526                	mv	a0,s1
    80001118:	eebff0ef          	jal	ra,80001002 <freeproc>
    release(&p->lock);
    8000111c:	8526                	mv	a0,s1
    8000111e:	7b4040ef          	jal	ra,800058d2 <release>
    return 0;
    80001122:	84ca                	mv	s1,s2
    80001124:	b7d1                	j	800010e8 <allocproc+0x88>

0000000080001126 <userinit>:
{
    80001126:	1101                	addi	sp,sp,-32
    80001128:	ec06                	sd	ra,24(sp)
    8000112a:	e822                	sd	s0,16(sp)
    8000112c:	e426                	sd	s1,8(sp)
    8000112e:	1000                	addi	s0,sp,32
  p = allocproc();
    80001130:	f31ff0ef          	jal	ra,80001060 <allocproc>
    80001134:	84aa                	mv	s1,a0
  initproc = p;
    80001136:	00007797          	auipc	a5,0x7
    8000113a:	84a7bd23          	sd	a0,-1958(a5) # 80007990 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    8000113e:	03400613          	li	a2,52
    80001142:	00006597          	auipc	a1,0x6
    80001146:	7fe58593          	addi	a1,a1,2046 # 80007940 <initcode>
    8000114a:	6928                	ld	a0,80(a0)
    8000114c:	de4ff0ef          	jal	ra,80000730 <uvmfirst>
  p->sz = PGSIZE;
    80001150:	6785                	lui	a5,0x1
    80001152:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001154:	6cb8                	ld	a4,88(s1)
    80001156:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    8000115a:	6cb8                	ld	a4,88(s1)
    8000115c:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    8000115e:	4641                	li	a2,16
    80001160:	00006597          	auipc	a1,0x6
    80001164:	0a858593          	addi	a1,a1,168 # 80007208 <etext+0x208>
    80001168:	15848513          	addi	a0,s1,344
    8000116c:	926ff0ef          	jal	ra,80000292 <safestrcpy>
  p->cwd = namei("/");
    80001170:	00006517          	auipc	a0,0x6
    80001174:	0a850513          	addi	a0,a0,168 # 80007218 <etext+0x218>
    80001178:	5df010ef          	jal	ra,80002f56 <namei>
    8000117c:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001180:	478d                	li	a5,3
    80001182:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001184:	8526                	mv	a0,s1
    80001186:	74c040ef          	jal	ra,800058d2 <release>
}
    8000118a:	60e2                	ld	ra,24(sp)
    8000118c:	6442                	ld	s0,16(sp)
    8000118e:	64a2                	ld	s1,8(sp)
    80001190:	6105                	addi	sp,sp,32
    80001192:	8082                	ret

0000000080001194 <growproc>:
{
    80001194:	1101                	addi	sp,sp,-32
    80001196:	ec06                	sd	ra,24(sp)
    80001198:	e822                	sd	s0,16(sp)
    8000119a:	e426                	sd	s1,8(sp)
    8000119c:	e04a                	sd	s2,0(sp)
    8000119e:	1000                	addi	s0,sp,32
    800011a0:	892a                	mv	s2,a0
  struct proc *p = myproc();
    800011a2:	c7dff0ef          	jal	ra,80000e1e <myproc>
    800011a6:	84aa                	mv	s1,a0
  sz = p->sz;
    800011a8:	652c                	ld	a1,72(a0)
  if(n > 0){
    800011aa:	01204c63          	bgtz	s2,800011c2 <growproc+0x2e>
  } else if(n < 0){
    800011ae:	02094463          	bltz	s2,800011d6 <growproc+0x42>
  p->sz = sz;
    800011b2:	e4ac                	sd	a1,72(s1)
  return 0;
    800011b4:	4501                	li	a0,0
}
    800011b6:	60e2                	ld	ra,24(sp)
    800011b8:	6442                	ld	s0,16(sp)
    800011ba:	64a2                	ld	s1,8(sp)
    800011bc:	6902                	ld	s2,0(sp)
    800011be:	6105                	addi	sp,sp,32
    800011c0:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    800011c2:	4691                	li	a3,4
    800011c4:	00b90633          	add	a2,s2,a1
    800011c8:	6928                	ld	a0,80(a0)
    800011ca:	e08ff0ef          	jal	ra,800007d2 <uvmalloc>
    800011ce:	85aa                	mv	a1,a0
    800011d0:	f16d                	bnez	a0,800011b2 <growproc+0x1e>
      return -1;
    800011d2:	557d                	li	a0,-1
    800011d4:	b7cd                	j	800011b6 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    800011d6:	00b90633          	add	a2,s2,a1
    800011da:	6928                	ld	a0,80(a0)
    800011dc:	db2ff0ef          	jal	ra,8000078e <uvmdealloc>
    800011e0:	85aa                	mv	a1,a0
    800011e2:	bfc1                	j	800011b2 <growproc+0x1e>

00000000800011e4 <fork>:
{
    800011e4:	7139                	addi	sp,sp,-64
    800011e6:	fc06                	sd	ra,56(sp)
    800011e8:	f822                	sd	s0,48(sp)
    800011ea:	f426                	sd	s1,40(sp)
    800011ec:	f04a                	sd	s2,32(sp)
    800011ee:	ec4e                	sd	s3,24(sp)
    800011f0:	e852                	sd	s4,16(sp)
    800011f2:	e456                	sd	s5,8(sp)
    800011f4:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    800011f6:	c29ff0ef          	jal	ra,80000e1e <myproc>
    800011fa:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    800011fc:	e65ff0ef          	jal	ra,80001060 <allocproc>
    80001200:	0e050663          	beqz	a0,800012ec <fork+0x108>
    80001204:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001206:	048ab603          	ld	a2,72(s5)
    8000120a:	692c                	ld	a1,80(a0)
    8000120c:	050ab503          	ld	a0,80(s5)
    80001210:	eeaff0ef          	jal	ra,800008fa <uvmcopy>
    80001214:	04054863          	bltz	a0,80001264 <fork+0x80>
  np->sz = p->sz;
    80001218:	048ab783          	ld	a5,72(s5)
    8000121c:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001220:	058ab683          	ld	a3,88(s5)
    80001224:	87b6                	mv	a5,a3
    80001226:	058a3703          	ld	a4,88(s4)
    8000122a:	12068693          	addi	a3,a3,288
    8000122e:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80001232:	6788                	ld	a0,8(a5)
    80001234:	6b8c                	ld	a1,16(a5)
    80001236:	6f90                	ld	a2,24(a5)
    80001238:	01073023          	sd	a6,0(a4)
    8000123c:	e708                	sd	a0,8(a4)
    8000123e:	eb0c                	sd	a1,16(a4)
    80001240:	ef10                	sd	a2,24(a4)
    80001242:	02078793          	addi	a5,a5,32
    80001246:	02070713          	addi	a4,a4,32
    8000124a:	fed792e3          	bne	a5,a3,8000122e <fork+0x4a>
  np->trapframe->a0 = 0;
    8000124e:	058a3783          	ld	a5,88(s4)
    80001252:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001256:	0d0a8493          	addi	s1,s5,208
    8000125a:	0d0a0913          	addi	s2,s4,208
    8000125e:	150a8993          	addi	s3,s5,336
    80001262:	a829                	j	8000127c <fork+0x98>
    freeproc(np);
    80001264:	8552                	mv	a0,s4
    80001266:	d9dff0ef          	jal	ra,80001002 <freeproc>
    release(&np->lock);
    8000126a:	8552                	mv	a0,s4
    8000126c:	666040ef          	jal	ra,800058d2 <release>
    return -1;
    80001270:	597d                	li	s2,-1
    80001272:	a09d                	j	800012d8 <fork+0xf4>
  for(i = 0; i < NOFILE; i++)
    80001274:	04a1                	addi	s1,s1,8
    80001276:	0921                	addi	s2,s2,8
    80001278:	01348963          	beq	s1,s3,8000128a <fork+0xa6>
    if(p->ofile[i])
    8000127c:	6088                	ld	a0,0(s1)
    8000127e:	d97d                	beqz	a0,80001274 <fork+0x90>
      np->ofile[i] = filedup(p->ofile[i]);
    80001280:	288020ef          	jal	ra,80003508 <filedup>
    80001284:	00a93023          	sd	a0,0(s2)
    80001288:	b7f5                	j	80001274 <fork+0x90>
  np->cwd = idup(p->cwd);
    8000128a:	150ab503          	ld	a0,336(s5)
    8000128e:	5e0010ef          	jal	ra,8000286e <idup>
    80001292:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001296:	4641                	li	a2,16
    80001298:	158a8593          	addi	a1,s5,344
    8000129c:	158a0513          	addi	a0,s4,344
    800012a0:	ff3fe0ef          	jal	ra,80000292 <safestrcpy>
  pid = np->pid;
    800012a4:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    800012a8:	8552                	mv	a0,s4
    800012aa:	628040ef          	jal	ra,800058d2 <release>
  acquire(&wait_lock);
    800012ae:	00006497          	auipc	s1,0x6
    800012b2:	73a48493          	addi	s1,s1,1850 # 800079e8 <wait_lock>
    800012b6:	8526                	mv	a0,s1
    800012b8:	582040ef          	jal	ra,8000583a <acquire>
  np->parent = p;
    800012bc:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    800012c0:	8526                	mv	a0,s1
    800012c2:	610040ef          	jal	ra,800058d2 <release>
  acquire(&np->lock);
    800012c6:	8552                	mv	a0,s4
    800012c8:	572040ef          	jal	ra,8000583a <acquire>
  np->state = RUNNABLE;
    800012cc:	478d                	li	a5,3
    800012ce:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    800012d2:	8552                	mv	a0,s4
    800012d4:	5fe040ef          	jal	ra,800058d2 <release>
}
    800012d8:	854a                	mv	a0,s2
    800012da:	70e2                	ld	ra,56(sp)
    800012dc:	7442                	ld	s0,48(sp)
    800012de:	74a2                	ld	s1,40(sp)
    800012e0:	7902                	ld	s2,32(sp)
    800012e2:	69e2                	ld	s3,24(sp)
    800012e4:	6a42                	ld	s4,16(sp)
    800012e6:	6aa2                	ld	s5,8(sp)
    800012e8:	6121                	addi	sp,sp,64
    800012ea:	8082                	ret
    return -1;
    800012ec:	597d                	li	s2,-1
    800012ee:	b7ed                	j	800012d8 <fork+0xf4>

00000000800012f0 <scheduler>:
{
    800012f0:	715d                	addi	sp,sp,-80
    800012f2:	e486                	sd	ra,72(sp)
    800012f4:	e0a2                	sd	s0,64(sp)
    800012f6:	fc26                	sd	s1,56(sp)
    800012f8:	f84a                	sd	s2,48(sp)
    800012fa:	f44e                	sd	s3,40(sp)
    800012fc:	f052                	sd	s4,32(sp)
    800012fe:	ec56                	sd	s5,24(sp)
    80001300:	e85a                	sd	s6,16(sp)
    80001302:	e45e                	sd	s7,8(sp)
    80001304:	e062                	sd	s8,0(sp)
    80001306:	0880                	addi	s0,sp,80
    80001308:	8792                	mv	a5,tp
  int id = r_tp();
    8000130a:	2781                	sext.w	a5,a5
  c->proc = 0;
    8000130c:	00779b13          	slli	s6,a5,0x7
    80001310:	00006717          	auipc	a4,0x6
    80001314:	6c070713          	addi	a4,a4,1728 # 800079d0 <pid_lock>
    80001318:	975a                	add	a4,a4,s6
    8000131a:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    8000131e:	00006717          	auipc	a4,0x6
    80001322:	6ea70713          	addi	a4,a4,1770 # 80007a08 <cpus+0x8>
    80001326:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001328:	4c11                	li	s8,4
        c->proc = p;
    8000132a:	079e                	slli	a5,a5,0x7
    8000132c:	00006a17          	auipc	s4,0x6
    80001330:	6a4a0a13          	addi	s4,s4,1700 # 800079d0 <pid_lock>
    80001334:	9a3e                	add	s4,s4,a5
        found = 1;
    80001336:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001338:	0000c997          	auipc	s3,0xc
    8000133c:	6c898993          	addi	s3,s3,1736 # 8000da00 <tickslock>
    80001340:	a0a9                	j	8000138a <scheduler+0x9a>
      release(&p->lock);
    80001342:	8526                	mv	a0,s1
    80001344:	58e040ef          	jal	ra,800058d2 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001348:	17048493          	addi	s1,s1,368
    8000134c:	03348563          	beq	s1,s3,80001376 <scheduler+0x86>
      acquire(&p->lock);
    80001350:	8526                	mv	a0,s1
    80001352:	4e8040ef          	jal	ra,8000583a <acquire>
      if(p->state == RUNNABLE) {
    80001356:	4c9c                	lw	a5,24(s1)
    80001358:	ff2795e3          	bne	a5,s2,80001342 <scheduler+0x52>
        p->state = RUNNING;
    8000135c:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001360:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001364:	06048593          	addi	a1,s1,96
    80001368:	855a                	mv	a0,s6
    8000136a:	5b4000ef          	jal	ra,8000191e <swtch>
        c->proc = 0;
    8000136e:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001372:	8ade                	mv	s5,s7
    80001374:	b7f9                	j	80001342 <scheduler+0x52>
    if(found == 0) {
    80001376:	000a9a63          	bnez	s5,8000138a <scheduler+0x9a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000137a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000137e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001382:	10079073          	csrw	sstatus,a5
      asm volatile("wfi");
    80001386:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000138a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000138e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001392:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001396:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001398:	00007497          	auipc	s1,0x7
    8000139c:	a6848493          	addi	s1,s1,-1432 # 80007e00 <proc>
      if(p->state == RUNNABLE) {
    800013a0:	490d                	li	s2,3
    800013a2:	b77d                	j	80001350 <scheduler+0x60>

00000000800013a4 <sched>:
{
    800013a4:	7179                	addi	sp,sp,-48
    800013a6:	f406                	sd	ra,40(sp)
    800013a8:	f022                	sd	s0,32(sp)
    800013aa:	ec26                	sd	s1,24(sp)
    800013ac:	e84a                	sd	s2,16(sp)
    800013ae:	e44e                	sd	s3,8(sp)
    800013b0:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    800013b2:	a6dff0ef          	jal	ra,80000e1e <myproc>
    800013b6:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    800013b8:	418040ef          	jal	ra,800057d0 <holding>
    800013bc:	c92d                	beqz	a0,8000142e <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    800013be:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    800013c0:	2781                	sext.w	a5,a5
    800013c2:	079e                	slli	a5,a5,0x7
    800013c4:	00006717          	auipc	a4,0x6
    800013c8:	60c70713          	addi	a4,a4,1548 # 800079d0 <pid_lock>
    800013cc:	97ba                	add	a5,a5,a4
    800013ce:	0a87a703          	lw	a4,168(a5)
    800013d2:	4785                	li	a5,1
    800013d4:	06f71363          	bne	a4,a5,8000143a <sched+0x96>
  if(p->state == RUNNING)
    800013d8:	4c98                	lw	a4,24(s1)
    800013da:	4791                	li	a5,4
    800013dc:	06f70563          	beq	a4,a5,80001446 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800013e0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800013e4:	8b89                	andi	a5,a5,2
  if(intr_get())
    800013e6:	e7b5                	bnez	a5,80001452 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    800013e8:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800013ea:	00006917          	auipc	s2,0x6
    800013ee:	5e690913          	addi	s2,s2,1510 # 800079d0 <pid_lock>
    800013f2:	2781                	sext.w	a5,a5
    800013f4:	079e                	slli	a5,a5,0x7
    800013f6:	97ca                	add	a5,a5,s2
    800013f8:	0ac7a983          	lw	s3,172(a5)
    800013fc:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800013fe:	2781                	sext.w	a5,a5
    80001400:	079e                	slli	a5,a5,0x7
    80001402:	00006597          	auipc	a1,0x6
    80001406:	60658593          	addi	a1,a1,1542 # 80007a08 <cpus+0x8>
    8000140a:	95be                	add	a1,a1,a5
    8000140c:	06048513          	addi	a0,s1,96
    80001410:	50e000ef          	jal	ra,8000191e <swtch>
    80001414:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001416:	2781                	sext.w	a5,a5
    80001418:	079e                	slli	a5,a5,0x7
    8000141a:	97ca                	add	a5,a5,s2
    8000141c:	0b37a623          	sw	s3,172(a5)
}
    80001420:	70a2                	ld	ra,40(sp)
    80001422:	7402                	ld	s0,32(sp)
    80001424:	64e2                	ld	s1,24(sp)
    80001426:	6942                	ld	s2,16(sp)
    80001428:	69a2                	ld	s3,8(sp)
    8000142a:	6145                	addi	sp,sp,48
    8000142c:	8082                	ret
    panic("sched p->lock");
    8000142e:	00006517          	auipc	a0,0x6
    80001432:	df250513          	addi	a0,a0,-526 # 80007220 <etext+0x220>
    80001436:	0f0040ef          	jal	ra,80005526 <panic>
    panic("sched locks");
    8000143a:	00006517          	auipc	a0,0x6
    8000143e:	df650513          	addi	a0,a0,-522 # 80007230 <etext+0x230>
    80001442:	0e4040ef          	jal	ra,80005526 <panic>
    panic("sched running");
    80001446:	00006517          	auipc	a0,0x6
    8000144a:	dfa50513          	addi	a0,a0,-518 # 80007240 <etext+0x240>
    8000144e:	0d8040ef          	jal	ra,80005526 <panic>
    panic("sched interruptible");
    80001452:	00006517          	auipc	a0,0x6
    80001456:	dfe50513          	addi	a0,a0,-514 # 80007250 <etext+0x250>
    8000145a:	0cc040ef          	jal	ra,80005526 <panic>

000000008000145e <yield>:
{
    8000145e:	1101                	addi	sp,sp,-32
    80001460:	ec06                	sd	ra,24(sp)
    80001462:	e822                	sd	s0,16(sp)
    80001464:	e426                	sd	s1,8(sp)
    80001466:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001468:	9b7ff0ef          	jal	ra,80000e1e <myproc>
    8000146c:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000146e:	3cc040ef          	jal	ra,8000583a <acquire>
  p->state = RUNNABLE;
    80001472:	478d                	li	a5,3
    80001474:	cc9c                	sw	a5,24(s1)
  sched();
    80001476:	f2fff0ef          	jal	ra,800013a4 <sched>
  release(&p->lock);
    8000147a:	8526                	mv	a0,s1
    8000147c:	456040ef          	jal	ra,800058d2 <release>
}
    80001480:	60e2                	ld	ra,24(sp)
    80001482:	6442                	ld	s0,16(sp)
    80001484:	64a2                	ld	s1,8(sp)
    80001486:	6105                	addi	sp,sp,32
    80001488:	8082                	ret

000000008000148a <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    8000148a:	7179                	addi	sp,sp,-48
    8000148c:	f406                	sd	ra,40(sp)
    8000148e:	f022                	sd	s0,32(sp)
    80001490:	ec26                	sd	s1,24(sp)
    80001492:	e84a                	sd	s2,16(sp)
    80001494:	e44e                	sd	s3,8(sp)
    80001496:	1800                	addi	s0,sp,48
    80001498:	89aa                	mv	s3,a0
    8000149a:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000149c:	983ff0ef          	jal	ra,80000e1e <myproc>
    800014a0:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    800014a2:	398040ef          	jal	ra,8000583a <acquire>
  release(lk);
    800014a6:	854a                	mv	a0,s2
    800014a8:	42a040ef          	jal	ra,800058d2 <release>

  // Go to sleep.
  p->chan = chan;
    800014ac:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    800014b0:	4789                	li	a5,2
    800014b2:	cc9c                	sw	a5,24(s1)

  sched();
    800014b4:	ef1ff0ef          	jal	ra,800013a4 <sched>

  // Tidy up.
  p->chan = 0;
    800014b8:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800014bc:	8526                	mv	a0,s1
    800014be:	414040ef          	jal	ra,800058d2 <release>
  acquire(lk);
    800014c2:	854a                	mv	a0,s2
    800014c4:	376040ef          	jal	ra,8000583a <acquire>
}
    800014c8:	70a2                	ld	ra,40(sp)
    800014ca:	7402                	ld	s0,32(sp)
    800014cc:	64e2                	ld	s1,24(sp)
    800014ce:	6942                	ld	s2,16(sp)
    800014d0:	69a2                	ld	s3,8(sp)
    800014d2:	6145                	addi	sp,sp,48
    800014d4:	8082                	ret

00000000800014d6 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800014d6:	7139                	addi	sp,sp,-64
    800014d8:	fc06                	sd	ra,56(sp)
    800014da:	f822                	sd	s0,48(sp)
    800014dc:	f426                	sd	s1,40(sp)
    800014de:	f04a                	sd	s2,32(sp)
    800014e0:	ec4e                	sd	s3,24(sp)
    800014e2:	e852                	sd	s4,16(sp)
    800014e4:	e456                	sd	s5,8(sp)
    800014e6:	0080                	addi	s0,sp,64
    800014e8:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800014ea:	00007497          	auipc	s1,0x7
    800014ee:	91648493          	addi	s1,s1,-1770 # 80007e00 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800014f2:	4989                	li	s3,2
        p->state = RUNNABLE;
    800014f4:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800014f6:	0000c917          	auipc	s2,0xc
    800014fa:	50a90913          	addi	s2,s2,1290 # 8000da00 <tickslock>
    800014fe:	a801                	j	8000150e <wakeup+0x38>
      }
      release(&p->lock);
    80001500:	8526                	mv	a0,s1
    80001502:	3d0040ef          	jal	ra,800058d2 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001506:	17048493          	addi	s1,s1,368
    8000150a:	03248263          	beq	s1,s2,8000152e <wakeup+0x58>
    if(p != myproc()){
    8000150e:	911ff0ef          	jal	ra,80000e1e <myproc>
    80001512:	fea48ae3          	beq	s1,a0,80001506 <wakeup+0x30>
      acquire(&p->lock);
    80001516:	8526                	mv	a0,s1
    80001518:	322040ef          	jal	ra,8000583a <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    8000151c:	4c9c                	lw	a5,24(s1)
    8000151e:	ff3791e3          	bne	a5,s3,80001500 <wakeup+0x2a>
    80001522:	709c                	ld	a5,32(s1)
    80001524:	fd479ee3          	bne	a5,s4,80001500 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001528:	0154ac23          	sw	s5,24(s1)
    8000152c:	bfd1                	j	80001500 <wakeup+0x2a>
    }
  }
}
    8000152e:	70e2                	ld	ra,56(sp)
    80001530:	7442                	ld	s0,48(sp)
    80001532:	74a2                	ld	s1,40(sp)
    80001534:	7902                	ld	s2,32(sp)
    80001536:	69e2                	ld	s3,24(sp)
    80001538:	6a42                	ld	s4,16(sp)
    8000153a:	6aa2                	ld	s5,8(sp)
    8000153c:	6121                	addi	sp,sp,64
    8000153e:	8082                	ret

0000000080001540 <reparent>:
{
    80001540:	7179                	addi	sp,sp,-48
    80001542:	f406                	sd	ra,40(sp)
    80001544:	f022                	sd	s0,32(sp)
    80001546:	ec26                	sd	s1,24(sp)
    80001548:	e84a                	sd	s2,16(sp)
    8000154a:	e44e                	sd	s3,8(sp)
    8000154c:	e052                	sd	s4,0(sp)
    8000154e:	1800                	addi	s0,sp,48
    80001550:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001552:	00007497          	auipc	s1,0x7
    80001556:	8ae48493          	addi	s1,s1,-1874 # 80007e00 <proc>
      pp->parent = initproc;
    8000155a:	00006a17          	auipc	s4,0x6
    8000155e:	436a0a13          	addi	s4,s4,1078 # 80007990 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001562:	0000c997          	auipc	s3,0xc
    80001566:	49e98993          	addi	s3,s3,1182 # 8000da00 <tickslock>
    8000156a:	a029                	j	80001574 <reparent+0x34>
    8000156c:	17048493          	addi	s1,s1,368
    80001570:	01348b63          	beq	s1,s3,80001586 <reparent+0x46>
    if(pp->parent == p){
    80001574:	7c9c                	ld	a5,56(s1)
    80001576:	ff279be3          	bne	a5,s2,8000156c <reparent+0x2c>
      pp->parent = initproc;
    8000157a:	000a3503          	ld	a0,0(s4)
    8000157e:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001580:	f57ff0ef          	jal	ra,800014d6 <wakeup>
    80001584:	b7e5                	j	8000156c <reparent+0x2c>
}
    80001586:	70a2                	ld	ra,40(sp)
    80001588:	7402                	ld	s0,32(sp)
    8000158a:	64e2                	ld	s1,24(sp)
    8000158c:	6942                	ld	s2,16(sp)
    8000158e:	69a2                	ld	s3,8(sp)
    80001590:	6a02                	ld	s4,0(sp)
    80001592:	6145                	addi	sp,sp,48
    80001594:	8082                	ret

0000000080001596 <exit>:
{
    80001596:	7179                	addi	sp,sp,-48
    80001598:	f406                	sd	ra,40(sp)
    8000159a:	f022                	sd	s0,32(sp)
    8000159c:	ec26                	sd	s1,24(sp)
    8000159e:	e84a                	sd	s2,16(sp)
    800015a0:	e44e                	sd	s3,8(sp)
    800015a2:	e052                	sd	s4,0(sp)
    800015a4:	1800                	addi	s0,sp,48
    800015a6:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800015a8:	877ff0ef          	jal	ra,80000e1e <myproc>
    800015ac:	89aa                	mv	s3,a0
  if(p == initproc)
    800015ae:	00006797          	auipc	a5,0x6
    800015b2:	3e27b783          	ld	a5,994(a5) # 80007990 <initproc>
    800015b6:	0d050493          	addi	s1,a0,208
    800015ba:	15050913          	addi	s2,a0,336
    800015be:	00a79f63          	bne	a5,a0,800015dc <exit+0x46>
    panic("init exiting");
    800015c2:	00006517          	auipc	a0,0x6
    800015c6:	ca650513          	addi	a0,a0,-858 # 80007268 <etext+0x268>
    800015ca:	75d030ef          	jal	ra,80005526 <panic>
      fileclose(f);
    800015ce:	781010ef          	jal	ra,8000354e <fileclose>
      p->ofile[fd] = 0;
    800015d2:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    800015d6:	04a1                	addi	s1,s1,8
    800015d8:	01248563          	beq	s1,s2,800015e2 <exit+0x4c>
    if(p->ofile[fd]){
    800015dc:	6088                	ld	a0,0(s1)
    800015de:	f965                	bnez	a0,800015ce <exit+0x38>
    800015e0:	bfdd                	j	800015d6 <exit+0x40>
  begin_op();
    800015e2:	351010ef          	jal	ra,80003132 <begin_op>
  iput(p->cwd);
    800015e6:	1509b503          	ld	a0,336(s3)
    800015ea:	438010ef          	jal	ra,80002a22 <iput>
  end_op();
    800015ee:	3b5010ef          	jal	ra,800031a2 <end_op>
  p->cwd = 0;
    800015f2:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800015f6:	00006497          	auipc	s1,0x6
    800015fa:	3f248493          	addi	s1,s1,1010 # 800079e8 <wait_lock>
    800015fe:	8526                	mv	a0,s1
    80001600:	23a040ef          	jal	ra,8000583a <acquire>
  reparent(p);
    80001604:	854e                	mv	a0,s3
    80001606:	f3bff0ef          	jal	ra,80001540 <reparent>
  wakeup(p->parent);
    8000160a:	0389b503          	ld	a0,56(s3)
    8000160e:	ec9ff0ef          	jal	ra,800014d6 <wakeup>
  acquire(&p->lock);
    80001612:	854e                	mv	a0,s3
    80001614:	226040ef          	jal	ra,8000583a <acquire>
  p->xstate = status;
    80001618:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    8000161c:	4795                	li	a5,5
    8000161e:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80001622:	8526                	mv	a0,s1
    80001624:	2ae040ef          	jal	ra,800058d2 <release>
  sched();
    80001628:	d7dff0ef          	jal	ra,800013a4 <sched>
  panic("zombie exit");
    8000162c:	00006517          	auipc	a0,0x6
    80001630:	c4c50513          	addi	a0,a0,-948 # 80007278 <etext+0x278>
    80001634:	6f3030ef          	jal	ra,80005526 <panic>

0000000080001638 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80001638:	7179                	addi	sp,sp,-48
    8000163a:	f406                	sd	ra,40(sp)
    8000163c:	f022                	sd	s0,32(sp)
    8000163e:	ec26                	sd	s1,24(sp)
    80001640:	e84a                	sd	s2,16(sp)
    80001642:	e44e                	sd	s3,8(sp)
    80001644:	1800                	addi	s0,sp,48
    80001646:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80001648:	00006497          	auipc	s1,0x6
    8000164c:	7b848493          	addi	s1,s1,1976 # 80007e00 <proc>
    80001650:	0000c997          	auipc	s3,0xc
    80001654:	3b098993          	addi	s3,s3,944 # 8000da00 <tickslock>
    acquire(&p->lock);
    80001658:	8526                	mv	a0,s1
    8000165a:	1e0040ef          	jal	ra,8000583a <acquire>
    if(p->pid == pid){
    8000165e:	589c                	lw	a5,48(s1)
    80001660:	01278b63          	beq	a5,s2,80001676 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80001664:	8526                	mv	a0,s1
    80001666:	26c040ef          	jal	ra,800058d2 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000166a:	17048493          	addi	s1,s1,368
    8000166e:	ff3495e3          	bne	s1,s3,80001658 <kill+0x20>
  }
  return -1;
    80001672:	557d                	li	a0,-1
    80001674:	a819                	j	8000168a <kill+0x52>
      p->killed = 1;
    80001676:	4785                	li	a5,1
    80001678:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000167a:	4c98                	lw	a4,24(s1)
    8000167c:	4789                	li	a5,2
    8000167e:	00f70d63          	beq	a4,a5,80001698 <kill+0x60>
      release(&p->lock);
    80001682:	8526                	mv	a0,s1
    80001684:	24e040ef          	jal	ra,800058d2 <release>
      return 0;
    80001688:	4501                	li	a0,0
}
    8000168a:	70a2                	ld	ra,40(sp)
    8000168c:	7402                	ld	s0,32(sp)
    8000168e:	64e2                	ld	s1,24(sp)
    80001690:	6942                	ld	s2,16(sp)
    80001692:	69a2                	ld	s3,8(sp)
    80001694:	6145                	addi	sp,sp,48
    80001696:	8082                	ret
        p->state = RUNNABLE;
    80001698:	478d                	li	a5,3
    8000169a:	cc9c                	sw	a5,24(s1)
    8000169c:	b7dd                	j	80001682 <kill+0x4a>

000000008000169e <setkilled>:

void
setkilled(struct proc *p)
{
    8000169e:	1101                	addi	sp,sp,-32
    800016a0:	ec06                	sd	ra,24(sp)
    800016a2:	e822                	sd	s0,16(sp)
    800016a4:	e426                	sd	s1,8(sp)
    800016a6:	1000                	addi	s0,sp,32
    800016a8:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800016aa:	190040ef          	jal	ra,8000583a <acquire>
  p->killed = 1;
    800016ae:	4785                	li	a5,1
    800016b0:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800016b2:	8526                	mv	a0,s1
    800016b4:	21e040ef          	jal	ra,800058d2 <release>
}
    800016b8:	60e2                	ld	ra,24(sp)
    800016ba:	6442                	ld	s0,16(sp)
    800016bc:	64a2                	ld	s1,8(sp)
    800016be:	6105                	addi	sp,sp,32
    800016c0:	8082                	ret

00000000800016c2 <killed>:

int
killed(struct proc *p)
{
    800016c2:	1101                	addi	sp,sp,-32
    800016c4:	ec06                	sd	ra,24(sp)
    800016c6:	e822                	sd	s0,16(sp)
    800016c8:	e426                	sd	s1,8(sp)
    800016ca:	e04a                	sd	s2,0(sp)
    800016cc:	1000                	addi	s0,sp,32
    800016ce:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800016d0:	16a040ef          	jal	ra,8000583a <acquire>
  k = p->killed;
    800016d4:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800016d8:	8526                	mv	a0,s1
    800016da:	1f8040ef          	jal	ra,800058d2 <release>
  return k;
}
    800016de:	854a                	mv	a0,s2
    800016e0:	60e2                	ld	ra,24(sp)
    800016e2:	6442                	ld	s0,16(sp)
    800016e4:	64a2                	ld	s1,8(sp)
    800016e6:	6902                	ld	s2,0(sp)
    800016e8:	6105                	addi	sp,sp,32
    800016ea:	8082                	ret

00000000800016ec <wait>:
{
    800016ec:	715d                	addi	sp,sp,-80
    800016ee:	e486                	sd	ra,72(sp)
    800016f0:	e0a2                	sd	s0,64(sp)
    800016f2:	fc26                	sd	s1,56(sp)
    800016f4:	f84a                	sd	s2,48(sp)
    800016f6:	f44e                	sd	s3,40(sp)
    800016f8:	f052                	sd	s4,32(sp)
    800016fa:	ec56                	sd	s5,24(sp)
    800016fc:	e85a                	sd	s6,16(sp)
    800016fe:	e45e                	sd	s7,8(sp)
    80001700:	e062                	sd	s8,0(sp)
    80001702:	0880                	addi	s0,sp,80
    80001704:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80001706:	f18ff0ef          	jal	ra,80000e1e <myproc>
    8000170a:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000170c:	00006517          	auipc	a0,0x6
    80001710:	2dc50513          	addi	a0,a0,732 # 800079e8 <wait_lock>
    80001714:	126040ef          	jal	ra,8000583a <acquire>
    havekids = 0;
    80001718:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    8000171a:	4a15                	li	s4,5
        havekids = 1;
    8000171c:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000171e:	0000c997          	auipc	s3,0xc
    80001722:	2e298993          	addi	s3,s3,738 # 8000da00 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80001726:	00006c17          	auipc	s8,0x6
    8000172a:	2c2c0c13          	addi	s8,s8,706 # 800079e8 <wait_lock>
    havekids = 0;
    8000172e:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001730:	00006497          	auipc	s1,0x6
    80001734:	6d048493          	addi	s1,s1,1744 # 80007e00 <proc>
    80001738:	a899                	j	8000178e <wait+0xa2>
          pid = pp->pid;
    8000173a:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000173e:	000b0c63          	beqz	s6,80001756 <wait+0x6a>
    80001742:	4691                	li	a3,4
    80001744:	02c48613          	addi	a2,s1,44
    80001748:	85da                	mv	a1,s6
    8000174a:	05093503          	ld	a0,80(s2)
    8000174e:	a88ff0ef          	jal	ra,800009d6 <copyout>
    80001752:	00054f63          	bltz	a0,80001770 <wait+0x84>
          freeproc(pp);
    80001756:	8526                	mv	a0,s1
    80001758:	8abff0ef          	jal	ra,80001002 <freeproc>
          release(&pp->lock);
    8000175c:	8526                	mv	a0,s1
    8000175e:	174040ef          	jal	ra,800058d2 <release>
          release(&wait_lock);
    80001762:	00006517          	auipc	a0,0x6
    80001766:	28650513          	addi	a0,a0,646 # 800079e8 <wait_lock>
    8000176a:	168040ef          	jal	ra,800058d2 <release>
          return pid;
    8000176e:	a891                	j	800017c2 <wait+0xd6>
            release(&pp->lock);
    80001770:	8526                	mv	a0,s1
    80001772:	160040ef          	jal	ra,800058d2 <release>
            release(&wait_lock);
    80001776:	00006517          	auipc	a0,0x6
    8000177a:	27250513          	addi	a0,a0,626 # 800079e8 <wait_lock>
    8000177e:	154040ef          	jal	ra,800058d2 <release>
            return -1;
    80001782:	59fd                	li	s3,-1
    80001784:	a83d                	j	800017c2 <wait+0xd6>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80001786:	17048493          	addi	s1,s1,368
    8000178a:	03348063          	beq	s1,s3,800017aa <wait+0xbe>
      if(pp->parent == p){
    8000178e:	7c9c                	ld	a5,56(s1)
    80001790:	ff279be3          	bne	a5,s2,80001786 <wait+0x9a>
        acquire(&pp->lock);
    80001794:	8526                	mv	a0,s1
    80001796:	0a4040ef          	jal	ra,8000583a <acquire>
        if(pp->state == ZOMBIE){
    8000179a:	4c9c                	lw	a5,24(s1)
    8000179c:	f9478fe3          	beq	a5,s4,8000173a <wait+0x4e>
        release(&pp->lock);
    800017a0:	8526                	mv	a0,s1
    800017a2:	130040ef          	jal	ra,800058d2 <release>
        havekids = 1;
    800017a6:	8756                	mv	a4,s5
    800017a8:	bff9                	j	80001786 <wait+0x9a>
    if(!havekids || killed(p)){
    800017aa:	c709                	beqz	a4,800017b4 <wait+0xc8>
    800017ac:	854a                	mv	a0,s2
    800017ae:	f15ff0ef          	jal	ra,800016c2 <killed>
    800017b2:	c50d                	beqz	a0,800017dc <wait+0xf0>
      release(&wait_lock);
    800017b4:	00006517          	auipc	a0,0x6
    800017b8:	23450513          	addi	a0,a0,564 # 800079e8 <wait_lock>
    800017bc:	116040ef          	jal	ra,800058d2 <release>
      return -1;
    800017c0:	59fd                	li	s3,-1
}
    800017c2:	854e                	mv	a0,s3
    800017c4:	60a6                	ld	ra,72(sp)
    800017c6:	6406                	ld	s0,64(sp)
    800017c8:	74e2                	ld	s1,56(sp)
    800017ca:	7942                	ld	s2,48(sp)
    800017cc:	79a2                	ld	s3,40(sp)
    800017ce:	7a02                	ld	s4,32(sp)
    800017d0:	6ae2                	ld	s5,24(sp)
    800017d2:	6b42                	ld	s6,16(sp)
    800017d4:	6ba2                	ld	s7,8(sp)
    800017d6:	6c02                	ld	s8,0(sp)
    800017d8:	6161                	addi	sp,sp,80
    800017da:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800017dc:	85e2                	mv	a1,s8
    800017de:	854a                	mv	a0,s2
    800017e0:	cabff0ef          	jal	ra,8000148a <sleep>
    havekids = 0;
    800017e4:	b7a9                	j	8000172e <wait+0x42>

00000000800017e6 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800017e6:	7179                	addi	sp,sp,-48
    800017e8:	f406                	sd	ra,40(sp)
    800017ea:	f022                	sd	s0,32(sp)
    800017ec:	ec26                	sd	s1,24(sp)
    800017ee:	e84a                	sd	s2,16(sp)
    800017f0:	e44e                	sd	s3,8(sp)
    800017f2:	e052                	sd	s4,0(sp)
    800017f4:	1800                	addi	s0,sp,48
    800017f6:	84aa                	mv	s1,a0
    800017f8:	892e                	mv	s2,a1
    800017fa:	89b2                	mv	s3,a2
    800017fc:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800017fe:	e20ff0ef          	jal	ra,80000e1e <myproc>
  if(user_dst){
    80001802:	cc99                	beqz	s1,80001820 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80001804:	86d2                	mv	a3,s4
    80001806:	864e                	mv	a2,s3
    80001808:	85ca                	mv	a1,s2
    8000180a:	6928                	ld	a0,80(a0)
    8000180c:	9caff0ef          	jal	ra,800009d6 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80001810:	70a2                	ld	ra,40(sp)
    80001812:	7402                	ld	s0,32(sp)
    80001814:	64e2                	ld	s1,24(sp)
    80001816:	6942                	ld	s2,16(sp)
    80001818:	69a2                	ld	s3,8(sp)
    8000181a:	6a02                	ld	s4,0(sp)
    8000181c:	6145                	addi	sp,sp,48
    8000181e:	8082                	ret
    memmove((char *)dst, src, len);
    80001820:	000a061b          	sext.w	a2,s4
    80001824:	85ce                	mv	a1,s3
    80001826:	854a                	mv	a0,s2
    80001828:	981fe0ef          	jal	ra,800001a8 <memmove>
    return 0;
    8000182c:	8526                	mv	a0,s1
    8000182e:	b7cd                	j	80001810 <either_copyout+0x2a>

0000000080001830 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80001830:	7179                	addi	sp,sp,-48
    80001832:	f406                	sd	ra,40(sp)
    80001834:	f022                	sd	s0,32(sp)
    80001836:	ec26                	sd	s1,24(sp)
    80001838:	e84a                	sd	s2,16(sp)
    8000183a:	e44e                	sd	s3,8(sp)
    8000183c:	e052                	sd	s4,0(sp)
    8000183e:	1800                	addi	s0,sp,48
    80001840:	892a                	mv	s2,a0
    80001842:	84ae                	mv	s1,a1
    80001844:	89b2                	mv	s3,a2
    80001846:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80001848:	dd6ff0ef          	jal	ra,80000e1e <myproc>
  if(user_src){
    8000184c:	cc99                	beqz	s1,8000186a <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    8000184e:	86d2                	mv	a3,s4
    80001850:	864e                	mv	a2,s3
    80001852:	85ca                	mv	a1,s2
    80001854:	6928                	ld	a0,80(a0)
    80001856:	a38ff0ef          	jal	ra,80000a8e <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    8000185a:	70a2                	ld	ra,40(sp)
    8000185c:	7402                	ld	s0,32(sp)
    8000185e:	64e2                	ld	s1,24(sp)
    80001860:	6942                	ld	s2,16(sp)
    80001862:	69a2                	ld	s3,8(sp)
    80001864:	6a02                	ld	s4,0(sp)
    80001866:	6145                	addi	sp,sp,48
    80001868:	8082                	ret
    memmove(dst, (char*)src, len);
    8000186a:	000a061b          	sext.w	a2,s4
    8000186e:	85ce                	mv	a1,s3
    80001870:	854a                	mv	a0,s2
    80001872:	937fe0ef          	jal	ra,800001a8 <memmove>
    return 0;
    80001876:	8526                	mv	a0,s1
    80001878:	b7cd                	j	8000185a <either_copyin+0x2a>

000000008000187a <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000187a:	715d                	addi	sp,sp,-80
    8000187c:	e486                	sd	ra,72(sp)
    8000187e:	e0a2                	sd	s0,64(sp)
    80001880:	fc26                	sd	s1,56(sp)
    80001882:	f84a                	sd	s2,48(sp)
    80001884:	f44e                	sd	s3,40(sp)
    80001886:	f052                	sd	s4,32(sp)
    80001888:	ec56                	sd	s5,24(sp)
    8000188a:	e85a                	sd	s6,16(sp)
    8000188c:	e45e                	sd	s7,8(sp)
    8000188e:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80001890:	00005517          	auipc	a0,0x5
    80001894:	7b850513          	addi	a0,a0,1976 # 80007048 <etext+0x48>
    80001898:	1db030ef          	jal	ra,80005272 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000189c:	00006497          	auipc	s1,0x6
    800018a0:	6bc48493          	addi	s1,s1,1724 # 80007f58 <proc+0x158>
    800018a4:	0000c917          	auipc	s2,0xc
    800018a8:	2b490913          	addi	s2,s2,692 # 8000db58 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018ac:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800018ae:	00006997          	auipc	s3,0x6
    800018b2:	9da98993          	addi	s3,s3,-1574 # 80007288 <etext+0x288>
    printf("%d %s %s", p->pid, state, p->name);
    800018b6:	00006a97          	auipc	s5,0x6
    800018ba:	9daa8a93          	addi	s5,s5,-1574 # 80007290 <etext+0x290>
    printf("\n");
    800018be:	00005a17          	auipc	s4,0x5
    800018c2:	78aa0a13          	addi	s4,s4,1930 # 80007048 <etext+0x48>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018c6:	00006b97          	auipc	s7,0x6
    800018ca:	a0ab8b93          	addi	s7,s7,-1526 # 800072d0 <states.0>
    800018ce:	a829                	j	800018e8 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800018d0:	ed86a583          	lw	a1,-296(a3)
    800018d4:	8556                	mv	a0,s5
    800018d6:	19d030ef          	jal	ra,80005272 <printf>
    printf("\n");
    800018da:	8552                	mv	a0,s4
    800018dc:	197030ef          	jal	ra,80005272 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800018e0:	17048493          	addi	s1,s1,368
    800018e4:	03248263          	beq	s1,s2,80001908 <procdump+0x8e>
    if(p->state == UNUSED)
    800018e8:	86a6                	mv	a3,s1
    800018ea:	ec04a783          	lw	a5,-320(s1)
    800018ee:	dbed                	beqz	a5,800018e0 <procdump+0x66>
      state = "???";
    800018f0:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800018f2:	fcfb6fe3          	bltu	s6,a5,800018d0 <procdump+0x56>
    800018f6:	02079713          	slli	a4,a5,0x20
    800018fa:	01d75793          	srli	a5,a4,0x1d
    800018fe:	97de                	add	a5,a5,s7
    80001900:	6390                	ld	a2,0(a5)
    80001902:	f679                	bnez	a2,800018d0 <procdump+0x56>
      state = "???";
    80001904:	864e                	mv	a2,s3
    80001906:	b7e9                	j	800018d0 <procdump+0x56>
  }
}
    80001908:	60a6                	ld	ra,72(sp)
    8000190a:	6406                	ld	s0,64(sp)
    8000190c:	74e2                	ld	s1,56(sp)
    8000190e:	7942                	ld	s2,48(sp)
    80001910:	79a2                	ld	s3,40(sp)
    80001912:	7a02                	ld	s4,32(sp)
    80001914:	6ae2                	ld	s5,24(sp)
    80001916:	6b42                	ld	s6,16(sp)
    80001918:	6ba2                	ld	s7,8(sp)
    8000191a:	6161                	addi	sp,sp,80
    8000191c:	8082                	ret

000000008000191e <swtch>:
    8000191e:	00153023          	sd	ra,0(a0)
    80001922:	00253423          	sd	sp,8(a0)
    80001926:	e900                	sd	s0,16(a0)
    80001928:	ed04                	sd	s1,24(a0)
    8000192a:	03253023          	sd	s2,32(a0)
    8000192e:	03353423          	sd	s3,40(a0)
    80001932:	03453823          	sd	s4,48(a0)
    80001936:	03553c23          	sd	s5,56(a0)
    8000193a:	05653023          	sd	s6,64(a0)
    8000193e:	05753423          	sd	s7,72(a0)
    80001942:	05853823          	sd	s8,80(a0)
    80001946:	05953c23          	sd	s9,88(a0)
    8000194a:	07a53023          	sd	s10,96(a0)
    8000194e:	07b53423          	sd	s11,104(a0)
    80001952:	0005b083          	ld	ra,0(a1)
    80001956:	0085b103          	ld	sp,8(a1)
    8000195a:	6980                	ld	s0,16(a1)
    8000195c:	6d84                	ld	s1,24(a1)
    8000195e:	0205b903          	ld	s2,32(a1)
    80001962:	0285b983          	ld	s3,40(a1)
    80001966:	0305ba03          	ld	s4,48(a1)
    8000196a:	0385ba83          	ld	s5,56(a1)
    8000196e:	0405bb03          	ld	s6,64(a1)
    80001972:	0485bb83          	ld	s7,72(a1)
    80001976:	0505bc03          	ld	s8,80(a1)
    8000197a:	0585bc83          	ld	s9,88(a1)
    8000197e:	0605bd03          	ld	s10,96(a1)
    80001982:	0685bd83          	ld	s11,104(a1)
    80001986:	8082                	ret

0000000080001988 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80001988:	1141                	addi	sp,sp,-16
    8000198a:	e406                	sd	ra,8(sp)
    8000198c:	e022                	sd	s0,0(sp)
    8000198e:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80001990:	00006597          	auipc	a1,0x6
    80001994:	97058593          	addi	a1,a1,-1680 # 80007300 <states.0+0x30>
    80001998:	0000c517          	auipc	a0,0xc
    8000199c:	06850513          	addi	a0,a0,104 # 8000da00 <tickslock>
    800019a0:	61b030ef          	jal	ra,800057ba <initlock>
}
    800019a4:	60a2                	ld	ra,8(sp)
    800019a6:	6402                	ld	s0,0(sp)
    800019a8:	0141                	addi	sp,sp,16
    800019aa:	8082                	ret

00000000800019ac <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800019ac:	1141                	addi	sp,sp,-16
    800019ae:	e422                	sd	s0,8(sp)
    800019b0:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800019b2:	00003797          	auipc	a5,0x3
    800019b6:	e5e78793          	addi	a5,a5,-418 # 80004810 <kernelvec>
    800019ba:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800019be:	6422                	ld	s0,8(sp)
    800019c0:	0141                	addi	sp,sp,16
    800019c2:	8082                	ret

00000000800019c4 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    800019c4:	1141                	addi	sp,sp,-16
    800019c6:	e406                	sd	ra,8(sp)
    800019c8:	e022                	sd	s0,0(sp)
    800019ca:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800019cc:	c52ff0ef          	jal	ra,80000e1e <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800019d0:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800019d4:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800019d6:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800019da:	00004617          	auipc	a2,0x4
    800019de:	62660613          	addi	a2,a2,1574 # 80006000 <_trampoline>
    800019e2:	00004697          	auipc	a3,0x4
    800019e6:	61e68693          	addi	a3,a3,1566 # 80006000 <_trampoline>
    800019ea:	8e91                	sub	a3,a3,a2
    800019ec:	040007b7          	lui	a5,0x4000
    800019f0:	17fd                	addi	a5,a5,-1
    800019f2:	07b2                	slli	a5,a5,0xc
    800019f4:	96be                	add	a3,a3,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    800019f6:	10569073          	csrw	stvec,a3
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800019fa:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800019fc:	180026f3          	csrr	a3,satp
    80001a00:	e314                	sd	a3,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80001a02:	6d38                	ld	a4,88(a0)
    80001a04:	6134                	ld	a3,64(a0)
    80001a06:	6585                	lui	a1,0x1
    80001a08:	96ae                	add	a3,a3,a1
    80001a0a:	e714                	sd	a3,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80001a0c:	6d38                	ld	a4,88(a0)
    80001a0e:	00000697          	auipc	a3,0x0
    80001a12:	10c68693          	addi	a3,a3,268 # 80001b1a <usertrap>
    80001a16:	eb14                	sd	a3,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80001a18:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80001a1a:	8692                	mv	a3,tp
    80001a1c:	f314                	sd	a3,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001a1e:	100026f3          	csrr	a3,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80001a22:	eff6f693          	andi	a3,a3,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80001a26:	0206e693          	ori	a3,a3,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001a2a:	10069073          	csrw	sstatus,a3
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80001a2e:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001a30:	6f18                	ld	a4,24(a4)
    80001a32:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80001a36:	6928                	ld	a0,80(a0)
    80001a38:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001a3a:	00004717          	auipc	a4,0x4
    80001a3e:	66270713          	addi	a4,a4,1634 # 8000609c <userret>
    80001a42:	8f11                	sub	a4,a4,a2
    80001a44:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001a46:	577d                	li	a4,-1
    80001a48:	177e                	slli	a4,a4,0x3f
    80001a4a:	8d59                	or	a0,a0,a4
    80001a4c:	9782                	jalr	a5
}
    80001a4e:	60a2                	ld	ra,8(sp)
    80001a50:	6402                	ld	s0,0(sp)
    80001a52:	0141                	addi	sp,sp,16
    80001a54:	8082                	ret

0000000080001a56 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80001a56:	1101                	addi	sp,sp,-32
    80001a58:	ec06                	sd	ra,24(sp)
    80001a5a:	e822                	sd	s0,16(sp)
    80001a5c:	e426                	sd	s1,8(sp)
    80001a5e:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    80001a60:	b92ff0ef          	jal	ra,80000df2 <cpuid>
    80001a64:	cd19                	beqz	a0,80001a82 <clockintr+0x2c>
  asm volatile("csrr %0, time" : "=r" (x) );
    80001a66:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80001a6a:	000f4737          	lui	a4,0xf4
    80001a6e:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80001a72:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80001a74:	14d79073          	csrw	0x14d,a5
}
    80001a78:	60e2                	ld	ra,24(sp)
    80001a7a:	6442                	ld	s0,16(sp)
    80001a7c:	64a2                	ld	s1,8(sp)
    80001a7e:	6105                	addi	sp,sp,32
    80001a80:	8082                	ret
    acquire(&tickslock);
    80001a82:	0000c497          	auipc	s1,0xc
    80001a86:	f7e48493          	addi	s1,s1,-130 # 8000da00 <tickslock>
    80001a8a:	8526                	mv	a0,s1
    80001a8c:	5af030ef          	jal	ra,8000583a <acquire>
    ticks++;
    80001a90:	00006517          	auipc	a0,0x6
    80001a94:	f0850513          	addi	a0,a0,-248 # 80007998 <ticks>
    80001a98:	411c                	lw	a5,0(a0)
    80001a9a:	2785                	addiw	a5,a5,1
    80001a9c:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    80001a9e:	a39ff0ef          	jal	ra,800014d6 <wakeup>
    release(&tickslock);
    80001aa2:	8526                	mv	a0,s1
    80001aa4:	62f030ef          	jal	ra,800058d2 <release>
    80001aa8:	bf7d                	j	80001a66 <clockintr+0x10>

0000000080001aaa <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80001aaa:	1101                	addi	sp,sp,-32
    80001aac:	ec06                	sd	ra,24(sp)
    80001aae:	e822                	sd	s0,16(sp)
    80001ab0:	e426                	sd	s1,8(sp)
    80001ab2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001ab4:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80001ab8:	57fd                	li	a5,-1
    80001aba:	17fe                	slli	a5,a5,0x3f
    80001abc:	07a5                	addi	a5,a5,9
    80001abe:	00f70d63          	beq	a4,a5,80001ad8 <devintr+0x2e>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80001ac2:	57fd                	li	a5,-1
    80001ac4:	17fe                	slli	a5,a5,0x3f
    80001ac6:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80001ac8:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80001aca:	04f70463          	beq	a4,a5,80001b12 <devintr+0x68>
  }
}
    80001ace:	60e2                	ld	ra,24(sp)
    80001ad0:	6442                	ld	s0,16(sp)
    80001ad2:	64a2                	ld	s1,8(sp)
    80001ad4:	6105                	addi	sp,sp,32
    80001ad6:	8082                	ret
    int irq = plic_claim();
    80001ad8:	5e1020ef          	jal	ra,800048b8 <plic_claim>
    80001adc:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80001ade:	47a9                	li	a5,10
    80001ae0:	02f50363          	beq	a0,a5,80001b06 <devintr+0x5c>
    } else if(irq == VIRTIO0_IRQ){
    80001ae4:	4785                	li	a5,1
    80001ae6:	02f50363          	beq	a0,a5,80001b0c <devintr+0x62>
    return 1;
    80001aea:	4505                	li	a0,1
    } else if(irq){
    80001aec:	d0ed                	beqz	s1,80001ace <devintr+0x24>
      printf("unexpected interrupt irq=%d\n", irq);
    80001aee:	85a6                	mv	a1,s1
    80001af0:	00006517          	auipc	a0,0x6
    80001af4:	81850513          	addi	a0,a0,-2024 # 80007308 <states.0+0x38>
    80001af8:	77a030ef          	jal	ra,80005272 <printf>
      plic_complete(irq);
    80001afc:	8526                	mv	a0,s1
    80001afe:	5db020ef          	jal	ra,800048d8 <plic_complete>
    return 1;
    80001b02:	4505                	li	a0,1
    80001b04:	b7e9                	j	80001ace <devintr+0x24>
      uartintr();
    80001b06:	479030ef          	jal	ra,8000577e <uartintr>
    80001b0a:	bfcd                	j	80001afc <devintr+0x52>
      virtio_disk_intr();
    80001b0c:	23c030ef          	jal	ra,80004d48 <virtio_disk_intr>
    80001b10:	b7f5                	j	80001afc <devintr+0x52>
    clockintr();
    80001b12:	f45ff0ef          	jal	ra,80001a56 <clockintr>
    return 2;
    80001b16:	4509                	li	a0,2
    80001b18:	bf5d                	j	80001ace <devintr+0x24>

0000000080001b1a <usertrap>:
{
    80001b1a:	1101                	addi	sp,sp,-32
    80001b1c:	ec06                	sd	ra,24(sp)
    80001b1e:	e822                	sd	s0,16(sp)
    80001b20:	e426                	sd	s1,8(sp)
    80001b22:	e04a                	sd	s2,0(sp)
    80001b24:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b26:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80001b2a:	1007f793          	andi	a5,a5,256
    80001b2e:	ef85                	bnez	a5,80001b66 <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80001b30:	00003797          	auipc	a5,0x3
    80001b34:	ce078793          	addi	a5,a5,-800 # 80004810 <kernelvec>
    80001b38:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80001b3c:	ae2ff0ef          	jal	ra,80000e1e <myproc>
    80001b40:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80001b42:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001b44:	14102773          	csrr	a4,sepc
    80001b48:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001b4a:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    80001b4e:	47a1                	li	a5,8
    80001b50:	02f70163          	beq	a4,a5,80001b72 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    80001b54:	f57ff0ef          	jal	ra,80001aaa <devintr>
    80001b58:	892a                	mv	s2,a0
    80001b5a:	c135                	beqz	a0,80001bbe <usertrap+0xa4>
  if(killed(p))
    80001b5c:	8526                	mv	a0,s1
    80001b5e:	b65ff0ef          	jal	ra,800016c2 <killed>
    80001b62:	cd1d                	beqz	a0,80001ba0 <usertrap+0x86>
    80001b64:	a81d                	j	80001b9a <usertrap+0x80>
    panic("usertrap: not from user mode");
    80001b66:	00005517          	auipc	a0,0x5
    80001b6a:	7c250513          	addi	a0,a0,1986 # 80007328 <states.0+0x58>
    80001b6e:	1b9030ef          	jal	ra,80005526 <panic>
    if(killed(p))
    80001b72:	b51ff0ef          	jal	ra,800016c2 <killed>
    80001b76:	e121                	bnez	a0,80001bb6 <usertrap+0x9c>
    p->trapframe->epc += 4;
    80001b78:	6cb8                	ld	a4,88(s1)
    80001b7a:	6f1c                	ld	a5,24(a4)
    80001b7c:	0791                	addi	a5,a5,4
    80001b7e:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001b80:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001b84:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001b88:	10079073          	csrw	sstatus,a5
    syscall();
    80001b8c:	248000ef          	jal	ra,80001dd4 <syscall>
  if(killed(p))
    80001b90:	8526                	mv	a0,s1
    80001b92:	b31ff0ef          	jal	ra,800016c2 <killed>
    80001b96:	c901                	beqz	a0,80001ba6 <usertrap+0x8c>
    80001b98:	4901                	li	s2,0
    exit(-1);
    80001b9a:	557d                	li	a0,-1
    80001b9c:	9fbff0ef          	jal	ra,80001596 <exit>
  if(which_dev == 2)
    80001ba0:	4789                	li	a5,2
    80001ba2:	04f90563          	beq	s2,a5,80001bec <usertrap+0xd2>
  usertrapret();
    80001ba6:	e1fff0ef          	jal	ra,800019c4 <usertrapret>
}
    80001baa:	60e2                	ld	ra,24(sp)
    80001bac:	6442                	ld	s0,16(sp)
    80001bae:	64a2                	ld	s1,8(sp)
    80001bb0:	6902                	ld	s2,0(sp)
    80001bb2:	6105                	addi	sp,sp,32
    80001bb4:	8082                	ret
      exit(-1);
    80001bb6:	557d                	li	a0,-1
    80001bb8:	9dfff0ef          	jal	ra,80001596 <exit>
    80001bbc:	bf75                	j	80001b78 <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001bbe:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80001bc2:	5890                	lw	a2,48(s1)
    80001bc4:	00005517          	auipc	a0,0x5
    80001bc8:	78450513          	addi	a0,a0,1924 # 80007348 <states.0+0x78>
    80001bcc:	6a6030ef          	jal	ra,80005272 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001bd0:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001bd4:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80001bd8:	00005517          	auipc	a0,0x5
    80001bdc:	7a050513          	addi	a0,a0,1952 # 80007378 <states.0+0xa8>
    80001be0:	692030ef          	jal	ra,80005272 <printf>
    setkilled(p);
    80001be4:	8526                	mv	a0,s1
    80001be6:	ab9ff0ef          	jal	ra,8000169e <setkilled>
    80001bea:	b75d                	j	80001b90 <usertrap+0x76>
    yield();
    80001bec:	873ff0ef          	jal	ra,8000145e <yield>
    80001bf0:	bf5d                	j	80001ba6 <usertrap+0x8c>

0000000080001bf2 <kerneltrap>:
{
    80001bf2:	7179                	addi	sp,sp,-48
    80001bf4:	f406                	sd	ra,40(sp)
    80001bf6:	f022                	sd	s0,32(sp)
    80001bf8:	ec26                	sd	s1,24(sp)
    80001bfa:	e84a                	sd	s2,16(sp)
    80001bfc:	e44e                	sd	s3,8(sp)
    80001bfe:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001c00:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c04:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80001c08:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80001c0c:	1004f793          	andi	a5,s1,256
    80001c10:	c795                	beqz	a5,80001c3c <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001c12:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001c16:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80001c18:	eb85                	bnez	a5,80001c48 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    80001c1a:	e91ff0ef          	jal	ra,80001aaa <devintr>
    80001c1e:	c91d                	beqz	a0,80001c54 <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    80001c20:	4789                	li	a5,2
    80001c22:	04f50a63          	beq	a0,a5,80001c76 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80001c26:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001c2a:	10049073          	csrw	sstatus,s1
}
    80001c2e:	70a2                	ld	ra,40(sp)
    80001c30:	7402                	ld	s0,32(sp)
    80001c32:	64e2                	ld	s1,24(sp)
    80001c34:	6942                	ld	s2,16(sp)
    80001c36:	69a2                	ld	s3,8(sp)
    80001c38:	6145                	addi	sp,sp,48
    80001c3a:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80001c3c:	00005517          	auipc	a0,0x5
    80001c40:	76450513          	addi	a0,a0,1892 # 800073a0 <states.0+0xd0>
    80001c44:	0e3030ef          	jal	ra,80005526 <panic>
    panic("kerneltrap: interrupts enabled");
    80001c48:	00005517          	auipc	a0,0x5
    80001c4c:	78050513          	addi	a0,a0,1920 # 800073c8 <states.0+0xf8>
    80001c50:	0d7030ef          	jal	ra,80005526 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80001c54:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80001c58:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80001c5c:	85ce                	mv	a1,s3
    80001c5e:	00005517          	auipc	a0,0x5
    80001c62:	78a50513          	addi	a0,a0,1930 # 800073e8 <states.0+0x118>
    80001c66:	60c030ef          	jal	ra,80005272 <printf>
    panic("kerneltrap");
    80001c6a:	00005517          	auipc	a0,0x5
    80001c6e:	7a650513          	addi	a0,a0,1958 # 80007410 <states.0+0x140>
    80001c72:	0b5030ef          	jal	ra,80005526 <panic>
  if(which_dev == 2 && myproc() != 0)
    80001c76:	9a8ff0ef          	jal	ra,80000e1e <myproc>
    80001c7a:	d555                	beqz	a0,80001c26 <kerneltrap+0x34>
    yield();
    80001c7c:	fe2ff0ef          	jal	ra,8000145e <yield>
    80001c80:	b75d                	j	80001c26 <kerneltrap+0x34>

0000000080001c82 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80001c82:	1101                	addi	sp,sp,-32
    80001c84:	ec06                	sd	ra,24(sp)
    80001c86:	e822                	sd	s0,16(sp)
    80001c88:	e426                	sd	s1,8(sp)
    80001c8a:	1000                	addi	s0,sp,32
    80001c8c:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c8e:	990ff0ef          	jal	ra,80000e1e <myproc>
  switch (n) {
    80001c92:	4795                	li	a5,5
    80001c94:	0497e163          	bltu	a5,s1,80001cd6 <argraw+0x54>
    80001c98:	048a                	slli	s1,s1,0x2
    80001c9a:	00005717          	auipc	a4,0x5
    80001c9e:	7ae70713          	addi	a4,a4,1966 # 80007448 <states.0+0x178>
    80001ca2:	94ba                	add	s1,s1,a4
    80001ca4:	409c                	lw	a5,0(s1)
    80001ca6:	97ba                	add	a5,a5,a4
    80001ca8:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80001caa:	6d3c                	ld	a5,88(a0)
    80001cac:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80001cae:	60e2                	ld	ra,24(sp)
    80001cb0:	6442                	ld	s0,16(sp)
    80001cb2:	64a2                	ld	s1,8(sp)
    80001cb4:	6105                	addi	sp,sp,32
    80001cb6:	8082                	ret
    return p->trapframe->a1;
    80001cb8:	6d3c                	ld	a5,88(a0)
    80001cba:	7fa8                	ld	a0,120(a5)
    80001cbc:	bfcd                	j	80001cae <argraw+0x2c>
    return p->trapframe->a2;
    80001cbe:	6d3c                	ld	a5,88(a0)
    80001cc0:	63c8                	ld	a0,128(a5)
    80001cc2:	b7f5                	j	80001cae <argraw+0x2c>
    return p->trapframe->a3;
    80001cc4:	6d3c                	ld	a5,88(a0)
    80001cc6:	67c8                	ld	a0,136(a5)
    80001cc8:	b7dd                	j	80001cae <argraw+0x2c>
    return p->trapframe->a4;
    80001cca:	6d3c                	ld	a5,88(a0)
    80001ccc:	6bc8                	ld	a0,144(a5)
    80001cce:	b7c5                	j	80001cae <argraw+0x2c>
    return p->trapframe->a5;
    80001cd0:	6d3c                	ld	a5,88(a0)
    80001cd2:	6fc8                	ld	a0,152(a5)
    80001cd4:	bfe9                	j	80001cae <argraw+0x2c>
  panic("argraw");
    80001cd6:	00005517          	auipc	a0,0x5
    80001cda:	74a50513          	addi	a0,a0,1866 # 80007420 <states.0+0x150>
    80001cde:	049030ef          	jal	ra,80005526 <panic>

0000000080001ce2 <fetchaddr>:
{
    80001ce2:	1101                	addi	sp,sp,-32
    80001ce4:	ec06                	sd	ra,24(sp)
    80001ce6:	e822                	sd	s0,16(sp)
    80001ce8:	e426                	sd	s1,8(sp)
    80001cea:	e04a                	sd	s2,0(sp)
    80001cec:	1000                	addi	s0,sp,32
    80001cee:	84aa                	mv	s1,a0
    80001cf0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001cf2:	92cff0ef          	jal	ra,80000e1e <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80001cf6:	653c                	ld	a5,72(a0)
    80001cf8:	02f4f663          	bgeu	s1,a5,80001d24 <fetchaddr+0x42>
    80001cfc:	00848713          	addi	a4,s1,8
    80001d00:	02e7e463          	bltu	a5,a4,80001d28 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80001d04:	46a1                	li	a3,8
    80001d06:	8626                	mv	a2,s1
    80001d08:	85ca                	mv	a1,s2
    80001d0a:	6928                	ld	a0,80(a0)
    80001d0c:	d83fe0ef          	jal	ra,80000a8e <copyin>
    80001d10:	00a03533          	snez	a0,a0
    80001d14:	40a00533          	neg	a0,a0
}
    80001d18:	60e2                	ld	ra,24(sp)
    80001d1a:	6442                	ld	s0,16(sp)
    80001d1c:	64a2                	ld	s1,8(sp)
    80001d1e:	6902                	ld	s2,0(sp)
    80001d20:	6105                	addi	sp,sp,32
    80001d22:	8082                	ret
    return -1;
    80001d24:	557d                	li	a0,-1
    80001d26:	bfcd                	j	80001d18 <fetchaddr+0x36>
    80001d28:	557d                	li	a0,-1
    80001d2a:	b7fd                	j	80001d18 <fetchaddr+0x36>

0000000080001d2c <fetchstr>:
{
    80001d2c:	7179                	addi	sp,sp,-48
    80001d2e:	f406                	sd	ra,40(sp)
    80001d30:	f022                	sd	s0,32(sp)
    80001d32:	ec26                	sd	s1,24(sp)
    80001d34:	e84a                	sd	s2,16(sp)
    80001d36:	e44e                	sd	s3,8(sp)
    80001d38:	1800                	addi	s0,sp,48
    80001d3a:	892a                	mv	s2,a0
    80001d3c:	84ae                	mv	s1,a1
    80001d3e:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80001d40:	8deff0ef          	jal	ra,80000e1e <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80001d44:	86ce                	mv	a3,s3
    80001d46:	864a                	mv	a2,s2
    80001d48:	85a6                	mv	a1,s1
    80001d4a:	6928                	ld	a0,80(a0)
    80001d4c:	dc9fe0ef          	jal	ra,80000b14 <copyinstr>
    80001d50:	00054c63          	bltz	a0,80001d68 <fetchstr+0x3c>
  return strlen(buf);
    80001d54:	8526                	mv	a0,s1
    80001d56:	d6efe0ef          	jal	ra,800002c4 <strlen>
}
    80001d5a:	70a2                	ld	ra,40(sp)
    80001d5c:	7402                	ld	s0,32(sp)
    80001d5e:	64e2                	ld	s1,24(sp)
    80001d60:	6942                	ld	s2,16(sp)
    80001d62:	69a2                	ld	s3,8(sp)
    80001d64:	6145                	addi	sp,sp,48
    80001d66:	8082                	ret
    return -1;
    80001d68:	557d                	li	a0,-1
    80001d6a:	bfc5                	j	80001d5a <fetchstr+0x2e>

0000000080001d6c <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80001d6c:	1101                	addi	sp,sp,-32
    80001d6e:	ec06                	sd	ra,24(sp)
    80001d70:	e822                	sd	s0,16(sp)
    80001d72:	e426                	sd	s1,8(sp)
    80001d74:	1000                	addi	s0,sp,32
    80001d76:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d78:	f0bff0ef          	jal	ra,80001c82 <argraw>
    80001d7c:	c088                	sw	a0,0(s1)
}
    80001d7e:	60e2                	ld	ra,24(sp)
    80001d80:	6442                	ld	s0,16(sp)
    80001d82:	64a2                	ld	s1,8(sp)
    80001d84:	6105                	addi	sp,sp,32
    80001d86:	8082                	ret

0000000080001d88 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80001d88:	1101                	addi	sp,sp,-32
    80001d8a:	ec06                	sd	ra,24(sp)
    80001d8c:	e822                	sd	s0,16(sp)
    80001d8e:	e426                	sd	s1,8(sp)
    80001d90:	1000                	addi	s0,sp,32
    80001d92:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80001d94:	eefff0ef          	jal	ra,80001c82 <argraw>
    80001d98:	e088                	sd	a0,0(s1)
}
    80001d9a:	60e2                	ld	ra,24(sp)
    80001d9c:	6442                	ld	s0,16(sp)
    80001d9e:	64a2                	ld	s1,8(sp)
    80001da0:	6105                	addi	sp,sp,32
    80001da2:	8082                	ret

0000000080001da4 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80001da4:	7179                	addi	sp,sp,-48
    80001da6:	f406                	sd	ra,40(sp)
    80001da8:	f022                	sd	s0,32(sp)
    80001daa:	ec26                	sd	s1,24(sp)
    80001dac:	e84a                	sd	s2,16(sp)
    80001dae:	1800                	addi	s0,sp,48
    80001db0:	84ae                	mv	s1,a1
    80001db2:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80001db4:	fd840593          	addi	a1,s0,-40
    80001db8:	fd1ff0ef          	jal	ra,80001d88 <argaddr>
  return fetchstr(addr, buf, max);
    80001dbc:	864a                	mv	a2,s2
    80001dbe:	85a6                	mv	a1,s1
    80001dc0:	fd843503          	ld	a0,-40(s0)
    80001dc4:	f69ff0ef          	jal	ra,80001d2c <fetchstr>
}
    80001dc8:	70a2                	ld	ra,40(sp)
    80001dca:	7402                	ld	s0,32(sp)
    80001dcc:	64e2                	ld	s1,24(sp)
    80001dce:	6942                	ld	s2,16(sp)
    80001dd0:	6145                	addi	sp,sp,48
    80001dd2:	8082                	ret

0000000080001dd4 <syscall>:



void
syscall(void)
{
    80001dd4:	1101                	addi	sp,sp,-32
    80001dd6:	ec06                	sd	ra,24(sp)
    80001dd8:	e822                	sd	s0,16(sp)
    80001dda:	e426                	sd	s1,8(sp)
    80001ddc:	e04a                	sd	s2,0(sp)
    80001dde:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80001de0:	83eff0ef          	jal	ra,80000e1e <myproc>
    80001de4:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80001de6:	05853903          	ld	s2,88(a0)
    80001dea:	0a893783          	ld	a5,168(s2)
    80001dee:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80001df2:	37fd                	addiw	a5,a5,-1
    80001df4:	02200713          	li	a4,34
    80001df8:	00f76f63          	bltu	a4,a5,80001e16 <syscall+0x42>
    80001dfc:	00369713          	slli	a4,a3,0x3
    80001e00:	00005797          	auipc	a5,0x5
    80001e04:	66078793          	addi	a5,a5,1632 # 80007460 <syscalls>
    80001e08:	97ba                	add	a5,a5,a4
    80001e0a:	639c                	ld	a5,0(a5)
    80001e0c:	c789                	beqz	a5,80001e16 <syscall+0x42>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80001e0e:	9782                	jalr	a5
    80001e10:	06a93823          	sd	a0,112(s2)
    80001e14:	a829                	j	80001e2e <syscall+0x5a>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80001e16:	15848613          	addi	a2,s1,344
    80001e1a:	588c                	lw	a1,48(s1)
    80001e1c:	00005517          	auipc	a0,0x5
    80001e20:	60c50513          	addi	a0,a0,1548 # 80007428 <states.0+0x158>
    80001e24:	44e030ef          	jal	ra,80005272 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80001e28:	6cbc                	ld	a5,88(s1)
    80001e2a:	577d                	li	a4,-1
    80001e2c:	fbb8                	sd	a4,112(a5)
  }
}
    80001e2e:	60e2                	ld	ra,24(sp)
    80001e30:	6442                	ld	s0,16(sp)
    80001e32:	64a2                	ld	s1,8(sp)
    80001e34:	6902                	ld	s2,0(sp)
    80001e36:	6105                	addi	sp,sp,32
    80001e38:	8082                	ret

0000000080001e3a <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80001e3a:	1101                	addi	sp,sp,-32
    80001e3c:	ec06                	sd	ra,24(sp)
    80001e3e:	e822                	sd	s0,16(sp)
    80001e40:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80001e42:	fec40593          	addi	a1,s0,-20
    80001e46:	4501                	li	a0,0
    80001e48:	f25ff0ef          	jal	ra,80001d6c <argint>
  exit(n);
    80001e4c:	fec42503          	lw	a0,-20(s0)
    80001e50:	f46ff0ef          	jal	ra,80001596 <exit>
  return 0;  // not reached
}
    80001e54:	4501                	li	a0,0
    80001e56:	60e2                	ld	ra,24(sp)
    80001e58:	6442                	ld	s0,16(sp)
    80001e5a:	6105                	addi	sp,sp,32
    80001e5c:	8082                	ret

0000000080001e5e <sys_getpid>:

uint64
sys_getpid(void)
{
    80001e5e:	1141                	addi	sp,sp,-16
    80001e60:	e406                	sd	ra,8(sp)
    80001e62:	e022                	sd	s0,0(sp)
    80001e64:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80001e66:	fb9fe0ef          	jal	ra,80000e1e <myproc>
}
    80001e6a:	5908                	lw	a0,48(a0)
    80001e6c:	60a2                	ld	ra,8(sp)
    80001e6e:	6402                	ld	s0,0(sp)
    80001e70:	0141                	addi	sp,sp,16
    80001e72:	8082                	ret

0000000080001e74 <sys_fork>:

uint64
sys_fork(void)
{
    80001e74:	1141                	addi	sp,sp,-16
    80001e76:	e406                	sd	ra,8(sp)
    80001e78:	e022                	sd	s0,0(sp)
    80001e7a:	0800                	addi	s0,sp,16
  return fork();
    80001e7c:	b68ff0ef          	jal	ra,800011e4 <fork>
}
    80001e80:	60a2                	ld	ra,8(sp)
    80001e82:	6402                	ld	s0,0(sp)
    80001e84:	0141                	addi	sp,sp,16
    80001e86:	8082                	ret

0000000080001e88 <sys_wait>:

uint64
sys_wait(void)
{
    80001e88:	1101                	addi	sp,sp,-32
    80001e8a:	ec06                	sd	ra,24(sp)
    80001e8c:	e822                	sd	s0,16(sp)
    80001e8e:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80001e90:	fe840593          	addi	a1,s0,-24
    80001e94:	4501                	li	a0,0
    80001e96:	ef3ff0ef          	jal	ra,80001d88 <argaddr>
  return wait(p);
    80001e9a:	fe843503          	ld	a0,-24(s0)
    80001e9e:	84fff0ef          	jal	ra,800016ec <wait>
}
    80001ea2:	60e2                	ld	ra,24(sp)
    80001ea4:	6442                	ld	s0,16(sp)
    80001ea6:	6105                	addi	sp,sp,32
    80001ea8:	8082                	ret

0000000080001eaa <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80001eaa:	7179                	addi	sp,sp,-48
    80001eac:	f406                	sd	ra,40(sp)
    80001eae:	f022                	sd	s0,32(sp)
    80001eb0:	ec26                	sd	s1,24(sp)
    80001eb2:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80001eb4:	fdc40593          	addi	a1,s0,-36
    80001eb8:	4501                	li	a0,0
    80001eba:	eb3ff0ef          	jal	ra,80001d6c <argint>
  addr = myproc()->sz;
    80001ebe:	f61fe0ef          	jal	ra,80000e1e <myproc>
    80001ec2:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80001ec4:	fdc42503          	lw	a0,-36(s0)
    80001ec8:	accff0ef          	jal	ra,80001194 <growproc>
    80001ecc:	00054863          	bltz	a0,80001edc <sys_sbrk+0x32>
    return -1;
  return addr;
}
    80001ed0:	8526                	mv	a0,s1
    80001ed2:	70a2                	ld	ra,40(sp)
    80001ed4:	7402                	ld	s0,32(sp)
    80001ed6:	64e2                	ld	s1,24(sp)
    80001ed8:	6145                	addi	sp,sp,48
    80001eda:	8082                	ret
    return -1;
    80001edc:	54fd                	li	s1,-1
    80001ede:	bfcd                	j	80001ed0 <sys_sbrk+0x26>

0000000080001ee0 <sys_sleep>:

uint64
sys_sleep(void)
{
    80001ee0:	7139                	addi	sp,sp,-64
    80001ee2:	fc06                	sd	ra,56(sp)
    80001ee4:	f822                	sd	s0,48(sp)
    80001ee6:	f426                	sd	s1,40(sp)
    80001ee8:	f04a                	sd	s2,32(sp)
    80001eea:	ec4e                	sd	s3,24(sp)
    80001eec:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;


  argint(0, &n);
    80001eee:	fcc40593          	addi	a1,s0,-52
    80001ef2:	4501                	li	a0,0
    80001ef4:	e79ff0ef          	jal	ra,80001d6c <argint>
  if(n < 0)
    80001ef8:	fcc42783          	lw	a5,-52(s0)
    80001efc:	0607c563          	bltz	a5,80001f66 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80001f00:	0000c517          	auipc	a0,0xc
    80001f04:	b0050513          	addi	a0,a0,-1280 # 8000da00 <tickslock>
    80001f08:	133030ef          	jal	ra,8000583a <acquire>
  ticks0 = ticks;
    80001f0c:	00006917          	auipc	s2,0x6
    80001f10:	a8c92903          	lw	s2,-1396(s2) # 80007998 <ticks>
  while(ticks - ticks0 < n){
    80001f14:	fcc42783          	lw	a5,-52(s0)
    80001f18:	cb8d                	beqz	a5,80001f4a <sys_sleep+0x6a>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80001f1a:	0000c997          	auipc	s3,0xc
    80001f1e:	ae698993          	addi	s3,s3,-1306 # 8000da00 <tickslock>
    80001f22:	00006497          	auipc	s1,0x6
    80001f26:	a7648493          	addi	s1,s1,-1418 # 80007998 <ticks>
    if(killed(myproc())){
    80001f2a:	ef5fe0ef          	jal	ra,80000e1e <myproc>
    80001f2e:	f94ff0ef          	jal	ra,800016c2 <killed>
    80001f32:	ed0d                	bnez	a0,80001f6c <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80001f34:	85ce                	mv	a1,s3
    80001f36:	8526                	mv	a0,s1
    80001f38:	d52ff0ef          	jal	ra,8000148a <sleep>
  while(ticks - ticks0 < n){
    80001f3c:	409c                	lw	a5,0(s1)
    80001f3e:	412787bb          	subw	a5,a5,s2
    80001f42:	fcc42703          	lw	a4,-52(s0)
    80001f46:	fee7e2e3          	bltu	a5,a4,80001f2a <sys_sleep+0x4a>
  }
  release(&tickslock);
    80001f4a:	0000c517          	auipc	a0,0xc
    80001f4e:	ab650513          	addi	a0,a0,-1354 # 8000da00 <tickslock>
    80001f52:	181030ef          	jal	ra,800058d2 <release>
  return 0;
    80001f56:	4501                	li	a0,0
}
    80001f58:	70e2                	ld	ra,56(sp)
    80001f5a:	7442                	ld	s0,48(sp)
    80001f5c:	74a2                	ld	s1,40(sp)
    80001f5e:	7902                	ld	s2,32(sp)
    80001f60:	69e2                	ld	s3,24(sp)
    80001f62:	6121                	addi	sp,sp,64
    80001f64:	8082                	ret
    n = 0;
    80001f66:	fc042623          	sw	zero,-52(s0)
    80001f6a:	bf59                	j	80001f00 <sys_sleep+0x20>
      release(&tickslock);
    80001f6c:	0000c517          	auipc	a0,0xc
    80001f70:	a9450513          	addi	a0,a0,-1388 # 8000da00 <tickslock>
    80001f74:	15f030ef          	jal	ra,800058d2 <release>
      return -1;
    80001f78:	557d                	li	a0,-1
    80001f7a:	bff9                	j	80001f58 <sys_sleep+0x78>

0000000080001f7c <sys_pgpte>:


#ifdef LAB_PGTBL
int
sys_pgpte(void)
{
    80001f7c:	7179                	addi	sp,sp,-48
    80001f7e:	f406                	sd	ra,40(sp)
    80001f80:	f022                	sd	s0,32(sp)
    80001f82:	ec26                	sd	s1,24(sp)
    80001f84:	1800                	addi	s0,sp,48
  uint64 va;
  struct proc *p;  

  p = myproc();
    80001f86:	e99fe0ef          	jal	ra,80000e1e <myproc>
    80001f8a:	84aa                	mv	s1,a0
  argaddr(0, &va);
    80001f8c:	fd840593          	addi	a1,s0,-40
    80001f90:	4501                	li	a0,0
    80001f92:	df7ff0ef          	jal	ra,80001d88 <argaddr>
  pte_t *pte = pgpte(p->pagetable, va);
    80001f96:	fd843583          	ld	a1,-40(s0)
    80001f9a:	68a8                	ld	a0,80(s1)
    80001f9c:	d13fe0ef          	jal	ra,80000cae <pgpte>
    80001fa0:	87aa                	mv	a5,a0
  if(pte != 0) {
      return (uint64) *pte;
  }
  return 0;
    80001fa2:	4501                	li	a0,0
  if(pte != 0) {
    80001fa4:	c391                	beqz	a5,80001fa8 <sys_pgpte+0x2c>
      return (uint64) *pte;
    80001fa6:	4388                	lw	a0,0(a5)
}
    80001fa8:	70a2                	ld	ra,40(sp)
    80001faa:	7402                	ld	s0,32(sp)
    80001fac:	64e2                	ld	s1,24(sp)
    80001fae:	6145                	addi	sp,sp,48
    80001fb0:	8082                	ret

0000000080001fb2 <sys_kpgtbl>:
#endif

#ifdef LAB_PGTBL
int
sys_kpgtbl(void)
{
    80001fb2:	1141                	addi	sp,sp,-16
    80001fb4:	e406                	sd	ra,8(sp)
    80001fb6:	e022                	sd	s0,0(sp)
    80001fb8:	0800                	addi	s0,sp,16
  struct proc *p;  

  p = myproc();
    80001fba:	e65fe0ef          	jal	ra,80000e1e <myproc>
  vmprint(p->pagetable);
    80001fbe:	6928                	ld	a0,80(a0)
    80001fc0:	cc3fe0ef          	jal	ra,80000c82 <vmprint>
  return 0;
}
    80001fc4:	4501                	li	a0,0
    80001fc6:	60a2                	ld	ra,8(sp)
    80001fc8:	6402                	ld	s0,0(sp)
    80001fca:	0141                	addi	sp,sp,16
    80001fcc:	8082                	ret

0000000080001fce <sys_pgaccess>:
// Implementing here
int
sys_pgaccess(void)
{
    80001fce:	711d                	addi	sp,sp,-96
    80001fd0:	ec86                	sd	ra,88(sp)
    80001fd2:	e8a2                	sd	s0,80(sp)
    80001fd4:	e4a6                	sd	s1,72(sp)
    80001fd6:	e0ca                	sd	s2,64(sp)
    80001fd8:	fc4e                	sd	s3,56(sp)
    80001fda:	f852                	sd	s4,48(sp)
    80001fdc:	f456                	sd	s5,40(sp)
    80001fde:	1080                	addi	s0,sp,96
  uint64 base;
  int len;
  uint64 mask;

  argaddr(0, &base);
    80001fe0:	fb840593          	addi	a1,s0,-72
    80001fe4:	4501                	li	a0,0
    80001fe6:	da3ff0ef          	jal	ra,80001d88 <argaddr>
  argint(1, &len);
    80001fea:	fb440593          	addi	a1,s0,-76
    80001fee:	4505                	li	a0,1
    80001ff0:	d7dff0ef          	jal	ra,80001d6c <argint>
  argaddr(2, &mask);
    80001ff4:	fa840593          	addi	a1,s0,-88
    80001ff8:	4509                	li	a0,2
    80001ffa:	d8fff0ef          	jal	ra,80001d88 <argaddr>

  // Limiting number of pages
  if(len < 0 || len > 32)
    80001ffe:	fb442703          	lw	a4,-76(s0)
    80002002:	02000793          	li	a5,32
    80002006:	08e7ec63          	bltu	a5,a4,8000209e <sys_pgaccess+0xd0>
    return -1;

  struct proc *p = myproc();
    8000200a:	e15fe0ef          	jal	ra,80000e1e <myproc>
    8000200e:	892a                	mv	s2,a0
  uint64 bitmask = 0;
    80002010:	fa043023          	sd	zero,-96(s0)

  for(int i = 0; i < len; i++){
    80002014:	fb442783          	lw	a5,-76(s0)
    80002018:	04f05f63          	blez	a5,80002076 <sys_pgaccess+0xa8>
    8000201c:	4481                	li	s1,0
    uint64 va = base + i * PGSIZE;
    pte_t *pte = walk(p->pagetable, va, 0);
    if(pte && (*pte & PTE_V) && (*pte & PTE_U)){
    8000201e:	49c5                	li	s3,17
      if(*pte & PTE_A){
        bitmask |= (1 << i);
    80002020:	4a05                	li	s4,1
    80002022:	a801                	j	80002032 <sys_pgaccess+0x64>
  for(int i = 0; i < len; i++){
    80002024:	0485                	addi	s1,s1,1
    80002026:	fb442703          	lw	a4,-76(s0)
    8000202a:	0004879b          	sext.w	a5,s1
    8000202e:	04e7d463          	bge	a5,a4,80002076 <sys_pgaccess+0xa8>
    80002032:	00048a9b          	sext.w	s5,s1
    uint64 va = base + i * PGSIZE;
    80002036:	00c49793          	slli	a5,s1,0xc
    pte_t *pte = walk(p->pagetable, va, 0);
    8000203a:	4601                	li	a2,0
    8000203c:	fb843583          	ld	a1,-72(s0)
    80002040:	95be                	add	a1,a1,a5
    80002042:	05093503          	ld	a0,80(s2)
    80002046:	b82fe0ef          	jal	ra,800003c8 <walk>
    if(pte && (*pte & PTE_V) && (*pte & PTE_U)){
    8000204a:	dd69                	beqz	a0,80002024 <sys_pgaccess+0x56>
    8000204c:	611c                	ld	a5,0(a0)
    8000204e:	0117f713          	andi	a4,a5,17
    80002052:	fd3719e3          	bne	a4,s3,80002024 <sys_pgaccess+0x56>
      if(*pte & PTE_A){
    80002056:	0407f793          	andi	a5,a5,64
    8000205a:	d7e9                	beqz	a5,80002024 <sys_pgaccess+0x56>
        bitmask |= (1 << i);
    8000205c:	015a1abb          	sllw	s5,s4,s5
    80002060:	fa043783          	ld	a5,-96(s0)
    80002064:	0157eab3          	or	s5,a5,s5
    80002068:	fb543023          	sd	s5,-96(s0)
        *pte &= ~PTE_A; 
    8000206c:	611c                	ld	a5,0(a0)
    8000206e:	fbf7f793          	andi	a5,a5,-65
    80002072:	e11c                	sd	a5,0(a0)
    80002074:	bf45                	j	80002024 <sys_pgaccess+0x56>
      }
    }
  }

  if(copyout(p->pagetable, mask, (char *)&bitmask, sizeof(bitmask)) < 0)
    80002076:	46a1                	li	a3,8
    80002078:	fa040613          	addi	a2,s0,-96
    8000207c:	fa843583          	ld	a1,-88(s0)
    80002080:	05093503          	ld	a0,80(s2)
    80002084:	953fe0ef          	jal	ra,800009d6 <copyout>
    80002088:	41f5551b          	sraiw	a0,a0,0x1f
    return -1;

  return 0;
}
    8000208c:	60e6                	ld	ra,88(sp)
    8000208e:	6446                	ld	s0,80(sp)
    80002090:	64a6                	ld	s1,72(sp)
    80002092:	6906                	ld	s2,64(sp)
    80002094:	79e2                	ld	s3,56(sp)
    80002096:	7a42                	ld	s4,48(sp)
    80002098:	7aa2                	ld	s5,40(sp)
    8000209a:	6125                	addi	sp,sp,96
    8000209c:	8082                	ret
    return -1;
    8000209e:	557d                	li	a0,-1
    800020a0:	b7f5                	j	8000208c <sys_pgaccess+0xbe>

00000000800020a2 <sys_kill>:
#endif


uint64
sys_kill(void)
{
    800020a2:	1101                	addi	sp,sp,-32
    800020a4:	ec06                	sd	ra,24(sp)
    800020a6:	e822                	sd	s0,16(sp)
    800020a8:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    800020aa:	fec40593          	addi	a1,s0,-20
    800020ae:	4501                	li	a0,0
    800020b0:	cbdff0ef          	jal	ra,80001d6c <argint>
  return kill(pid);
    800020b4:	fec42503          	lw	a0,-20(s0)
    800020b8:	d80ff0ef          	jal	ra,80001638 <kill>
}
    800020bc:	60e2                	ld	ra,24(sp)
    800020be:	6442                	ld	s0,16(sp)
    800020c0:	6105                	addi	sp,sp,32
    800020c2:	8082                	ret

00000000800020c4 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    800020c4:	1101                	addi	sp,sp,-32
    800020c6:	ec06                	sd	ra,24(sp)
    800020c8:	e822                	sd	s0,16(sp)
    800020ca:	e426                	sd	s1,8(sp)
    800020cc:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    800020ce:	0000c517          	auipc	a0,0xc
    800020d2:	93250513          	addi	a0,a0,-1742 # 8000da00 <tickslock>
    800020d6:	764030ef          	jal	ra,8000583a <acquire>
  xticks = ticks;
    800020da:	00006497          	auipc	s1,0x6
    800020de:	8be4a483          	lw	s1,-1858(s1) # 80007998 <ticks>
  release(&tickslock);
    800020e2:	0000c517          	auipc	a0,0xc
    800020e6:	91e50513          	addi	a0,a0,-1762 # 8000da00 <tickslock>
    800020ea:	7e8030ef          	jal	ra,800058d2 <release>
  return xticks;
}
    800020ee:	02049513          	slli	a0,s1,0x20
    800020f2:	9101                	srli	a0,a0,0x20
    800020f4:	60e2                	ld	ra,24(sp)
    800020f6:	6442                	ld	s0,16(sp)
    800020f8:	64a2                	ld	s1,8(sp)
    800020fa:	6105                	addi	sp,sp,32
    800020fc:	8082                	ret

00000000800020fe <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    800020fe:	7179                	addi	sp,sp,-48
    80002100:	f406                	sd	ra,40(sp)
    80002102:	f022                	sd	s0,32(sp)
    80002104:	ec26                	sd	s1,24(sp)
    80002106:	e84a                	sd	s2,16(sp)
    80002108:	e44e                	sd	s3,8(sp)
    8000210a:	e052                	sd	s4,0(sp)
    8000210c:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    8000210e:	00005597          	auipc	a1,0x5
    80002112:	47258593          	addi	a1,a1,1138 # 80007580 <syscalls+0x120>
    80002116:	0000c517          	auipc	a0,0xc
    8000211a:	90250513          	addi	a0,a0,-1790 # 8000da18 <bcache>
    8000211e:	69c030ef          	jal	ra,800057ba <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002122:	00014797          	auipc	a5,0x14
    80002126:	8f678793          	addi	a5,a5,-1802 # 80015a18 <bcache+0x8000>
    8000212a:	00014717          	auipc	a4,0x14
    8000212e:	b5670713          	addi	a4,a4,-1194 # 80015c80 <bcache+0x8268>
    80002132:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002136:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000213a:	0000c497          	auipc	s1,0xc
    8000213e:	8f648493          	addi	s1,s1,-1802 # 8000da30 <bcache+0x18>
    b->next = bcache.head.next;
    80002142:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002144:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002146:	00005a17          	auipc	s4,0x5
    8000214a:	442a0a13          	addi	s4,s4,1090 # 80007588 <syscalls+0x128>
    b->next = bcache.head.next;
    8000214e:	2b893783          	ld	a5,696(s2)
    80002152:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002154:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002158:	85d2                	mv	a1,s4
    8000215a:	01048513          	addi	a0,s1,16
    8000215e:	22a010ef          	jal	ra,80003388 <initsleeplock>
    bcache.head.next->prev = b;
    80002162:	2b893783          	ld	a5,696(s2)
    80002166:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002168:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000216c:	45848493          	addi	s1,s1,1112
    80002170:	fd349fe3          	bne	s1,s3,8000214e <binit+0x50>
  }
}
    80002174:	70a2                	ld	ra,40(sp)
    80002176:	7402                	ld	s0,32(sp)
    80002178:	64e2                	ld	s1,24(sp)
    8000217a:	6942                	ld	s2,16(sp)
    8000217c:	69a2                	ld	s3,8(sp)
    8000217e:	6a02                	ld	s4,0(sp)
    80002180:	6145                	addi	sp,sp,48
    80002182:	8082                	ret

0000000080002184 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002184:	7179                	addi	sp,sp,-48
    80002186:	f406                	sd	ra,40(sp)
    80002188:	f022                	sd	s0,32(sp)
    8000218a:	ec26                	sd	s1,24(sp)
    8000218c:	e84a                	sd	s2,16(sp)
    8000218e:	e44e                	sd	s3,8(sp)
    80002190:	1800                	addi	s0,sp,48
    80002192:	892a                	mv	s2,a0
    80002194:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002196:	0000c517          	auipc	a0,0xc
    8000219a:	88250513          	addi	a0,a0,-1918 # 8000da18 <bcache>
    8000219e:	69c030ef          	jal	ra,8000583a <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    800021a2:	00014497          	auipc	s1,0x14
    800021a6:	b2e4b483          	ld	s1,-1234(s1) # 80015cd0 <bcache+0x82b8>
    800021aa:	00014797          	auipc	a5,0x14
    800021ae:	ad678793          	addi	a5,a5,-1322 # 80015c80 <bcache+0x8268>
    800021b2:	02f48b63          	beq	s1,a5,800021e8 <bread+0x64>
    800021b6:	873e                	mv	a4,a5
    800021b8:	a021                	j	800021c0 <bread+0x3c>
    800021ba:	68a4                	ld	s1,80(s1)
    800021bc:	02e48663          	beq	s1,a4,800021e8 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    800021c0:	449c                	lw	a5,8(s1)
    800021c2:	ff279ce3          	bne	a5,s2,800021ba <bread+0x36>
    800021c6:	44dc                	lw	a5,12(s1)
    800021c8:	ff3799e3          	bne	a5,s3,800021ba <bread+0x36>
      b->refcnt++;
    800021cc:	40bc                	lw	a5,64(s1)
    800021ce:	2785                	addiw	a5,a5,1
    800021d0:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800021d2:	0000c517          	auipc	a0,0xc
    800021d6:	84650513          	addi	a0,a0,-1978 # 8000da18 <bcache>
    800021da:	6f8030ef          	jal	ra,800058d2 <release>
      acquiresleep(&b->lock);
    800021de:	01048513          	addi	a0,s1,16
    800021e2:	1dc010ef          	jal	ra,800033be <acquiresleep>
      return b;
    800021e6:	a889                	j	80002238 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800021e8:	00014497          	auipc	s1,0x14
    800021ec:	ae04b483          	ld	s1,-1312(s1) # 80015cc8 <bcache+0x82b0>
    800021f0:	00014797          	auipc	a5,0x14
    800021f4:	a9078793          	addi	a5,a5,-1392 # 80015c80 <bcache+0x8268>
    800021f8:	00f48863          	beq	s1,a5,80002208 <bread+0x84>
    800021fc:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    800021fe:	40bc                	lw	a5,64(s1)
    80002200:	cb91                	beqz	a5,80002214 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002202:	64a4                	ld	s1,72(s1)
    80002204:	fee49de3          	bne	s1,a4,800021fe <bread+0x7a>
  panic("bget: no buffers");
    80002208:	00005517          	auipc	a0,0x5
    8000220c:	38850513          	addi	a0,a0,904 # 80007590 <syscalls+0x130>
    80002210:	316030ef          	jal	ra,80005526 <panic>
      b->dev = dev;
    80002214:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002218:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    8000221c:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002220:	4785                	li	a5,1
    80002222:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002224:	0000b517          	auipc	a0,0xb
    80002228:	7f450513          	addi	a0,a0,2036 # 8000da18 <bcache>
    8000222c:	6a6030ef          	jal	ra,800058d2 <release>
      acquiresleep(&b->lock);
    80002230:	01048513          	addi	a0,s1,16
    80002234:	18a010ef          	jal	ra,800033be <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002238:	409c                	lw	a5,0(s1)
    8000223a:	cb89                	beqz	a5,8000224c <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000223c:	8526                	mv	a0,s1
    8000223e:	70a2                	ld	ra,40(sp)
    80002240:	7402                	ld	s0,32(sp)
    80002242:	64e2                	ld	s1,24(sp)
    80002244:	6942                	ld	s2,16(sp)
    80002246:	69a2                	ld	s3,8(sp)
    80002248:	6145                	addi	sp,sp,48
    8000224a:	8082                	ret
    virtio_disk_rw(b, 0);
    8000224c:	4581                	li	a1,0
    8000224e:	8526                	mv	a0,s1
    80002250:	0dd020ef          	jal	ra,80004b2c <virtio_disk_rw>
    b->valid = 1;
    80002254:	4785                	li	a5,1
    80002256:	c09c                	sw	a5,0(s1)
  return b;
    80002258:	b7d5                	j	8000223c <bread+0xb8>

000000008000225a <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000225a:	1101                	addi	sp,sp,-32
    8000225c:	ec06                	sd	ra,24(sp)
    8000225e:	e822                	sd	s0,16(sp)
    80002260:	e426                	sd	s1,8(sp)
    80002262:	1000                	addi	s0,sp,32
    80002264:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002266:	0541                	addi	a0,a0,16
    80002268:	1d4010ef          	jal	ra,8000343c <holdingsleep>
    8000226c:	c911                	beqz	a0,80002280 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    8000226e:	4585                	li	a1,1
    80002270:	8526                	mv	a0,s1
    80002272:	0bb020ef          	jal	ra,80004b2c <virtio_disk_rw>
}
    80002276:	60e2                	ld	ra,24(sp)
    80002278:	6442                	ld	s0,16(sp)
    8000227a:	64a2                	ld	s1,8(sp)
    8000227c:	6105                	addi	sp,sp,32
    8000227e:	8082                	ret
    panic("bwrite");
    80002280:	00005517          	auipc	a0,0x5
    80002284:	32850513          	addi	a0,a0,808 # 800075a8 <syscalls+0x148>
    80002288:	29e030ef          	jal	ra,80005526 <panic>

000000008000228c <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000228c:	1101                	addi	sp,sp,-32
    8000228e:	ec06                	sd	ra,24(sp)
    80002290:	e822                	sd	s0,16(sp)
    80002292:	e426                	sd	s1,8(sp)
    80002294:	e04a                	sd	s2,0(sp)
    80002296:	1000                	addi	s0,sp,32
    80002298:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000229a:	01050913          	addi	s2,a0,16
    8000229e:	854a                	mv	a0,s2
    800022a0:	19c010ef          	jal	ra,8000343c <holdingsleep>
    800022a4:	c13d                	beqz	a0,8000230a <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
    800022a6:	854a                	mv	a0,s2
    800022a8:	15c010ef          	jal	ra,80003404 <releasesleep>

  acquire(&bcache.lock);
    800022ac:	0000b517          	auipc	a0,0xb
    800022b0:	76c50513          	addi	a0,a0,1900 # 8000da18 <bcache>
    800022b4:	586030ef          	jal	ra,8000583a <acquire>
  b->refcnt--;
    800022b8:	40bc                	lw	a5,64(s1)
    800022ba:	37fd                	addiw	a5,a5,-1
    800022bc:	0007871b          	sext.w	a4,a5
    800022c0:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800022c2:	eb05                	bnez	a4,800022f2 <brelse+0x66>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800022c4:	68bc                	ld	a5,80(s1)
    800022c6:	64b8                	ld	a4,72(s1)
    800022c8:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    800022ca:	64bc                	ld	a5,72(s1)
    800022cc:	68b8                	ld	a4,80(s1)
    800022ce:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800022d0:	00013797          	auipc	a5,0x13
    800022d4:	74878793          	addi	a5,a5,1864 # 80015a18 <bcache+0x8000>
    800022d8:	2b87b703          	ld	a4,696(a5)
    800022dc:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800022de:	00014717          	auipc	a4,0x14
    800022e2:	9a270713          	addi	a4,a4,-1630 # 80015c80 <bcache+0x8268>
    800022e6:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800022e8:	2b87b703          	ld	a4,696(a5)
    800022ec:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800022ee:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800022f2:	0000b517          	auipc	a0,0xb
    800022f6:	72650513          	addi	a0,a0,1830 # 8000da18 <bcache>
    800022fa:	5d8030ef          	jal	ra,800058d2 <release>
}
    800022fe:	60e2                	ld	ra,24(sp)
    80002300:	6442                	ld	s0,16(sp)
    80002302:	64a2                	ld	s1,8(sp)
    80002304:	6902                	ld	s2,0(sp)
    80002306:	6105                	addi	sp,sp,32
    80002308:	8082                	ret
    panic("brelse");
    8000230a:	00005517          	auipc	a0,0x5
    8000230e:	2a650513          	addi	a0,a0,678 # 800075b0 <syscalls+0x150>
    80002312:	214030ef          	jal	ra,80005526 <panic>

0000000080002316 <bpin>:

void
bpin(struct buf *b) {
    80002316:	1101                	addi	sp,sp,-32
    80002318:	ec06                	sd	ra,24(sp)
    8000231a:	e822                	sd	s0,16(sp)
    8000231c:	e426                	sd	s1,8(sp)
    8000231e:	1000                	addi	s0,sp,32
    80002320:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002322:	0000b517          	auipc	a0,0xb
    80002326:	6f650513          	addi	a0,a0,1782 # 8000da18 <bcache>
    8000232a:	510030ef          	jal	ra,8000583a <acquire>
  b->refcnt++;
    8000232e:	40bc                	lw	a5,64(s1)
    80002330:	2785                	addiw	a5,a5,1
    80002332:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002334:	0000b517          	auipc	a0,0xb
    80002338:	6e450513          	addi	a0,a0,1764 # 8000da18 <bcache>
    8000233c:	596030ef          	jal	ra,800058d2 <release>
}
    80002340:	60e2                	ld	ra,24(sp)
    80002342:	6442                	ld	s0,16(sp)
    80002344:	64a2                	ld	s1,8(sp)
    80002346:	6105                	addi	sp,sp,32
    80002348:	8082                	ret

000000008000234a <bunpin>:

void
bunpin(struct buf *b) {
    8000234a:	1101                	addi	sp,sp,-32
    8000234c:	ec06                	sd	ra,24(sp)
    8000234e:	e822                	sd	s0,16(sp)
    80002350:	e426                	sd	s1,8(sp)
    80002352:	1000                	addi	s0,sp,32
    80002354:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002356:	0000b517          	auipc	a0,0xb
    8000235a:	6c250513          	addi	a0,a0,1730 # 8000da18 <bcache>
    8000235e:	4dc030ef          	jal	ra,8000583a <acquire>
  b->refcnt--;
    80002362:	40bc                	lw	a5,64(s1)
    80002364:	37fd                	addiw	a5,a5,-1
    80002366:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002368:	0000b517          	auipc	a0,0xb
    8000236c:	6b050513          	addi	a0,a0,1712 # 8000da18 <bcache>
    80002370:	562030ef          	jal	ra,800058d2 <release>
}
    80002374:	60e2                	ld	ra,24(sp)
    80002376:	6442                	ld	s0,16(sp)
    80002378:	64a2                	ld	s1,8(sp)
    8000237a:	6105                	addi	sp,sp,32
    8000237c:	8082                	ret

000000008000237e <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    8000237e:	1101                	addi	sp,sp,-32
    80002380:	ec06                	sd	ra,24(sp)
    80002382:	e822                	sd	s0,16(sp)
    80002384:	e426                	sd	s1,8(sp)
    80002386:	e04a                	sd	s2,0(sp)
    80002388:	1000                	addi	s0,sp,32
    8000238a:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000238c:	00d5d59b          	srliw	a1,a1,0xd
    80002390:	00014797          	auipc	a5,0x14
    80002394:	d647a783          	lw	a5,-668(a5) # 800160f4 <sb+0x1c>
    80002398:	9dbd                	addw	a1,a1,a5
    8000239a:	debff0ef          	jal	ra,80002184 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    8000239e:	0074f713          	andi	a4,s1,7
    800023a2:	4785                	li	a5,1
    800023a4:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    800023a8:	14ce                	slli	s1,s1,0x33
    800023aa:	90d9                	srli	s1,s1,0x36
    800023ac:	00950733          	add	a4,a0,s1
    800023b0:	05874703          	lbu	a4,88(a4)
    800023b4:	00e7f6b3          	and	a3,a5,a4
    800023b8:	c29d                	beqz	a3,800023de <bfree+0x60>
    800023ba:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800023bc:	94aa                	add	s1,s1,a0
    800023be:	fff7c793          	not	a5,a5
    800023c2:	8ff9                	and	a5,a5,a4
    800023c4:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    800023c8:	6ef000ef          	jal	ra,800032b6 <log_write>
  brelse(bp);
    800023cc:	854a                	mv	a0,s2
    800023ce:	ebfff0ef          	jal	ra,8000228c <brelse>
}
    800023d2:	60e2                	ld	ra,24(sp)
    800023d4:	6442                	ld	s0,16(sp)
    800023d6:	64a2                	ld	s1,8(sp)
    800023d8:	6902                	ld	s2,0(sp)
    800023da:	6105                	addi	sp,sp,32
    800023dc:	8082                	ret
    panic("freeing free block");
    800023de:	00005517          	auipc	a0,0x5
    800023e2:	1da50513          	addi	a0,a0,474 # 800075b8 <syscalls+0x158>
    800023e6:	140030ef          	jal	ra,80005526 <panic>

00000000800023ea <balloc>:
{
    800023ea:	711d                	addi	sp,sp,-96
    800023ec:	ec86                	sd	ra,88(sp)
    800023ee:	e8a2                	sd	s0,80(sp)
    800023f0:	e4a6                	sd	s1,72(sp)
    800023f2:	e0ca                	sd	s2,64(sp)
    800023f4:	fc4e                	sd	s3,56(sp)
    800023f6:	f852                	sd	s4,48(sp)
    800023f8:	f456                	sd	s5,40(sp)
    800023fa:	f05a                	sd	s6,32(sp)
    800023fc:	ec5e                	sd	s7,24(sp)
    800023fe:	e862                	sd	s8,16(sp)
    80002400:	e466                	sd	s9,8(sp)
    80002402:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80002404:	00014797          	auipc	a5,0x14
    80002408:	cd87a783          	lw	a5,-808(a5) # 800160dc <sb+0x4>
    8000240c:	0e078163          	beqz	a5,800024ee <balloc+0x104>
    80002410:	8baa                	mv	s7,a0
    80002412:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002414:	00014b17          	auipc	s6,0x14
    80002418:	cc4b0b13          	addi	s6,s6,-828 # 800160d8 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000241c:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    8000241e:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002420:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002422:	6c89                	lui	s9,0x2
    80002424:	a0b5                	j	80002490 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002426:	974a                	add	a4,a4,s2
    80002428:	8fd5                	or	a5,a5,a3
    8000242a:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    8000242e:	854a                	mv	a0,s2
    80002430:	687000ef          	jal	ra,800032b6 <log_write>
        brelse(bp);
    80002434:	854a                	mv	a0,s2
    80002436:	e57ff0ef          	jal	ra,8000228c <brelse>
  bp = bread(dev, bno);
    8000243a:	85a6                	mv	a1,s1
    8000243c:	855e                	mv	a0,s7
    8000243e:	d47ff0ef          	jal	ra,80002184 <bread>
    80002442:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002444:	40000613          	li	a2,1024
    80002448:	4581                	li	a1,0
    8000244a:	05850513          	addi	a0,a0,88
    8000244e:	cfffd0ef          	jal	ra,8000014c <memset>
  log_write(bp);
    80002452:	854a                	mv	a0,s2
    80002454:	663000ef          	jal	ra,800032b6 <log_write>
  brelse(bp);
    80002458:	854a                	mv	a0,s2
    8000245a:	e33ff0ef          	jal	ra,8000228c <brelse>
}
    8000245e:	8526                	mv	a0,s1
    80002460:	60e6                	ld	ra,88(sp)
    80002462:	6446                	ld	s0,80(sp)
    80002464:	64a6                	ld	s1,72(sp)
    80002466:	6906                	ld	s2,64(sp)
    80002468:	79e2                	ld	s3,56(sp)
    8000246a:	7a42                	ld	s4,48(sp)
    8000246c:	7aa2                	ld	s5,40(sp)
    8000246e:	7b02                	ld	s6,32(sp)
    80002470:	6be2                	ld	s7,24(sp)
    80002472:	6c42                	ld	s8,16(sp)
    80002474:	6ca2                	ld	s9,8(sp)
    80002476:	6125                	addi	sp,sp,96
    80002478:	8082                	ret
    brelse(bp);
    8000247a:	854a                	mv	a0,s2
    8000247c:	e11ff0ef          	jal	ra,8000228c <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002480:	015c87bb          	addw	a5,s9,s5
    80002484:	00078a9b          	sext.w	s5,a5
    80002488:	004b2703          	lw	a4,4(s6)
    8000248c:	06eaf163          	bgeu	s5,a4,800024ee <balloc+0x104>
    bp = bread(dev, BBLOCK(b, sb));
    80002490:	41fad79b          	sraiw	a5,s5,0x1f
    80002494:	0137d79b          	srliw	a5,a5,0x13
    80002498:	015787bb          	addw	a5,a5,s5
    8000249c:	40d7d79b          	sraiw	a5,a5,0xd
    800024a0:	01cb2583          	lw	a1,28(s6)
    800024a4:	9dbd                	addw	a1,a1,a5
    800024a6:	855e                	mv	a0,s7
    800024a8:	cddff0ef          	jal	ra,80002184 <bread>
    800024ac:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800024ae:	004b2503          	lw	a0,4(s6)
    800024b2:	000a849b          	sext.w	s1,s5
    800024b6:	8662                	mv	a2,s8
    800024b8:	fca4f1e3          	bgeu	s1,a0,8000247a <balloc+0x90>
      m = 1 << (bi % 8);
    800024bc:	41f6579b          	sraiw	a5,a2,0x1f
    800024c0:	01d7d69b          	srliw	a3,a5,0x1d
    800024c4:	00c6873b          	addw	a4,a3,a2
    800024c8:	00777793          	andi	a5,a4,7
    800024cc:	9f95                	subw	a5,a5,a3
    800024ce:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800024d2:	4037571b          	sraiw	a4,a4,0x3
    800024d6:	00e906b3          	add	a3,s2,a4
    800024da:	0586c683          	lbu	a3,88(a3)
    800024de:	00d7f5b3          	and	a1,a5,a3
    800024e2:	d1b1                	beqz	a1,80002426 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800024e4:	2605                	addiw	a2,a2,1
    800024e6:	2485                	addiw	s1,s1,1
    800024e8:	fd4618e3          	bne	a2,s4,800024b8 <balloc+0xce>
    800024ec:	b779                	j	8000247a <balloc+0x90>
  printf("balloc: out of blocks\n");
    800024ee:	00005517          	auipc	a0,0x5
    800024f2:	0e250513          	addi	a0,a0,226 # 800075d0 <syscalls+0x170>
    800024f6:	57d020ef          	jal	ra,80005272 <printf>
  return 0;
    800024fa:	4481                	li	s1,0
    800024fc:	b78d                	j	8000245e <balloc+0x74>

00000000800024fe <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800024fe:	7179                	addi	sp,sp,-48
    80002500:	f406                	sd	ra,40(sp)
    80002502:	f022                	sd	s0,32(sp)
    80002504:	ec26                	sd	s1,24(sp)
    80002506:	e84a                	sd	s2,16(sp)
    80002508:	e44e                	sd	s3,8(sp)
    8000250a:	e052                	sd	s4,0(sp)
    8000250c:	1800                	addi	s0,sp,48
    8000250e:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002510:	47ad                	li	a5,11
    80002512:	02b7e663          	bltu	a5,a1,8000253e <bmap+0x40>
    if((addr = ip->addrs[bn]) == 0){
    80002516:	02059793          	slli	a5,a1,0x20
    8000251a:	01e7d593          	srli	a1,a5,0x1e
    8000251e:	00b504b3          	add	s1,a0,a1
    80002522:	0504a903          	lw	s2,80(s1)
    80002526:	06091663          	bnez	s2,80002592 <bmap+0x94>
      addr = balloc(ip->dev);
    8000252a:	4108                	lw	a0,0(a0)
    8000252c:	ebfff0ef          	jal	ra,800023ea <balloc>
    80002530:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002534:	04090f63          	beqz	s2,80002592 <bmap+0x94>
        return 0;
      ip->addrs[bn] = addr;
    80002538:	0524a823          	sw	s2,80(s1)
    8000253c:	a899                	j	80002592 <bmap+0x94>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000253e:	ff45849b          	addiw	s1,a1,-12
    80002542:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80002546:	0ff00793          	li	a5,255
    8000254a:	06e7eb63          	bltu	a5,a4,800025c0 <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000254e:	08052903          	lw	s2,128(a0)
    80002552:	00091b63          	bnez	s2,80002568 <bmap+0x6a>
      addr = balloc(ip->dev);
    80002556:	4108                	lw	a0,0(a0)
    80002558:	e93ff0ef          	jal	ra,800023ea <balloc>
    8000255c:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002560:	02090963          	beqz	s2,80002592 <bmap+0x94>
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002564:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80002568:	85ca                	mv	a1,s2
    8000256a:	0009a503          	lw	a0,0(s3)
    8000256e:	c17ff0ef          	jal	ra,80002184 <bread>
    80002572:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002574:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002578:	02049713          	slli	a4,s1,0x20
    8000257c:	01e75593          	srli	a1,a4,0x1e
    80002580:	00b784b3          	add	s1,a5,a1
    80002584:	0004a903          	lw	s2,0(s1)
    80002588:	00090e63          	beqz	s2,800025a4 <bmap+0xa6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000258c:	8552                	mv	a0,s4
    8000258e:	cffff0ef          	jal	ra,8000228c <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    80002592:	854a                	mv	a0,s2
    80002594:	70a2                	ld	ra,40(sp)
    80002596:	7402                	ld	s0,32(sp)
    80002598:	64e2                	ld	s1,24(sp)
    8000259a:	6942                	ld	s2,16(sp)
    8000259c:	69a2                	ld	s3,8(sp)
    8000259e:	6a02                	ld	s4,0(sp)
    800025a0:	6145                	addi	sp,sp,48
    800025a2:	8082                	ret
      addr = balloc(ip->dev);
    800025a4:	0009a503          	lw	a0,0(s3)
    800025a8:	e43ff0ef          	jal	ra,800023ea <balloc>
    800025ac:	0005091b          	sext.w	s2,a0
      if(addr){
    800025b0:	fc090ee3          	beqz	s2,8000258c <bmap+0x8e>
        a[bn] = addr;
    800025b4:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    800025b8:	8552                	mv	a0,s4
    800025ba:	4fd000ef          	jal	ra,800032b6 <log_write>
    800025be:	b7f9                	j	8000258c <bmap+0x8e>
  panic("bmap: out of range");
    800025c0:	00005517          	auipc	a0,0x5
    800025c4:	02850513          	addi	a0,a0,40 # 800075e8 <syscalls+0x188>
    800025c8:	75f020ef          	jal	ra,80005526 <panic>

00000000800025cc <iget>:
{
    800025cc:	7179                	addi	sp,sp,-48
    800025ce:	f406                	sd	ra,40(sp)
    800025d0:	f022                	sd	s0,32(sp)
    800025d2:	ec26                	sd	s1,24(sp)
    800025d4:	e84a                	sd	s2,16(sp)
    800025d6:	e44e                	sd	s3,8(sp)
    800025d8:	e052                	sd	s4,0(sp)
    800025da:	1800                	addi	s0,sp,48
    800025dc:	89aa                	mv	s3,a0
    800025de:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800025e0:	00014517          	auipc	a0,0x14
    800025e4:	b1850513          	addi	a0,a0,-1256 # 800160f8 <itable>
    800025e8:	252030ef          	jal	ra,8000583a <acquire>
  empty = 0;
    800025ec:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800025ee:	00014497          	auipc	s1,0x14
    800025f2:	b2248493          	addi	s1,s1,-1246 # 80016110 <itable+0x18>
    800025f6:	00015697          	auipc	a3,0x15
    800025fa:	5aa68693          	addi	a3,a3,1450 # 80017ba0 <log>
    800025fe:	a039                	j	8000260c <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002600:	02090963          	beqz	s2,80002632 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002604:	08848493          	addi	s1,s1,136
    80002608:	02d48863          	beq	s1,a3,80002638 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    8000260c:	449c                	lw	a5,8(s1)
    8000260e:	fef059e3          	blez	a5,80002600 <iget+0x34>
    80002612:	4098                	lw	a4,0(s1)
    80002614:	ff3716e3          	bne	a4,s3,80002600 <iget+0x34>
    80002618:	40d8                	lw	a4,4(s1)
    8000261a:	ff4713e3          	bne	a4,s4,80002600 <iget+0x34>
      ip->ref++;
    8000261e:	2785                	addiw	a5,a5,1
    80002620:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002622:	00014517          	auipc	a0,0x14
    80002626:	ad650513          	addi	a0,a0,-1322 # 800160f8 <itable>
    8000262a:	2a8030ef          	jal	ra,800058d2 <release>
      return ip;
    8000262e:	8926                	mv	s2,s1
    80002630:	a02d                	j	8000265a <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002632:	fbe9                	bnez	a5,80002604 <iget+0x38>
    80002634:	8926                	mv	s2,s1
    80002636:	b7f9                	j	80002604 <iget+0x38>
  if(empty == 0)
    80002638:	02090a63          	beqz	s2,8000266c <iget+0xa0>
  ip->dev = dev;
    8000263c:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002640:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002644:	4785                	li	a5,1
    80002646:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000264a:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000264e:	00014517          	auipc	a0,0x14
    80002652:	aaa50513          	addi	a0,a0,-1366 # 800160f8 <itable>
    80002656:	27c030ef          	jal	ra,800058d2 <release>
}
    8000265a:	854a                	mv	a0,s2
    8000265c:	70a2                	ld	ra,40(sp)
    8000265e:	7402                	ld	s0,32(sp)
    80002660:	64e2                	ld	s1,24(sp)
    80002662:	6942                	ld	s2,16(sp)
    80002664:	69a2                	ld	s3,8(sp)
    80002666:	6a02                	ld	s4,0(sp)
    80002668:	6145                	addi	sp,sp,48
    8000266a:	8082                	ret
    panic("iget: no inodes");
    8000266c:	00005517          	auipc	a0,0x5
    80002670:	f9450513          	addi	a0,a0,-108 # 80007600 <syscalls+0x1a0>
    80002674:	6b3020ef          	jal	ra,80005526 <panic>

0000000080002678 <fsinit>:
fsinit(int dev) {
    80002678:	7179                	addi	sp,sp,-48
    8000267a:	f406                	sd	ra,40(sp)
    8000267c:	f022                	sd	s0,32(sp)
    8000267e:	ec26                	sd	s1,24(sp)
    80002680:	e84a                	sd	s2,16(sp)
    80002682:	e44e                	sd	s3,8(sp)
    80002684:	1800                	addi	s0,sp,48
    80002686:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002688:	4585                	li	a1,1
    8000268a:	afbff0ef          	jal	ra,80002184 <bread>
    8000268e:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002690:	00014997          	auipc	s3,0x14
    80002694:	a4898993          	addi	s3,s3,-1464 # 800160d8 <sb>
    80002698:	02000613          	li	a2,32
    8000269c:	05850593          	addi	a1,a0,88
    800026a0:	854e                	mv	a0,s3
    800026a2:	b07fd0ef          	jal	ra,800001a8 <memmove>
  brelse(bp);
    800026a6:	8526                	mv	a0,s1
    800026a8:	be5ff0ef          	jal	ra,8000228c <brelse>
  if(sb.magic != FSMAGIC)
    800026ac:	0009a703          	lw	a4,0(s3)
    800026b0:	102037b7          	lui	a5,0x10203
    800026b4:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800026b8:	02f71063          	bne	a4,a5,800026d8 <fsinit+0x60>
  initlog(dev, &sb);
    800026bc:	00014597          	auipc	a1,0x14
    800026c0:	a1c58593          	addi	a1,a1,-1508 # 800160d8 <sb>
    800026c4:	854a                	mv	a0,s2
    800026c6:	1db000ef          	jal	ra,800030a0 <initlog>
}
    800026ca:	70a2                	ld	ra,40(sp)
    800026cc:	7402                	ld	s0,32(sp)
    800026ce:	64e2                	ld	s1,24(sp)
    800026d0:	6942                	ld	s2,16(sp)
    800026d2:	69a2                	ld	s3,8(sp)
    800026d4:	6145                	addi	sp,sp,48
    800026d6:	8082                	ret
    panic("invalid file system");
    800026d8:	00005517          	auipc	a0,0x5
    800026dc:	f3850513          	addi	a0,a0,-200 # 80007610 <syscalls+0x1b0>
    800026e0:	647020ef          	jal	ra,80005526 <panic>

00000000800026e4 <iinit>:
{
    800026e4:	7179                	addi	sp,sp,-48
    800026e6:	f406                	sd	ra,40(sp)
    800026e8:	f022                	sd	s0,32(sp)
    800026ea:	ec26                	sd	s1,24(sp)
    800026ec:	e84a                	sd	s2,16(sp)
    800026ee:	e44e                	sd	s3,8(sp)
    800026f0:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800026f2:	00005597          	auipc	a1,0x5
    800026f6:	f3658593          	addi	a1,a1,-202 # 80007628 <syscalls+0x1c8>
    800026fa:	00014517          	auipc	a0,0x14
    800026fe:	9fe50513          	addi	a0,a0,-1538 # 800160f8 <itable>
    80002702:	0b8030ef          	jal	ra,800057ba <initlock>
  for(i = 0; i < NINODE; i++) {
    80002706:	00014497          	auipc	s1,0x14
    8000270a:	a1a48493          	addi	s1,s1,-1510 # 80016120 <itable+0x28>
    8000270e:	00015997          	auipc	s3,0x15
    80002712:	4a298993          	addi	s3,s3,1186 # 80017bb0 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80002716:	00005917          	auipc	s2,0x5
    8000271a:	f1a90913          	addi	s2,s2,-230 # 80007630 <syscalls+0x1d0>
    8000271e:	85ca                	mv	a1,s2
    80002720:	8526                	mv	a0,s1
    80002722:	467000ef          	jal	ra,80003388 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80002726:	08848493          	addi	s1,s1,136
    8000272a:	ff349ae3          	bne	s1,s3,8000271e <iinit+0x3a>
}
    8000272e:	70a2                	ld	ra,40(sp)
    80002730:	7402                	ld	s0,32(sp)
    80002732:	64e2                	ld	s1,24(sp)
    80002734:	6942                	ld	s2,16(sp)
    80002736:	69a2                	ld	s3,8(sp)
    80002738:	6145                	addi	sp,sp,48
    8000273a:	8082                	ret

000000008000273c <ialloc>:
{
    8000273c:	715d                	addi	sp,sp,-80
    8000273e:	e486                	sd	ra,72(sp)
    80002740:	e0a2                	sd	s0,64(sp)
    80002742:	fc26                	sd	s1,56(sp)
    80002744:	f84a                	sd	s2,48(sp)
    80002746:	f44e                	sd	s3,40(sp)
    80002748:	f052                	sd	s4,32(sp)
    8000274a:	ec56                	sd	s5,24(sp)
    8000274c:	e85a                	sd	s6,16(sp)
    8000274e:	e45e                	sd	s7,8(sp)
    80002750:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    80002752:	00014717          	auipc	a4,0x14
    80002756:	99272703          	lw	a4,-1646(a4) # 800160e4 <sb+0xc>
    8000275a:	4785                	li	a5,1
    8000275c:	04e7f663          	bgeu	a5,a4,800027a8 <ialloc+0x6c>
    80002760:	8aaa                	mv	s5,a0
    80002762:	8bae                	mv	s7,a1
    80002764:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    80002766:	00014a17          	auipc	s4,0x14
    8000276a:	972a0a13          	addi	s4,s4,-1678 # 800160d8 <sb>
    8000276e:	00048b1b          	sext.w	s6,s1
    80002772:	0044d793          	srli	a5,s1,0x4
    80002776:	018a2583          	lw	a1,24(s4)
    8000277a:	9dbd                	addw	a1,a1,a5
    8000277c:	8556                	mv	a0,s5
    8000277e:	a07ff0ef          	jal	ra,80002184 <bread>
    80002782:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80002784:	05850993          	addi	s3,a0,88
    80002788:	00f4f793          	andi	a5,s1,15
    8000278c:	079a                	slli	a5,a5,0x6
    8000278e:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80002790:	00099783          	lh	a5,0(s3)
    80002794:	cf85                	beqz	a5,800027cc <ialloc+0x90>
    brelse(bp);
    80002796:	af7ff0ef          	jal	ra,8000228c <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000279a:	0485                	addi	s1,s1,1
    8000279c:	00ca2703          	lw	a4,12(s4)
    800027a0:	0004879b          	sext.w	a5,s1
    800027a4:	fce7e5e3          	bltu	a5,a4,8000276e <ialloc+0x32>
  printf("ialloc: no inodes\n");
    800027a8:	00005517          	auipc	a0,0x5
    800027ac:	e9050513          	addi	a0,a0,-368 # 80007638 <syscalls+0x1d8>
    800027b0:	2c3020ef          	jal	ra,80005272 <printf>
  return 0;
    800027b4:	4501                	li	a0,0
}
    800027b6:	60a6                	ld	ra,72(sp)
    800027b8:	6406                	ld	s0,64(sp)
    800027ba:	74e2                	ld	s1,56(sp)
    800027bc:	7942                	ld	s2,48(sp)
    800027be:	79a2                	ld	s3,40(sp)
    800027c0:	7a02                	ld	s4,32(sp)
    800027c2:	6ae2                	ld	s5,24(sp)
    800027c4:	6b42                	ld	s6,16(sp)
    800027c6:	6ba2                	ld	s7,8(sp)
    800027c8:	6161                	addi	sp,sp,80
    800027ca:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800027cc:	04000613          	li	a2,64
    800027d0:	4581                	li	a1,0
    800027d2:	854e                	mv	a0,s3
    800027d4:	979fd0ef          	jal	ra,8000014c <memset>
      dip->type = type;
    800027d8:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800027dc:	854a                	mv	a0,s2
    800027de:	2d9000ef          	jal	ra,800032b6 <log_write>
      brelse(bp);
    800027e2:	854a                	mv	a0,s2
    800027e4:	aa9ff0ef          	jal	ra,8000228c <brelse>
      return iget(dev, inum);
    800027e8:	85da                	mv	a1,s6
    800027ea:	8556                	mv	a0,s5
    800027ec:	de1ff0ef          	jal	ra,800025cc <iget>
    800027f0:	b7d9                	j	800027b6 <ialloc+0x7a>

00000000800027f2 <iupdate>:
{
    800027f2:	1101                	addi	sp,sp,-32
    800027f4:	ec06                	sd	ra,24(sp)
    800027f6:	e822                	sd	s0,16(sp)
    800027f8:	e426                	sd	s1,8(sp)
    800027fa:	e04a                	sd	s2,0(sp)
    800027fc:	1000                	addi	s0,sp,32
    800027fe:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80002800:	415c                	lw	a5,4(a0)
    80002802:	0047d79b          	srliw	a5,a5,0x4
    80002806:	00014597          	auipc	a1,0x14
    8000280a:	8ea5a583          	lw	a1,-1814(a1) # 800160f0 <sb+0x18>
    8000280e:	9dbd                	addw	a1,a1,a5
    80002810:	4108                	lw	a0,0(a0)
    80002812:	973ff0ef          	jal	ra,80002184 <bread>
    80002816:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80002818:	05850793          	addi	a5,a0,88
    8000281c:	40c8                	lw	a0,4(s1)
    8000281e:	893d                	andi	a0,a0,15
    80002820:	051a                	slli	a0,a0,0x6
    80002822:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    80002824:	04449703          	lh	a4,68(s1)
    80002828:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    8000282c:	04649703          	lh	a4,70(s1)
    80002830:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    80002834:	04849703          	lh	a4,72(s1)
    80002838:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    8000283c:	04a49703          	lh	a4,74(s1)
    80002840:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    80002844:	44f8                	lw	a4,76(s1)
    80002846:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80002848:	03400613          	li	a2,52
    8000284c:	05048593          	addi	a1,s1,80
    80002850:	0531                	addi	a0,a0,12
    80002852:	957fd0ef          	jal	ra,800001a8 <memmove>
  log_write(bp);
    80002856:	854a                	mv	a0,s2
    80002858:	25f000ef          	jal	ra,800032b6 <log_write>
  brelse(bp);
    8000285c:	854a                	mv	a0,s2
    8000285e:	a2fff0ef          	jal	ra,8000228c <brelse>
}
    80002862:	60e2                	ld	ra,24(sp)
    80002864:	6442                	ld	s0,16(sp)
    80002866:	64a2                	ld	s1,8(sp)
    80002868:	6902                	ld	s2,0(sp)
    8000286a:	6105                	addi	sp,sp,32
    8000286c:	8082                	ret

000000008000286e <idup>:
{
    8000286e:	1101                	addi	sp,sp,-32
    80002870:	ec06                	sd	ra,24(sp)
    80002872:	e822                	sd	s0,16(sp)
    80002874:	e426                	sd	s1,8(sp)
    80002876:	1000                	addi	s0,sp,32
    80002878:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000287a:	00014517          	auipc	a0,0x14
    8000287e:	87e50513          	addi	a0,a0,-1922 # 800160f8 <itable>
    80002882:	7b9020ef          	jal	ra,8000583a <acquire>
  ip->ref++;
    80002886:	449c                	lw	a5,8(s1)
    80002888:	2785                	addiw	a5,a5,1
    8000288a:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000288c:	00014517          	auipc	a0,0x14
    80002890:	86c50513          	addi	a0,a0,-1940 # 800160f8 <itable>
    80002894:	03e030ef          	jal	ra,800058d2 <release>
}
    80002898:	8526                	mv	a0,s1
    8000289a:	60e2                	ld	ra,24(sp)
    8000289c:	6442                	ld	s0,16(sp)
    8000289e:	64a2                	ld	s1,8(sp)
    800028a0:	6105                	addi	sp,sp,32
    800028a2:	8082                	ret

00000000800028a4 <ilock>:
{
    800028a4:	1101                	addi	sp,sp,-32
    800028a6:	ec06                	sd	ra,24(sp)
    800028a8:	e822                	sd	s0,16(sp)
    800028aa:	e426                	sd	s1,8(sp)
    800028ac:	e04a                	sd	s2,0(sp)
    800028ae:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800028b0:	c105                	beqz	a0,800028d0 <ilock+0x2c>
    800028b2:	84aa                	mv	s1,a0
    800028b4:	451c                	lw	a5,8(a0)
    800028b6:	00f05d63          	blez	a5,800028d0 <ilock+0x2c>
  acquiresleep(&ip->lock);
    800028ba:	0541                	addi	a0,a0,16
    800028bc:	303000ef          	jal	ra,800033be <acquiresleep>
  if(ip->valid == 0){
    800028c0:	40bc                	lw	a5,64(s1)
    800028c2:	cf89                	beqz	a5,800028dc <ilock+0x38>
}
    800028c4:	60e2                	ld	ra,24(sp)
    800028c6:	6442                	ld	s0,16(sp)
    800028c8:	64a2                	ld	s1,8(sp)
    800028ca:	6902                	ld	s2,0(sp)
    800028cc:	6105                	addi	sp,sp,32
    800028ce:	8082                	ret
    panic("ilock");
    800028d0:	00005517          	auipc	a0,0x5
    800028d4:	d8050513          	addi	a0,a0,-640 # 80007650 <syscalls+0x1f0>
    800028d8:	44f020ef          	jal	ra,80005526 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800028dc:	40dc                	lw	a5,4(s1)
    800028de:	0047d79b          	srliw	a5,a5,0x4
    800028e2:	00014597          	auipc	a1,0x14
    800028e6:	80e5a583          	lw	a1,-2034(a1) # 800160f0 <sb+0x18>
    800028ea:	9dbd                	addw	a1,a1,a5
    800028ec:	4088                	lw	a0,0(s1)
    800028ee:	897ff0ef          	jal	ra,80002184 <bread>
    800028f2:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800028f4:	05850593          	addi	a1,a0,88
    800028f8:	40dc                	lw	a5,4(s1)
    800028fa:	8bbd                	andi	a5,a5,15
    800028fc:	079a                	slli	a5,a5,0x6
    800028fe:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80002900:	00059783          	lh	a5,0(a1)
    80002904:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80002908:	00259783          	lh	a5,2(a1)
    8000290c:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80002910:	00459783          	lh	a5,4(a1)
    80002914:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80002918:	00659783          	lh	a5,6(a1)
    8000291c:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80002920:	459c                	lw	a5,8(a1)
    80002922:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80002924:	03400613          	li	a2,52
    80002928:	05b1                	addi	a1,a1,12
    8000292a:	05048513          	addi	a0,s1,80
    8000292e:	87bfd0ef          	jal	ra,800001a8 <memmove>
    brelse(bp);
    80002932:	854a                	mv	a0,s2
    80002934:	959ff0ef          	jal	ra,8000228c <brelse>
    ip->valid = 1;
    80002938:	4785                	li	a5,1
    8000293a:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000293c:	04449783          	lh	a5,68(s1)
    80002940:	f3d1                	bnez	a5,800028c4 <ilock+0x20>
      panic("ilock: no type");
    80002942:	00005517          	auipc	a0,0x5
    80002946:	d1650513          	addi	a0,a0,-746 # 80007658 <syscalls+0x1f8>
    8000294a:	3dd020ef          	jal	ra,80005526 <panic>

000000008000294e <iunlock>:
{
    8000294e:	1101                	addi	sp,sp,-32
    80002950:	ec06                	sd	ra,24(sp)
    80002952:	e822                	sd	s0,16(sp)
    80002954:	e426                	sd	s1,8(sp)
    80002956:	e04a                	sd	s2,0(sp)
    80002958:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000295a:	c505                	beqz	a0,80002982 <iunlock+0x34>
    8000295c:	84aa                	mv	s1,a0
    8000295e:	01050913          	addi	s2,a0,16
    80002962:	854a                	mv	a0,s2
    80002964:	2d9000ef          	jal	ra,8000343c <holdingsleep>
    80002968:	cd09                	beqz	a0,80002982 <iunlock+0x34>
    8000296a:	449c                	lw	a5,8(s1)
    8000296c:	00f05b63          	blez	a5,80002982 <iunlock+0x34>
  releasesleep(&ip->lock);
    80002970:	854a                	mv	a0,s2
    80002972:	293000ef          	jal	ra,80003404 <releasesleep>
}
    80002976:	60e2                	ld	ra,24(sp)
    80002978:	6442                	ld	s0,16(sp)
    8000297a:	64a2                	ld	s1,8(sp)
    8000297c:	6902                	ld	s2,0(sp)
    8000297e:	6105                	addi	sp,sp,32
    80002980:	8082                	ret
    panic("iunlock");
    80002982:	00005517          	auipc	a0,0x5
    80002986:	ce650513          	addi	a0,a0,-794 # 80007668 <syscalls+0x208>
    8000298a:	39d020ef          	jal	ra,80005526 <panic>

000000008000298e <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000298e:	7179                	addi	sp,sp,-48
    80002990:	f406                	sd	ra,40(sp)
    80002992:	f022                	sd	s0,32(sp)
    80002994:	ec26                	sd	s1,24(sp)
    80002996:	e84a                	sd	s2,16(sp)
    80002998:	e44e                	sd	s3,8(sp)
    8000299a:	e052                	sd	s4,0(sp)
    8000299c:	1800                	addi	s0,sp,48
    8000299e:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800029a0:	05050493          	addi	s1,a0,80
    800029a4:	08050913          	addi	s2,a0,128
    800029a8:	a021                	j	800029b0 <itrunc+0x22>
    800029aa:	0491                	addi	s1,s1,4
    800029ac:	01248b63          	beq	s1,s2,800029c2 <itrunc+0x34>
    if(ip->addrs[i]){
    800029b0:	408c                	lw	a1,0(s1)
    800029b2:	dde5                	beqz	a1,800029aa <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    800029b4:	0009a503          	lw	a0,0(s3)
    800029b8:	9c7ff0ef          	jal	ra,8000237e <bfree>
      ip->addrs[i] = 0;
    800029bc:	0004a023          	sw	zero,0(s1)
    800029c0:	b7ed                	j	800029aa <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    800029c2:	0809a583          	lw	a1,128(s3)
    800029c6:	ed91                	bnez	a1,800029e2 <itrunc+0x54>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800029c8:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800029cc:	854e                	mv	a0,s3
    800029ce:	e25ff0ef          	jal	ra,800027f2 <iupdate>
}
    800029d2:	70a2                	ld	ra,40(sp)
    800029d4:	7402                	ld	s0,32(sp)
    800029d6:	64e2                	ld	s1,24(sp)
    800029d8:	6942                	ld	s2,16(sp)
    800029da:	69a2                	ld	s3,8(sp)
    800029dc:	6a02                	ld	s4,0(sp)
    800029de:	6145                	addi	sp,sp,48
    800029e0:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800029e2:	0009a503          	lw	a0,0(s3)
    800029e6:	f9eff0ef          	jal	ra,80002184 <bread>
    800029ea:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800029ec:	05850493          	addi	s1,a0,88
    800029f0:	45850913          	addi	s2,a0,1112
    800029f4:	a021                	j	800029fc <itrunc+0x6e>
    800029f6:	0491                	addi	s1,s1,4
    800029f8:	01248963          	beq	s1,s2,80002a0a <itrunc+0x7c>
      if(a[j])
    800029fc:	408c                	lw	a1,0(s1)
    800029fe:	dde5                	beqz	a1,800029f6 <itrunc+0x68>
        bfree(ip->dev, a[j]);
    80002a00:	0009a503          	lw	a0,0(s3)
    80002a04:	97bff0ef          	jal	ra,8000237e <bfree>
    80002a08:	b7fd                	j	800029f6 <itrunc+0x68>
    brelse(bp);
    80002a0a:	8552                	mv	a0,s4
    80002a0c:	881ff0ef          	jal	ra,8000228c <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80002a10:	0809a583          	lw	a1,128(s3)
    80002a14:	0009a503          	lw	a0,0(s3)
    80002a18:	967ff0ef          	jal	ra,8000237e <bfree>
    ip->addrs[NDIRECT] = 0;
    80002a1c:	0809a023          	sw	zero,128(s3)
    80002a20:	b765                	j	800029c8 <itrunc+0x3a>

0000000080002a22 <iput>:
{
    80002a22:	1101                	addi	sp,sp,-32
    80002a24:	ec06                	sd	ra,24(sp)
    80002a26:	e822                	sd	s0,16(sp)
    80002a28:	e426                	sd	s1,8(sp)
    80002a2a:	e04a                	sd	s2,0(sp)
    80002a2c:	1000                	addi	s0,sp,32
    80002a2e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80002a30:	00013517          	auipc	a0,0x13
    80002a34:	6c850513          	addi	a0,a0,1736 # 800160f8 <itable>
    80002a38:	603020ef          	jal	ra,8000583a <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a3c:	4498                	lw	a4,8(s1)
    80002a3e:	4785                	li	a5,1
    80002a40:	02f70163          	beq	a4,a5,80002a62 <iput+0x40>
  ip->ref--;
    80002a44:	449c                	lw	a5,8(s1)
    80002a46:	37fd                	addiw	a5,a5,-1
    80002a48:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80002a4a:	00013517          	auipc	a0,0x13
    80002a4e:	6ae50513          	addi	a0,a0,1710 # 800160f8 <itable>
    80002a52:	681020ef          	jal	ra,800058d2 <release>
}
    80002a56:	60e2                	ld	ra,24(sp)
    80002a58:	6442                	ld	s0,16(sp)
    80002a5a:	64a2                	ld	s1,8(sp)
    80002a5c:	6902                	ld	s2,0(sp)
    80002a5e:	6105                	addi	sp,sp,32
    80002a60:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80002a62:	40bc                	lw	a5,64(s1)
    80002a64:	d3e5                	beqz	a5,80002a44 <iput+0x22>
    80002a66:	04a49783          	lh	a5,74(s1)
    80002a6a:	ffe9                	bnez	a5,80002a44 <iput+0x22>
    acquiresleep(&ip->lock);
    80002a6c:	01048913          	addi	s2,s1,16
    80002a70:	854a                	mv	a0,s2
    80002a72:	14d000ef          	jal	ra,800033be <acquiresleep>
    release(&itable.lock);
    80002a76:	00013517          	auipc	a0,0x13
    80002a7a:	68250513          	addi	a0,a0,1666 # 800160f8 <itable>
    80002a7e:	655020ef          	jal	ra,800058d2 <release>
    itrunc(ip);
    80002a82:	8526                	mv	a0,s1
    80002a84:	f0bff0ef          	jal	ra,8000298e <itrunc>
    ip->type = 0;
    80002a88:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80002a8c:	8526                	mv	a0,s1
    80002a8e:	d65ff0ef          	jal	ra,800027f2 <iupdate>
    ip->valid = 0;
    80002a92:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80002a96:	854a                	mv	a0,s2
    80002a98:	16d000ef          	jal	ra,80003404 <releasesleep>
    acquire(&itable.lock);
    80002a9c:	00013517          	auipc	a0,0x13
    80002aa0:	65c50513          	addi	a0,a0,1628 # 800160f8 <itable>
    80002aa4:	597020ef          	jal	ra,8000583a <acquire>
    80002aa8:	bf71                	j	80002a44 <iput+0x22>

0000000080002aaa <iunlockput>:
{
    80002aaa:	1101                	addi	sp,sp,-32
    80002aac:	ec06                	sd	ra,24(sp)
    80002aae:	e822                	sd	s0,16(sp)
    80002ab0:	e426                	sd	s1,8(sp)
    80002ab2:	1000                	addi	s0,sp,32
    80002ab4:	84aa                	mv	s1,a0
  iunlock(ip);
    80002ab6:	e99ff0ef          	jal	ra,8000294e <iunlock>
  iput(ip);
    80002aba:	8526                	mv	a0,s1
    80002abc:	f67ff0ef          	jal	ra,80002a22 <iput>
}
    80002ac0:	60e2                	ld	ra,24(sp)
    80002ac2:	6442                	ld	s0,16(sp)
    80002ac4:	64a2                	ld	s1,8(sp)
    80002ac6:	6105                	addi	sp,sp,32
    80002ac8:	8082                	ret

0000000080002aca <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80002aca:	1141                	addi	sp,sp,-16
    80002acc:	e422                	sd	s0,8(sp)
    80002ace:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80002ad0:	411c                	lw	a5,0(a0)
    80002ad2:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80002ad4:	415c                	lw	a5,4(a0)
    80002ad6:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80002ad8:	04451783          	lh	a5,68(a0)
    80002adc:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80002ae0:	04a51783          	lh	a5,74(a0)
    80002ae4:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80002ae8:	04c56783          	lwu	a5,76(a0)
    80002aec:	e99c                	sd	a5,16(a1)
}
    80002aee:	6422                	ld	s0,8(sp)
    80002af0:	0141                	addi	sp,sp,16
    80002af2:	8082                	ret

0000000080002af4 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002af4:	457c                	lw	a5,76(a0)
    80002af6:	0cd7ef63          	bltu	a5,a3,80002bd4 <readi+0xe0>
{
    80002afa:	7159                	addi	sp,sp,-112
    80002afc:	f486                	sd	ra,104(sp)
    80002afe:	f0a2                	sd	s0,96(sp)
    80002b00:	eca6                	sd	s1,88(sp)
    80002b02:	e8ca                	sd	s2,80(sp)
    80002b04:	e4ce                	sd	s3,72(sp)
    80002b06:	e0d2                	sd	s4,64(sp)
    80002b08:	fc56                	sd	s5,56(sp)
    80002b0a:	f85a                	sd	s6,48(sp)
    80002b0c:	f45e                	sd	s7,40(sp)
    80002b0e:	f062                	sd	s8,32(sp)
    80002b10:	ec66                	sd	s9,24(sp)
    80002b12:	e86a                	sd	s10,16(sp)
    80002b14:	e46e                	sd	s11,8(sp)
    80002b16:	1880                	addi	s0,sp,112
    80002b18:	8b2a                	mv	s6,a0
    80002b1a:	8bae                	mv	s7,a1
    80002b1c:	8a32                	mv	s4,a2
    80002b1e:	84b6                	mv	s1,a3
    80002b20:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80002b22:	9f35                	addw	a4,a4,a3
    return 0;
    80002b24:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80002b26:	08d76663          	bltu	a4,a3,80002bb2 <readi+0xbe>
  if(off + n > ip->size)
    80002b2a:	00e7f463          	bgeu	a5,a4,80002b32 <readi+0x3e>
    n = ip->size - off;
    80002b2e:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b32:	080a8f63          	beqz	s5,80002bd0 <readi+0xdc>
    80002b36:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b38:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80002b3c:	5c7d                	li	s8,-1
    80002b3e:	a80d                	j	80002b70 <readi+0x7c>
    80002b40:	020d1d93          	slli	s11,s10,0x20
    80002b44:	020ddd93          	srli	s11,s11,0x20
    80002b48:	05890793          	addi	a5,s2,88
    80002b4c:	86ee                	mv	a3,s11
    80002b4e:	963e                	add	a2,a2,a5
    80002b50:	85d2                	mv	a1,s4
    80002b52:	855e                	mv	a0,s7
    80002b54:	c93fe0ef          	jal	ra,800017e6 <either_copyout>
    80002b58:	05850763          	beq	a0,s8,80002ba6 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80002b5c:	854a                	mv	a0,s2
    80002b5e:	f2eff0ef          	jal	ra,8000228c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002b62:	013d09bb          	addw	s3,s10,s3
    80002b66:	009d04bb          	addw	s1,s10,s1
    80002b6a:	9a6e                	add	s4,s4,s11
    80002b6c:	0559f163          	bgeu	s3,s5,80002bae <readi+0xba>
    uint addr = bmap(ip, off/BSIZE);
    80002b70:	00a4d59b          	srliw	a1,s1,0xa
    80002b74:	855a                	mv	a0,s6
    80002b76:	989ff0ef          	jal	ra,800024fe <bmap>
    80002b7a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80002b7e:	c985                	beqz	a1,80002bae <readi+0xba>
    bp = bread(ip->dev, addr);
    80002b80:	000b2503          	lw	a0,0(s6)
    80002b84:	e00ff0ef          	jal	ra,80002184 <bread>
    80002b88:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002b8a:	3ff4f613          	andi	a2,s1,1023
    80002b8e:	40cc87bb          	subw	a5,s9,a2
    80002b92:	413a873b          	subw	a4,s5,s3
    80002b96:	8d3e                	mv	s10,a5
    80002b98:	2781                	sext.w	a5,a5
    80002b9a:	0007069b          	sext.w	a3,a4
    80002b9e:	faf6f1e3          	bgeu	a3,a5,80002b40 <readi+0x4c>
    80002ba2:	8d3a                	mv	s10,a4
    80002ba4:	bf71                	j	80002b40 <readi+0x4c>
      brelse(bp);
    80002ba6:	854a                	mv	a0,s2
    80002ba8:	ee4ff0ef          	jal	ra,8000228c <brelse>
      tot = -1;
    80002bac:	59fd                	li	s3,-1
  }
  return tot;
    80002bae:	0009851b          	sext.w	a0,s3
}
    80002bb2:	70a6                	ld	ra,104(sp)
    80002bb4:	7406                	ld	s0,96(sp)
    80002bb6:	64e6                	ld	s1,88(sp)
    80002bb8:	6946                	ld	s2,80(sp)
    80002bba:	69a6                	ld	s3,72(sp)
    80002bbc:	6a06                	ld	s4,64(sp)
    80002bbe:	7ae2                	ld	s5,56(sp)
    80002bc0:	7b42                	ld	s6,48(sp)
    80002bc2:	7ba2                	ld	s7,40(sp)
    80002bc4:	7c02                	ld	s8,32(sp)
    80002bc6:	6ce2                	ld	s9,24(sp)
    80002bc8:	6d42                	ld	s10,16(sp)
    80002bca:	6da2                	ld	s11,8(sp)
    80002bcc:	6165                	addi	sp,sp,112
    80002bce:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80002bd0:	89d6                	mv	s3,s5
    80002bd2:	bff1                	j	80002bae <readi+0xba>
    return 0;
    80002bd4:	4501                	li	a0,0
}
    80002bd6:	8082                	ret

0000000080002bd8 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80002bd8:	457c                	lw	a5,76(a0)
    80002bda:	0ed7ea63          	bltu	a5,a3,80002cce <writei+0xf6>
{
    80002bde:	7159                	addi	sp,sp,-112
    80002be0:	f486                	sd	ra,104(sp)
    80002be2:	f0a2                	sd	s0,96(sp)
    80002be4:	eca6                	sd	s1,88(sp)
    80002be6:	e8ca                	sd	s2,80(sp)
    80002be8:	e4ce                	sd	s3,72(sp)
    80002bea:	e0d2                	sd	s4,64(sp)
    80002bec:	fc56                	sd	s5,56(sp)
    80002bee:	f85a                	sd	s6,48(sp)
    80002bf0:	f45e                	sd	s7,40(sp)
    80002bf2:	f062                	sd	s8,32(sp)
    80002bf4:	ec66                	sd	s9,24(sp)
    80002bf6:	e86a                	sd	s10,16(sp)
    80002bf8:	e46e                	sd	s11,8(sp)
    80002bfa:	1880                	addi	s0,sp,112
    80002bfc:	8aaa                	mv	s5,a0
    80002bfe:	8bae                	mv	s7,a1
    80002c00:	8a32                	mv	s4,a2
    80002c02:	8936                	mv	s2,a3
    80002c04:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80002c06:	00e687bb          	addw	a5,a3,a4
    80002c0a:	0cd7e463          	bltu	a5,a3,80002cd2 <writei+0xfa>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80002c0e:	00043737          	lui	a4,0x43
    80002c12:	0cf76263          	bltu	a4,a5,80002cd6 <writei+0xfe>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c16:	0a0b0a63          	beqz	s6,80002cca <writei+0xf2>
    80002c1a:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c1c:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80002c20:	5c7d                	li	s8,-1
    80002c22:	a825                	j	80002c5a <writei+0x82>
    80002c24:	020d1d93          	slli	s11,s10,0x20
    80002c28:	020ddd93          	srli	s11,s11,0x20
    80002c2c:	05848793          	addi	a5,s1,88
    80002c30:	86ee                	mv	a3,s11
    80002c32:	8652                	mv	a2,s4
    80002c34:	85de                	mv	a1,s7
    80002c36:	953e                	add	a0,a0,a5
    80002c38:	bf9fe0ef          	jal	ra,80001830 <either_copyin>
    80002c3c:	05850a63          	beq	a0,s8,80002c90 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    80002c40:	8526                	mv	a0,s1
    80002c42:	674000ef          	jal	ra,800032b6 <log_write>
    brelse(bp);
    80002c46:	8526                	mv	a0,s1
    80002c48:	e44ff0ef          	jal	ra,8000228c <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002c4c:	013d09bb          	addw	s3,s10,s3
    80002c50:	012d093b          	addw	s2,s10,s2
    80002c54:	9a6e                	add	s4,s4,s11
    80002c56:	0569f063          	bgeu	s3,s6,80002c96 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80002c5a:	00a9559b          	srliw	a1,s2,0xa
    80002c5e:	8556                	mv	a0,s5
    80002c60:	89fff0ef          	jal	ra,800024fe <bmap>
    80002c64:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80002c68:	c59d                	beqz	a1,80002c96 <writei+0xbe>
    bp = bread(ip->dev, addr);
    80002c6a:	000aa503          	lw	a0,0(s5)
    80002c6e:	d16ff0ef          	jal	ra,80002184 <bread>
    80002c72:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80002c74:	3ff97513          	andi	a0,s2,1023
    80002c78:	40ac87bb          	subw	a5,s9,a0
    80002c7c:	413b073b          	subw	a4,s6,s3
    80002c80:	8d3e                	mv	s10,a5
    80002c82:	2781                	sext.w	a5,a5
    80002c84:	0007069b          	sext.w	a3,a4
    80002c88:	f8f6fee3          	bgeu	a3,a5,80002c24 <writei+0x4c>
    80002c8c:	8d3a                	mv	s10,a4
    80002c8e:	bf59                	j	80002c24 <writei+0x4c>
      brelse(bp);
    80002c90:	8526                	mv	a0,s1
    80002c92:	dfaff0ef          	jal	ra,8000228c <brelse>
  }

  if(off > ip->size)
    80002c96:	04caa783          	lw	a5,76(s5)
    80002c9a:	0127f463          	bgeu	a5,s2,80002ca2 <writei+0xca>
    ip->size = off;
    80002c9e:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80002ca2:	8556                	mv	a0,s5
    80002ca4:	b4fff0ef          	jal	ra,800027f2 <iupdate>

  return tot;
    80002ca8:	0009851b          	sext.w	a0,s3
}
    80002cac:	70a6                	ld	ra,104(sp)
    80002cae:	7406                	ld	s0,96(sp)
    80002cb0:	64e6                	ld	s1,88(sp)
    80002cb2:	6946                	ld	s2,80(sp)
    80002cb4:	69a6                	ld	s3,72(sp)
    80002cb6:	6a06                	ld	s4,64(sp)
    80002cb8:	7ae2                	ld	s5,56(sp)
    80002cba:	7b42                	ld	s6,48(sp)
    80002cbc:	7ba2                	ld	s7,40(sp)
    80002cbe:	7c02                	ld	s8,32(sp)
    80002cc0:	6ce2                	ld	s9,24(sp)
    80002cc2:	6d42                	ld	s10,16(sp)
    80002cc4:	6da2                	ld	s11,8(sp)
    80002cc6:	6165                	addi	sp,sp,112
    80002cc8:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80002cca:	89da                	mv	s3,s6
    80002ccc:	bfd9                	j	80002ca2 <writei+0xca>
    return -1;
    80002cce:	557d                	li	a0,-1
}
    80002cd0:	8082                	ret
    return -1;
    80002cd2:	557d                	li	a0,-1
    80002cd4:	bfe1                	j	80002cac <writei+0xd4>
    return -1;
    80002cd6:	557d                	li	a0,-1
    80002cd8:	bfd1                	j	80002cac <writei+0xd4>

0000000080002cda <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80002cda:	1141                	addi	sp,sp,-16
    80002cdc:	e406                	sd	ra,8(sp)
    80002cde:	e022                	sd	s0,0(sp)
    80002ce0:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80002ce2:	4639                	li	a2,14
    80002ce4:	d34fd0ef          	jal	ra,80000218 <strncmp>
}
    80002ce8:	60a2                	ld	ra,8(sp)
    80002cea:	6402                	ld	s0,0(sp)
    80002cec:	0141                	addi	sp,sp,16
    80002cee:	8082                	ret

0000000080002cf0 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80002cf0:	7139                	addi	sp,sp,-64
    80002cf2:	fc06                	sd	ra,56(sp)
    80002cf4:	f822                	sd	s0,48(sp)
    80002cf6:	f426                	sd	s1,40(sp)
    80002cf8:	f04a                	sd	s2,32(sp)
    80002cfa:	ec4e                	sd	s3,24(sp)
    80002cfc:	e852                	sd	s4,16(sp)
    80002cfe:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80002d00:	04451703          	lh	a4,68(a0)
    80002d04:	4785                	li	a5,1
    80002d06:	00f71a63          	bne	a4,a5,80002d1a <dirlookup+0x2a>
    80002d0a:	892a                	mv	s2,a0
    80002d0c:	89ae                	mv	s3,a1
    80002d0e:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d10:	457c                	lw	a5,76(a0)
    80002d12:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80002d14:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d16:	e39d                	bnez	a5,80002d3c <dirlookup+0x4c>
    80002d18:	a095                	j	80002d7c <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80002d1a:	00005517          	auipc	a0,0x5
    80002d1e:	95650513          	addi	a0,a0,-1706 # 80007670 <syscalls+0x210>
    80002d22:	005020ef          	jal	ra,80005526 <panic>
      panic("dirlookup read");
    80002d26:	00005517          	auipc	a0,0x5
    80002d2a:	96250513          	addi	a0,a0,-1694 # 80007688 <syscalls+0x228>
    80002d2e:	7f8020ef          	jal	ra,80005526 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002d32:	24c1                	addiw	s1,s1,16
    80002d34:	04c92783          	lw	a5,76(s2)
    80002d38:	04f4f163          	bgeu	s1,a5,80002d7a <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002d3c:	4741                	li	a4,16
    80002d3e:	86a6                	mv	a3,s1
    80002d40:	fc040613          	addi	a2,s0,-64
    80002d44:	4581                	li	a1,0
    80002d46:	854a                	mv	a0,s2
    80002d48:	dadff0ef          	jal	ra,80002af4 <readi>
    80002d4c:	47c1                	li	a5,16
    80002d4e:	fcf51ce3          	bne	a0,a5,80002d26 <dirlookup+0x36>
    if(de.inum == 0)
    80002d52:	fc045783          	lhu	a5,-64(s0)
    80002d56:	dff1                	beqz	a5,80002d32 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80002d58:	fc240593          	addi	a1,s0,-62
    80002d5c:	854e                	mv	a0,s3
    80002d5e:	f7dff0ef          	jal	ra,80002cda <namecmp>
    80002d62:	f961                	bnez	a0,80002d32 <dirlookup+0x42>
      if(poff)
    80002d64:	000a0463          	beqz	s4,80002d6c <dirlookup+0x7c>
        *poff = off;
    80002d68:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80002d6c:	fc045583          	lhu	a1,-64(s0)
    80002d70:	00092503          	lw	a0,0(s2)
    80002d74:	859ff0ef          	jal	ra,800025cc <iget>
    80002d78:	a011                	j	80002d7c <dirlookup+0x8c>
  return 0;
    80002d7a:	4501                	li	a0,0
}
    80002d7c:	70e2                	ld	ra,56(sp)
    80002d7e:	7442                	ld	s0,48(sp)
    80002d80:	74a2                	ld	s1,40(sp)
    80002d82:	7902                	ld	s2,32(sp)
    80002d84:	69e2                	ld	s3,24(sp)
    80002d86:	6a42                	ld	s4,16(sp)
    80002d88:	6121                	addi	sp,sp,64
    80002d8a:	8082                	ret

0000000080002d8c <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80002d8c:	711d                	addi	sp,sp,-96
    80002d8e:	ec86                	sd	ra,88(sp)
    80002d90:	e8a2                	sd	s0,80(sp)
    80002d92:	e4a6                	sd	s1,72(sp)
    80002d94:	e0ca                	sd	s2,64(sp)
    80002d96:	fc4e                	sd	s3,56(sp)
    80002d98:	f852                	sd	s4,48(sp)
    80002d9a:	f456                	sd	s5,40(sp)
    80002d9c:	f05a                	sd	s6,32(sp)
    80002d9e:	ec5e                	sd	s7,24(sp)
    80002da0:	e862                	sd	s8,16(sp)
    80002da2:	e466                	sd	s9,8(sp)
    80002da4:	1080                	addi	s0,sp,96
    80002da6:	84aa                	mv	s1,a0
    80002da8:	8aae                	mv	s5,a1
    80002daa:	8a32                	mv	s4,a2
  struct inode *ip, *next;

  if(*path == '/')
    80002dac:	00054703          	lbu	a4,0(a0)
    80002db0:	02f00793          	li	a5,47
    80002db4:	00f70f63          	beq	a4,a5,80002dd2 <namex+0x46>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80002db8:	866fe0ef          	jal	ra,80000e1e <myproc>
    80002dbc:	15053503          	ld	a0,336(a0)
    80002dc0:	aafff0ef          	jal	ra,8000286e <idup>
    80002dc4:	89aa                	mv	s3,a0
  while(*path == '/')
    80002dc6:	02f00913          	li	s2,47
  len = path - s;
    80002dca:	4b01                	li	s6,0
  if(len >= DIRSIZ)
    80002dcc:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80002dce:	4b85                	li	s7,1
    80002dd0:	a861                	j	80002e68 <namex+0xdc>
    ip = iget(ROOTDEV, ROOTINO);
    80002dd2:	4585                	li	a1,1
    80002dd4:	4505                	li	a0,1
    80002dd6:	ff6ff0ef          	jal	ra,800025cc <iget>
    80002dda:	89aa                	mv	s3,a0
    80002ddc:	b7ed                	j	80002dc6 <namex+0x3a>
      iunlockput(ip);
    80002dde:	854e                	mv	a0,s3
    80002de0:	ccbff0ef          	jal	ra,80002aaa <iunlockput>
      return 0;
    80002de4:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80002de6:	854e                	mv	a0,s3
    80002de8:	60e6                	ld	ra,88(sp)
    80002dea:	6446                	ld	s0,80(sp)
    80002dec:	64a6                	ld	s1,72(sp)
    80002dee:	6906                	ld	s2,64(sp)
    80002df0:	79e2                	ld	s3,56(sp)
    80002df2:	7a42                	ld	s4,48(sp)
    80002df4:	7aa2                	ld	s5,40(sp)
    80002df6:	7b02                	ld	s6,32(sp)
    80002df8:	6be2                	ld	s7,24(sp)
    80002dfa:	6c42                	ld	s8,16(sp)
    80002dfc:	6ca2                	ld	s9,8(sp)
    80002dfe:	6125                	addi	sp,sp,96
    80002e00:	8082                	ret
      iunlock(ip);
    80002e02:	854e                	mv	a0,s3
    80002e04:	b4bff0ef          	jal	ra,8000294e <iunlock>
      return ip;
    80002e08:	bff9                	j	80002de6 <namex+0x5a>
      iunlockput(ip);
    80002e0a:	854e                	mv	a0,s3
    80002e0c:	c9fff0ef          	jal	ra,80002aaa <iunlockput>
      return 0;
    80002e10:	89e6                	mv	s3,s9
    80002e12:	bfd1                	j	80002de6 <namex+0x5a>
  len = path - s;
    80002e14:	40b48633          	sub	a2,s1,a1
    80002e18:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80002e1c:	079c5c63          	bge	s8,s9,80002e94 <namex+0x108>
    memmove(name, s, DIRSIZ);
    80002e20:	4639                	li	a2,14
    80002e22:	8552                	mv	a0,s4
    80002e24:	b84fd0ef          	jal	ra,800001a8 <memmove>
  while(*path == '/')
    80002e28:	0004c783          	lbu	a5,0(s1)
    80002e2c:	01279763          	bne	a5,s2,80002e3a <namex+0xae>
    path++;
    80002e30:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e32:	0004c783          	lbu	a5,0(s1)
    80002e36:	ff278de3          	beq	a5,s2,80002e30 <namex+0xa4>
    ilock(ip);
    80002e3a:	854e                	mv	a0,s3
    80002e3c:	a69ff0ef          	jal	ra,800028a4 <ilock>
    if(ip->type != T_DIR){
    80002e40:	04499783          	lh	a5,68(s3)
    80002e44:	f9779de3          	bne	a5,s7,80002dde <namex+0x52>
    if(nameiparent && *path == '\0'){
    80002e48:	000a8563          	beqz	s5,80002e52 <namex+0xc6>
    80002e4c:	0004c783          	lbu	a5,0(s1)
    80002e50:	dbcd                	beqz	a5,80002e02 <namex+0x76>
    if((next = dirlookup(ip, name, 0)) == 0){
    80002e52:	865a                	mv	a2,s6
    80002e54:	85d2                	mv	a1,s4
    80002e56:	854e                	mv	a0,s3
    80002e58:	e99ff0ef          	jal	ra,80002cf0 <dirlookup>
    80002e5c:	8caa                	mv	s9,a0
    80002e5e:	d555                	beqz	a0,80002e0a <namex+0x7e>
    iunlockput(ip);
    80002e60:	854e                	mv	a0,s3
    80002e62:	c49ff0ef          	jal	ra,80002aaa <iunlockput>
    ip = next;
    80002e66:	89e6                	mv	s3,s9
  while(*path == '/')
    80002e68:	0004c783          	lbu	a5,0(s1)
    80002e6c:	05279363          	bne	a5,s2,80002eb2 <namex+0x126>
    path++;
    80002e70:	0485                	addi	s1,s1,1
  while(*path == '/')
    80002e72:	0004c783          	lbu	a5,0(s1)
    80002e76:	ff278de3          	beq	a5,s2,80002e70 <namex+0xe4>
  if(*path == 0)
    80002e7a:	c78d                	beqz	a5,80002ea4 <namex+0x118>
    path++;
    80002e7c:	85a6                	mv	a1,s1
  len = path - s;
    80002e7e:	8cda                	mv	s9,s6
    80002e80:	865a                	mv	a2,s6
  while(*path != '/' && *path != 0)
    80002e82:	01278963          	beq	a5,s2,80002e94 <namex+0x108>
    80002e86:	d7d9                	beqz	a5,80002e14 <namex+0x88>
    path++;
    80002e88:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80002e8a:	0004c783          	lbu	a5,0(s1)
    80002e8e:	ff279ce3          	bne	a5,s2,80002e86 <namex+0xfa>
    80002e92:	b749                	j	80002e14 <namex+0x88>
    memmove(name, s, len);
    80002e94:	2601                	sext.w	a2,a2
    80002e96:	8552                	mv	a0,s4
    80002e98:	b10fd0ef          	jal	ra,800001a8 <memmove>
    name[len] = 0;
    80002e9c:	9cd2                	add	s9,s9,s4
    80002e9e:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80002ea2:	b759                	j	80002e28 <namex+0x9c>
  if(nameiparent){
    80002ea4:	f40a81e3          	beqz	s5,80002de6 <namex+0x5a>
    iput(ip);
    80002ea8:	854e                	mv	a0,s3
    80002eaa:	b79ff0ef          	jal	ra,80002a22 <iput>
    return 0;
    80002eae:	4981                	li	s3,0
    80002eb0:	bf1d                	j	80002de6 <namex+0x5a>
  if(*path == 0)
    80002eb2:	dbed                	beqz	a5,80002ea4 <namex+0x118>
  while(*path != '/' && *path != 0)
    80002eb4:	0004c783          	lbu	a5,0(s1)
    80002eb8:	85a6                	mv	a1,s1
    80002eba:	b7f1                	j	80002e86 <namex+0xfa>

0000000080002ebc <dirlink>:
{
    80002ebc:	7139                	addi	sp,sp,-64
    80002ebe:	fc06                	sd	ra,56(sp)
    80002ec0:	f822                	sd	s0,48(sp)
    80002ec2:	f426                	sd	s1,40(sp)
    80002ec4:	f04a                	sd	s2,32(sp)
    80002ec6:	ec4e                	sd	s3,24(sp)
    80002ec8:	e852                	sd	s4,16(sp)
    80002eca:	0080                	addi	s0,sp,64
    80002ecc:	892a                	mv	s2,a0
    80002ece:	8a2e                	mv	s4,a1
    80002ed0:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80002ed2:	4601                	li	a2,0
    80002ed4:	e1dff0ef          	jal	ra,80002cf0 <dirlookup>
    80002ed8:	e52d                	bnez	a0,80002f42 <dirlink+0x86>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002eda:	04c92483          	lw	s1,76(s2)
    80002ede:	c48d                	beqz	s1,80002f08 <dirlink+0x4c>
    80002ee0:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002ee2:	4741                	li	a4,16
    80002ee4:	86a6                	mv	a3,s1
    80002ee6:	fc040613          	addi	a2,s0,-64
    80002eea:	4581                	li	a1,0
    80002eec:	854a                	mv	a0,s2
    80002eee:	c07ff0ef          	jal	ra,80002af4 <readi>
    80002ef2:	47c1                	li	a5,16
    80002ef4:	04f51b63          	bne	a0,a5,80002f4a <dirlink+0x8e>
    if(de.inum == 0)
    80002ef8:	fc045783          	lhu	a5,-64(s0)
    80002efc:	c791                	beqz	a5,80002f08 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80002efe:	24c1                	addiw	s1,s1,16
    80002f00:	04c92783          	lw	a5,76(s2)
    80002f04:	fcf4efe3          	bltu	s1,a5,80002ee2 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80002f08:	4639                	li	a2,14
    80002f0a:	85d2                	mv	a1,s4
    80002f0c:	fc240513          	addi	a0,s0,-62
    80002f10:	b44fd0ef          	jal	ra,80000254 <strncpy>
  de.inum = inum;
    80002f14:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80002f18:	4741                	li	a4,16
    80002f1a:	86a6                	mv	a3,s1
    80002f1c:	fc040613          	addi	a2,s0,-64
    80002f20:	4581                	li	a1,0
    80002f22:	854a                	mv	a0,s2
    80002f24:	cb5ff0ef          	jal	ra,80002bd8 <writei>
    80002f28:	1541                	addi	a0,a0,-16
    80002f2a:	00a03533          	snez	a0,a0
    80002f2e:	40a00533          	neg	a0,a0
}
    80002f32:	70e2                	ld	ra,56(sp)
    80002f34:	7442                	ld	s0,48(sp)
    80002f36:	74a2                	ld	s1,40(sp)
    80002f38:	7902                	ld	s2,32(sp)
    80002f3a:	69e2                	ld	s3,24(sp)
    80002f3c:	6a42                	ld	s4,16(sp)
    80002f3e:	6121                	addi	sp,sp,64
    80002f40:	8082                	ret
    iput(ip);
    80002f42:	ae1ff0ef          	jal	ra,80002a22 <iput>
    return -1;
    80002f46:	557d                	li	a0,-1
    80002f48:	b7ed                	j	80002f32 <dirlink+0x76>
      panic("dirlink read");
    80002f4a:	00004517          	auipc	a0,0x4
    80002f4e:	74e50513          	addi	a0,a0,1870 # 80007698 <syscalls+0x238>
    80002f52:	5d4020ef          	jal	ra,80005526 <panic>

0000000080002f56 <namei>:

struct inode*
namei(char *path)
{
    80002f56:	1101                	addi	sp,sp,-32
    80002f58:	ec06                	sd	ra,24(sp)
    80002f5a:	e822                	sd	s0,16(sp)
    80002f5c:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80002f5e:	fe040613          	addi	a2,s0,-32
    80002f62:	4581                	li	a1,0
    80002f64:	e29ff0ef          	jal	ra,80002d8c <namex>
}
    80002f68:	60e2                	ld	ra,24(sp)
    80002f6a:	6442                	ld	s0,16(sp)
    80002f6c:	6105                	addi	sp,sp,32
    80002f6e:	8082                	ret

0000000080002f70 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80002f70:	1141                	addi	sp,sp,-16
    80002f72:	e406                	sd	ra,8(sp)
    80002f74:	e022                	sd	s0,0(sp)
    80002f76:	0800                	addi	s0,sp,16
    80002f78:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80002f7a:	4585                	li	a1,1
    80002f7c:	e11ff0ef          	jal	ra,80002d8c <namex>
}
    80002f80:	60a2                	ld	ra,8(sp)
    80002f82:	6402                	ld	s0,0(sp)
    80002f84:	0141                	addi	sp,sp,16
    80002f86:	8082                	ret

0000000080002f88 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80002f88:	1101                	addi	sp,sp,-32
    80002f8a:	ec06                	sd	ra,24(sp)
    80002f8c:	e822                	sd	s0,16(sp)
    80002f8e:	e426                	sd	s1,8(sp)
    80002f90:	e04a                	sd	s2,0(sp)
    80002f92:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80002f94:	00015917          	auipc	s2,0x15
    80002f98:	c0c90913          	addi	s2,s2,-1012 # 80017ba0 <log>
    80002f9c:	01892583          	lw	a1,24(s2)
    80002fa0:	02892503          	lw	a0,40(s2)
    80002fa4:	9e0ff0ef          	jal	ra,80002184 <bread>
    80002fa8:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80002faa:	02c92683          	lw	a3,44(s2)
    80002fae:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80002fb0:	02d05863          	blez	a3,80002fe0 <write_head+0x58>
    80002fb4:	00015797          	auipc	a5,0x15
    80002fb8:	c1c78793          	addi	a5,a5,-996 # 80017bd0 <log+0x30>
    80002fbc:	05c50713          	addi	a4,a0,92
    80002fc0:	36fd                	addiw	a3,a3,-1
    80002fc2:	02069613          	slli	a2,a3,0x20
    80002fc6:	01e65693          	srli	a3,a2,0x1e
    80002fca:	00015617          	auipc	a2,0x15
    80002fce:	c0a60613          	addi	a2,a2,-1014 # 80017bd4 <log+0x34>
    80002fd2:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80002fd4:	4390                	lw	a2,0(a5)
    80002fd6:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80002fd8:	0791                	addi	a5,a5,4
    80002fda:	0711                	addi	a4,a4,4
    80002fdc:	fed79ce3          	bne	a5,a3,80002fd4 <write_head+0x4c>
  }
  bwrite(buf);
    80002fe0:	8526                	mv	a0,s1
    80002fe2:	a78ff0ef          	jal	ra,8000225a <bwrite>
  brelse(buf);
    80002fe6:	8526                	mv	a0,s1
    80002fe8:	aa4ff0ef          	jal	ra,8000228c <brelse>
}
    80002fec:	60e2                	ld	ra,24(sp)
    80002fee:	6442                	ld	s0,16(sp)
    80002ff0:	64a2                	ld	s1,8(sp)
    80002ff2:	6902                	ld	s2,0(sp)
    80002ff4:	6105                	addi	sp,sp,32
    80002ff6:	8082                	ret

0000000080002ff8 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80002ff8:	00015797          	auipc	a5,0x15
    80002ffc:	bd47a783          	lw	a5,-1068(a5) # 80017bcc <log+0x2c>
    80003000:	08f05f63          	blez	a5,8000309e <install_trans+0xa6>
{
    80003004:	7139                	addi	sp,sp,-64
    80003006:	fc06                	sd	ra,56(sp)
    80003008:	f822                	sd	s0,48(sp)
    8000300a:	f426                	sd	s1,40(sp)
    8000300c:	f04a                	sd	s2,32(sp)
    8000300e:	ec4e                	sd	s3,24(sp)
    80003010:	e852                	sd	s4,16(sp)
    80003012:	e456                	sd	s5,8(sp)
    80003014:	e05a                	sd	s6,0(sp)
    80003016:	0080                	addi	s0,sp,64
    80003018:	8b2a                	mv	s6,a0
    8000301a:	00015a97          	auipc	s5,0x15
    8000301e:	bb6a8a93          	addi	s5,s5,-1098 # 80017bd0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003022:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003024:	00015997          	auipc	s3,0x15
    80003028:	b7c98993          	addi	s3,s3,-1156 # 80017ba0 <log>
    8000302c:	a829                	j	80003046 <install_trans+0x4e>
    brelse(lbuf);
    8000302e:	854a                	mv	a0,s2
    80003030:	a5cff0ef          	jal	ra,8000228c <brelse>
    brelse(dbuf);
    80003034:	8526                	mv	a0,s1
    80003036:	a56ff0ef          	jal	ra,8000228c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000303a:	2a05                	addiw	s4,s4,1
    8000303c:	0a91                	addi	s5,s5,4
    8000303e:	02c9a783          	lw	a5,44(s3)
    80003042:	04fa5463          	bge	s4,a5,8000308a <install_trans+0x92>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003046:	0189a583          	lw	a1,24(s3)
    8000304a:	014585bb          	addw	a1,a1,s4
    8000304e:	2585                	addiw	a1,a1,1
    80003050:	0289a503          	lw	a0,40(s3)
    80003054:	930ff0ef          	jal	ra,80002184 <bread>
    80003058:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    8000305a:	000aa583          	lw	a1,0(s5)
    8000305e:	0289a503          	lw	a0,40(s3)
    80003062:	922ff0ef          	jal	ra,80002184 <bread>
    80003066:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003068:	40000613          	li	a2,1024
    8000306c:	05890593          	addi	a1,s2,88
    80003070:	05850513          	addi	a0,a0,88
    80003074:	934fd0ef          	jal	ra,800001a8 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003078:	8526                	mv	a0,s1
    8000307a:	9e0ff0ef          	jal	ra,8000225a <bwrite>
    if(recovering == 0)
    8000307e:	fa0b18e3          	bnez	s6,8000302e <install_trans+0x36>
      bunpin(dbuf);
    80003082:	8526                	mv	a0,s1
    80003084:	ac6ff0ef          	jal	ra,8000234a <bunpin>
    80003088:	b75d                	j	8000302e <install_trans+0x36>
}
    8000308a:	70e2                	ld	ra,56(sp)
    8000308c:	7442                	ld	s0,48(sp)
    8000308e:	74a2                	ld	s1,40(sp)
    80003090:	7902                	ld	s2,32(sp)
    80003092:	69e2                	ld	s3,24(sp)
    80003094:	6a42                	ld	s4,16(sp)
    80003096:	6aa2                	ld	s5,8(sp)
    80003098:	6b02                	ld	s6,0(sp)
    8000309a:	6121                	addi	sp,sp,64
    8000309c:	8082                	ret
    8000309e:	8082                	ret

00000000800030a0 <initlog>:
{
    800030a0:	7179                	addi	sp,sp,-48
    800030a2:	f406                	sd	ra,40(sp)
    800030a4:	f022                	sd	s0,32(sp)
    800030a6:	ec26                	sd	s1,24(sp)
    800030a8:	e84a                	sd	s2,16(sp)
    800030aa:	e44e                	sd	s3,8(sp)
    800030ac:	1800                	addi	s0,sp,48
    800030ae:	892a                	mv	s2,a0
    800030b0:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    800030b2:	00015497          	auipc	s1,0x15
    800030b6:	aee48493          	addi	s1,s1,-1298 # 80017ba0 <log>
    800030ba:	00004597          	auipc	a1,0x4
    800030be:	5ee58593          	addi	a1,a1,1518 # 800076a8 <syscalls+0x248>
    800030c2:	8526                	mv	a0,s1
    800030c4:	6f6020ef          	jal	ra,800057ba <initlock>
  log.start = sb->logstart;
    800030c8:	0149a583          	lw	a1,20(s3)
    800030cc:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    800030ce:	0109a783          	lw	a5,16(s3)
    800030d2:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    800030d4:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    800030d8:	854a                	mv	a0,s2
    800030da:	8aaff0ef          	jal	ra,80002184 <bread>
  log.lh.n = lh->n;
    800030de:	4d34                	lw	a3,88(a0)
    800030e0:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    800030e2:	02d05663          	blez	a3,8000310e <initlog+0x6e>
    800030e6:	05c50793          	addi	a5,a0,92
    800030ea:	00015717          	auipc	a4,0x15
    800030ee:	ae670713          	addi	a4,a4,-1306 # 80017bd0 <log+0x30>
    800030f2:	36fd                	addiw	a3,a3,-1
    800030f4:	02069613          	slli	a2,a3,0x20
    800030f8:	01e65693          	srli	a3,a2,0x1e
    800030fc:	06050613          	addi	a2,a0,96
    80003100:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    80003102:	4390                	lw	a2,0(a5)
    80003104:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003106:	0791                	addi	a5,a5,4
    80003108:	0711                	addi	a4,a4,4
    8000310a:	fed79ce3          	bne	a5,a3,80003102 <initlog+0x62>
  brelse(buf);
    8000310e:	97eff0ef          	jal	ra,8000228c <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003112:	4505                	li	a0,1
    80003114:	ee5ff0ef          	jal	ra,80002ff8 <install_trans>
  log.lh.n = 0;
    80003118:	00015797          	auipc	a5,0x15
    8000311c:	aa07aa23          	sw	zero,-1356(a5) # 80017bcc <log+0x2c>
  write_head(); // clear the log
    80003120:	e69ff0ef          	jal	ra,80002f88 <write_head>
}
    80003124:	70a2                	ld	ra,40(sp)
    80003126:	7402                	ld	s0,32(sp)
    80003128:	64e2                	ld	s1,24(sp)
    8000312a:	6942                	ld	s2,16(sp)
    8000312c:	69a2                	ld	s3,8(sp)
    8000312e:	6145                	addi	sp,sp,48
    80003130:	8082                	ret

0000000080003132 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003132:	1101                	addi	sp,sp,-32
    80003134:	ec06                	sd	ra,24(sp)
    80003136:	e822                	sd	s0,16(sp)
    80003138:	e426                	sd	s1,8(sp)
    8000313a:	e04a                	sd	s2,0(sp)
    8000313c:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000313e:	00015517          	auipc	a0,0x15
    80003142:	a6250513          	addi	a0,a0,-1438 # 80017ba0 <log>
    80003146:	6f4020ef          	jal	ra,8000583a <acquire>
  while(1){
    if(log.committing){
    8000314a:	00015497          	auipc	s1,0x15
    8000314e:	a5648493          	addi	s1,s1,-1450 # 80017ba0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003152:	4979                	li	s2,30
    80003154:	a029                	j	8000315e <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003156:	85a6                	mv	a1,s1
    80003158:	8526                	mv	a0,s1
    8000315a:	b30fe0ef          	jal	ra,8000148a <sleep>
    if(log.committing){
    8000315e:	50dc                	lw	a5,36(s1)
    80003160:	fbfd                	bnez	a5,80003156 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003162:	509c                	lw	a5,32(s1)
    80003164:	0017871b          	addiw	a4,a5,1
    80003168:	0007069b          	sext.w	a3,a4
    8000316c:	0027179b          	slliw	a5,a4,0x2
    80003170:	9fb9                	addw	a5,a5,a4
    80003172:	0017979b          	slliw	a5,a5,0x1
    80003176:	54d8                	lw	a4,44(s1)
    80003178:	9fb9                	addw	a5,a5,a4
    8000317a:	00f95763          	bge	s2,a5,80003188 <begin_op+0x56>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    8000317e:	85a6                	mv	a1,s1
    80003180:	8526                	mv	a0,s1
    80003182:	b08fe0ef          	jal	ra,8000148a <sleep>
    80003186:	bfe1                	j	8000315e <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003188:	00015517          	auipc	a0,0x15
    8000318c:	a1850513          	addi	a0,a0,-1512 # 80017ba0 <log>
    80003190:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80003192:	740020ef          	jal	ra,800058d2 <release>
      break;
    }
  }
}
    80003196:	60e2                	ld	ra,24(sp)
    80003198:	6442                	ld	s0,16(sp)
    8000319a:	64a2                	ld	s1,8(sp)
    8000319c:	6902                	ld	s2,0(sp)
    8000319e:	6105                	addi	sp,sp,32
    800031a0:	8082                	ret

00000000800031a2 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    800031a2:	7139                	addi	sp,sp,-64
    800031a4:	fc06                	sd	ra,56(sp)
    800031a6:	f822                	sd	s0,48(sp)
    800031a8:	f426                	sd	s1,40(sp)
    800031aa:	f04a                	sd	s2,32(sp)
    800031ac:	ec4e                	sd	s3,24(sp)
    800031ae:	e852                	sd	s4,16(sp)
    800031b0:	e456                	sd	s5,8(sp)
    800031b2:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800031b4:	00015497          	auipc	s1,0x15
    800031b8:	9ec48493          	addi	s1,s1,-1556 # 80017ba0 <log>
    800031bc:	8526                	mv	a0,s1
    800031be:	67c020ef          	jal	ra,8000583a <acquire>
  log.outstanding -= 1;
    800031c2:	509c                	lw	a5,32(s1)
    800031c4:	37fd                	addiw	a5,a5,-1
    800031c6:	0007891b          	sext.w	s2,a5
    800031ca:	d09c                	sw	a5,32(s1)
  if(log.committing)
    800031cc:	50dc                	lw	a5,36(s1)
    800031ce:	ef9d                	bnez	a5,8000320c <end_op+0x6a>
    panic("log.committing");
  if(log.outstanding == 0){
    800031d0:	04091463          	bnez	s2,80003218 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    800031d4:	00015497          	auipc	s1,0x15
    800031d8:	9cc48493          	addi	s1,s1,-1588 # 80017ba0 <log>
    800031dc:	4785                	li	a5,1
    800031de:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800031e0:	8526                	mv	a0,s1
    800031e2:	6f0020ef          	jal	ra,800058d2 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800031e6:	54dc                	lw	a5,44(s1)
    800031e8:	04f04b63          	bgtz	a5,8000323e <end_op+0x9c>
    acquire(&log.lock);
    800031ec:	00015497          	auipc	s1,0x15
    800031f0:	9b448493          	addi	s1,s1,-1612 # 80017ba0 <log>
    800031f4:	8526                	mv	a0,s1
    800031f6:	644020ef          	jal	ra,8000583a <acquire>
    log.committing = 0;
    800031fa:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    800031fe:	8526                	mv	a0,s1
    80003200:	ad6fe0ef          	jal	ra,800014d6 <wakeup>
    release(&log.lock);
    80003204:	8526                	mv	a0,s1
    80003206:	6cc020ef          	jal	ra,800058d2 <release>
}
    8000320a:	a00d                	j	8000322c <end_op+0x8a>
    panic("log.committing");
    8000320c:	00004517          	auipc	a0,0x4
    80003210:	4a450513          	addi	a0,a0,1188 # 800076b0 <syscalls+0x250>
    80003214:	312020ef          	jal	ra,80005526 <panic>
    wakeup(&log);
    80003218:	00015497          	auipc	s1,0x15
    8000321c:	98848493          	addi	s1,s1,-1656 # 80017ba0 <log>
    80003220:	8526                	mv	a0,s1
    80003222:	ab4fe0ef          	jal	ra,800014d6 <wakeup>
  release(&log.lock);
    80003226:	8526                	mv	a0,s1
    80003228:	6aa020ef          	jal	ra,800058d2 <release>
}
    8000322c:	70e2                	ld	ra,56(sp)
    8000322e:	7442                	ld	s0,48(sp)
    80003230:	74a2                	ld	s1,40(sp)
    80003232:	7902                	ld	s2,32(sp)
    80003234:	69e2                	ld	s3,24(sp)
    80003236:	6a42                	ld	s4,16(sp)
    80003238:	6aa2                	ld	s5,8(sp)
    8000323a:	6121                	addi	sp,sp,64
    8000323c:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    8000323e:	00015a97          	auipc	s5,0x15
    80003242:	992a8a93          	addi	s5,s5,-1646 # 80017bd0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003246:	00015a17          	auipc	s4,0x15
    8000324a:	95aa0a13          	addi	s4,s4,-1702 # 80017ba0 <log>
    8000324e:	018a2583          	lw	a1,24(s4)
    80003252:	012585bb          	addw	a1,a1,s2
    80003256:	2585                	addiw	a1,a1,1
    80003258:	028a2503          	lw	a0,40(s4)
    8000325c:	f29fe0ef          	jal	ra,80002184 <bread>
    80003260:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003262:	000aa583          	lw	a1,0(s5)
    80003266:	028a2503          	lw	a0,40(s4)
    8000326a:	f1bfe0ef          	jal	ra,80002184 <bread>
    8000326e:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003270:	40000613          	li	a2,1024
    80003274:	05850593          	addi	a1,a0,88
    80003278:	05848513          	addi	a0,s1,88
    8000327c:	f2dfc0ef          	jal	ra,800001a8 <memmove>
    bwrite(to);  // write the log
    80003280:	8526                	mv	a0,s1
    80003282:	fd9fe0ef          	jal	ra,8000225a <bwrite>
    brelse(from);
    80003286:	854e                	mv	a0,s3
    80003288:	804ff0ef          	jal	ra,8000228c <brelse>
    brelse(to);
    8000328c:	8526                	mv	a0,s1
    8000328e:	ffffe0ef          	jal	ra,8000228c <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003292:	2905                	addiw	s2,s2,1
    80003294:	0a91                	addi	s5,s5,4
    80003296:	02ca2783          	lw	a5,44(s4)
    8000329a:	faf94ae3          	blt	s2,a5,8000324e <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    8000329e:	cebff0ef          	jal	ra,80002f88 <write_head>
    install_trans(0); // Now install writes to home locations
    800032a2:	4501                	li	a0,0
    800032a4:	d55ff0ef          	jal	ra,80002ff8 <install_trans>
    log.lh.n = 0;
    800032a8:	00015797          	auipc	a5,0x15
    800032ac:	9207a223          	sw	zero,-1756(a5) # 80017bcc <log+0x2c>
    write_head();    // Erase the transaction from the log
    800032b0:	cd9ff0ef          	jal	ra,80002f88 <write_head>
    800032b4:	bf25                	j	800031ec <end_op+0x4a>

00000000800032b6 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800032b6:	1101                	addi	sp,sp,-32
    800032b8:	ec06                	sd	ra,24(sp)
    800032ba:	e822                	sd	s0,16(sp)
    800032bc:	e426                	sd	s1,8(sp)
    800032be:	e04a                	sd	s2,0(sp)
    800032c0:	1000                	addi	s0,sp,32
    800032c2:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800032c4:	00015917          	auipc	s2,0x15
    800032c8:	8dc90913          	addi	s2,s2,-1828 # 80017ba0 <log>
    800032cc:	854a                	mv	a0,s2
    800032ce:	56c020ef          	jal	ra,8000583a <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    800032d2:	02c92603          	lw	a2,44(s2)
    800032d6:	47f5                	li	a5,29
    800032d8:	06c7c363          	blt	a5,a2,8000333e <log_write+0x88>
    800032dc:	00015797          	auipc	a5,0x15
    800032e0:	8e07a783          	lw	a5,-1824(a5) # 80017bbc <log+0x1c>
    800032e4:	37fd                	addiw	a5,a5,-1
    800032e6:	04f65c63          	bge	a2,a5,8000333e <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800032ea:	00015797          	auipc	a5,0x15
    800032ee:	8d67a783          	lw	a5,-1834(a5) # 80017bc0 <log+0x20>
    800032f2:	04f05c63          	blez	a5,8000334a <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800032f6:	4781                	li	a5,0
    800032f8:	04c05f63          	blez	a2,80003356 <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800032fc:	44cc                	lw	a1,12(s1)
    800032fe:	00015717          	auipc	a4,0x15
    80003302:	8d270713          	addi	a4,a4,-1838 # 80017bd0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003306:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003308:	4314                	lw	a3,0(a4)
    8000330a:	04b68663          	beq	a3,a1,80003356 <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    8000330e:	2785                	addiw	a5,a5,1
    80003310:	0711                	addi	a4,a4,4
    80003312:	fef61be3          	bne	a2,a5,80003308 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003316:	0621                	addi	a2,a2,8
    80003318:	060a                	slli	a2,a2,0x2
    8000331a:	00015797          	auipc	a5,0x15
    8000331e:	88678793          	addi	a5,a5,-1914 # 80017ba0 <log>
    80003322:	963e                	add	a2,a2,a5
    80003324:	44dc                	lw	a5,12(s1)
    80003326:	ca1c                	sw	a5,16(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003328:	8526                	mv	a0,s1
    8000332a:	fedfe0ef          	jal	ra,80002316 <bpin>
    log.lh.n++;
    8000332e:	00015717          	auipc	a4,0x15
    80003332:	87270713          	addi	a4,a4,-1934 # 80017ba0 <log>
    80003336:	575c                	lw	a5,44(a4)
    80003338:	2785                	addiw	a5,a5,1
    8000333a:	d75c                	sw	a5,44(a4)
    8000333c:	a815                	j	80003370 <log_write+0xba>
    panic("too big a transaction");
    8000333e:	00004517          	auipc	a0,0x4
    80003342:	38250513          	addi	a0,a0,898 # 800076c0 <syscalls+0x260>
    80003346:	1e0020ef          	jal	ra,80005526 <panic>
    panic("log_write outside of trans");
    8000334a:	00004517          	auipc	a0,0x4
    8000334e:	38e50513          	addi	a0,a0,910 # 800076d8 <syscalls+0x278>
    80003352:	1d4020ef          	jal	ra,80005526 <panic>
  log.lh.block[i] = b->blockno;
    80003356:	00878713          	addi	a4,a5,8
    8000335a:	00271693          	slli	a3,a4,0x2
    8000335e:	00015717          	auipc	a4,0x15
    80003362:	84270713          	addi	a4,a4,-1982 # 80017ba0 <log>
    80003366:	9736                	add	a4,a4,a3
    80003368:	44d4                	lw	a3,12(s1)
    8000336a:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    8000336c:	faf60ee3          	beq	a2,a5,80003328 <log_write+0x72>
  }
  release(&log.lock);
    80003370:	00015517          	auipc	a0,0x15
    80003374:	83050513          	addi	a0,a0,-2000 # 80017ba0 <log>
    80003378:	55a020ef          	jal	ra,800058d2 <release>
}
    8000337c:	60e2                	ld	ra,24(sp)
    8000337e:	6442                	ld	s0,16(sp)
    80003380:	64a2                	ld	s1,8(sp)
    80003382:	6902                	ld	s2,0(sp)
    80003384:	6105                	addi	sp,sp,32
    80003386:	8082                	ret

0000000080003388 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003388:	1101                	addi	sp,sp,-32
    8000338a:	ec06                	sd	ra,24(sp)
    8000338c:	e822                	sd	s0,16(sp)
    8000338e:	e426                	sd	s1,8(sp)
    80003390:	e04a                	sd	s2,0(sp)
    80003392:	1000                	addi	s0,sp,32
    80003394:	84aa                	mv	s1,a0
    80003396:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003398:	00004597          	auipc	a1,0x4
    8000339c:	36058593          	addi	a1,a1,864 # 800076f8 <syscalls+0x298>
    800033a0:	0521                	addi	a0,a0,8
    800033a2:	418020ef          	jal	ra,800057ba <initlock>
  lk->name = name;
    800033a6:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800033aa:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800033ae:	0204a423          	sw	zero,40(s1)
}
    800033b2:	60e2                	ld	ra,24(sp)
    800033b4:	6442                	ld	s0,16(sp)
    800033b6:	64a2                	ld	s1,8(sp)
    800033b8:	6902                	ld	s2,0(sp)
    800033ba:	6105                	addi	sp,sp,32
    800033bc:	8082                	ret

00000000800033be <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800033be:	1101                	addi	sp,sp,-32
    800033c0:	ec06                	sd	ra,24(sp)
    800033c2:	e822                	sd	s0,16(sp)
    800033c4:	e426                	sd	s1,8(sp)
    800033c6:	e04a                	sd	s2,0(sp)
    800033c8:	1000                	addi	s0,sp,32
    800033ca:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800033cc:	00850913          	addi	s2,a0,8
    800033d0:	854a                	mv	a0,s2
    800033d2:	468020ef          	jal	ra,8000583a <acquire>
  while (lk->locked) {
    800033d6:	409c                	lw	a5,0(s1)
    800033d8:	c799                	beqz	a5,800033e6 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    800033da:	85ca                	mv	a1,s2
    800033dc:	8526                	mv	a0,s1
    800033de:	8acfe0ef          	jal	ra,8000148a <sleep>
  while (lk->locked) {
    800033e2:	409c                	lw	a5,0(s1)
    800033e4:	fbfd                	bnez	a5,800033da <acquiresleep+0x1c>
  }
  lk->locked = 1;
    800033e6:	4785                	li	a5,1
    800033e8:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800033ea:	a35fd0ef          	jal	ra,80000e1e <myproc>
    800033ee:	591c                	lw	a5,48(a0)
    800033f0:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800033f2:	854a                	mv	a0,s2
    800033f4:	4de020ef          	jal	ra,800058d2 <release>
}
    800033f8:	60e2                	ld	ra,24(sp)
    800033fa:	6442                	ld	s0,16(sp)
    800033fc:	64a2                	ld	s1,8(sp)
    800033fe:	6902                	ld	s2,0(sp)
    80003400:	6105                	addi	sp,sp,32
    80003402:	8082                	ret

0000000080003404 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003404:	1101                	addi	sp,sp,-32
    80003406:	ec06                	sd	ra,24(sp)
    80003408:	e822                	sd	s0,16(sp)
    8000340a:	e426                	sd	s1,8(sp)
    8000340c:	e04a                	sd	s2,0(sp)
    8000340e:	1000                	addi	s0,sp,32
    80003410:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003412:	00850913          	addi	s2,a0,8
    80003416:	854a                	mv	a0,s2
    80003418:	422020ef          	jal	ra,8000583a <acquire>
  lk->locked = 0;
    8000341c:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003420:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003424:	8526                	mv	a0,s1
    80003426:	8b0fe0ef          	jal	ra,800014d6 <wakeup>
  release(&lk->lk);
    8000342a:	854a                	mv	a0,s2
    8000342c:	4a6020ef          	jal	ra,800058d2 <release>
}
    80003430:	60e2                	ld	ra,24(sp)
    80003432:	6442                	ld	s0,16(sp)
    80003434:	64a2                	ld	s1,8(sp)
    80003436:	6902                	ld	s2,0(sp)
    80003438:	6105                	addi	sp,sp,32
    8000343a:	8082                	ret

000000008000343c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000343c:	7179                	addi	sp,sp,-48
    8000343e:	f406                	sd	ra,40(sp)
    80003440:	f022                	sd	s0,32(sp)
    80003442:	ec26                	sd	s1,24(sp)
    80003444:	e84a                	sd	s2,16(sp)
    80003446:	e44e                	sd	s3,8(sp)
    80003448:	1800                	addi	s0,sp,48
    8000344a:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    8000344c:	00850913          	addi	s2,a0,8
    80003450:	854a                	mv	a0,s2
    80003452:	3e8020ef          	jal	ra,8000583a <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003456:	409c                	lw	a5,0(s1)
    80003458:	ef89                	bnez	a5,80003472 <holdingsleep+0x36>
    8000345a:	4481                	li	s1,0
  release(&lk->lk);
    8000345c:	854a                	mv	a0,s2
    8000345e:	474020ef          	jal	ra,800058d2 <release>
  return r;
}
    80003462:	8526                	mv	a0,s1
    80003464:	70a2                	ld	ra,40(sp)
    80003466:	7402                	ld	s0,32(sp)
    80003468:	64e2                	ld	s1,24(sp)
    8000346a:	6942                	ld	s2,16(sp)
    8000346c:	69a2                	ld	s3,8(sp)
    8000346e:	6145                	addi	sp,sp,48
    80003470:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80003472:	0284a983          	lw	s3,40(s1)
    80003476:	9a9fd0ef          	jal	ra,80000e1e <myproc>
    8000347a:	5904                	lw	s1,48(a0)
    8000347c:	413484b3          	sub	s1,s1,s3
    80003480:	0014b493          	seqz	s1,s1
    80003484:	bfe1                	j	8000345c <holdingsleep+0x20>

0000000080003486 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003486:	1141                	addi	sp,sp,-16
    80003488:	e406                	sd	ra,8(sp)
    8000348a:	e022                	sd	s0,0(sp)
    8000348c:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    8000348e:	00004597          	auipc	a1,0x4
    80003492:	27a58593          	addi	a1,a1,634 # 80007708 <syscalls+0x2a8>
    80003496:	00015517          	auipc	a0,0x15
    8000349a:	85250513          	addi	a0,a0,-1966 # 80017ce8 <ftable>
    8000349e:	31c020ef          	jal	ra,800057ba <initlock>
}
    800034a2:	60a2                	ld	ra,8(sp)
    800034a4:	6402                	ld	s0,0(sp)
    800034a6:	0141                	addi	sp,sp,16
    800034a8:	8082                	ret

00000000800034aa <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    800034aa:	1101                	addi	sp,sp,-32
    800034ac:	ec06                	sd	ra,24(sp)
    800034ae:	e822                	sd	s0,16(sp)
    800034b0:	e426                	sd	s1,8(sp)
    800034b2:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800034b4:	00015517          	auipc	a0,0x15
    800034b8:	83450513          	addi	a0,a0,-1996 # 80017ce8 <ftable>
    800034bc:	37e020ef          	jal	ra,8000583a <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800034c0:	00015497          	auipc	s1,0x15
    800034c4:	84048493          	addi	s1,s1,-1984 # 80017d00 <ftable+0x18>
    800034c8:	00015717          	auipc	a4,0x15
    800034cc:	7d870713          	addi	a4,a4,2008 # 80018ca0 <disk>
    if(f->ref == 0){
    800034d0:	40dc                	lw	a5,4(s1)
    800034d2:	cf89                	beqz	a5,800034ec <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800034d4:	02848493          	addi	s1,s1,40
    800034d8:	fee49ce3          	bne	s1,a4,800034d0 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800034dc:	00015517          	auipc	a0,0x15
    800034e0:	80c50513          	addi	a0,a0,-2036 # 80017ce8 <ftable>
    800034e4:	3ee020ef          	jal	ra,800058d2 <release>
  return 0;
    800034e8:	4481                	li	s1,0
    800034ea:	a809                	j	800034fc <filealloc+0x52>
      f->ref = 1;
    800034ec:	4785                	li	a5,1
    800034ee:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800034f0:	00014517          	auipc	a0,0x14
    800034f4:	7f850513          	addi	a0,a0,2040 # 80017ce8 <ftable>
    800034f8:	3da020ef          	jal	ra,800058d2 <release>
}
    800034fc:	8526                	mv	a0,s1
    800034fe:	60e2                	ld	ra,24(sp)
    80003500:	6442                	ld	s0,16(sp)
    80003502:	64a2                	ld	s1,8(sp)
    80003504:	6105                	addi	sp,sp,32
    80003506:	8082                	ret

0000000080003508 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003508:	1101                	addi	sp,sp,-32
    8000350a:	ec06                	sd	ra,24(sp)
    8000350c:	e822                	sd	s0,16(sp)
    8000350e:	e426                	sd	s1,8(sp)
    80003510:	1000                	addi	s0,sp,32
    80003512:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003514:	00014517          	auipc	a0,0x14
    80003518:	7d450513          	addi	a0,a0,2004 # 80017ce8 <ftable>
    8000351c:	31e020ef          	jal	ra,8000583a <acquire>
  if(f->ref < 1)
    80003520:	40dc                	lw	a5,4(s1)
    80003522:	02f05063          	blez	a5,80003542 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003526:	2785                	addiw	a5,a5,1
    80003528:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000352a:	00014517          	auipc	a0,0x14
    8000352e:	7be50513          	addi	a0,a0,1982 # 80017ce8 <ftable>
    80003532:	3a0020ef          	jal	ra,800058d2 <release>
  return f;
}
    80003536:	8526                	mv	a0,s1
    80003538:	60e2                	ld	ra,24(sp)
    8000353a:	6442                	ld	s0,16(sp)
    8000353c:	64a2                	ld	s1,8(sp)
    8000353e:	6105                	addi	sp,sp,32
    80003540:	8082                	ret
    panic("filedup");
    80003542:	00004517          	auipc	a0,0x4
    80003546:	1ce50513          	addi	a0,a0,462 # 80007710 <syscalls+0x2b0>
    8000354a:	7dd010ef          	jal	ra,80005526 <panic>

000000008000354e <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    8000354e:	7139                	addi	sp,sp,-64
    80003550:	fc06                	sd	ra,56(sp)
    80003552:	f822                	sd	s0,48(sp)
    80003554:	f426                	sd	s1,40(sp)
    80003556:	f04a                	sd	s2,32(sp)
    80003558:	ec4e                	sd	s3,24(sp)
    8000355a:	e852                	sd	s4,16(sp)
    8000355c:	e456                	sd	s5,8(sp)
    8000355e:	0080                	addi	s0,sp,64
    80003560:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003562:	00014517          	auipc	a0,0x14
    80003566:	78650513          	addi	a0,a0,1926 # 80017ce8 <ftable>
    8000356a:	2d0020ef          	jal	ra,8000583a <acquire>
  if(f->ref < 1)
    8000356e:	40dc                	lw	a5,4(s1)
    80003570:	04f05963          	blez	a5,800035c2 <fileclose+0x74>
    panic("fileclose");
  if(--f->ref > 0){
    80003574:	37fd                	addiw	a5,a5,-1
    80003576:	0007871b          	sext.w	a4,a5
    8000357a:	c0dc                	sw	a5,4(s1)
    8000357c:	04e04963          	bgtz	a4,800035ce <fileclose+0x80>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003580:	0004a903          	lw	s2,0(s1)
    80003584:	0094ca83          	lbu	s5,9(s1)
    80003588:	0104ba03          	ld	s4,16(s1)
    8000358c:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80003590:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003594:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003598:	00014517          	auipc	a0,0x14
    8000359c:	75050513          	addi	a0,a0,1872 # 80017ce8 <ftable>
    800035a0:	332020ef          	jal	ra,800058d2 <release>

  if(ff.type == FD_PIPE){
    800035a4:	4785                	li	a5,1
    800035a6:	04f90363          	beq	s2,a5,800035ec <fileclose+0x9e>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800035aa:	3979                	addiw	s2,s2,-2
    800035ac:	4785                	li	a5,1
    800035ae:	0327e663          	bltu	a5,s2,800035da <fileclose+0x8c>
    begin_op();
    800035b2:	b81ff0ef          	jal	ra,80003132 <begin_op>
    iput(ff.ip);
    800035b6:	854e                	mv	a0,s3
    800035b8:	c6aff0ef          	jal	ra,80002a22 <iput>
    end_op();
    800035bc:	be7ff0ef          	jal	ra,800031a2 <end_op>
    800035c0:	a829                	j	800035da <fileclose+0x8c>
    panic("fileclose");
    800035c2:	00004517          	auipc	a0,0x4
    800035c6:	15650513          	addi	a0,a0,342 # 80007718 <syscalls+0x2b8>
    800035ca:	75d010ef          	jal	ra,80005526 <panic>
    release(&ftable.lock);
    800035ce:	00014517          	auipc	a0,0x14
    800035d2:	71a50513          	addi	a0,a0,1818 # 80017ce8 <ftable>
    800035d6:	2fc020ef          	jal	ra,800058d2 <release>
  }
}
    800035da:	70e2                	ld	ra,56(sp)
    800035dc:	7442                	ld	s0,48(sp)
    800035de:	74a2                	ld	s1,40(sp)
    800035e0:	7902                	ld	s2,32(sp)
    800035e2:	69e2                	ld	s3,24(sp)
    800035e4:	6a42                	ld	s4,16(sp)
    800035e6:	6aa2                	ld	s5,8(sp)
    800035e8:	6121                	addi	sp,sp,64
    800035ea:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800035ec:	85d6                	mv	a1,s5
    800035ee:	8552                	mv	a0,s4
    800035f0:	2ec000ef          	jal	ra,800038dc <pipeclose>
    800035f4:	b7dd                	j	800035da <fileclose+0x8c>

00000000800035f6 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800035f6:	715d                	addi	sp,sp,-80
    800035f8:	e486                	sd	ra,72(sp)
    800035fa:	e0a2                	sd	s0,64(sp)
    800035fc:	fc26                	sd	s1,56(sp)
    800035fe:	f84a                	sd	s2,48(sp)
    80003600:	f44e                	sd	s3,40(sp)
    80003602:	0880                	addi	s0,sp,80
    80003604:	84aa                	mv	s1,a0
    80003606:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80003608:	817fd0ef          	jal	ra,80000e1e <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    8000360c:	409c                	lw	a5,0(s1)
    8000360e:	37f9                	addiw	a5,a5,-2
    80003610:	4705                	li	a4,1
    80003612:	02f76f63          	bltu	a4,a5,80003650 <filestat+0x5a>
    80003616:	892a                	mv	s2,a0
    ilock(f->ip);
    80003618:	6c88                	ld	a0,24(s1)
    8000361a:	a8aff0ef          	jal	ra,800028a4 <ilock>
    stati(f->ip, &st);
    8000361e:	fb840593          	addi	a1,s0,-72
    80003622:	6c88                	ld	a0,24(s1)
    80003624:	ca6ff0ef          	jal	ra,80002aca <stati>
    iunlock(f->ip);
    80003628:	6c88                	ld	a0,24(s1)
    8000362a:	b24ff0ef          	jal	ra,8000294e <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000362e:	46e1                	li	a3,24
    80003630:	fb840613          	addi	a2,s0,-72
    80003634:	85ce                	mv	a1,s3
    80003636:	05093503          	ld	a0,80(s2)
    8000363a:	b9cfd0ef          	jal	ra,800009d6 <copyout>
    8000363e:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    80003642:	60a6                	ld	ra,72(sp)
    80003644:	6406                	ld	s0,64(sp)
    80003646:	74e2                	ld	s1,56(sp)
    80003648:	7942                	ld	s2,48(sp)
    8000364a:	79a2                	ld	s3,40(sp)
    8000364c:	6161                	addi	sp,sp,80
    8000364e:	8082                	ret
  return -1;
    80003650:	557d                	li	a0,-1
    80003652:	bfc5                	j	80003642 <filestat+0x4c>

0000000080003654 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003654:	7179                	addi	sp,sp,-48
    80003656:	f406                	sd	ra,40(sp)
    80003658:	f022                	sd	s0,32(sp)
    8000365a:	ec26                	sd	s1,24(sp)
    8000365c:	e84a                	sd	s2,16(sp)
    8000365e:	e44e                	sd	s3,8(sp)
    80003660:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003662:	00854783          	lbu	a5,8(a0)
    80003666:	cbc1                	beqz	a5,800036f6 <fileread+0xa2>
    80003668:	84aa                	mv	s1,a0
    8000366a:	89ae                	mv	s3,a1
    8000366c:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    8000366e:	411c                	lw	a5,0(a0)
    80003670:	4705                	li	a4,1
    80003672:	04e78363          	beq	a5,a4,800036b8 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003676:	470d                	li	a4,3
    80003678:	04e78563          	beq	a5,a4,800036c2 <fileread+0x6e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    8000367c:	4709                	li	a4,2
    8000367e:	06e79663          	bne	a5,a4,800036ea <fileread+0x96>
    ilock(f->ip);
    80003682:	6d08                	ld	a0,24(a0)
    80003684:	a20ff0ef          	jal	ra,800028a4 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80003688:	874a                	mv	a4,s2
    8000368a:	5094                	lw	a3,32(s1)
    8000368c:	864e                	mv	a2,s3
    8000368e:	4585                	li	a1,1
    80003690:	6c88                	ld	a0,24(s1)
    80003692:	c62ff0ef          	jal	ra,80002af4 <readi>
    80003696:	892a                	mv	s2,a0
    80003698:	00a05563          	blez	a0,800036a2 <fileread+0x4e>
      f->off += r;
    8000369c:	509c                	lw	a5,32(s1)
    8000369e:	9fa9                	addw	a5,a5,a0
    800036a0:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800036a2:	6c88                	ld	a0,24(s1)
    800036a4:	aaaff0ef          	jal	ra,8000294e <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    800036a8:	854a                	mv	a0,s2
    800036aa:	70a2                	ld	ra,40(sp)
    800036ac:	7402                	ld	s0,32(sp)
    800036ae:	64e2                	ld	s1,24(sp)
    800036b0:	6942                	ld	s2,16(sp)
    800036b2:	69a2                	ld	s3,8(sp)
    800036b4:	6145                	addi	sp,sp,48
    800036b6:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800036b8:	6908                	ld	a0,16(a0)
    800036ba:	34e000ef          	jal	ra,80003a08 <piperead>
    800036be:	892a                	mv	s2,a0
    800036c0:	b7e5                	j	800036a8 <fileread+0x54>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800036c2:	02451783          	lh	a5,36(a0)
    800036c6:	03079693          	slli	a3,a5,0x30
    800036ca:	92c1                	srli	a3,a3,0x30
    800036cc:	4725                	li	a4,9
    800036ce:	02d76663          	bltu	a4,a3,800036fa <fileread+0xa6>
    800036d2:	0792                	slli	a5,a5,0x4
    800036d4:	00014717          	auipc	a4,0x14
    800036d8:	57470713          	addi	a4,a4,1396 # 80017c48 <devsw>
    800036dc:	97ba                	add	a5,a5,a4
    800036de:	639c                	ld	a5,0(a5)
    800036e0:	cf99                	beqz	a5,800036fe <fileread+0xaa>
    r = devsw[f->major].read(1, addr, n);
    800036e2:	4505                	li	a0,1
    800036e4:	9782                	jalr	a5
    800036e6:	892a                	mv	s2,a0
    800036e8:	b7c1                	j	800036a8 <fileread+0x54>
    panic("fileread");
    800036ea:	00004517          	auipc	a0,0x4
    800036ee:	03e50513          	addi	a0,a0,62 # 80007728 <syscalls+0x2c8>
    800036f2:	635010ef          	jal	ra,80005526 <panic>
    return -1;
    800036f6:	597d                	li	s2,-1
    800036f8:	bf45                	j	800036a8 <fileread+0x54>
      return -1;
    800036fa:	597d                	li	s2,-1
    800036fc:	b775                	j	800036a8 <fileread+0x54>
    800036fe:	597d                	li	s2,-1
    80003700:	b765                	j	800036a8 <fileread+0x54>

0000000080003702 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    80003702:	715d                	addi	sp,sp,-80
    80003704:	e486                	sd	ra,72(sp)
    80003706:	e0a2                	sd	s0,64(sp)
    80003708:	fc26                	sd	s1,56(sp)
    8000370a:	f84a                	sd	s2,48(sp)
    8000370c:	f44e                	sd	s3,40(sp)
    8000370e:	f052                	sd	s4,32(sp)
    80003710:	ec56                	sd	s5,24(sp)
    80003712:	e85a                	sd	s6,16(sp)
    80003714:	e45e                	sd	s7,8(sp)
    80003716:	e062                	sd	s8,0(sp)
    80003718:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    8000371a:	00954783          	lbu	a5,9(a0)
    8000371e:	0e078863          	beqz	a5,8000380e <filewrite+0x10c>
    80003722:	892a                	mv	s2,a0
    80003724:	8aae                	mv	s5,a1
    80003726:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    80003728:	411c                	lw	a5,0(a0)
    8000372a:	4705                	li	a4,1
    8000372c:	02e78263          	beq	a5,a4,80003750 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003730:	470d                	li	a4,3
    80003732:	02e78463          	beq	a5,a4,8000375a <filewrite+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80003736:	4709                	li	a4,2
    80003738:	0ce79563          	bne	a5,a4,80003802 <filewrite+0x100>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    8000373c:	0ac05163          	blez	a2,800037de <filewrite+0xdc>
    int i = 0;
    80003740:	4981                	li	s3,0
    80003742:	6b05                	lui	s6,0x1
    80003744:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    80003748:	6b85                	lui	s7,0x1
    8000374a:	c00b8b9b          	addiw	s7,s7,-1024
    8000374e:	a041                	j	800037ce <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80003750:	6908                	ld	a0,16(a0)
    80003752:	1e2000ef          	jal	ra,80003934 <pipewrite>
    80003756:	8a2a                	mv	s4,a0
    80003758:	a071                	j	800037e4 <filewrite+0xe2>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000375a:	02451783          	lh	a5,36(a0)
    8000375e:	03079693          	slli	a3,a5,0x30
    80003762:	92c1                	srli	a3,a3,0x30
    80003764:	4725                	li	a4,9
    80003766:	0ad76663          	bltu	a4,a3,80003812 <filewrite+0x110>
    8000376a:	0792                	slli	a5,a5,0x4
    8000376c:	00014717          	auipc	a4,0x14
    80003770:	4dc70713          	addi	a4,a4,1244 # 80017c48 <devsw>
    80003774:	97ba                	add	a5,a5,a4
    80003776:	679c                	ld	a5,8(a5)
    80003778:	cfd9                	beqz	a5,80003816 <filewrite+0x114>
    ret = devsw[f->major].write(1, addr, n);
    8000377a:	4505                	li	a0,1
    8000377c:	9782                	jalr	a5
    8000377e:	8a2a                	mv	s4,a0
    80003780:	a095                	j	800037e4 <filewrite+0xe2>
    80003782:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    80003786:	9adff0ef          	jal	ra,80003132 <begin_op>
      ilock(f->ip);
    8000378a:	01893503          	ld	a0,24(s2)
    8000378e:	916ff0ef          	jal	ra,800028a4 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80003792:	8762                	mv	a4,s8
    80003794:	02092683          	lw	a3,32(s2)
    80003798:	01598633          	add	a2,s3,s5
    8000379c:	4585                	li	a1,1
    8000379e:	01893503          	ld	a0,24(s2)
    800037a2:	c36ff0ef          	jal	ra,80002bd8 <writei>
    800037a6:	84aa                	mv	s1,a0
    800037a8:	00a05763          	blez	a0,800037b6 <filewrite+0xb4>
        f->off += r;
    800037ac:	02092783          	lw	a5,32(s2)
    800037b0:	9fa9                	addw	a5,a5,a0
    800037b2:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800037b6:	01893503          	ld	a0,24(s2)
    800037ba:	994ff0ef          	jal	ra,8000294e <iunlock>
      end_op();
    800037be:	9e5ff0ef          	jal	ra,800031a2 <end_op>

      if(r != n1){
    800037c2:	009c1f63          	bne	s8,s1,800037e0 <filewrite+0xde>
        // error from writei
        break;
      }
      i += r;
    800037c6:	013489bb          	addw	s3,s1,s3
    while(i < n){
    800037ca:	0149db63          	bge	s3,s4,800037e0 <filewrite+0xde>
      int n1 = n - i;
    800037ce:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    800037d2:	84be                	mv	s1,a5
    800037d4:	2781                	sext.w	a5,a5
    800037d6:	fafb56e3          	bge	s6,a5,80003782 <filewrite+0x80>
    800037da:	84de                	mv	s1,s7
    800037dc:	b75d                	j	80003782 <filewrite+0x80>
    int i = 0;
    800037de:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    800037e0:	013a1f63          	bne	s4,s3,800037fe <filewrite+0xfc>
  } else {
    panic("filewrite");
  }

  return ret;
}
    800037e4:	8552                	mv	a0,s4
    800037e6:	60a6                	ld	ra,72(sp)
    800037e8:	6406                	ld	s0,64(sp)
    800037ea:	74e2                	ld	s1,56(sp)
    800037ec:	7942                	ld	s2,48(sp)
    800037ee:	79a2                	ld	s3,40(sp)
    800037f0:	7a02                	ld	s4,32(sp)
    800037f2:	6ae2                	ld	s5,24(sp)
    800037f4:	6b42                	ld	s6,16(sp)
    800037f6:	6ba2                	ld	s7,8(sp)
    800037f8:	6c02                	ld	s8,0(sp)
    800037fa:	6161                	addi	sp,sp,80
    800037fc:	8082                	ret
    ret = (i == n ? n : -1);
    800037fe:	5a7d                	li	s4,-1
    80003800:	b7d5                	j	800037e4 <filewrite+0xe2>
    panic("filewrite");
    80003802:	00004517          	auipc	a0,0x4
    80003806:	f3650513          	addi	a0,a0,-202 # 80007738 <syscalls+0x2d8>
    8000380a:	51d010ef          	jal	ra,80005526 <panic>
    return -1;
    8000380e:	5a7d                	li	s4,-1
    80003810:	bfd1                	j	800037e4 <filewrite+0xe2>
      return -1;
    80003812:	5a7d                	li	s4,-1
    80003814:	bfc1                	j	800037e4 <filewrite+0xe2>
    80003816:	5a7d                	li	s4,-1
    80003818:	b7f1                	j	800037e4 <filewrite+0xe2>

000000008000381a <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    8000381a:	7179                	addi	sp,sp,-48
    8000381c:	f406                	sd	ra,40(sp)
    8000381e:	f022                	sd	s0,32(sp)
    80003820:	ec26                	sd	s1,24(sp)
    80003822:	e84a                	sd	s2,16(sp)
    80003824:	e44e                	sd	s3,8(sp)
    80003826:	e052                	sd	s4,0(sp)
    80003828:	1800                	addi	s0,sp,48
    8000382a:	84aa                	mv	s1,a0
    8000382c:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000382e:	0005b023          	sd	zero,0(a1)
    80003832:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80003836:	c75ff0ef          	jal	ra,800034aa <filealloc>
    8000383a:	e088                	sd	a0,0(s1)
    8000383c:	cd35                	beqz	a0,800038b8 <pipealloc+0x9e>
    8000383e:	c6dff0ef          	jal	ra,800034aa <filealloc>
    80003842:	00aa3023          	sd	a0,0(s4)
    80003846:	c52d                	beqz	a0,800038b0 <pipealloc+0x96>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80003848:	8b5fc0ef          	jal	ra,800000fc <kalloc>
    8000384c:	892a                	mv	s2,a0
    8000384e:	cd31                	beqz	a0,800038aa <pipealloc+0x90>
    goto bad;
  pi->readopen = 1;
    80003850:	4985                	li	s3,1
    80003852:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80003856:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000385a:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000385e:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80003862:	00004597          	auipc	a1,0x4
    80003866:	ee658593          	addi	a1,a1,-282 # 80007748 <syscalls+0x2e8>
    8000386a:	751010ef          	jal	ra,800057ba <initlock>
  (*f0)->type = FD_PIPE;
    8000386e:	609c                	ld	a5,0(s1)
    80003870:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80003874:	609c                	ld	a5,0(s1)
    80003876:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000387a:	609c                	ld	a5,0(s1)
    8000387c:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80003880:	609c                	ld	a5,0(s1)
    80003882:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80003886:	000a3783          	ld	a5,0(s4)
    8000388a:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000388e:	000a3783          	ld	a5,0(s4)
    80003892:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80003896:	000a3783          	ld	a5,0(s4)
    8000389a:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000389e:	000a3783          	ld	a5,0(s4)
    800038a2:	0127b823          	sd	s2,16(a5)
  return 0;
    800038a6:	4501                	li	a0,0
    800038a8:	a005                	j	800038c8 <pipealloc+0xae>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800038aa:	6088                	ld	a0,0(s1)
    800038ac:	e501                	bnez	a0,800038b4 <pipealloc+0x9a>
    800038ae:	a029                	j	800038b8 <pipealloc+0x9e>
    800038b0:	6088                	ld	a0,0(s1)
    800038b2:	c11d                	beqz	a0,800038d8 <pipealloc+0xbe>
    fileclose(*f0);
    800038b4:	c9bff0ef          	jal	ra,8000354e <fileclose>
  if(*f1)
    800038b8:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800038bc:	557d                	li	a0,-1
  if(*f1)
    800038be:	c789                	beqz	a5,800038c8 <pipealloc+0xae>
    fileclose(*f1);
    800038c0:	853e                	mv	a0,a5
    800038c2:	c8dff0ef          	jal	ra,8000354e <fileclose>
  return -1;
    800038c6:	557d                	li	a0,-1
}
    800038c8:	70a2                	ld	ra,40(sp)
    800038ca:	7402                	ld	s0,32(sp)
    800038cc:	64e2                	ld	s1,24(sp)
    800038ce:	6942                	ld	s2,16(sp)
    800038d0:	69a2                	ld	s3,8(sp)
    800038d2:	6a02                	ld	s4,0(sp)
    800038d4:	6145                	addi	sp,sp,48
    800038d6:	8082                	ret
  return -1;
    800038d8:	557d                	li	a0,-1
    800038da:	b7fd                	j	800038c8 <pipealloc+0xae>

00000000800038dc <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800038dc:	1101                	addi	sp,sp,-32
    800038de:	ec06                	sd	ra,24(sp)
    800038e0:	e822                	sd	s0,16(sp)
    800038e2:	e426                	sd	s1,8(sp)
    800038e4:	e04a                	sd	s2,0(sp)
    800038e6:	1000                	addi	s0,sp,32
    800038e8:	84aa                	mv	s1,a0
    800038ea:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800038ec:	74f010ef          	jal	ra,8000583a <acquire>
  if(writable){
    800038f0:	02090763          	beqz	s2,8000391e <pipeclose+0x42>
    pi->writeopen = 0;
    800038f4:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800038f8:	21848513          	addi	a0,s1,536
    800038fc:	bdbfd0ef          	jal	ra,800014d6 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80003900:	2204b783          	ld	a5,544(s1)
    80003904:	e785                	bnez	a5,8000392c <pipeclose+0x50>
    release(&pi->lock);
    80003906:	8526                	mv	a0,s1
    80003908:	7cb010ef          	jal	ra,800058d2 <release>
    kfree((char*)pi);
    8000390c:	8526                	mv	a0,s1
    8000390e:	f0efc0ef          	jal	ra,8000001c <kfree>
  } else
    release(&pi->lock);
}
    80003912:	60e2                	ld	ra,24(sp)
    80003914:	6442                	ld	s0,16(sp)
    80003916:	64a2                	ld	s1,8(sp)
    80003918:	6902                	ld	s2,0(sp)
    8000391a:	6105                	addi	sp,sp,32
    8000391c:	8082                	ret
    pi->readopen = 0;
    8000391e:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80003922:	21c48513          	addi	a0,s1,540
    80003926:	bb1fd0ef          	jal	ra,800014d6 <wakeup>
    8000392a:	bfd9                	j	80003900 <pipeclose+0x24>
    release(&pi->lock);
    8000392c:	8526                	mv	a0,s1
    8000392e:	7a5010ef          	jal	ra,800058d2 <release>
}
    80003932:	b7c5                	j	80003912 <pipeclose+0x36>

0000000080003934 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80003934:	711d                	addi	sp,sp,-96
    80003936:	ec86                	sd	ra,88(sp)
    80003938:	e8a2                	sd	s0,80(sp)
    8000393a:	e4a6                	sd	s1,72(sp)
    8000393c:	e0ca                	sd	s2,64(sp)
    8000393e:	fc4e                	sd	s3,56(sp)
    80003940:	f852                	sd	s4,48(sp)
    80003942:	f456                	sd	s5,40(sp)
    80003944:	f05a                	sd	s6,32(sp)
    80003946:	ec5e                	sd	s7,24(sp)
    80003948:	e862                	sd	s8,16(sp)
    8000394a:	1080                	addi	s0,sp,96
    8000394c:	84aa                	mv	s1,a0
    8000394e:	8aae                	mv	s5,a1
    80003950:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80003952:	cccfd0ef          	jal	ra,80000e1e <myproc>
    80003956:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80003958:	8526                	mv	a0,s1
    8000395a:	6e1010ef          	jal	ra,8000583a <acquire>
  while(i < n){
    8000395e:	09405c63          	blez	s4,800039f6 <pipewrite+0xc2>
  int i = 0;
    80003962:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80003964:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80003966:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000396a:	21c48b93          	addi	s7,s1,540
    8000396e:	a81d                	j	800039a4 <pipewrite+0x70>
      release(&pi->lock);
    80003970:	8526                	mv	a0,s1
    80003972:	761010ef          	jal	ra,800058d2 <release>
      return -1;
    80003976:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80003978:	854a                	mv	a0,s2
    8000397a:	60e6                	ld	ra,88(sp)
    8000397c:	6446                	ld	s0,80(sp)
    8000397e:	64a6                	ld	s1,72(sp)
    80003980:	6906                	ld	s2,64(sp)
    80003982:	79e2                	ld	s3,56(sp)
    80003984:	7a42                	ld	s4,48(sp)
    80003986:	7aa2                	ld	s5,40(sp)
    80003988:	7b02                	ld	s6,32(sp)
    8000398a:	6be2                	ld	s7,24(sp)
    8000398c:	6c42                	ld	s8,16(sp)
    8000398e:	6125                	addi	sp,sp,96
    80003990:	8082                	ret
      wakeup(&pi->nread);
    80003992:	8562                	mv	a0,s8
    80003994:	b43fd0ef          	jal	ra,800014d6 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80003998:	85a6                	mv	a1,s1
    8000399a:	855e                	mv	a0,s7
    8000399c:	aeffd0ef          	jal	ra,8000148a <sleep>
  while(i < n){
    800039a0:	05495c63          	bge	s2,s4,800039f8 <pipewrite+0xc4>
    if(pi->readopen == 0 || killed(pr)){
    800039a4:	2204a783          	lw	a5,544(s1)
    800039a8:	d7e1                	beqz	a5,80003970 <pipewrite+0x3c>
    800039aa:	854e                	mv	a0,s3
    800039ac:	d17fd0ef          	jal	ra,800016c2 <killed>
    800039b0:	f161                	bnez	a0,80003970 <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800039b2:	2184a783          	lw	a5,536(s1)
    800039b6:	21c4a703          	lw	a4,540(s1)
    800039ba:	2007879b          	addiw	a5,a5,512
    800039be:	fcf70ae3          	beq	a4,a5,80003992 <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800039c2:	4685                	li	a3,1
    800039c4:	01590633          	add	a2,s2,s5
    800039c8:	faf40593          	addi	a1,s0,-81
    800039cc:	0509b503          	ld	a0,80(s3)
    800039d0:	8befd0ef          	jal	ra,80000a8e <copyin>
    800039d4:	03650263          	beq	a0,s6,800039f8 <pipewrite+0xc4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800039d8:	21c4a783          	lw	a5,540(s1)
    800039dc:	0017871b          	addiw	a4,a5,1
    800039e0:	20e4ae23          	sw	a4,540(s1)
    800039e4:	1ff7f793          	andi	a5,a5,511
    800039e8:	97a6                	add	a5,a5,s1
    800039ea:	faf44703          	lbu	a4,-81(s0)
    800039ee:	00e78c23          	sb	a4,24(a5)
      i++;
    800039f2:	2905                	addiw	s2,s2,1
    800039f4:	b775                	j	800039a0 <pipewrite+0x6c>
  int i = 0;
    800039f6:	4901                	li	s2,0
  wakeup(&pi->nread);
    800039f8:	21848513          	addi	a0,s1,536
    800039fc:	adbfd0ef          	jal	ra,800014d6 <wakeup>
  release(&pi->lock);
    80003a00:	8526                	mv	a0,s1
    80003a02:	6d1010ef          	jal	ra,800058d2 <release>
  return i;
    80003a06:	bf8d                	j	80003978 <pipewrite+0x44>

0000000080003a08 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80003a08:	715d                	addi	sp,sp,-80
    80003a0a:	e486                	sd	ra,72(sp)
    80003a0c:	e0a2                	sd	s0,64(sp)
    80003a0e:	fc26                	sd	s1,56(sp)
    80003a10:	f84a                	sd	s2,48(sp)
    80003a12:	f44e                	sd	s3,40(sp)
    80003a14:	f052                	sd	s4,32(sp)
    80003a16:	ec56                	sd	s5,24(sp)
    80003a18:	e85a                	sd	s6,16(sp)
    80003a1a:	0880                	addi	s0,sp,80
    80003a1c:	84aa                	mv	s1,a0
    80003a1e:	892e                	mv	s2,a1
    80003a20:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80003a22:	bfcfd0ef          	jal	ra,80000e1e <myproc>
    80003a26:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80003a28:	8526                	mv	a0,s1
    80003a2a:	611010ef          	jal	ra,8000583a <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a2e:	2184a703          	lw	a4,536(s1)
    80003a32:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003a36:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a3a:	02f71363          	bne	a4,a5,80003a60 <piperead+0x58>
    80003a3e:	2244a783          	lw	a5,548(s1)
    80003a42:	cf99                	beqz	a5,80003a60 <piperead+0x58>
    if(killed(pr)){
    80003a44:	8552                	mv	a0,s4
    80003a46:	c7dfd0ef          	jal	ra,800016c2 <killed>
    80003a4a:	e141                	bnez	a0,80003aca <piperead+0xc2>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80003a4c:	85a6                	mv	a1,s1
    80003a4e:	854e                	mv	a0,s3
    80003a50:	a3bfd0ef          	jal	ra,8000148a <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80003a54:	2184a703          	lw	a4,536(s1)
    80003a58:	21c4a783          	lw	a5,540(s1)
    80003a5c:	fef701e3          	beq	a4,a5,80003a3e <piperead+0x36>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a60:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003a62:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a64:	05505163          	blez	s5,80003aa6 <piperead+0x9e>
    if(pi->nread == pi->nwrite)
    80003a68:	2184a783          	lw	a5,536(s1)
    80003a6c:	21c4a703          	lw	a4,540(s1)
    80003a70:	02f70b63          	beq	a4,a5,80003aa6 <piperead+0x9e>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80003a74:	0017871b          	addiw	a4,a5,1
    80003a78:	20e4ac23          	sw	a4,536(s1)
    80003a7c:	1ff7f793          	andi	a5,a5,511
    80003a80:	97a6                	add	a5,a5,s1
    80003a82:	0187c783          	lbu	a5,24(a5)
    80003a86:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80003a8a:	4685                	li	a3,1
    80003a8c:	fbf40613          	addi	a2,s0,-65
    80003a90:	85ca                	mv	a1,s2
    80003a92:	050a3503          	ld	a0,80(s4)
    80003a96:	f41fc0ef          	jal	ra,800009d6 <copyout>
    80003a9a:	01650663          	beq	a0,s6,80003aa6 <piperead+0x9e>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80003a9e:	2985                	addiw	s3,s3,1
    80003aa0:	0905                	addi	s2,s2,1
    80003aa2:	fd3a93e3          	bne	s5,s3,80003a68 <piperead+0x60>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80003aa6:	21c48513          	addi	a0,s1,540
    80003aaa:	a2dfd0ef          	jal	ra,800014d6 <wakeup>
  release(&pi->lock);
    80003aae:	8526                	mv	a0,s1
    80003ab0:	623010ef          	jal	ra,800058d2 <release>
  return i;
}
    80003ab4:	854e                	mv	a0,s3
    80003ab6:	60a6                	ld	ra,72(sp)
    80003ab8:	6406                	ld	s0,64(sp)
    80003aba:	74e2                	ld	s1,56(sp)
    80003abc:	7942                	ld	s2,48(sp)
    80003abe:	79a2                	ld	s3,40(sp)
    80003ac0:	7a02                	ld	s4,32(sp)
    80003ac2:	6ae2                	ld	s5,24(sp)
    80003ac4:	6b42                	ld	s6,16(sp)
    80003ac6:	6161                	addi	sp,sp,80
    80003ac8:	8082                	ret
      release(&pi->lock);
    80003aca:	8526                	mv	a0,s1
    80003acc:	607010ef          	jal	ra,800058d2 <release>
      return -1;
    80003ad0:	59fd                	li	s3,-1
    80003ad2:	b7cd                	j	80003ab4 <piperead+0xac>

0000000080003ad4 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80003ad4:	1141                	addi	sp,sp,-16
    80003ad6:	e422                	sd	s0,8(sp)
    80003ad8:	0800                	addi	s0,sp,16
    80003ada:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80003adc:	8905                	andi	a0,a0,1
    80003ade:	c111                	beqz	a0,80003ae2 <flags2perm+0xe>
      perm = PTE_X;
    80003ae0:	4521                	li	a0,8
    if(flags & 0x2)
    80003ae2:	8b89                	andi	a5,a5,2
    80003ae4:	c399                	beqz	a5,80003aea <flags2perm+0x16>
      perm |= PTE_W;
    80003ae6:	00456513          	ori	a0,a0,4
    return perm;
}
    80003aea:	6422                	ld	s0,8(sp)
    80003aec:	0141                	addi	sp,sp,16
    80003aee:	8082                	ret

0000000080003af0 <exec>:

int
exec(char *path, char **argv)
{
    80003af0:	de010113          	addi	sp,sp,-544
    80003af4:	20113c23          	sd	ra,536(sp)
    80003af8:	20813823          	sd	s0,528(sp)
    80003afc:	20913423          	sd	s1,520(sp)
    80003b00:	21213023          	sd	s2,512(sp)
    80003b04:	ffce                	sd	s3,504(sp)
    80003b06:	fbd2                	sd	s4,496(sp)
    80003b08:	f7d6                	sd	s5,488(sp)
    80003b0a:	f3da                	sd	s6,480(sp)
    80003b0c:	efde                	sd	s7,472(sp)
    80003b0e:	ebe2                	sd	s8,464(sp)
    80003b10:	e7e6                	sd	s9,456(sp)
    80003b12:	e3ea                	sd	s10,448(sp)
    80003b14:	ff6e                	sd	s11,440(sp)
    80003b16:	1400                	addi	s0,sp,544
    80003b18:	892a                	mv	s2,a0
    80003b1a:	dea43423          	sd	a0,-536(s0)
    80003b1e:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80003b22:	afcfd0ef          	jal	ra,80000e1e <myproc>
    80003b26:	84aa                	mv	s1,a0

  begin_op();
    80003b28:	e0aff0ef          	jal	ra,80003132 <begin_op>

  if((ip = namei(path)) == 0){
    80003b2c:	854a                	mv	a0,s2
    80003b2e:	c28ff0ef          	jal	ra,80002f56 <namei>
    80003b32:	c13d                	beqz	a0,80003b98 <exec+0xa8>
    80003b34:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80003b36:	d6ffe0ef          	jal	ra,800028a4 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80003b3a:	04000713          	li	a4,64
    80003b3e:	4681                	li	a3,0
    80003b40:	e5040613          	addi	a2,s0,-432
    80003b44:	4581                	li	a1,0
    80003b46:	8556                	mv	a0,s5
    80003b48:	fadfe0ef          	jal	ra,80002af4 <readi>
    80003b4c:	04000793          	li	a5,64
    80003b50:	00f51a63          	bne	a0,a5,80003b64 <exec+0x74>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80003b54:	e5042703          	lw	a4,-432(s0)
    80003b58:	464c47b7          	lui	a5,0x464c4
    80003b5c:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80003b60:	04f70063          	beq	a4,a5,80003ba0 <exec+0xb0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80003b64:	8556                	mv	a0,s5
    80003b66:	f45fe0ef          	jal	ra,80002aaa <iunlockput>
    end_op();
    80003b6a:	e38ff0ef          	jal	ra,800031a2 <end_op>
  }
  return -1;
    80003b6e:	557d                	li	a0,-1
}
    80003b70:	21813083          	ld	ra,536(sp)
    80003b74:	21013403          	ld	s0,528(sp)
    80003b78:	20813483          	ld	s1,520(sp)
    80003b7c:	20013903          	ld	s2,512(sp)
    80003b80:	79fe                	ld	s3,504(sp)
    80003b82:	7a5e                	ld	s4,496(sp)
    80003b84:	7abe                	ld	s5,488(sp)
    80003b86:	7b1e                	ld	s6,480(sp)
    80003b88:	6bfe                	ld	s7,472(sp)
    80003b8a:	6c5e                	ld	s8,464(sp)
    80003b8c:	6cbe                	ld	s9,456(sp)
    80003b8e:	6d1e                	ld	s10,448(sp)
    80003b90:	7dfa                	ld	s11,440(sp)
    80003b92:	22010113          	addi	sp,sp,544
    80003b96:	8082                	ret
    end_op();
    80003b98:	e0aff0ef          	jal	ra,800031a2 <end_op>
    return -1;
    80003b9c:	557d                	li	a0,-1
    80003b9e:	bfc9                	j	80003b70 <exec+0x80>
  if((pagetable = proc_pagetable(p)) == 0)
    80003ba0:	8526                	mv	a0,s1
    80003ba2:	b24fd0ef          	jal	ra,80000ec6 <proc_pagetable>
    80003ba6:	8b2a                	mv	s6,a0
    80003ba8:	dd55                	beqz	a0,80003b64 <exec+0x74>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003baa:	e7042783          	lw	a5,-400(s0)
    80003bae:	e8845703          	lhu	a4,-376(s0)
    80003bb2:	c325                	beqz	a4,80003c12 <exec+0x122>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003bb4:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003bb6:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80003bba:	6a05                	lui	s4,0x1
    80003bbc:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80003bc0:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    80003bc4:	6d85                	lui	s11,0x1
    80003bc6:	7d7d                	lui	s10,0xfffff
    80003bc8:	a431                	j	80003dd4 <exec+0x2e4>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80003bca:	00004517          	auipc	a0,0x4
    80003bce:	b8650513          	addi	a0,a0,-1146 # 80007750 <syscalls+0x2f0>
    80003bd2:	155010ef          	jal	ra,80005526 <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80003bd6:	874a                	mv	a4,s2
    80003bd8:	009c86bb          	addw	a3,s9,s1
    80003bdc:	4581                	li	a1,0
    80003bde:	8556                	mv	a0,s5
    80003be0:	f15fe0ef          	jal	ra,80002af4 <readi>
    80003be4:	2501                	sext.w	a0,a0
    80003be6:	18a91663          	bne	s2,a0,80003d72 <exec+0x282>
  for(i = 0; i < sz; i += PGSIZE){
    80003bea:	009d84bb          	addw	s1,s11,s1
    80003bee:	013d09bb          	addw	s3,s10,s3
    80003bf2:	1d74f163          	bgeu	s1,s7,80003db4 <exec+0x2c4>
    pa = walkaddr(pagetable, va + i);
    80003bf6:	02049593          	slli	a1,s1,0x20
    80003bfa:	9181                	srli	a1,a1,0x20
    80003bfc:	95e2                	add	a1,a1,s8
    80003bfe:	855a                	mv	a0,s6
    80003c00:	86bfc0ef          	jal	ra,8000046a <walkaddr>
    80003c04:	862a                	mv	a2,a0
    if(pa == 0)
    80003c06:	d171                	beqz	a0,80003bca <exec+0xda>
      n = PGSIZE;
    80003c08:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80003c0a:	fd49f6e3          	bgeu	s3,s4,80003bd6 <exec+0xe6>
      n = sz - i;
    80003c0e:	894e                	mv	s2,s3
    80003c10:	b7d9                	j	80003bd6 <exec+0xe6>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80003c12:	4901                	li	s2,0
  iunlockput(ip);
    80003c14:	8556                	mv	a0,s5
    80003c16:	e95fe0ef          	jal	ra,80002aaa <iunlockput>
  end_op();
    80003c1a:	d88ff0ef          	jal	ra,800031a2 <end_op>
  p = myproc();
    80003c1e:	a00fd0ef          	jal	ra,80000e1e <myproc>
    80003c22:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    80003c24:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80003c28:	6785                	lui	a5,0x1
    80003c2a:	17fd                	addi	a5,a5,-1
    80003c2c:	993e                	add	s2,s2,a5
    80003c2e:	77fd                	lui	a5,0xfffff
    80003c30:	00f977b3          	and	a5,s2,a5
    80003c34:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003c38:	4691                	li	a3,4
    80003c3a:	6609                	lui	a2,0x2
    80003c3c:	963e                	add	a2,a2,a5
    80003c3e:	85be                	mv	a1,a5
    80003c40:	855a                	mv	a0,s6
    80003c42:	b91fc0ef          	jal	ra,800007d2 <uvmalloc>
    80003c46:	8c2a                	mv	s8,a0
  ip = 0;
    80003c48:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80003c4a:	12050463          	beqz	a0,80003d72 <exec+0x282>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80003c4e:	75f9                	lui	a1,0xffffe
    80003c50:	95aa                	add	a1,a1,a0
    80003c52:	855a                	mv	a0,s6
    80003c54:	d59fc0ef          	jal	ra,800009ac <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80003c58:	7afd                	lui	s5,0xfffff
    80003c5a:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80003c5c:	df043783          	ld	a5,-528(s0)
    80003c60:	6388                	ld	a0,0(a5)
    80003c62:	c135                	beqz	a0,80003cc6 <exec+0x1d6>
    80003c64:	e9040993          	addi	s3,s0,-368
    80003c68:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80003c6c:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80003c6e:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80003c70:	e54fc0ef          	jal	ra,800002c4 <strlen>
    80003c74:	0015079b          	addiw	a5,a0,1
    80003c78:	40f90933          	sub	s2,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80003c7c:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    80003c80:	11596e63          	bltu	s2,s5,80003d9c <exec+0x2ac>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80003c84:	df043d83          	ld	s11,-528(s0)
    80003c88:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80003c8c:	8552                	mv	a0,s4
    80003c8e:	e36fc0ef          	jal	ra,800002c4 <strlen>
    80003c92:	0015069b          	addiw	a3,a0,1
    80003c96:	8652                	mv	a2,s4
    80003c98:	85ca                	mv	a1,s2
    80003c9a:	855a                	mv	a0,s6
    80003c9c:	d3bfc0ef          	jal	ra,800009d6 <copyout>
    80003ca0:	10054263          	bltz	a0,80003da4 <exec+0x2b4>
    ustack[argc] = sp;
    80003ca4:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80003ca8:	0485                	addi	s1,s1,1
    80003caa:	008d8793          	addi	a5,s11,8
    80003cae:	def43823          	sd	a5,-528(s0)
    80003cb2:	008db503          	ld	a0,8(s11)
    80003cb6:	c911                	beqz	a0,80003cca <exec+0x1da>
    if(argc >= MAXARG)
    80003cb8:	09a1                	addi	s3,s3,8
    80003cba:	fb3c9be3          	bne	s9,s3,80003c70 <exec+0x180>
  sz = sz1;
    80003cbe:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003cc2:	4a81                	li	s5,0
    80003cc4:	a07d                	j	80003d72 <exec+0x282>
  sp = sz;
    80003cc6:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80003cc8:	4481                	li	s1,0
  ustack[argc] = 0;
    80003cca:	00349793          	slli	a5,s1,0x3
    80003cce:	f9040713          	addi	a4,s0,-112
    80003cd2:	97ba                	add	a5,a5,a4
    80003cd4:	f007b023          	sd	zero,-256(a5) # ffffffffffffef00 <end+0xffffffff7ffde020>
  sp -= (argc+1) * sizeof(uint64);
    80003cd8:	00148693          	addi	a3,s1,1
    80003cdc:	068e                	slli	a3,a3,0x3
    80003cde:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80003ce2:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80003ce6:	01597663          	bgeu	s2,s5,80003cf2 <exec+0x202>
  sz = sz1;
    80003cea:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003cee:	4a81                	li	s5,0
    80003cf0:	a049                	j	80003d72 <exec+0x282>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80003cf2:	e9040613          	addi	a2,s0,-368
    80003cf6:	85ca                	mv	a1,s2
    80003cf8:	855a                	mv	a0,s6
    80003cfa:	cddfc0ef          	jal	ra,800009d6 <copyout>
    80003cfe:	0a054763          	bltz	a0,80003dac <exec+0x2bc>
  p->trapframe->a1 = sp;
    80003d02:	058bb783          	ld	a5,88(s7) # 1058 <_entry-0x7fffefa8>
    80003d06:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80003d0a:	de843783          	ld	a5,-536(s0)
    80003d0e:	0007c703          	lbu	a4,0(a5)
    80003d12:	cf11                	beqz	a4,80003d2e <exec+0x23e>
    80003d14:	0785                	addi	a5,a5,1
    if(*s == '/')
    80003d16:	02f00693          	li	a3,47
    80003d1a:	a039                	j	80003d28 <exec+0x238>
      last = s+1;
    80003d1c:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    80003d20:	0785                	addi	a5,a5,1
    80003d22:	fff7c703          	lbu	a4,-1(a5)
    80003d26:	c701                	beqz	a4,80003d2e <exec+0x23e>
    if(*s == '/')
    80003d28:	fed71ce3          	bne	a4,a3,80003d20 <exec+0x230>
    80003d2c:	bfc5                	j	80003d1c <exec+0x22c>
  safestrcpy(p->name, last, sizeof(p->name));
    80003d2e:	4641                	li	a2,16
    80003d30:	de843583          	ld	a1,-536(s0)
    80003d34:	158b8513          	addi	a0,s7,344
    80003d38:	d5afc0ef          	jal	ra,80000292 <safestrcpy>
  oldpagetable = p->pagetable;
    80003d3c:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    80003d40:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    80003d44:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80003d48:	058bb783          	ld	a5,88(s7)
    80003d4c:	e6843703          	ld	a4,-408(s0)
    80003d50:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80003d52:	058bb783          	ld	a5,88(s7)
    80003d56:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80003d5a:	85ea                	mv	a1,s10
    80003d5c:	a4afd0ef          	jal	ra,80000fa6 <proc_freepagetable>
  vmprint(p->pagetable);
    80003d60:	050bb503          	ld	a0,80(s7)
    80003d64:	f1ffc0ef          	jal	ra,80000c82 <vmprint>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80003d68:	0004851b          	sext.w	a0,s1
    80003d6c:	b511                	j	80003b70 <exec+0x80>
    80003d6e:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80003d72:	df843583          	ld	a1,-520(s0)
    80003d76:	855a                	mv	a0,s6
    80003d78:	a2efd0ef          	jal	ra,80000fa6 <proc_freepagetable>
  if(ip){
    80003d7c:	de0a94e3          	bnez	s5,80003b64 <exec+0x74>
  return -1;
    80003d80:	557d                	li	a0,-1
    80003d82:	b3fd                	j	80003b70 <exec+0x80>
    80003d84:	df243c23          	sd	s2,-520(s0)
    80003d88:	b7ed                	j	80003d72 <exec+0x282>
    80003d8a:	df243c23          	sd	s2,-520(s0)
    80003d8e:	b7d5                	j	80003d72 <exec+0x282>
    80003d90:	df243c23          	sd	s2,-520(s0)
    80003d94:	bff9                	j	80003d72 <exec+0x282>
    80003d96:	df243c23          	sd	s2,-520(s0)
    80003d9a:	bfe1                	j	80003d72 <exec+0x282>
  sz = sz1;
    80003d9c:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003da0:	4a81                	li	s5,0
    80003da2:	bfc1                	j	80003d72 <exec+0x282>
  sz = sz1;
    80003da4:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003da8:	4a81                	li	s5,0
    80003daa:	b7e1                	j	80003d72 <exec+0x282>
  sz = sz1;
    80003dac:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80003db0:	4a81                	li	s5,0
    80003db2:	b7c1                	j	80003d72 <exec+0x282>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003db4:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80003db8:	e0843783          	ld	a5,-504(s0)
    80003dbc:	0017869b          	addiw	a3,a5,1
    80003dc0:	e0d43423          	sd	a3,-504(s0)
    80003dc4:	e0043783          	ld	a5,-512(s0)
    80003dc8:	0387879b          	addiw	a5,a5,56
    80003dcc:	e8845703          	lhu	a4,-376(s0)
    80003dd0:	e4e6d2e3          	bge	a3,a4,80003c14 <exec+0x124>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80003dd4:	2781                	sext.w	a5,a5
    80003dd6:	e0f43023          	sd	a5,-512(s0)
    80003dda:	03800713          	li	a4,56
    80003dde:	86be                	mv	a3,a5
    80003de0:	e1840613          	addi	a2,s0,-488
    80003de4:	4581                	li	a1,0
    80003de6:	8556                	mv	a0,s5
    80003de8:	d0dfe0ef          	jal	ra,80002af4 <readi>
    80003dec:	03800793          	li	a5,56
    80003df0:	f6f51fe3          	bne	a0,a5,80003d6e <exec+0x27e>
    if(ph.type != ELF_PROG_LOAD)
    80003df4:	e1842783          	lw	a5,-488(s0)
    80003df8:	4705                	li	a4,1
    80003dfa:	fae79fe3          	bne	a5,a4,80003db8 <exec+0x2c8>
    if(ph.memsz < ph.filesz)
    80003dfe:	e4043483          	ld	s1,-448(s0)
    80003e02:	e3843783          	ld	a5,-456(s0)
    80003e06:	f6f4efe3          	bltu	s1,a5,80003d84 <exec+0x294>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80003e0a:	e2843783          	ld	a5,-472(s0)
    80003e0e:	94be                	add	s1,s1,a5
    80003e10:	f6f4ede3          	bltu	s1,a5,80003d8a <exec+0x29a>
    if(ph.vaddr % PGSIZE != 0)
    80003e14:	de043703          	ld	a4,-544(s0)
    80003e18:	8ff9                	and	a5,a5,a4
    80003e1a:	fbbd                	bnez	a5,80003d90 <exec+0x2a0>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80003e1c:	e1c42503          	lw	a0,-484(s0)
    80003e20:	cb5ff0ef          	jal	ra,80003ad4 <flags2perm>
    80003e24:	86aa                	mv	a3,a0
    80003e26:	8626                	mv	a2,s1
    80003e28:	85ca                	mv	a1,s2
    80003e2a:	855a                	mv	a0,s6
    80003e2c:	9a7fc0ef          	jal	ra,800007d2 <uvmalloc>
    80003e30:	dea43c23          	sd	a0,-520(s0)
    80003e34:	d12d                	beqz	a0,80003d96 <exec+0x2a6>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80003e36:	e2843c03          	ld	s8,-472(s0)
    80003e3a:	e2042c83          	lw	s9,-480(s0)
    80003e3e:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80003e42:	f60b89e3          	beqz	s7,80003db4 <exec+0x2c4>
    80003e46:	89de                	mv	s3,s7
    80003e48:	4481                	li	s1,0
    80003e4a:	b375                	j	80003bf6 <exec+0x106>

0000000080003e4c <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80003e4c:	7179                	addi	sp,sp,-48
    80003e4e:	f406                	sd	ra,40(sp)
    80003e50:	f022                	sd	s0,32(sp)
    80003e52:	ec26                	sd	s1,24(sp)
    80003e54:	e84a                	sd	s2,16(sp)
    80003e56:	1800                	addi	s0,sp,48
    80003e58:	892e                	mv	s2,a1
    80003e5a:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80003e5c:	fdc40593          	addi	a1,s0,-36
    80003e60:	f0dfd0ef          	jal	ra,80001d6c <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80003e64:	fdc42703          	lw	a4,-36(s0)
    80003e68:	47bd                	li	a5,15
    80003e6a:	02e7e963          	bltu	a5,a4,80003e9c <argfd+0x50>
    80003e6e:	fb1fc0ef          	jal	ra,80000e1e <myproc>
    80003e72:	fdc42703          	lw	a4,-36(s0)
    80003e76:	01a70793          	addi	a5,a4,26
    80003e7a:	078e                	slli	a5,a5,0x3
    80003e7c:	953e                	add	a0,a0,a5
    80003e7e:	611c                	ld	a5,0(a0)
    80003e80:	c385                	beqz	a5,80003ea0 <argfd+0x54>
    return -1;
  if(pfd)
    80003e82:	00090463          	beqz	s2,80003e8a <argfd+0x3e>
    *pfd = fd;
    80003e86:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80003e8a:	4501                	li	a0,0
  if(pf)
    80003e8c:	c091                	beqz	s1,80003e90 <argfd+0x44>
    *pf = f;
    80003e8e:	e09c                	sd	a5,0(s1)
}
    80003e90:	70a2                	ld	ra,40(sp)
    80003e92:	7402                	ld	s0,32(sp)
    80003e94:	64e2                	ld	s1,24(sp)
    80003e96:	6942                	ld	s2,16(sp)
    80003e98:	6145                	addi	sp,sp,48
    80003e9a:	8082                	ret
    return -1;
    80003e9c:	557d                	li	a0,-1
    80003e9e:	bfcd                	j	80003e90 <argfd+0x44>
    80003ea0:	557d                	li	a0,-1
    80003ea2:	b7fd                	j	80003e90 <argfd+0x44>

0000000080003ea4 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80003ea4:	1101                	addi	sp,sp,-32
    80003ea6:	ec06                	sd	ra,24(sp)
    80003ea8:	e822                	sd	s0,16(sp)
    80003eaa:	e426                	sd	s1,8(sp)
    80003eac:	1000                	addi	s0,sp,32
    80003eae:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80003eb0:	f6ffc0ef          	jal	ra,80000e1e <myproc>
    80003eb4:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80003eb6:	0d050793          	addi	a5,a0,208
    80003eba:	4501                	li	a0,0
    80003ebc:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80003ebe:	6398                	ld	a4,0(a5)
    80003ec0:	cb19                	beqz	a4,80003ed6 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80003ec2:	2505                	addiw	a0,a0,1
    80003ec4:	07a1                	addi	a5,a5,8
    80003ec6:	fed51ce3          	bne	a0,a3,80003ebe <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80003eca:	557d                	li	a0,-1
}
    80003ecc:	60e2                	ld	ra,24(sp)
    80003ece:	6442                	ld	s0,16(sp)
    80003ed0:	64a2                	ld	s1,8(sp)
    80003ed2:	6105                	addi	sp,sp,32
    80003ed4:	8082                	ret
      p->ofile[fd] = f;
    80003ed6:	01a50793          	addi	a5,a0,26
    80003eda:	078e                	slli	a5,a5,0x3
    80003edc:	963e                	add	a2,a2,a5
    80003ede:	e204                	sd	s1,0(a2)
      return fd;
    80003ee0:	b7f5                	j	80003ecc <fdalloc+0x28>

0000000080003ee2 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80003ee2:	715d                	addi	sp,sp,-80
    80003ee4:	e486                	sd	ra,72(sp)
    80003ee6:	e0a2                	sd	s0,64(sp)
    80003ee8:	fc26                	sd	s1,56(sp)
    80003eea:	f84a                	sd	s2,48(sp)
    80003eec:	f44e                	sd	s3,40(sp)
    80003eee:	f052                	sd	s4,32(sp)
    80003ef0:	ec56                	sd	s5,24(sp)
    80003ef2:	e85a                	sd	s6,16(sp)
    80003ef4:	0880                	addi	s0,sp,80
    80003ef6:	8b2e                	mv	s6,a1
    80003ef8:	89b2                	mv	s3,a2
    80003efa:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80003efc:	fb040593          	addi	a1,s0,-80
    80003f00:	870ff0ef          	jal	ra,80002f70 <nameiparent>
    80003f04:	84aa                	mv	s1,a0
    80003f06:	10050b63          	beqz	a0,8000401c <create+0x13a>
    return 0;

  ilock(dp);
    80003f0a:	99bfe0ef          	jal	ra,800028a4 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80003f0e:	4601                	li	a2,0
    80003f10:	fb040593          	addi	a1,s0,-80
    80003f14:	8526                	mv	a0,s1
    80003f16:	ddbfe0ef          	jal	ra,80002cf0 <dirlookup>
    80003f1a:	8aaa                	mv	s5,a0
    80003f1c:	c521                	beqz	a0,80003f64 <create+0x82>
    iunlockput(dp);
    80003f1e:	8526                	mv	a0,s1
    80003f20:	b8bfe0ef          	jal	ra,80002aaa <iunlockput>
    ilock(ip);
    80003f24:	8556                	mv	a0,s5
    80003f26:	97ffe0ef          	jal	ra,800028a4 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80003f2a:	000b059b          	sext.w	a1,s6
    80003f2e:	4789                	li	a5,2
    80003f30:	02f59563          	bne	a1,a5,80003f5a <create+0x78>
    80003f34:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffde164>
    80003f38:	37f9                	addiw	a5,a5,-2
    80003f3a:	17c2                	slli	a5,a5,0x30
    80003f3c:	93c1                	srli	a5,a5,0x30
    80003f3e:	4705                	li	a4,1
    80003f40:	00f76d63          	bltu	a4,a5,80003f5a <create+0x78>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80003f44:	8556                	mv	a0,s5
    80003f46:	60a6                	ld	ra,72(sp)
    80003f48:	6406                	ld	s0,64(sp)
    80003f4a:	74e2                	ld	s1,56(sp)
    80003f4c:	7942                	ld	s2,48(sp)
    80003f4e:	79a2                	ld	s3,40(sp)
    80003f50:	7a02                	ld	s4,32(sp)
    80003f52:	6ae2                	ld	s5,24(sp)
    80003f54:	6b42                	ld	s6,16(sp)
    80003f56:	6161                	addi	sp,sp,80
    80003f58:	8082                	ret
    iunlockput(ip);
    80003f5a:	8556                	mv	a0,s5
    80003f5c:	b4ffe0ef          	jal	ra,80002aaa <iunlockput>
    return 0;
    80003f60:	4a81                	li	s5,0
    80003f62:	b7cd                	j	80003f44 <create+0x62>
  if((ip = ialloc(dp->dev, type)) == 0){
    80003f64:	85da                	mv	a1,s6
    80003f66:	4088                	lw	a0,0(s1)
    80003f68:	fd4fe0ef          	jal	ra,8000273c <ialloc>
    80003f6c:	8a2a                	mv	s4,a0
    80003f6e:	cd1d                	beqz	a0,80003fac <create+0xca>
  ilock(ip);
    80003f70:	935fe0ef          	jal	ra,800028a4 <ilock>
  ip->major = major;
    80003f74:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80003f78:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80003f7c:	4905                	li	s2,1
    80003f7e:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80003f82:	8552                	mv	a0,s4
    80003f84:	86ffe0ef          	jal	ra,800027f2 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80003f88:	000b059b          	sext.w	a1,s6
    80003f8c:	03258563          	beq	a1,s2,80003fb6 <create+0xd4>
  if(dirlink(dp, name, ip->inum) < 0)
    80003f90:	004a2603          	lw	a2,4(s4)
    80003f94:	fb040593          	addi	a1,s0,-80
    80003f98:	8526                	mv	a0,s1
    80003f9a:	f23fe0ef          	jal	ra,80002ebc <dirlink>
    80003f9e:	06054363          	bltz	a0,80004004 <create+0x122>
  iunlockput(dp);
    80003fa2:	8526                	mv	a0,s1
    80003fa4:	b07fe0ef          	jal	ra,80002aaa <iunlockput>
  return ip;
    80003fa8:	8ad2                	mv	s5,s4
    80003faa:	bf69                	j	80003f44 <create+0x62>
    iunlockput(dp);
    80003fac:	8526                	mv	a0,s1
    80003fae:	afdfe0ef          	jal	ra,80002aaa <iunlockput>
    return 0;
    80003fb2:	8ad2                	mv	s5,s4
    80003fb4:	bf41                	j	80003f44 <create+0x62>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80003fb6:	004a2603          	lw	a2,4(s4)
    80003fba:	00003597          	auipc	a1,0x3
    80003fbe:	7b658593          	addi	a1,a1,1974 # 80007770 <syscalls+0x310>
    80003fc2:	8552                	mv	a0,s4
    80003fc4:	ef9fe0ef          	jal	ra,80002ebc <dirlink>
    80003fc8:	02054e63          	bltz	a0,80004004 <create+0x122>
    80003fcc:	40d0                	lw	a2,4(s1)
    80003fce:	00003597          	auipc	a1,0x3
    80003fd2:	1da58593          	addi	a1,a1,474 # 800071a8 <etext+0x1a8>
    80003fd6:	8552                	mv	a0,s4
    80003fd8:	ee5fe0ef          	jal	ra,80002ebc <dirlink>
    80003fdc:	02054463          	bltz	a0,80004004 <create+0x122>
  if(dirlink(dp, name, ip->inum) < 0)
    80003fe0:	004a2603          	lw	a2,4(s4)
    80003fe4:	fb040593          	addi	a1,s0,-80
    80003fe8:	8526                	mv	a0,s1
    80003fea:	ed3fe0ef          	jal	ra,80002ebc <dirlink>
    80003fee:	00054b63          	bltz	a0,80004004 <create+0x122>
    dp->nlink++;  // for ".."
    80003ff2:	04a4d783          	lhu	a5,74(s1)
    80003ff6:	2785                	addiw	a5,a5,1
    80003ff8:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80003ffc:	8526                	mv	a0,s1
    80003ffe:	ff4fe0ef          	jal	ra,800027f2 <iupdate>
    80004002:	b745                	j	80003fa2 <create+0xc0>
  ip->nlink = 0;
    80004004:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004008:	8552                	mv	a0,s4
    8000400a:	fe8fe0ef          	jal	ra,800027f2 <iupdate>
  iunlockput(ip);
    8000400e:	8552                	mv	a0,s4
    80004010:	a9bfe0ef          	jal	ra,80002aaa <iunlockput>
  iunlockput(dp);
    80004014:	8526                	mv	a0,s1
    80004016:	a95fe0ef          	jal	ra,80002aaa <iunlockput>
  return 0;
    8000401a:	b72d                	j	80003f44 <create+0x62>
    return 0;
    8000401c:	8aaa                	mv	s5,a0
    8000401e:	b71d                	j	80003f44 <create+0x62>

0000000080004020 <sys_dup>:
{
    80004020:	7179                	addi	sp,sp,-48
    80004022:	f406                	sd	ra,40(sp)
    80004024:	f022                	sd	s0,32(sp)
    80004026:	ec26                	sd	s1,24(sp)
    80004028:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    8000402a:	fd840613          	addi	a2,s0,-40
    8000402e:	4581                	li	a1,0
    80004030:	4501                	li	a0,0
    80004032:	e1bff0ef          	jal	ra,80003e4c <argfd>
    return -1;
    80004036:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004038:	00054f63          	bltz	a0,80004056 <sys_dup+0x36>
  if((fd=fdalloc(f)) < 0)
    8000403c:	fd843503          	ld	a0,-40(s0)
    80004040:	e65ff0ef          	jal	ra,80003ea4 <fdalloc>
    80004044:	84aa                	mv	s1,a0
    return -1;
    80004046:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004048:	00054763          	bltz	a0,80004056 <sys_dup+0x36>
  filedup(f);
    8000404c:	fd843503          	ld	a0,-40(s0)
    80004050:	cb8ff0ef          	jal	ra,80003508 <filedup>
  return fd;
    80004054:	87a6                	mv	a5,s1
}
    80004056:	853e                	mv	a0,a5
    80004058:	70a2                	ld	ra,40(sp)
    8000405a:	7402                	ld	s0,32(sp)
    8000405c:	64e2                	ld	s1,24(sp)
    8000405e:	6145                	addi	sp,sp,48
    80004060:	8082                	ret

0000000080004062 <sys_read>:
{
    80004062:	7179                	addi	sp,sp,-48
    80004064:	f406                	sd	ra,40(sp)
    80004066:	f022                	sd	s0,32(sp)
    80004068:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000406a:	fd840593          	addi	a1,s0,-40
    8000406e:	4505                	li	a0,1
    80004070:	d19fd0ef          	jal	ra,80001d88 <argaddr>
  argint(2, &n);
    80004074:	fe440593          	addi	a1,s0,-28
    80004078:	4509                	li	a0,2
    8000407a:	cf3fd0ef          	jal	ra,80001d6c <argint>
  if(argfd(0, 0, &f) < 0)
    8000407e:	fe840613          	addi	a2,s0,-24
    80004082:	4581                	li	a1,0
    80004084:	4501                	li	a0,0
    80004086:	dc7ff0ef          	jal	ra,80003e4c <argfd>
    8000408a:	87aa                	mv	a5,a0
    return -1;
    8000408c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000408e:	0007ca63          	bltz	a5,800040a2 <sys_read+0x40>
  return fileread(f, p, n);
    80004092:	fe442603          	lw	a2,-28(s0)
    80004096:	fd843583          	ld	a1,-40(s0)
    8000409a:	fe843503          	ld	a0,-24(s0)
    8000409e:	db6ff0ef          	jal	ra,80003654 <fileread>
}
    800040a2:	70a2                	ld	ra,40(sp)
    800040a4:	7402                	ld	s0,32(sp)
    800040a6:	6145                	addi	sp,sp,48
    800040a8:	8082                	ret

00000000800040aa <sys_write>:
{
    800040aa:	7179                	addi	sp,sp,-48
    800040ac:	f406                	sd	ra,40(sp)
    800040ae:	f022                	sd	s0,32(sp)
    800040b0:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800040b2:	fd840593          	addi	a1,s0,-40
    800040b6:	4505                	li	a0,1
    800040b8:	cd1fd0ef          	jal	ra,80001d88 <argaddr>
  argint(2, &n);
    800040bc:	fe440593          	addi	a1,s0,-28
    800040c0:	4509                	li	a0,2
    800040c2:	cabfd0ef          	jal	ra,80001d6c <argint>
  if(argfd(0, 0, &f) < 0)
    800040c6:	fe840613          	addi	a2,s0,-24
    800040ca:	4581                	li	a1,0
    800040cc:	4501                	li	a0,0
    800040ce:	d7fff0ef          	jal	ra,80003e4c <argfd>
    800040d2:	87aa                	mv	a5,a0
    return -1;
    800040d4:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800040d6:	0007ca63          	bltz	a5,800040ea <sys_write+0x40>
  return filewrite(f, p, n);
    800040da:	fe442603          	lw	a2,-28(s0)
    800040de:	fd843583          	ld	a1,-40(s0)
    800040e2:	fe843503          	ld	a0,-24(s0)
    800040e6:	e1cff0ef          	jal	ra,80003702 <filewrite>
}
    800040ea:	70a2                	ld	ra,40(sp)
    800040ec:	7402                	ld	s0,32(sp)
    800040ee:	6145                	addi	sp,sp,48
    800040f0:	8082                	ret

00000000800040f2 <sys_close>:
{
    800040f2:	1101                	addi	sp,sp,-32
    800040f4:	ec06                	sd	ra,24(sp)
    800040f6:	e822                	sd	s0,16(sp)
    800040f8:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800040fa:	fe040613          	addi	a2,s0,-32
    800040fe:	fec40593          	addi	a1,s0,-20
    80004102:	4501                	li	a0,0
    80004104:	d49ff0ef          	jal	ra,80003e4c <argfd>
    return -1;
    80004108:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    8000410a:	02054063          	bltz	a0,8000412a <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    8000410e:	d11fc0ef          	jal	ra,80000e1e <myproc>
    80004112:	fec42783          	lw	a5,-20(s0)
    80004116:	07e9                	addi	a5,a5,26
    80004118:	078e                	slli	a5,a5,0x3
    8000411a:	97aa                	add	a5,a5,a0
    8000411c:	0007b023          	sd	zero,0(a5)
  fileclose(f);
    80004120:	fe043503          	ld	a0,-32(s0)
    80004124:	c2aff0ef          	jal	ra,8000354e <fileclose>
  return 0;
    80004128:	4781                	li	a5,0
}
    8000412a:	853e                	mv	a0,a5
    8000412c:	60e2                	ld	ra,24(sp)
    8000412e:	6442                	ld	s0,16(sp)
    80004130:	6105                	addi	sp,sp,32
    80004132:	8082                	ret

0000000080004134 <sys_fstat>:
{
    80004134:	1101                	addi	sp,sp,-32
    80004136:	ec06                	sd	ra,24(sp)
    80004138:	e822                	sd	s0,16(sp)
    8000413a:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    8000413c:	fe040593          	addi	a1,s0,-32
    80004140:	4505                	li	a0,1
    80004142:	c47fd0ef          	jal	ra,80001d88 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004146:	fe840613          	addi	a2,s0,-24
    8000414a:	4581                	li	a1,0
    8000414c:	4501                	li	a0,0
    8000414e:	cffff0ef          	jal	ra,80003e4c <argfd>
    80004152:	87aa                	mv	a5,a0
    return -1;
    80004154:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004156:	0007c863          	bltz	a5,80004166 <sys_fstat+0x32>
  return filestat(f, st);
    8000415a:	fe043583          	ld	a1,-32(s0)
    8000415e:	fe843503          	ld	a0,-24(s0)
    80004162:	c94ff0ef          	jal	ra,800035f6 <filestat>
}
    80004166:	60e2                	ld	ra,24(sp)
    80004168:	6442                	ld	s0,16(sp)
    8000416a:	6105                	addi	sp,sp,32
    8000416c:	8082                	ret

000000008000416e <sys_link>:
{
    8000416e:	7169                	addi	sp,sp,-304
    80004170:	f606                	sd	ra,296(sp)
    80004172:	f222                	sd	s0,288(sp)
    80004174:	ee26                	sd	s1,280(sp)
    80004176:	ea4a                	sd	s2,272(sp)
    80004178:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000417a:	08000613          	li	a2,128
    8000417e:	ed040593          	addi	a1,s0,-304
    80004182:	4501                	li	a0,0
    80004184:	c21fd0ef          	jal	ra,80001da4 <argstr>
    return -1;
    80004188:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000418a:	0c054663          	bltz	a0,80004256 <sys_link+0xe8>
    8000418e:	08000613          	li	a2,128
    80004192:	f5040593          	addi	a1,s0,-176
    80004196:	4505                	li	a0,1
    80004198:	c0dfd0ef          	jal	ra,80001da4 <argstr>
    return -1;
    8000419c:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000419e:	0a054c63          	bltz	a0,80004256 <sys_link+0xe8>
  begin_op();
    800041a2:	f91fe0ef          	jal	ra,80003132 <begin_op>
  if((ip = namei(old)) == 0){
    800041a6:	ed040513          	addi	a0,s0,-304
    800041aa:	dadfe0ef          	jal	ra,80002f56 <namei>
    800041ae:	84aa                	mv	s1,a0
    800041b0:	c525                	beqz	a0,80004218 <sys_link+0xaa>
  ilock(ip);
    800041b2:	ef2fe0ef          	jal	ra,800028a4 <ilock>
  if(ip->type == T_DIR){
    800041b6:	04449703          	lh	a4,68(s1)
    800041ba:	4785                	li	a5,1
    800041bc:	06f70263          	beq	a4,a5,80004220 <sys_link+0xb2>
  ip->nlink++;
    800041c0:	04a4d783          	lhu	a5,74(s1)
    800041c4:	2785                	addiw	a5,a5,1
    800041c6:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800041ca:	8526                	mv	a0,s1
    800041cc:	e26fe0ef          	jal	ra,800027f2 <iupdate>
  iunlock(ip);
    800041d0:	8526                	mv	a0,s1
    800041d2:	f7cfe0ef          	jal	ra,8000294e <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800041d6:	fd040593          	addi	a1,s0,-48
    800041da:	f5040513          	addi	a0,s0,-176
    800041de:	d93fe0ef          	jal	ra,80002f70 <nameiparent>
    800041e2:	892a                	mv	s2,a0
    800041e4:	c921                	beqz	a0,80004234 <sys_link+0xc6>
  ilock(dp);
    800041e6:	ebefe0ef          	jal	ra,800028a4 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800041ea:	00092703          	lw	a4,0(s2)
    800041ee:	409c                	lw	a5,0(s1)
    800041f0:	02f71f63          	bne	a4,a5,8000422e <sys_link+0xc0>
    800041f4:	40d0                	lw	a2,4(s1)
    800041f6:	fd040593          	addi	a1,s0,-48
    800041fa:	854a                	mv	a0,s2
    800041fc:	cc1fe0ef          	jal	ra,80002ebc <dirlink>
    80004200:	02054763          	bltz	a0,8000422e <sys_link+0xc0>
  iunlockput(dp);
    80004204:	854a                	mv	a0,s2
    80004206:	8a5fe0ef          	jal	ra,80002aaa <iunlockput>
  iput(ip);
    8000420a:	8526                	mv	a0,s1
    8000420c:	817fe0ef          	jal	ra,80002a22 <iput>
  end_op();
    80004210:	f93fe0ef          	jal	ra,800031a2 <end_op>
  return 0;
    80004214:	4781                	li	a5,0
    80004216:	a081                	j	80004256 <sys_link+0xe8>
    end_op();
    80004218:	f8bfe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    8000421c:	57fd                	li	a5,-1
    8000421e:	a825                	j	80004256 <sys_link+0xe8>
    iunlockput(ip);
    80004220:	8526                	mv	a0,s1
    80004222:	889fe0ef          	jal	ra,80002aaa <iunlockput>
    end_op();
    80004226:	f7dfe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    8000422a:	57fd                	li	a5,-1
    8000422c:	a02d                	j	80004256 <sys_link+0xe8>
    iunlockput(dp);
    8000422e:	854a                	mv	a0,s2
    80004230:	87bfe0ef          	jal	ra,80002aaa <iunlockput>
  ilock(ip);
    80004234:	8526                	mv	a0,s1
    80004236:	e6efe0ef          	jal	ra,800028a4 <ilock>
  ip->nlink--;
    8000423a:	04a4d783          	lhu	a5,74(s1)
    8000423e:	37fd                	addiw	a5,a5,-1
    80004240:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004244:	8526                	mv	a0,s1
    80004246:	dacfe0ef          	jal	ra,800027f2 <iupdate>
  iunlockput(ip);
    8000424a:	8526                	mv	a0,s1
    8000424c:	85ffe0ef          	jal	ra,80002aaa <iunlockput>
  end_op();
    80004250:	f53fe0ef          	jal	ra,800031a2 <end_op>
  return -1;
    80004254:	57fd                	li	a5,-1
}
    80004256:	853e                	mv	a0,a5
    80004258:	70b2                	ld	ra,296(sp)
    8000425a:	7412                	ld	s0,288(sp)
    8000425c:	64f2                	ld	s1,280(sp)
    8000425e:	6952                	ld	s2,272(sp)
    80004260:	6155                	addi	sp,sp,304
    80004262:	8082                	ret

0000000080004264 <sys_unlink>:
{
    80004264:	7151                	addi	sp,sp,-240
    80004266:	f586                	sd	ra,232(sp)
    80004268:	f1a2                	sd	s0,224(sp)
    8000426a:	eda6                	sd	s1,216(sp)
    8000426c:	e9ca                	sd	s2,208(sp)
    8000426e:	e5ce                	sd	s3,200(sp)
    80004270:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004272:	08000613          	li	a2,128
    80004276:	f3040593          	addi	a1,s0,-208
    8000427a:	4501                	li	a0,0
    8000427c:	b29fd0ef          	jal	ra,80001da4 <argstr>
    80004280:	12054b63          	bltz	a0,800043b6 <sys_unlink+0x152>
  begin_op();
    80004284:	eaffe0ef          	jal	ra,80003132 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004288:	fb040593          	addi	a1,s0,-80
    8000428c:	f3040513          	addi	a0,s0,-208
    80004290:	ce1fe0ef          	jal	ra,80002f70 <nameiparent>
    80004294:	84aa                	mv	s1,a0
    80004296:	c54d                	beqz	a0,80004340 <sys_unlink+0xdc>
  ilock(dp);
    80004298:	e0cfe0ef          	jal	ra,800028a4 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    8000429c:	00003597          	auipc	a1,0x3
    800042a0:	4d458593          	addi	a1,a1,1236 # 80007770 <syscalls+0x310>
    800042a4:	fb040513          	addi	a0,s0,-80
    800042a8:	a33fe0ef          	jal	ra,80002cda <namecmp>
    800042ac:	10050a63          	beqz	a0,800043c0 <sys_unlink+0x15c>
    800042b0:	00003597          	auipc	a1,0x3
    800042b4:	ef858593          	addi	a1,a1,-264 # 800071a8 <etext+0x1a8>
    800042b8:	fb040513          	addi	a0,s0,-80
    800042bc:	a1ffe0ef          	jal	ra,80002cda <namecmp>
    800042c0:	10050063          	beqz	a0,800043c0 <sys_unlink+0x15c>
  if((ip = dirlookup(dp, name, &off)) == 0)
    800042c4:	f2c40613          	addi	a2,s0,-212
    800042c8:	fb040593          	addi	a1,s0,-80
    800042cc:	8526                	mv	a0,s1
    800042ce:	a23fe0ef          	jal	ra,80002cf0 <dirlookup>
    800042d2:	892a                	mv	s2,a0
    800042d4:	0e050663          	beqz	a0,800043c0 <sys_unlink+0x15c>
  ilock(ip);
    800042d8:	dccfe0ef          	jal	ra,800028a4 <ilock>
  if(ip->nlink < 1)
    800042dc:	04a91783          	lh	a5,74(s2)
    800042e0:	06f05463          	blez	a5,80004348 <sys_unlink+0xe4>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800042e4:	04491703          	lh	a4,68(s2)
    800042e8:	4785                	li	a5,1
    800042ea:	06f70563          	beq	a4,a5,80004354 <sys_unlink+0xf0>
  memset(&de, 0, sizeof(de));
    800042ee:	4641                	li	a2,16
    800042f0:	4581                	li	a1,0
    800042f2:	fc040513          	addi	a0,s0,-64
    800042f6:	e57fb0ef          	jal	ra,8000014c <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800042fa:	4741                	li	a4,16
    800042fc:	f2c42683          	lw	a3,-212(s0)
    80004300:	fc040613          	addi	a2,s0,-64
    80004304:	4581                	li	a1,0
    80004306:	8526                	mv	a0,s1
    80004308:	8d1fe0ef          	jal	ra,80002bd8 <writei>
    8000430c:	47c1                	li	a5,16
    8000430e:	08f51563          	bne	a0,a5,80004398 <sys_unlink+0x134>
  if(ip->type == T_DIR){
    80004312:	04491703          	lh	a4,68(s2)
    80004316:	4785                	li	a5,1
    80004318:	08f70663          	beq	a4,a5,800043a4 <sys_unlink+0x140>
  iunlockput(dp);
    8000431c:	8526                	mv	a0,s1
    8000431e:	f8cfe0ef          	jal	ra,80002aaa <iunlockput>
  ip->nlink--;
    80004322:	04a95783          	lhu	a5,74(s2)
    80004326:	37fd                	addiw	a5,a5,-1
    80004328:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000432c:	854a                	mv	a0,s2
    8000432e:	cc4fe0ef          	jal	ra,800027f2 <iupdate>
  iunlockput(ip);
    80004332:	854a                	mv	a0,s2
    80004334:	f76fe0ef          	jal	ra,80002aaa <iunlockput>
  end_op();
    80004338:	e6bfe0ef          	jal	ra,800031a2 <end_op>
  return 0;
    8000433c:	4501                	li	a0,0
    8000433e:	a079                	j	800043cc <sys_unlink+0x168>
    end_op();
    80004340:	e63fe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    80004344:	557d                	li	a0,-1
    80004346:	a059                	j	800043cc <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004348:	00003517          	auipc	a0,0x3
    8000434c:	43050513          	addi	a0,a0,1072 # 80007778 <syscalls+0x318>
    80004350:	1d6010ef          	jal	ra,80005526 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004354:	04c92703          	lw	a4,76(s2)
    80004358:	02000793          	li	a5,32
    8000435c:	f8e7f9e3          	bgeu	a5,a4,800042ee <sys_unlink+0x8a>
    80004360:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004364:	4741                	li	a4,16
    80004366:	86ce                	mv	a3,s3
    80004368:	f1840613          	addi	a2,s0,-232
    8000436c:	4581                	li	a1,0
    8000436e:	854a                	mv	a0,s2
    80004370:	f84fe0ef          	jal	ra,80002af4 <readi>
    80004374:	47c1                	li	a5,16
    80004376:	00f51b63          	bne	a0,a5,8000438c <sys_unlink+0x128>
    if(de.inum != 0)
    8000437a:	f1845783          	lhu	a5,-232(s0)
    8000437e:	ef95                	bnez	a5,800043ba <sys_unlink+0x156>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004380:	29c1                	addiw	s3,s3,16
    80004382:	04c92783          	lw	a5,76(s2)
    80004386:	fcf9efe3          	bltu	s3,a5,80004364 <sys_unlink+0x100>
    8000438a:	b795                	j	800042ee <sys_unlink+0x8a>
      panic("isdirempty: readi");
    8000438c:	00003517          	auipc	a0,0x3
    80004390:	40450513          	addi	a0,a0,1028 # 80007790 <syscalls+0x330>
    80004394:	192010ef          	jal	ra,80005526 <panic>
    panic("unlink: writei");
    80004398:	00003517          	auipc	a0,0x3
    8000439c:	41050513          	addi	a0,a0,1040 # 800077a8 <syscalls+0x348>
    800043a0:	186010ef          	jal	ra,80005526 <panic>
    dp->nlink--;
    800043a4:	04a4d783          	lhu	a5,74(s1)
    800043a8:	37fd                	addiw	a5,a5,-1
    800043aa:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800043ae:	8526                	mv	a0,s1
    800043b0:	c42fe0ef          	jal	ra,800027f2 <iupdate>
    800043b4:	b7a5                	j	8000431c <sys_unlink+0xb8>
    return -1;
    800043b6:	557d                	li	a0,-1
    800043b8:	a811                	j	800043cc <sys_unlink+0x168>
    iunlockput(ip);
    800043ba:	854a                	mv	a0,s2
    800043bc:	eeefe0ef          	jal	ra,80002aaa <iunlockput>
  iunlockput(dp);
    800043c0:	8526                	mv	a0,s1
    800043c2:	ee8fe0ef          	jal	ra,80002aaa <iunlockput>
  end_op();
    800043c6:	dddfe0ef          	jal	ra,800031a2 <end_op>
  return -1;
    800043ca:	557d                	li	a0,-1
}
    800043cc:	70ae                	ld	ra,232(sp)
    800043ce:	740e                	ld	s0,224(sp)
    800043d0:	64ee                	ld	s1,216(sp)
    800043d2:	694e                	ld	s2,208(sp)
    800043d4:	69ae                	ld	s3,200(sp)
    800043d6:	616d                	addi	sp,sp,240
    800043d8:	8082                	ret

00000000800043da <sys_open>:

uint64
sys_open(void)
{
    800043da:	7131                	addi	sp,sp,-192
    800043dc:	fd06                	sd	ra,184(sp)
    800043de:	f922                	sd	s0,176(sp)
    800043e0:	f526                	sd	s1,168(sp)
    800043e2:	f14a                	sd	s2,160(sp)
    800043e4:	ed4e                	sd	s3,152(sp)
    800043e6:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800043e8:	f4c40593          	addi	a1,s0,-180
    800043ec:	4505                	li	a0,1
    800043ee:	97ffd0ef          	jal	ra,80001d6c <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800043f2:	08000613          	li	a2,128
    800043f6:	f5040593          	addi	a1,s0,-176
    800043fa:	4501                	li	a0,0
    800043fc:	9a9fd0ef          	jal	ra,80001da4 <argstr>
    80004400:	87aa                	mv	a5,a0
    return -1;
    80004402:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004404:	0807cd63          	bltz	a5,8000449e <sys_open+0xc4>

  begin_op();
    80004408:	d2bfe0ef          	jal	ra,80003132 <begin_op>

  if(omode & O_CREATE){
    8000440c:	f4c42783          	lw	a5,-180(s0)
    80004410:	2007f793          	andi	a5,a5,512
    80004414:	c3c5                	beqz	a5,800044b4 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80004416:	4681                	li	a3,0
    80004418:	4601                	li	a2,0
    8000441a:	4589                	li	a1,2
    8000441c:	f5040513          	addi	a0,s0,-176
    80004420:	ac3ff0ef          	jal	ra,80003ee2 <create>
    80004424:	84aa                	mv	s1,a0
    if(ip == 0){
    80004426:	c159                	beqz	a0,800044ac <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004428:	04449703          	lh	a4,68(s1)
    8000442c:	478d                	li	a5,3
    8000442e:	00f71763          	bne	a4,a5,8000443c <sys_open+0x62>
    80004432:	0464d703          	lhu	a4,70(s1)
    80004436:	47a5                	li	a5,9
    80004438:	0ae7e963          	bltu	a5,a4,800044ea <sys_open+0x110>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000443c:	86eff0ef          	jal	ra,800034aa <filealloc>
    80004440:	89aa                	mv	s3,a0
    80004442:	0c050963          	beqz	a0,80004514 <sys_open+0x13a>
    80004446:	a5fff0ef          	jal	ra,80003ea4 <fdalloc>
    8000444a:	892a                	mv	s2,a0
    8000444c:	0c054163          	bltz	a0,8000450e <sys_open+0x134>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004450:	04449703          	lh	a4,68(s1)
    80004454:	478d                	li	a5,3
    80004456:	0af70163          	beq	a4,a5,800044f8 <sys_open+0x11e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000445a:	4789                	li	a5,2
    8000445c:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80004460:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80004464:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80004468:	f4c42783          	lw	a5,-180(s0)
    8000446c:	0017c713          	xori	a4,a5,1
    80004470:	8b05                	andi	a4,a4,1
    80004472:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004476:	0037f713          	andi	a4,a5,3
    8000447a:	00e03733          	snez	a4,a4
    8000447e:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004482:	4007f793          	andi	a5,a5,1024
    80004486:	c791                	beqz	a5,80004492 <sys_open+0xb8>
    80004488:	04449703          	lh	a4,68(s1)
    8000448c:	4789                	li	a5,2
    8000448e:	06f70c63          	beq	a4,a5,80004506 <sys_open+0x12c>
    itrunc(ip);
  }

  iunlock(ip);
    80004492:	8526                	mv	a0,s1
    80004494:	cbafe0ef          	jal	ra,8000294e <iunlock>
  end_op();
    80004498:	d0bfe0ef          	jal	ra,800031a2 <end_op>

  return fd;
    8000449c:	854a                	mv	a0,s2
}
    8000449e:	70ea                	ld	ra,184(sp)
    800044a0:	744a                	ld	s0,176(sp)
    800044a2:	74aa                	ld	s1,168(sp)
    800044a4:	790a                	ld	s2,160(sp)
    800044a6:	69ea                	ld	s3,152(sp)
    800044a8:	6129                	addi	sp,sp,192
    800044aa:	8082                	ret
      end_op();
    800044ac:	cf7fe0ef          	jal	ra,800031a2 <end_op>
      return -1;
    800044b0:	557d                	li	a0,-1
    800044b2:	b7f5                	j	8000449e <sys_open+0xc4>
    if((ip = namei(path)) == 0){
    800044b4:	f5040513          	addi	a0,s0,-176
    800044b8:	a9ffe0ef          	jal	ra,80002f56 <namei>
    800044bc:	84aa                	mv	s1,a0
    800044be:	c115                	beqz	a0,800044e2 <sys_open+0x108>
    ilock(ip);
    800044c0:	be4fe0ef          	jal	ra,800028a4 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800044c4:	04449703          	lh	a4,68(s1)
    800044c8:	4785                	li	a5,1
    800044ca:	f4f71fe3          	bne	a4,a5,80004428 <sys_open+0x4e>
    800044ce:	f4c42783          	lw	a5,-180(s0)
    800044d2:	d7ad                	beqz	a5,8000443c <sys_open+0x62>
      iunlockput(ip);
    800044d4:	8526                	mv	a0,s1
    800044d6:	dd4fe0ef          	jal	ra,80002aaa <iunlockput>
      end_op();
    800044da:	cc9fe0ef          	jal	ra,800031a2 <end_op>
      return -1;
    800044de:	557d                	li	a0,-1
    800044e0:	bf7d                	j	8000449e <sys_open+0xc4>
      end_op();
    800044e2:	cc1fe0ef          	jal	ra,800031a2 <end_op>
      return -1;
    800044e6:	557d                	li	a0,-1
    800044e8:	bf5d                	j	8000449e <sys_open+0xc4>
    iunlockput(ip);
    800044ea:	8526                	mv	a0,s1
    800044ec:	dbefe0ef          	jal	ra,80002aaa <iunlockput>
    end_op();
    800044f0:	cb3fe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    800044f4:	557d                	li	a0,-1
    800044f6:	b765                	j	8000449e <sys_open+0xc4>
    f->type = FD_DEVICE;
    800044f8:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    800044fc:	04649783          	lh	a5,70(s1)
    80004500:	02f99223          	sh	a5,36(s3)
    80004504:	b785                	j	80004464 <sys_open+0x8a>
    itrunc(ip);
    80004506:	8526                	mv	a0,s1
    80004508:	c86fe0ef          	jal	ra,8000298e <itrunc>
    8000450c:	b759                	j	80004492 <sys_open+0xb8>
      fileclose(f);
    8000450e:	854e                	mv	a0,s3
    80004510:	83eff0ef          	jal	ra,8000354e <fileclose>
    iunlockput(ip);
    80004514:	8526                	mv	a0,s1
    80004516:	d94fe0ef          	jal	ra,80002aaa <iunlockput>
    end_op();
    8000451a:	c89fe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    8000451e:	557d                	li	a0,-1
    80004520:	bfbd                	j	8000449e <sys_open+0xc4>

0000000080004522 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004522:	7175                	addi	sp,sp,-144
    80004524:	e506                	sd	ra,136(sp)
    80004526:	e122                	sd	s0,128(sp)
    80004528:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000452a:	c09fe0ef          	jal	ra,80003132 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000452e:	08000613          	li	a2,128
    80004532:	f7040593          	addi	a1,s0,-144
    80004536:	4501                	li	a0,0
    80004538:	86dfd0ef          	jal	ra,80001da4 <argstr>
    8000453c:	02054363          	bltz	a0,80004562 <sys_mkdir+0x40>
    80004540:	4681                	li	a3,0
    80004542:	4601                	li	a2,0
    80004544:	4585                	li	a1,1
    80004546:	f7040513          	addi	a0,s0,-144
    8000454a:	999ff0ef          	jal	ra,80003ee2 <create>
    8000454e:	c911                	beqz	a0,80004562 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004550:	d5afe0ef          	jal	ra,80002aaa <iunlockput>
  end_op();
    80004554:	c4ffe0ef          	jal	ra,800031a2 <end_op>
  return 0;
    80004558:	4501                	li	a0,0
}
    8000455a:	60aa                	ld	ra,136(sp)
    8000455c:	640a                	ld	s0,128(sp)
    8000455e:	6149                	addi	sp,sp,144
    80004560:	8082                	ret
    end_op();
    80004562:	c41fe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    80004566:	557d                	li	a0,-1
    80004568:	bfcd                	j	8000455a <sys_mkdir+0x38>

000000008000456a <sys_mknod>:

uint64
sys_mknod(void)
{
    8000456a:	7135                	addi	sp,sp,-160
    8000456c:	ed06                	sd	ra,152(sp)
    8000456e:	e922                	sd	s0,144(sp)
    80004570:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004572:	bc1fe0ef          	jal	ra,80003132 <begin_op>
  argint(1, &major);
    80004576:	f6c40593          	addi	a1,s0,-148
    8000457a:	4505                	li	a0,1
    8000457c:	ff0fd0ef          	jal	ra,80001d6c <argint>
  argint(2, &minor);
    80004580:	f6840593          	addi	a1,s0,-152
    80004584:	4509                	li	a0,2
    80004586:	fe6fd0ef          	jal	ra,80001d6c <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000458a:	08000613          	li	a2,128
    8000458e:	f7040593          	addi	a1,s0,-144
    80004592:	4501                	li	a0,0
    80004594:	811fd0ef          	jal	ra,80001da4 <argstr>
    80004598:	02054563          	bltz	a0,800045c2 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    8000459c:	f6841683          	lh	a3,-152(s0)
    800045a0:	f6c41603          	lh	a2,-148(s0)
    800045a4:	458d                	li	a1,3
    800045a6:	f7040513          	addi	a0,s0,-144
    800045aa:	939ff0ef          	jal	ra,80003ee2 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800045ae:	c911                	beqz	a0,800045c2 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800045b0:	cfafe0ef          	jal	ra,80002aaa <iunlockput>
  end_op();
    800045b4:	beffe0ef          	jal	ra,800031a2 <end_op>
  return 0;
    800045b8:	4501                	li	a0,0
}
    800045ba:	60ea                	ld	ra,152(sp)
    800045bc:	644a                	ld	s0,144(sp)
    800045be:	610d                	addi	sp,sp,160
    800045c0:	8082                	ret
    end_op();
    800045c2:	be1fe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    800045c6:	557d                	li	a0,-1
    800045c8:	bfcd                	j	800045ba <sys_mknod+0x50>

00000000800045ca <sys_chdir>:

uint64
sys_chdir(void)
{
    800045ca:	7135                	addi	sp,sp,-160
    800045cc:	ed06                	sd	ra,152(sp)
    800045ce:	e922                	sd	s0,144(sp)
    800045d0:	e526                	sd	s1,136(sp)
    800045d2:	e14a                	sd	s2,128(sp)
    800045d4:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800045d6:	849fc0ef          	jal	ra,80000e1e <myproc>
    800045da:	892a                	mv	s2,a0
  
  begin_op();
    800045dc:	b57fe0ef          	jal	ra,80003132 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800045e0:	08000613          	li	a2,128
    800045e4:	f6040593          	addi	a1,s0,-160
    800045e8:	4501                	li	a0,0
    800045ea:	fbafd0ef          	jal	ra,80001da4 <argstr>
    800045ee:	04054163          	bltz	a0,80004630 <sys_chdir+0x66>
    800045f2:	f6040513          	addi	a0,s0,-160
    800045f6:	961fe0ef          	jal	ra,80002f56 <namei>
    800045fa:	84aa                	mv	s1,a0
    800045fc:	c915                	beqz	a0,80004630 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800045fe:	aa6fe0ef          	jal	ra,800028a4 <ilock>
  if(ip->type != T_DIR){
    80004602:	04449703          	lh	a4,68(s1)
    80004606:	4785                	li	a5,1
    80004608:	02f71863          	bne	a4,a5,80004638 <sys_chdir+0x6e>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000460c:	8526                	mv	a0,s1
    8000460e:	b40fe0ef          	jal	ra,8000294e <iunlock>
  iput(p->cwd);
    80004612:	15093503          	ld	a0,336(s2)
    80004616:	c0cfe0ef          	jal	ra,80002a22 <iput>
  end_op();
    8000461a:	b89fe0ef          	jal	ra,800031a2 <end_op>
  p->cwd = ip;
    8000461e:	14993823          	sd	s1,336(s2)
  return 0;
    80004622:	4501                	li	a0,0
}
    80004624:	60ea                	ld	ra,152(sp)
    80004626:	644a                	ld	s0,144(sp)
    80004628:	64aa                	ld	s1,136(sp)
    8000462a:	690a                	ld	s2,128(sp)
    8000462c:	610d                	addi	sp,sp,160
    8000462e:	8082                	ret
    end_op();
    80004630:	b73fe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    80004634:	557d                	li	a0,-1
    80004636:	b7fd                	j	80004624 <sys_chdir+0x5a>
    iunlockput(ip);
    80004638:	8526                	mv	a0,s1
    8000463a:	c70fe0ef          	jal	ra,80002aaa <iunlockput>
    end_op();
    8000463e:	b65fe0ef          	jal	ra,800031a2 <end_op>
    return -1;
    80004642:	557d                	li	a0,-1
    80004644:	b7c5                	j	80004624 <sys_chdir+0x5a>

0000000080004646 <sys_exec>:

uint64
sys_exec(void)
{
    80004646:	7145                	addi	sp,sp,-464
    80004648:	e786                	sd	ra,456(sp)
    8000464a:	e3a2                	sd	s0,448(sp)
    8000464c:	ff26                	sd	s1,440(sp)
    8000464e:	fb4a                	sd	s2,432(sp)
    80004650:	f74e                	sd	s3,424(sp)
    80004652:	f352                	sd	s4,416(sp)
    80004654:	ef56                	sd	s5,408(sp)
    80004656:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004658:	e3840593          	addi	a1,s0,-456
    8000465c:	4505                	li	a0,1
    8000465e:	f2afd0ef          	jal	ra,80001d88 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80004662:	08000613          	li	a2,128
    80004666:	f4040593          	addi	a1,s0,-192
    8000466a:	4501                	li	a0,0
    8000466c:	f38fd0ef          	jal	ra,80001da4 <argstr>
    80004670:	87aa                	mv	a5,a0
    return -1;
    80004672:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80004674:	0a07c463          	bltz	a5,8000471c <sys_exec+0xd6>
  }
  memset(argv, 0, sizeof(argv));
    80004678:	10000613          	li	a2,256
    8000467c:	4581                	li	a1,0
    8000467e:	e4040513          	addi	a0,s0,-448
    80004682:	acbfb0ef          	jal	ra,8000014c <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80004686:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    8000468a:	89a6                	mv	s3,s1
    8000468c:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    8000468e:	02000a13          	li	s4,32
    80004692:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80004696:	00391793          	slli	a5,s2,0x3
    8000469a:	e3040593          	addi	a1,s0,-464
    8000469e:	e3843503          	ld	a0,-456(s0)
    800046a2:	953e                	add	a0,a0,a5
    800046a4:	e3efd0ef          	jal	ra,80001ce2 <fetchaddr>
    800046a8:	02054663          	bltz	a0,800046d4 <sys_exec+0x8e>
      goto bad;
    }
    if(uarg == 0){
    800046ac:	e3043783          	ld	a5,-464(s0)
    800046b0:	cf8d                	beqz	a5,800046ea <sys_exec+0xa4>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    800046b2:	a4bfb0ef          	jal	ra,800000fc <kalloc>
    800046b6:	85aa                	mv	a1,a0
    800046b8:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800046bc:	cd01                	beqz	a0,800046d4 <sys_exec+0x8e>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800046be:	6605                	lui	a2,0x1
    800046c0:	e3043503          	ld	a0,-464(s0)
    800046c4:	e68fd0ef          	jal	ra,80001d2c <fetchstr>
    800046c8:	00054663          	bltz	a0,800046d4 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    800046cc:	0905                	addi	s2,s2,1
    800046ce:	09a1                	addi	s3,s3,8
    800046d0:	fd4911e3          	bne	s2,s4,80004692 <sys_exec+0x4c>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046d4:	10048913          	addi	s2,s1,256
    800046d8:	6088                	ld	a0,0(s1)
    800046da:	c121                	beqz	a0,8000471a <sys_exec+0xd4>
    kfree(argv[i]);
    800046dc:	941fb0ef          	jal	ra,8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800046e0:	04a1                	addi	s1,s1,8
    800046e2:	ff249be3          	bne	s1,s2,800046d8 <sys_exec+0x92>
  return -1;
    800046e6:	557d                	li	a0,-1
    800046e8:	a815                	j	8000471c <sys_exec+0xd6>
      argv[i] = 0;
    800046ea:	0a8e                	slli	s5,s5,0x3
    800046ec:	fc040793          	addi	a5,s0,-64
    800046f0:	9abe                	add	s5,s5,a5
    800046f2:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    800046f6:	e4040593          	addi	a1,s0,-448
    800046fa:	f4040513          	addi	a0,s0,-192
    800046fe:	bf2ff0ef          	jal	ra,80003af0 <exec>
    80004702:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004704:	10048993          	addi	s3,s1,256
    80004708:	6088                	ld	a0,0(s1)
    8000470a:	c511                	beqz	a0,80004716 <sys_exec+0xd0>
    kfree(argv[i]);
    8000470c:	911fb0ef          	jal	ra,8000001c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80004710:	04a1                	addi	s1,s1,8
    80004712:	ff349be3          	bne	s1,s3,80004708 <sys_exec+0xc2>
  return ret;
    80004716:	854a                	mv	a0,s2
    80004718:	a011                	j	8000471c <sys_exec+0xd6>
  return -1;
    8000471a:	557d                	li	a0,-1
}
    8000471c:	60be                	ld	ra,456(sp)
    8000471e:	641e                	ld	s0,448(sp)
    80004720:	74fa                	ld	s1,440(sp)
    80004722:	795a                	ld	s2,432(sp)
    80004724:	79ba                	ld	s3,424(sp)
    80004726:	7a1a                	ld	s4,416(sp)
    80004728:	6afa                	ld	s5,408(sp)
    8000472a:	6179                	addi	sp,sp,464
    8000472c:	8082                	ret

000000008000472e <sys_pipe>:

uint64
sys_pipe(void)
{
    8000472e:	7139                	addi	sp,sp,-64
    80004730:	fc06                	sd	ra,56(sp)
    80004732:	f822                	sd	s0,48(sp)
    80004734:	f426                	sd	s1,40(sp)
    80004736:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80004738:	ee6fc0ef          	jal	ra,80000e1e <myproc>
    8000473c:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000473e:	fd840593          	addi	a1,s0,-40
    80004742:	4501                	li	a0,0
    80004744:	e44fd0ef          	jal	ra,80001d88 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80004748:	fc840593          	addi	a1,s0,-56
    8000474c:	fd040513          	addi	a0,s0,-48
    80004750:	8caff0ef          	jal	ra,8000381a <pipealloc>
    return -1;
    80004754:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80004756:	0a054463          	bltz	a0,800047fe <sys_pipe+0xd0>
  fd0 = -1;
    8000475a:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000475e:	fd043503          	ld	a0,-48(s0)
    80004762:	f42ff0ef          	jal	ra,80003ea4 <fdalloc>
    80004766:	fca42223          	sw	a0,-60(s0)
    8000476a:	08054163          	bltz	a0,800047ec <sys_pipe+0xbe>
    8000476e:	fc843503          	ld	a0,-56(s0)
    80004772:	f32ff0ef          	jal	ra,80003ea4 <fdalloc>
    80004776:	fca42023          	sw	a0,-64(s0)
    8000477a:	06054063          	bltz	a0,800047da <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000477e:	4691                	li	a3,4
    80004780:	fc440613          	addi	a2,s0,-60
    80004784:	fd843583          	ld	a1,-40(s0)
    80004788:	68a8                	ld	a0,80(s1)
    8000478a:	a4cfc0ef          	jal	ra,800009d6 <copyout>
    8000478e:	00054e63          	bltz	a0,800047aa <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80004792:	4691                	li	a3,4
    80004794:	fc040613          	addi	a2,s0,-64
    80004798:	fd843583          	ld	a1,-40(s0)
    8000479c:	0591                	addi	a1,a1,4
    8000479e:	68a8                	ld	a0,80(s1)
    800047a0:	a36fc0ef          	jal	ra,800009d6 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800047a4:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800047a6:	04055c63          	bgez	a0,800047fe <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    800047aa:	fc442783          	lw	a5,-60(s0)
    800047ae:	07e9                	addi	a5,a5,26
    800047b0:	078e                	slli	a5,a5,0x3
    800047b2:	97a6                	add	a5,a5,s1
    800047b4:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800047b8:	fc042503          	lw	a0,-64(s0)
    800047bc:	0569                	addi	a0,a0,26
    800047be:	050e                	slli	a0,a0,0x3
    800047c0:	94aa                	add	s1,s1,a0
    800047c2:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    800047c6:	fd043503          	ld	a0,-48(s0)
    800047ca:	d85fe0ef          	jal	ra,8000354e <fileclose>
    fileclose(wf);
    800047ce:	fc843503          	ld	a0,-56(s0)
    800047d2:	d7dfe0ef          	jal	ra,8000354e <fileclose>
    return -1;
    800047d6:	57fd                	li	a5,-1
    800047d8:	a01d                	j	800047fe <sys_pipe+0xd0>
    if(fd0 >= 0)
    800047da:	fc442783          	lw	a5,-60(s0)
    800047de:	0007c763          	bltz	a5,800047ec <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800047e2:	07e9                	addi	a5,a5,26
    800047e4:	078e                	slli	a5,a5,0x3
    800047e6:	94be                	add	s1,s1,a5
    800047e8:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    800047ec:	fd043503          	ld	a0,-48(s0)
    800047f0:	d5ffe0ef          	jal	ra,8000354e <fileclose>
    fileclose(wf);
    800047f4:	fc843503          	ld	a0,-56(s0)
    800047f8:	d57fe0ef          	jal	ra,8000354e <fileclose>
    return -1;
    800047fc:	57fd                	li	a5,-1
}
    800047fe:	853e                	mv	a0,a5
    80004800:	70e2                	ld	ra,56(sp)
    80004802:	7442                	ld	s0,48(sp)
    80004804:	74a2                	ld	s1,40(sp)
    80004806:	6121                	addi	sp,sp,64
    80004808:	8082                	ret
    8000480a:	0000                	unimp
    8000480c:	0000                	unimp
	...

0000000080004810 <kernelvec>:
    80004810:	7111                	addi	sp,sp,-256
    80004812:	e006                	sd	ra,0(sp)
    80004814:	e40a                	sd	sp,8(sp)
    80004816:	e80e                	sd	gp,16(sp)
    80004818:	ec12                	sd	tp,24(sp)
    8000481a:	f016                	sd	t0,32(sp)
    8000481c:	f41a                	sd	t1,40(sp)
    8000481e:	f81e                	sd	t2,48(sp)
    80004820:	e4aa                	sd	a0,72(sp)
    80004822:	e8ae                	sd	a1,80(sp)
    80004824:	ecb2                	sd	a2,88(sp)
    80004826:	f0b6                	sd	a3,96(sp)
    80004828:	f4ba                	sd	a4,104(sp)
    8000482a:	f8be                	sd	a5,112(sp)
    8000482c:	fcc2                	sd	a6,120(sp)
    8000482e:	e146                	sd	a7,128(sp)
    80004830:	edf2                	sd	t3,216(sp)
    80004832:	f1f6                	sd	t4,224(sp)
    80004834:	f5fa                	sd	t5,232(sp)
    80004836:	f9fe                	sd	t6,240(sp)
    80004838:	bbafd0ef          	jal	ra,80001bf2 <kerneltrap>
    8000483c:	6082                	ld	ra,0(sp)
    8000483e:	6122                	ld	sp,8(sp)
    80004840:	61c2                	ld	gp,16(sp)
    80004842:	7282                	ld	t0,32(sp)
    80004844:	7322                	ld	t1,40(sp)
    80004846:	73c2                	ld	t2,48(sp)
    80004848:	6526                	ld	a0,72(sp)
    8000484a:	65c6                	ld	a1,80(sp)
    8000484c:	6666                	ld	a2,88(sp)
    8000484e:	7686                	ld	a3,96(sp)
    80004850:	7726                	ld	a4,104(sp)
    80004852:	77c6                	ld	a5,112(sp)
    80004854:	7866                	ld	a6,120(sp)
    80004856:	688a                	ld	a7,128(sp)
    80004858:	6e6e                	ld	t3,216(sp)
    8000485a:	7e8e                	ld	t4,224(sp)
    8000485c:	7f2e                	ld	t5,232(sp)
    8000485e:	7fce                	ld	t6,240(sp)
    80004860:	6111                	addi	sp,sp,256
    80004862:	10200073          	sret
	...

000000008000486e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000486e:	1141                	addi	sp,sp,-16
    80004870:	e422                	sd	s0,8(sp)
    80004872:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80004874:	0c0007b7          	lui	a5,0xc000
    80004878:	4705                	li	a4,1
    8000487a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000487c:	c3d8                	sw	a4,4(a5)
}
    8000487e:	6422                	ld	s0,8(sp)
    80004880:	0141                	addi	sp,sp,16
    80004882:	8082                	ret

0000000080004884 <plicinithart>:

void
plicinithart(void)
{
    80004884:	1141                	addi	sp,sp,-16
    80004886:	e406                	sd	ra,8(sp)
    80004888:	e022                	sd	s0,0(sp)
    8000488a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    8000488c:	d66fc0ef          	jal	ra,80000df2 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80004890:	0085171b          	slliw	a4,a0,0x8
    80004894:	0c0027b7          	lui	a5,0xc002
    80004898:	97ba                	add	a5,a5,a4
    8000489a:	40200713          	li	a4,1026
    8000489e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800048a2:	00d5151b          	slliw	a0,a0,0xd
    800048a6:	0c2017b7          	lui	a5,0xc201
    800048aa:	953e                	add	a0,a0,a5
    800048ac:	00052023          	sw	zero,0(a0)
}
    800048b0:	60a2                	ld	ra,8(sp)
    800048b2:	6402                	ld	s0,0(sp)
    800048b4:	0141                	addi	sp,sp,16
    800048b6:	8082                	ret

00000000800048b8 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800048b8:	1141                	addi	sp,sp,-16
    800048ba:	e406                	sd	ra,8(sp)
    800048bc:	e022                	sd	s0,0(sp)
    800048be:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800048c0:	d32fc0ef          	jal	ra,80000df2 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800048c4:	00d5179b          	slliw	a5,a0,0xd
    800048c8:	0c201537          	lui	a0,0xc201
    800048cc:	953e                	add	a0,a0,a5
  return irq;
}
    800048ce:	4148                	lw	a0,4(a0)
    800048d0:	60a2                	ld	ra,8(sp)
    800048d2:	6402                	ld	s0,0(sp)
    800048d4:	0141                	addi	sp,sp,16
    800048d6:	8082                	ret

00000000800048d8 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800048d8:	1101                	addi	sp,sp,-32
    800048da:	ec06                	sd	ra,24(sp)
    800048dc:	e822                	sd	s0,16(sp)
    800048de:	e426                	sd	s1,8(sp)
    800048e0:	1000                	addi	s0,sp,32
    800048e2:	84aa                	mv	s1,a0
  int hart = cpuid();
    800048e4:	d0efc0ef          	jal	ra,80000df2 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800048e8:	00d5151b          	slliw	a0,a0,0xd
    800048ec:	0c2017b7          	lui	a5,0xc201
    800048f0:	97aa                	add	a5,a5,a0
    800048f2:	c3c4                	sw	s1,4(a5)
}
    800048f4:	60e2                	ld	ra,24(sp)
    800048f6:	6442                	ld	s0,16(sp)
    800048f8:	64a2                	ld	s1,8(sp)
    800048fa:	6105                	addi	sp,sp,32
    800048fc:	8082                	ret

00000000800048fe <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800048fe:	1141                	addi	sp,sp,-16
    80004900:	e406                	sd	ra,8(sp)
    80004902:	e022                	sd	s0,0(sp)
    80004904:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80004906:	479d                	li	a5,7
    80004908:	04a7ca63          	blt	a5,a0,8000495c <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    8000490c:	00014797          	auipc	a5,0x14
    80004910:	39478793          	addi	a5,a5,916 # 80018ca0 <disk>
    80004914:	97aa                	add	a5,a5,a0
    80004916:	0187c783          	lbu	a5,24(a5)
    8000491a:	e7b9                	bnez	a5,80004968 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    8000491c:	00451613          	slli	a2,a0,0x4
    80004920:	00014797          	auipc	a5,0x14
    80004924:	38078793          	addi	a5,a5,896 # 80018ca0 <disk>
    80004928:	6394                	ld	a3,0(a5)
    8000492a:	96b2                	add	a3,a3,a2
    8000492c:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    80004930:	6398                	ld	a4,0(a5)
    80004932:	9732                	add	a4,a4,a2
    80004934:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80004938:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    8000493c:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80004940:	953e                	add	a0,a0,a5
    80004942:	4785                	li	a5,1
    80004944:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    80004948:	00014517          	auipc	a0,0x14
    8000494c:	37050513          	addi	a0,a0,880 # 80018cb8 <disk+0x18>
    80004950:	b87fc0ef          	jal	ra,800014d6 <wakeup>
}
    80004954:	60a2                	ld	ra,8(sp)
    80004956:	6402                	ld	s0,0(sp)
    80004958:	0141                	addi	sp,sp,16
    8000495a:	8082                	ret
    panic("free_desc 1");
    8000495c:	00003517          	auipc	a0,0x3
    80004960:	e5c50513          	addi	a0,a0,-420 # 800077b8 <syscalls+0x358>
    80004964:	3c3000ef          	jal	ra,80005526 <panic>
    panic("free_desc 2");
    80004968:	00003517          	auipc	a0,0x3
    8000496c:	e6050513          	addi	a0,a0,-416 # 800077c8 <syscalls+0x368>
    80004970:	3b7000ef          	jal	ra,80005526 <panic>

0000000080004974 <virtio_disk_init>:
{
    80004974:	1101                	addi	sp,sp,-32
    80004976:	ec06                	sd	ra,24(sp)
    80004978:	e822                	sd	s0,16(sp)
    8000497a:	e426                	sd	s1,8(sp)
    8000497c:	e04a                	sd	s2,0(sp)
    8000497e:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80004980:	00003597          	auipc	a1,0x3
    80004984:	e5858593          	addi	a1,a1,-424 # 800077d8 <syscalls+0x378>
    80004988:	00014517          	auipc	a0,0x14
    8000498c:	44050513          	addi	a0,a0,1088 # 80018dc8 <disk+0x128>
    80004990:	62b000ef          	jal	ra,800057ba <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80004994:	100017b7          	lui	a5,0x10001
    80004998:	4398                	lw	a4,0(a5)
    8000499a:	2701                	sext.w	a4,a4
    8000499c:	747277b7          	lui	a5,0x74727
    800049a0:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800049a4:	14f71063          	bne	a4,a5,80004ae4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800049a8:	100017b7          	lui	a5,0x10001
    800049ac:	43dc                	lw	a5,4(a5)
    800049ae:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800049b0:	4709                	li	a4,2
    800049b2:	12e79963          	bne	a5,a4,80004ae4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800049b6:	100017b7          	lui	a5,0x10001
    800049ba:	479c                	lw	a5,8(a5)
    800049bc:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800049be:	12e79363          	bne	a5,a4,80004ae4 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800049c2:	100017b7          	lui	a5,0x10001
    800049c6:	47d8                	lw	a4,12(a5)
    800049c8:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800049ca:	554d47b7          	lui	a5,0x554d4
    800049ce:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800049d2:	10f71963          	bne	a4,a5,80004ae4 <virtio_disk_init+0x170>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049d6:	100017b7          	lui	a5,0x10001
    800049da:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800049de:	4705                	li	a4,1
    800049e0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049e2:	470d                	li	a4,3
    800049e4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800049e6:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800049e8:	c7ffe737          	lui	a4,0xc7ffe
    800049ec:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd87f>
    800049f0:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800049f2:	2701                	sext.w	a4,a4
    800049f4:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800049f6:	472d                	li	a4,11
    800049f8:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800049fa:	5bbc                	lw	a5,112(a5)
    800049fc:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80004a00:	8ba1                	andi	a5,a5,8
    80004a02:	0e078763          	beqz	a5,80004af0 <virtio_disk_init+0x17c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80004a06:	100017b7          	lui	a5,0x10001
    80004a0a:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80004a0e:	43fc                	lw	a5,68(a5)
    80004a10:	2781                	sext.w	a5,a5
    80004a12:	0e079563          	bnez	a5,80004afc <virtio_disk_init+0x188>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80004a16:	100017b7          	lui	a5,0x10001
    80004a1a:	5bdc                	lw	a5,52(a5)
    80004a1c:	2781                	sext.w	a5,a5
  if(max == 0)
    80004a1e:	0e078563          	beqz	a5,80004b08 <virtio_disk_init+0x194>
  if(max < NUM)
    80004a22:	471d                	li	a4,7
    80004a24:	0ef77863          	bgeu	a4,a5,80004b14 <virtio_disk_init+0x1a0>
  disk.desc = kalloc();
    80004a28:	ed4fb0ef          	jal	ra,800000fc <kalloc>
    80004a2c:	00014497          	auipc	s1,0x14
    80004a30:	27448493          	addi	s1,s1,628 # 80018ca0 <disk>
    80004a34:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80004a36:	ec6fb0ef          	jal	ra,800000fc <kalloc>
    80004a3a:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80004a3c:	ec0fb0ef          	jal	ra,800000fc <kalloc>
    80004a40:	87aa                	mv	a5,a0
    80004a42:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80004a44:	6088                	ld	a0,0(s1)
    80004a46:	cd69                	beqz	a0,80004b20 <virtio_disk_init+0x1ac>
    80004a48:	00014717          	auipc	a4,0x14
    80004a4c:	26073703          	ld	a4,608(a4) # 80018ca8 <disk+0x8>
    80004a50:	cb61                	beqz	a4,80004b20 <virtio_disk_init+0x1ac>
    80004a52:	c7f9                	beqz	a5,80004b20 <virtio_disk_init+0x1ac>
  memset(disk.desc, 0, PGSIZE);
    80004a54:	6605                	lui	a2,0x1
    80004a56:	4581                	li	a1,0
    80004a58:	ef4fb0ef          	jal	ra,8000014c <memset>
  memset(disk.avail, 0, PGSIZE);
    80004a5c:	00014497          	auipc	s1,0x14
    80004a60:	24448493          	addi	s1,s1,580 # 80018ca0 <disk>
    80004a64:	6605                	lui	a2,0x1
    80004a66:	4581                	li	a1,0
    80004a68:	6488                	ld	a0,8(s1)
    80004a6a:	ee2fb0ef          	jal	ra,8000014c <memset>
  memset(disk.used, 0, PGSIZE);
    80004a6e:	6605                	lui	a2,0x1
    80004a70:	4581                	li	a1,0
    80004a72:	6888                	ld	a0,16(s1)
    80004a74:	ed8fb0ef          	jal	ra,8000014c <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80004a78:	100017b7          	lui	a5,0x10001
    80004a7c:	4721                	li	a4,8
    80004a7e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80004a80:	4098                	lw	a4,0(s1)
    80004a82:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80004a86:	40d8                	lw	a4,4(s1)
    80004a88:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80004a8c:	6498                	ld	a4,8(s1)
    80004a8e:	0007069b          	sext.w	a3,a4
    80004a92:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80004a96:	9701                	srai	a4,a4,0x20
    80004a98:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80004a9c:	6898                	ld	a4,16(s1)
    80004a9e:	0007069b          	sext.w	a3,a4
    80004aa2:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80004aa6:	9701                	srai	a4,a4,0x20
    80004aa8:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80004aac:	4705                	li	a4,1
    80004aae:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80004ab0:	00e48c23          	sb	a4,24(s1)
    80004ab4:	00e48ca3          	sb	a4,25(s1)
    80004ab8:	00e48d23          	sb	a4,26(s1)
    80004abc:	00e48da3          	sb	a4,27(s1)
    80004ac0:	00e48e23          	sb	a4,28(s1)
    80004ac4:	00e48ea3          	sb	a4,29(s1)
    80004ac8:	00e48f23          	sb	a4,30(s1)
    80004acc:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80004ad0:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80004ad4:	0727a823          	sw	s2,112(a5)
}
    80004ad8:	60e2                	ld	ra,24(sp)
    80004ada:	6442                	ld	s0,16(sp)
    80004adc:	64a2                	ld	s1,8(sp)
    80004ade:	6902                	ld	s2,0(sp)
    80004ae0:	6105                	addi	sp,sp,32
    80004ae2:	8082                	ret
    panic("could not find virtio disk");
    80004ae4:	00003517          	auipc	a0,0x3
    80004ae8:	d0450513          	addi	a0,a0,-764 # 800077e8 <syscalls+0x388>
    80004aec:	23b000ef          	jal	ra,80005526 <panic>
    panic("virtio disk FEATURES_OK unset");
    80004af0:	00003517          	auipc	a0,0x3
    80004af4:	d1850513          	addi	a0,a0,-744 # 80007808 <syscalls+0x3a8>
    80004af8:	22f000ef          	jal	ra,80005526 <panic>
    panic("virtio disk should not be ready");
    80004afc:	00003517          	auipc	a0,0x3
    80004b00:	d2c50513          	addi	a0,a0,-724 # 80007828 <syscalls+0x3c8>
    80004b04:	223000ef          	jal	ra,80005526 <panic>
    panic("virtio disk has no queue 0");
    80004b08:	00003517          	auipc	a0,0x3
    80004b0c:	d4050513          	addi	a0,a0,-704 # 80007848 <syscalls+0x3e8>
    80004b10:	217000ef          	jal	ra,80005526 <panic>
    panic("virtio disk max queue too short");
    80004b14:	00003517          	auipc	a0,0x3
    80004b18:	d5450513          	addi	a0,a0,-684 # 80007868 <syscalls+0x408>
    80004b1c:	20b000ef          	jal	ra,80005526 <panic>
    panic("virtio disk kalloc");
    80004b20:	00003517          	auipc	a0,0x3
    80004b24:	d6850513          	addi	a0,a0,-664 # 80007888 <syscalls+0x428>
    80004b28:	1ff000ef          	jal	ra,80005526 <panic>

0000000080004b2c <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80004b2c:	7119                	addi	sp,sp,-128
    80004b2e:	fc86                	sd	ra,120(sp)
    80004b30:	f8a2                	sd	s0,112(sp)
    80004b32:	f4a6                	sd	s1,104(sp)
    80004b34:	f0ca                	sd	s2,96(sp)
    80004b36:	ecce                	sd	s3,88(sp)
    80004b38:	e8d2                	sd	s4,80(sp)
    80004b3a:	e4d6                	sd	s5,72(sp)
    80004b3c:	e0da                	sd	s6,64(sp)
    80004b3e:	fc5e                	sd	s7,56(sp)
    80004b40:	f862                	sd	s8,48(sp)
    80004b42:	f466                	sd	s9,40(sp)
    80004b44:	f06a                	sd	s10,32(sp)
    80004b46:	ec6e                	sd	s11,24(sp)
    80004b48:	0100                	addi	s0,sp,128
    80004b4a:	8aaa                	mv	s5,a0
    80004b4c:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80004b4e:	00c52d03          	lw	s10,12(a0)
    80004b52:	001d1d1b          	slliw	s10,s10,0x1
    80004b56:	1d02                	slli	s10,s10,0x20
    80004b58:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    80004b5c:	00014517          	auipc	a0,0x14
    80004b60:	26c50513          	addi	a0,a0,620 # 80018dc8 <disk+0x128>
    80004b64:	4d7000ef          	jal	ra,8000583a <acquire>
  for(int i = 0; i < 3; i++){
    80004b68:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80004b6a:	44a1                	li	s1,8
      disk.free[i] = 0;
    80004b6c:	00014b97          	auipc	s7,0x14
    80004b70:	134b8b93          	addi	s7,s7,308 # 80018ca0 <disk>
  for(int i = 0; i < 3; i++){
    80004b74:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004b76:	00014c97          	auipc	s9,0x14
    80004b7a:	252c8c93          	addi	s9,s9,594 # 80018dc8 <disk+0x128>
    80004b7e:	a8a9                	j	80004bd8 <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    80004b80:	00fb8733          	add	a4,s7,a5
    80004b84:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80004b88:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80004b8a:	0207c563          	bltz	a5,80004bb4 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    80004b8e:	2905                	addiw	s2,s2,1
    80004b90:	0611                	addi	a2,a2,4
    80004b92:	05690863          	beq	s2,s6,80004be2 <virtio_disk_rw+0xb6>
    idx[i] = alloc_desc();
    80004b96:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80004b98:	00014717          	auipc	a4,0x14
    80004b9c:	10870713          	addi	a4,a4,264 # 80018ca0 <disk>
    80004ba0:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80004ba2:	01874683          	lbu	a3,24(a4)
    80004ba6:	fee9                	bnez	a3,80004b80 <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80004ba8:	2785                	addiw	a5,a5,1
    80004baa:	0705                	addi	a4,a4,1
    80004bac:	fe979be3          	bne	a5,s1,80004ba2 <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    80004bb0:	57fd                	li	a5,-1
    80004bb2:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80004bb4:	01205b63          	blez	s2,80004bca <virtio_disk_rw+0x9e>
    80004bb8:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    80004bba:	000a2503          	lw	a0,0(s4)
    80004bbe:	d41ff0ef          	jal	ra,800048fe <free_desc>
      for(int j = 0; j < i; j++)
    80004bc2:	2d85                	addiw	s11,s11,1
    80004bc4:	0a11                	addi	s4,s4,4
    80004bc6:	ffb91ae3          	bne	s2,s11,80004bba <virtio_disk_rw+0x8e>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80004bca:	85e6                	mv	a1,s9
    80004bcc:	00014517          	auipc	a0,0x14
    80004bd0:	0ec50513          	addi	a0,a0,236 # 80018cb8 <disk+0x18>
    80004bd4:	8b7fc0ef          	jal	ra,8000148a <sleep>
  for(int i = 0; i < 3; i++){
    80004bd8:	f8040a13          	addi	s4,s0,-128
{
    80004bdc:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    80004bde:	894e                	mv	s2,s3
    80004be0:	bf5d                	j	80004b96 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004be2:	f8042583          	lw	a1,-128(s0)
    80004be6:	00a58793          	addi	a5,a1,10
    80004bea:	0792                	slli	a5,a5,0x4

  if(write)
    80004bec:	00014617          	auipc	a2,0x14
    80004bf0:	0b460613          	addi	a2,a2,180 # 80018ca0 <disk>
    80004bf4:	00f60733          	add	a4,a2,a5
    80004bf8:	018036b3          	snez	a3,s8
    80004bfc:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80004bfe:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80004c02:	01a73823          	sd	s10,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80004c06:	f6078693          	addi	a3,a5,-160
    80004c0a:	6218                	ld	a4,0(a2)
    80004c0c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80004c0e:	00878513          	addi	a0,a5,8
    80004c12:	9532                	add	a0,a0,a2
  disk.desc[idx[0]].addr = (uint64) buf0;
    80004c14:	e308                	sd	a0,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80004c16:	6208                	ld	a0,0(a2)
    80004c18:	96aa                	add	a3,a3,a0
    80004c1a:	4741                	li	a4,16
    80004c1c:	c698                	sw	a4,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80004c1e:	4705                	li	a4,1
    80004c20:	00e69623          	sh	a4,12(a3)
  disk.desc[idx[0]].next = idx[1];
    80004c24:	f8442703          	lw	a4,-124(s0)
    80004c28:	00e69723          	sh	a4,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80004c2c:	0712                	slli	a4,a4,0x4
    80004c2e:	953a                	add	a0,a0,a4
    80004c30:	058a8693          	addi	a3,s5,88
    80004c34:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    80004c36:	6208                	ld	a0,0(a2)
    80004c38:	972a                	add	a4,a4,a0
    80004c3a:	40000693          	li	a3,1024
    80004c3e:	c714                	sw	a3,8(a4)
  if(write)
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    80004c40:	001c3c13          	seqz	s8,s8
    80004c44:	0c06                	slli	s8,s8,0x1
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80004c46:	001c6c13          	ori	s8,s8,1
    80004c4a:	01871623          	sh	s8,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80004c4e:	f8842603          	lw	a2,-120(s0)
    80004c52:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80004c56:	00014697          	auipc	a3,0x14
    80004c5a:	04a68693          	addi	a3,a3,74 # 80018ca0 <disk>
    80004c5e:	00258713          	addi	a4,a1,2
    80004c62:	0712                	slli	a4,a4,0x4
    80004c64:	9736                	add	a4,a4,a3
    80004c66:	587d                	li	a6,-1
    80004c68:	01070823          	sb	a6,16(a4)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80004c6c:	0612                	slli	a2,a2,0x4
    80004c6e:	9532                	add	a0,a0,a2
    80004c70:	f9078793          	addi	a5,a5,-112
    80004c74:	97b6                	add	a5,a5,a3
    80004c76:	e11c                	sd	a5,0(a0)
  disk.desc[idx[2]].len = 1;
    80004c78:	629c                	ld	a5,0(a3)
    80004c7a:	97b2                	add	a5,a5,a2
    80004c7c:	4605                	li	a2,1
    80004c7e:	c790                	sw	a2,8(a5)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80004c80:	4509                	li	a0,2
    80004c82:	00a79623          	sh	a0,12(a5)
  disk.desc[idx[2]].next = 0;
    80004c86:	00079723          	sh	zero,14(a5)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80004c8a:	00caa223          	sw	a2,4(s5)
  disk.info[idx[0]].b = b;
    80004c8e:	01573423          	sd	s5,8(a4)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80004c92:	6698                	ld	a4,8(a3)
    80004c94:	00275783          	lhu	a5,2(a4)
    80004c98:	8b9d                	andi	a5,a5,7
    80004c9a:	0786                	slli	a5,a5,0x1
    80004c9c:	97ba                	add	a5,a5,a4
    80004c9e:	00b79223          	sh	a1,4(a5)

  __sync_synchronize();
    80004ca2:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80004ca6:	6698                	ld	a4,8(a3)
    80004ca8:	00275783          	lhu	a5,2(a4)
    80004cac:	2785                	addiw	a5,a5,1
    80004cae:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80004cb2:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80004cb6:	100017b7          	lui	a5,0x10001
    80004cba:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80004cbe:	004aa783          	lw	a5,4(s5)
    80004cc2:	00c79f63          	bne	a5,a2,80004ce0 <virtio_disk_rw+0x1b4>
    sleep(b, &disk.vdisk_lock);
    80004cc6:	00014917          	auipc	s2,0x14
    80004cca:	10290913          	addi	s2,s2,258 # 80018dc8 <disk+0x128>
  while(b->disk == 1) {
    80004cce:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80004cd0:	85ca                	mv	a1,s2
    80004cd2:	8556                	mv	a0,s5
    80004cd4:	fb6fc0ef          	jal	ra,8000148a <sleep>
  while(b->disk == 1) {
    80004cd8:	004aa783          	lw	a5,4(s5)
    80004cdc:	fe978ae3          	beq	a5,s1,80004cd0 <virtio_disk_rw+0x1a4>
  }

  disk.info[idx[0]].b = 0;
    80004ce0:	f8042903          	lw	s2,-128(s0)
    80004ce4:	00290793          	addi	a5,s2,2
    80004ce8:	00479713          	slli	a4,a5,0x4
    80004cec:	00014797          	auipc	a5,0x14
    80004cf0:	fb478793          	addi	a5,a5,-76 # 80018ca0 <disk>
    80004cf4:	97ba                	add	a5,a5,a4
    80004cf6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80004cfa:	00014997          	auipc	s3,0x14
    80004cfe:	fa698993          	addi	s3,s3,-90 # 80018ca0 <disk>
    80004d02:	00491713          	slli	a4,s2,0x4
    80004d06:	0009b783          	ld	a5,0(s3)
    80004d0a:	97ba                	add	a5,a5,a4
    80004d0c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80004d10:	854a                	mv	a0,s2
    80004d12:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80004d16:	be9ff0ef          	jal	ra,800048fe <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80004d1a:	8885                	andi	s1,s1,1
    80004d1c:	f0fd                	bnez	s1,80004d02 <virtio_disk_rw+0x1d6>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80004d1e:	00014517          	auipc	a0,0x14
    80004d22:	0aa50513          	addi	a0,a0,170 # 80018dc8 <disk+0x128>
    80004d26:	3ad000ef          	jal	ra,800058d2 <release>
}
    80004d2a:	70e6                	ld	ra,120(sp)
    80004d2c:	7446                	ld	s0,112(sp)
    80004d2e:	74a6                	ld	s1,104(sp)
    80004d30:	7906                	ld	s2,96(sp)
    80004d32:	69e6                	ld	s3,88(sp)
    80004d34:	6a46                	ld	s4,80(sp)
    80004d36:	6aa6                	ld	s5,72(sp)
    80004d38:	6b06                	ld	s6,64(sp)
    80004d3a:	7be2                	ld	s7,56(sp)
    80004d3c:	7c42                	ld	s8,48(sp)
    80004d3e:	7ca2                	ld	s9,40(sp)
    80004d40:	7d02                	ld	s10,32(sp)
    80004d42:	6de2                	ld	s11,24(sp)
    80004d44:	6109                	addi	sp,sp,128
    80004d46:	8082                	ret

0000000080004d48 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80004d48:	1101                	addi	sp,sp,-32
    80004d4a:	ec06                	sd	ra,24(sp)
    80004d4c:	e822                	sd	s0,16(sp)
    80004d4e:	e426                	sd	s1,8(sp)
    80004d50:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80004d52:	00014497          	auipc	s1,0x14
    80004d56:	f4e48493          	addi	s1,s1,-178 # 80018ca0 <disk>
    80004d5a:	00014517          	auipc	a0,0x14
    80004d5e:	06e50513          	addi	a0,a0,110 # 80018dc8 <disk+0x128>
    80004d62:	2d9000ef          	jal	ra,8000583a <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80004d66:	10001737          	lui	a4,0x10001
    80004d6a:	533c                	lw	a5,96(a4)
    80004d6c:	8b8d                	andi	a5,a5,3
    80004d6e:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80004d70:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80004d74:	689c                	ld	a5,16(s1)
    80004d76:	0204d703          	lhu	a4,32(s1)
    80004d7a:	0027d783          	lhu	a5,2(a5)
    80004d7e:	04f70663          	beq	a4,a5,80004dca <virtio_disk_intr+0x82>
    __sync_synchronize();
    80004d82:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80004d86:	6898                	ld	a4,16(s1)
    80004d88:	0204d783          	lhu	a5,32(s1)
    80004d8c:	8b9d                	andi	a5,a5,7
    80004d8e:	078e                	slli	a5,a5,0x3
    80004d90:	97ba                	add	a5,a5,a4
    80004d92:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80004d94:	00278713          	addi	a4,a5,2
    80004d98:	0712                	slli	a4,a4,0x4
    80004d9a:	9726                	add	a4,a4,s1
    80004d9c:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80004da0:	e321                	bnez	a4,80004de0 <virtio_disk_intr+0x98>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80004da2:	0789                	addi	a5,a5,2
    80004da4:	0792                	slli	a5,a5,0x4
    80004da6:	97a6                	add	a5,a5,s1
    80004da8:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80004daa:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80004dae:	f28fc0ef          	jal	ra,800014d6 <wakeup>

    disk.used_idx += 1;
    80004db2:	0204d783          	lhu	a5,32(s1)
    80004db6:	2785                	addiw	a5,a5,1
    80004db8:	17c2                	slli	a5,a5,0x30
    80004dba:	93c1                	srli	a5,a5,0x30
    80004dbc:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80004dc0:	6898                	ld	a4,16(s1)
    80004dc2:	00275703          	lhu	a4,2(a4)
    80004dc6:	faf71ee3          	bne	a4,a5,80004d82 <virtio_disk_intr+0x3a>
  }

  release(&disk.vdisk_lock);
    80004dca:	00014517          	auipc	a0,0x14
    80004dce:	ffe50513          	addi	a0,a0,-2 # 80018dc8 <disk+0x128>
    80004dd2:	301000ef          	jal	ra,800058d2 <release>
}
    80004dd6:	60e2                	ld	ra,24(sp)
    80004dd8:	6442                	ld	s0,16(sp)
    80004dda:	64a2                	ld	s1,8(sp)
    80004ddc:	6105                	addi	sp,sp,32
    80004dde:	8082                	ret
      panic("virtio_disk_intr status");
    80004de0:	00003517          	auipc	a0,0x3
    80004de4:	ac050513          	addi	a0,a0,-1344 # 800078a0 <syscalls+0x440>
    80004de8:	73e000ef          	jal	ra,80005526 <panic>

0000000080004dec <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    80004dec:	1141                	addi	sp,sp,-16
    80004dee:	e422                	sd	s0,8(sp)
    80004df0:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mie" : "=r" (x) );
    80004df2:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80004df6:	0207e793          	ori	a5,a5,32
  asm volatile("csrw mie, %0" : : "r" (x));
    80004dfa:	30479073          	csrw	mie,a5
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80004dfe:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80004e02:	577d                	li	a4,-1
    80004e04:	177e                	slli	a4,a4,0x3f
    80004e06:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80004e08:	30a79073          	csrw	0x30a,a5
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    80004e0c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80004e10:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80004e14:	30679073          	csrw	mcounteren,a5
  asm volatile("csrr %0, time" : "=r" (x) );
    80004e18:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80004e1c:	000f4737          	lui	a4,0xf4
    80004e20:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80004e24:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80004e26:	14d79073          	csrw	0x14d,a5
}
    80004e2a:	6422                	ld	s0,8(sp)
    80004e2c:	0141                	addi	sp,sp,16
    80004e2e:	8082                	ret

0000000080004e30 <start>:
{
    80004e30:	1141                	addi	sp,sp,-16
    80004e32:	e406                	sd	ra,8(sp)
    80004e34:	e022                	sd	s0,0(sp)
    80004e36:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80004e38:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80004e3c:	7779                	lui	a4,0xffffe
    80004e3e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd91f>
    80004e42:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80004e44:	6705                	lui	a4,0x1
    80004e46:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80004e4a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80004e4c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80004e50:	ffffb797          	auipc	a5,0xffffb
    80004e54:	49e78793          	addi	a5,a5,1182 # 800002ee <main>
    80004e58:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80004e5c:	4781                	li	a5,0
    80004e5e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80004e62:	67c1                	lui	a5,0x10
    80004e64:	17fd                	addi	a5,a5,-1
    80004e66:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80004e6a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    80004e6e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    80004e72:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    80004e76:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    80004e7a:	57fd                	li	a5,-1
    80004e7c:	83a9                	srli	a5,a5,0xa
    80004e7e:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    80004e82:	47bd                	li	a5,15
    80004e84:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    80004e88:	f65ff0ef          	jal	ra,80004dec <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80004e8c:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    80004e90:	2781                	sext.w	a5,a5
  asm volatile("mv tp, %0" : : "r" (x));
    80004e92:	823e                	mv	tp,a5
  asm volatile("mret");
    80004e94:	30200073          	mret
}
    80004e98:	60a2                	ld	ra,8(sp)
    80004e9a:	6402                	ld	s0,0(sp)
    80004e9c:	0141                	addi	sp,sp,16
    80004e9e:	8082                	ret

0000000080004ea0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80004ea0:	715d                	addi	sp,sp,-80
    80004ea2:	e486                	sd	ra,72(sp)
    80004ea4:	e0a2                	sd	s0,64(sp)
    80004ea6:	fc26                	sd	s1,56(sp)
    80004ea8:	f84a                	sd	s2,48(sp)
    80004eaa:	f44e                	sd	s3,40(sp)
    80004eac:	f052                	sd	s4,32(sp)
    80004eae:	ec56                	sd	s5,24(sp)
    80004eb0:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80004eb2:	04c05263          	blez	a2,80004ef6 <consolewrite+0x56>
    80004eb6:	8a2a                	mv	s4,a0
    80004eb8:	84ae                	mv	s1,a1
    80004eba:	89b2                	mv	s3,a2
    80004ebc:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80004ebe:	5afd                	li	s5,-1
    80004ec0:	4685                	li	a3,1
    80004ec2:	8626                	mv	a2,s1
    80004ec4:	85d2                	mv	a1,s4
    80004ec6:	fbf40513          	addi	a0,s0,-65
    80004eca:	967fc0ef          	jal	ra,80001830 <either_copyin>
    80004ece:	01550a63          	beq	a0,s5,80004ee2 <consolewrite+0x42>
      break;
    uartputc(c);
    80004ed2:	fbf44503          	lbu	a0,-65(s0)
    80004ed6:	7da000ef          	jal	ra,800056b0 <uartputc>
  for(i = 0; i < n; i++){
    80004eda:	2905                	addiw	s2,s2,1
    80004edc:	0485                	addi	s1,s1,1
    80004ede:	ff2991e3          	bne	s3,s2,80004ec0 <consolewrite+0x20>
  }

  return i;
}
    80004ee2:	854a                	mv	a0,s2
    80004ee4:	60a6                	ld	ra,72(sp)
    80004ee6:	6406                	ld	s0,64(sp)
    80004ee8:	74e2                	ld	s1,56(sp)
    80004eea:	7942                	ld	s2,48(sp)
    80004eec:	79a2                	ld	s3,40(sp)
    80004eee:	7a02                	ld	s4,32(sp)
    80004ef0:	6ae2                	ld	s5,24(sp)
    80004ef2:	6161                	addi	sp,sp,80
    80004ef4:	8082                	ret
  for(i = 0; i < n; i++){
    80004ef6:	4901                	li	s2,0
    80004ef8:	b7ed                	j	80004ee2 <consolewrite+0x42>

0000000080004efa <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80004efa:	7159                	addi	sp,sp,-112
    80004efc:	f486                	sd	ra,104(sp)
    80004efe:	f0a2                	sd	s0,96(sp)
    80004f00:	eca6                	sd	s1,88(sp)
    80004f02:	e8ca                	sd	s2,80(sp)
    80004f04:	e4ce                	sd	s3,72(sp)
    80004f06:	e0d2                	sd	s4,64(sp)
    80004f08:	fc56                	sd	s5,56(sp)
    80004f0a:	f85a                	sd	s6,48(sp)
    80004f0c:	f45e                	sd	s7,40(sp)
    80004f0e:	f062                	sd	s8,32(sp)
    80004f10:	ec66                	sd	s9,24(sp)
    80004f12:	e86a                	sd	s10,16(sp)
    80004f14:	1880                	addi	s0,sp,112
    80004f16:	8aaa                	mv	s5,a0
    80004f18:	8a2e                	mv	s4,a1
    80004f1a:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80004f1c:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80004f20:	0001c517          	auipc	a0,0x1c
    80004f24:	ec050513          	addi	a0,a0,-320 # 80020de0 <cons>
    80004f28:	113000ef          	jal	ra,8000583a <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80004f2c:	0001c497          	auipc	s1,0x1c
    80004f30:	eb448493          	addi	s1,s1,-332 # 80020de0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80004f34:	0001c917          	auipc	s2,0x1c
    80004f38:	f4490913          	addi	s2,s2,-188 # 80020e78 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    80004f3c:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004f3e:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    80004f40:	4ca9                	li	s9,10
  while(n > 0){
    80004f42:	07305363          	blez	s3,80004fa8 <consoleread+0xae>
    while(cons.r == cons.w){
    80004f46:	0984a783          	lw	a5,152(s1)
    80004f4a:	09c4a703          	lw	a4,156(s1)
    80004f4e:	02f71163          	bne	a4,a5,80004f70 <consoleread+0x76>
      if(killed(myproc())){
    80004f52:	ecdfb0ef          	jal	ra,80000e1e <myproc>
    80004f56:	f6cfc0ef          	jal	ra,800016c2 <killed>
    80004f5a:	e125                	bnez	a0,80004fba <consoleread+0xc0>
      sleep(&cons.r, &cons.lock);
    80004f5c:	85a6                	mv	a1,s1
    80004f5e:	854a                	mv	a0,s2
    80004f60:	d2afc0ef          	jal	ra,8000148a <sleep>
    while(cons.r == cons.w){
    80004f64:	0984a783          	lw	a5,152(s1)
    80004f68:	09c4a703          	lw	a4,156(s1)
    80004f6c:	fef703e3          	beq	a4,a5,80004f52 <consoleread+0x58>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    80004f70:	0017871b          	addiw	a4,a5,1
    80004f74:	08e4ac23          	sw	a4,152(s1)
    80004f78:	07f7f713          	andi	a4,a5,127
    80004f7c:	9726                	add	a4,a4,s1
    80004f7e:	01874703          	lbu	a4,24(a4)
    80004f82:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    80004f86:	057d0f63          	beq	s10,s7,80004fe4 <consoleread+0xea>
    cbuf = c;
    80004f8a:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80004f8e:	4685                	li	a3,1
    80004f90:	f9f40613          	addi	a2,s0,-97
    80004f94:	85d2                	mv	a1,s4
    80004f96:	8556                	mv	a0,s5
    80004f98:	84ffc0ef          	jal	ra,800017e6 <either_copyout>
    80004f9c:	01850663          	beq	a0,s8,80004fa8 <consoleread+0xae>
    dst++;
    80004fa0:	0a05                	addi	s4,s4,1
    --n;
    80004fa2:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    80004fa4:	f99d1fe3          	bne	s10,s9,80004f42 <consoleread+0x48>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    80004fa8:	0001c517          	auipc	a0,0x1c
    80004fac:	e3850513          	addi	a0,a0,-456 # 80020de0 <cons>
    80004fb0:	123000ef          	jal	ra,800058d2 <release>

  return target - n;
    80004fb4:	413b053b          	subw	a0,s6,s3
    80004fb8:	a801                	j	80004fc8 <consoleread+0xce>
        release(&cons.lock);
    80004fba:	0001c517          	auipc	a0,0x1c
    80004fbe:	e2650513          	addi	a0,a0,-474 # 80020de0 <cons>
    80004fc2:	111000ef          	jal	ra,800058d2 <release>
        return -1;
    80004fc6:	557d                	li	a0,-1
}
    80004fc8:	70a6                	ld	ra,104(sp)
    80004fca:	7406                	ld	s0,96(sp)
    80004fcc:	64e6                	ld	s1,88(sp)
    80004fce:	6946                	ld	s2,80(sp)
    80004fd0:	69a6                	ld	s3,72(sp)
    80004fd2:	6a06                	ld	s4,64(sp)
    80004fd4:	7ae2                	ld	s5,56(sp)
    80004fd6:	7b42                	ld	s6,48(sp)
    80004fd8:	7ba2                	ld	s7,40(sp)
    80004fda:	7c02                	ld	s8,32(sp)
    80004fdc:	6ce2                	ld	s9,24(sp)
    80004fde:	6d42                	ld	s10,16(sp)
    80004fe0:	6165                	addi	sp,sp,112
    80004fe2:	8082                	ret
      if(n < target){
    80004fe4:	0009871b          	sext.w	a4,s3
    80004fe8:	fd6770e3          	bgeu	a4,s6,80004fa8 <consoleread+0xae>
        cons.r--;
    80004fec:	0001c717          	auipc	a4,0x1c
    80004ff0:	e8f72623          	sw	a5,-372(a4) # 80020e78 <cons+0x98>
    80004ff4:	bf55                	j	80004fa8 <consoleread+0xae>

0000000080004ff6 <consputc>:
{
    80004ff6:	1141                	addi	sp,sp,-16
    80004ff8:	e406                	sd	ra,8(sp)
    80004ffa:	e022                	sd	s0,0(sp)
    80004ffc:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80004ffe:	10000793          	li	a5,256
    80005002:	00f50863          	beq	a0,a5,80005012 <consputc+0x1c>
    uartputc_sync(c);
    80005006:	5d4000ef          	jal	ra,800055da <uartputc_sync>
}
    8000500a:	60a2                	ld	ra,8(sp)
    8000500c:	6402                	ld	s0,0(sp)
    8000500e:	0141                	addi	sp,sp,16
    80005010:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80005012:	4521                	li	a0,8
    80005014:	5c6000ef          	jal	ra,800055da <uartputc_sync>
    80005018:	02000513          	li	a0,32
    8000501c:	5be000ef          	jal	ra,800055da <uartputc_sync>
    80005020:	4521                	li	a0,8
    80005022:	5b8000ef          	jal	ra,800055da <uartputc_sync>
    80005026:	b7d5                	j	8000500a <consputc+0x14>

0000000080005028 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80005028:	1101                	addi	sp,sp,-32
    8000502a:	ec06                	sd	ra,24(sp)
    8000502c:	e822                	sd	s0,16(sp)
    8000502e:	e426                	sd	s1,8(sp)
    80005030:	e04a                	sd	s2,0(sp)
    80005032:	1000                	addi	s0,sp,32
    80005034:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80005036:	0001c517          	auipc	a0,0x1c
    8000503a:	daa50513          	addi	a0,a0,-598 # 80020de0 <cons>
    8000503e:	7fc000ef          	jal	ra,8000583a <acquire>

  switch(c){
    80005042:	47d5                	li	a5,21
    80005044:	0af48063          	beq	s1,a5,800050e4 <consoleintr+0xbc>
    80005048:	0297c663          	blt	a5,s1,80005074 <consoleintr+0x4c>
    8000504c:	47a1                	li	a5,8
    8000504e:	0cf48f63          	beq	s1,a5,8000512c <consoleintr+0x104>
    80005052:	47c1                	li	a5,16
    80005054:	10f49063          	bne	s1,a5,80005154 <consoleintr+0x12c>
  case C('P'):  // Print process list.
    procdump();
    80005058:	823fc0ef          	jal	ra,8000187a <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    8000505c:	0001c517          	auipc	a0,0x1c
    80005060:	d8450513          	addi	a0,a0,-636 # 80020de0 <cons>
    80005064:	06f000ef          	jal	ra,800058d2 <release>
}
    80005068:	60e2                	ld	ra,24(sp)
    8000506a:	6442                	ld	s0,16(sp)
    8000506c:	64a2                	ld	s1,8(sp)
    8000506e:	6902                	ld	s2,0(sp)
    80005070:	6105                	addi	sp,sp,32
    80005072:	8082                	ret
  switch(c){
    80005074:	07f00793          	li	a5,127
    80005078:	0af48a63          	beq	s1,a5,8000512c <consoleintr+0x104>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    8000507c:	0001c717          	auipc	a4,0x1c
    80005080:	d6470713          	addi	a4,a4,-668 # 80020de0 <cons>
    80005084:	0a072783          	lw	a5,160(a4)
    80005088:	09872703          	lw	a4,152(a4)
    8000508c:	9f99                	subw	a5,a5,a4
    8000508e:	07f00713          	li	a4,127
    80005092:	fcf765e3          	bltu	a4,a5,8000505c <consoleintr+0x34>
      c = (c == '\r') ? '\n' : c;
    80005096:	47b5                	li	a5,13
    80005098:	0cf48163          	beq	s1,a5,8000515a <consoleintr+0x132>
      consputc(c);
    8000509c:	8526                	mv	a0,s1
    8000509e:	f59ff0ef          	jal	ra,80004ff6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800050a2:	0001c797          	auipc	a5,0x1c
    800050a6:	d3e78793          	addi	a5,a5,-706 # 80020de0 <cons>
    800050aa:	0a07a683          	lw	a3,160(a5)
    800050ae:	0016871b          	addiw	a4,a3,1
    800050b2:	0007061b          	sext.w	a2,a4
    800050b6:	0ae7a023          	sw	a4,160(a5)
    800050ba:	07f6f693          	andi	a3,a3,127
    800050be:	97b6                	add	a5,a5,a3
    800050c0:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    800050c4:	47a9                	li	a5,10
    800050c6:	0af48f63          	beq	s1,a5,80005184 <consoleintr+0x15c>
    800050ca:	4791                	li	a5,4
    800050cc:	0af48c63          	beq	s1,a5,80005184 <consoleintr+0x15c>
    800050d0:	0001c797          	auipc	a5,0x1c
    800050d4:	da87a783          	lw	a5,-600(a5) # 80020e78 <cons+0x98>
    800050d8:	9f1d                	subw	a4,a4,a5
    800050da:	08000793          	li	a5,128
    800050de:	f6f71fe3          	bne	a4,a5,8000505c <consoleintr+0x34>
    800050e2:	a04d                	j	80005184 <consoleintr+0x15c>
    while(cons.e != cons.w &&
    800050e4:	0001c717          	auipc	a4,0x1c
    800050e8:	cfc70713          	addi	a4,a4,-772 # 80020de0 <cons>
    800050ec:	0a072783          	lw	a5,160(a4)
    800050f0:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800050f4:	0001c497          	auipc	s1,0x1c
    800050f8:	cec48493          	addi	s1,s1,-788 # 80020de0 <cons>
    while(cons.e != cons.w &&
    800050fc:	4929                	li	s2,10
    800050fe:	f4f70fe3          	beq	a4,a5,8000505c <consoleintr+0x34>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80005102:	37fd                	addiw	a5,a5,-1
    80005104:	07f7f713          	andi	a4,a5,127
    80005108:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000510a:	01874703          	lbu	a4,24(a4)
    8000510e:	f52707e3          	beq	a4,s2,8000505c <consoleintr+0x34>
      cons.e--;
    80005112:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80005116:	10000513          	li	a0,256
    8000511a:	eddff0ef          	jal	ra,80004ff6 <consputc>
    while(cons.e != cons.w &&
    8000511e:	0a04a783          	lw	a5,160(s1)
    80005122:	09c4a703          	lw	a4,156(s1)
    80005126:	fcf71ee3          	bne	a4,a5,80005102 <consoleintr+0xda>
    8000512a:	bf0d                	j	8000505c <consoleintr+0x34>
    if(cons.e != cons.w){
    8000512c:	0001c717          	auipc	a4,0x1c
    80005130:	cb470713          	addi	a4,a4,-844 # 80020de0 <cons>
    80005134:	0a072783          	lw	a5,160(a4)
    80005138:	09c72703          	lw	a4,156(a4)
    8000513c:	f2f700e3          	beq	a4,a5,8000505c <consoleintr+0x34>
      cons.e--;
    80005140:	37fd                	addiw	a5,a5,-1
    80005142:	0001c717          	auipc	a4,0x1c
    80005146:	d2f72f23          	sw	a5,-706(a4) # 80020e80 <cons+0xa0>
      consputc(BACKSPACE);
    8000514a:	10000513          	li	a0,256
    8000514e:	ea9ff0ef          	jal	ra,80004ff6 <consputc>
    80005152:	b729                	j	8000505c <consoleintr+0x34>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80005154:	f00484e3          	beqz	s1,8000505c <consoleintr+0x34>
    80005158:	b715                	j	8000507c <consoleintr+0x54>
      consputc(c);
    8000515a:	4529                	li	a0,10
    8000515c:	e9bff0ef          	jal	ra,80004ff6 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80005160:	0001c797          	auipc	a5,0x1c
    80005164:	c8078793          	addi	a5,a5,-896 # 80020de0 <cons>
    80005168:	0a07a703          	lw	a4,160(a5)
    8000516c:	0017069b          	addiw	a3,a4,1
    80005170:	0006861b          	sext.w	a2,a3
    80005174:	0ad7a023          	sw	a3,160(a5)
    80005178:	07f77713          	andi	a4,a4,127
    8000517c:	97ba                	add	a5,a5,a4
    8000517e:	4729                	li	a4,10
    80005180:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80005184:	0001c797          	auipc	a5,0x1c
    80005188:	cec7ac23          	sw	a2,-776(a5) # 80020e7c <cons+0x9c>
        wakeup(&cons.r);
    8000518c:	0001c517          	auipc	a0,0x1c
    80005190:	cec50513          	addi	a0,a0,-788 # 80020e78 <cons+0x98>
    80005194:	b42fc0ef          	jal	ra,800014d6 <wakeup>
    80005198:	b5d1                	j	8000505c <consoleintr+0x34>

000000008000519a <consoleinit>:

void
consoleinit(void)
{
    8000519a:	1141                	addi	sp,sp,-16
    8000519c:	e406                	sd	ra,8(sp)
    8000519e:	e022                	sd	s0,0(sp)
    800051a0:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800051a2:	00002597          	auipc	a1,0x2
    800051a6:	71658593          	addi	a1,a1,1814 # 800078b8 <syscalls+0x458>
    800051aa:	0001c517          	auipc	a0,0x1c
    800051ae:	c3650513          	addi	a0,a0,-970 # 80020de0 <cons>
    800051b2:	608000ef          	jal	ra,800057ba <initlock>

  uartinit();
    800051b6:	3d8000ef          	jal	ra,8000558e <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    800051ba:	00013797          	auipc	a5,0x13
    800051be:	a8e78793          	addi	a5,a5,-1394 # 80017c48 <devsw>
    800051c2:	00000717          	auipc	a4,0x0
    800051c6:	d3870713          	addi	a4,a4,-712 # 80004efa <consoleread>
    800051ca:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800051cc:	00000717          	auipc	a4,0x0
    800051d0:	cd470713          	addi	a4,a4,-812 # 80004ea0 <consolewrite>
    800051d4:	ef98                	sd	a4,24(a5)
}
    800051d6:	60a2                	ld	ra,8(sp)
    800051d8:	6402                	ld	s0,0(sp)
    800051da:	0141                	addi	sp,sp,16
    800051dc:	8082                	ret

00000000800051de <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    800051de:	7179                	addi	sp,sp,-48
    800051e0:	f406                	sd	ra,40(sp)
    800051e2:	f022                	sd	s0,32(sp)
    800051e4:	ec26                	sd	s1,24(sp)
    800051e6:	e84a                	sd	s2,16(sp)
    800051e8:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    800051ea:	c219                	beqz	a2,800051f0 <printint+0x12>
    800051ec:	06054f63          	bltz	a0,8000526a <printint+0x8c>
    x = -xx;
  else
    x = xx;
    800051f0:	4881                	li	a7,0
    800051f2:	fd040693          	addi	a3,s0,-48

  i = 0;
    800051f6:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    800051f8:	00002617          	auipc	a2,0x2
    800051fc:	6e860613          	addi	a2,a2,1768 # 800078e0 <digits>
    80005200:	883e                	mv	a6,a5
    80005202:	2785                	addiw	a5,a5,1
    80005204:	02b57733          	remu	a4,a0,a1
    80005208:	9732                	add	a4,a4,a2
    8000520a:	00074703          	lbu	a4,0(a4)
    8000520e:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80005212:	872a                	mv	a4,a0
    80005214:	02b55533          	divu	a0,a0,a1
    80005218:	0685                	addi	a3,a3,1
    8000521a:	feb773e3          	bgeu	a4,a1,80005200 <printint+0x22>

  if(sign)
    8000521e:	00088b63          	beqz	a7,80005234 <printint+0x56>
    buf[i++] = '-';
    80005222:	fe040713          	addi	a4,s0,-32
    80005226:	97ba                	add	a5,a5,a4
    80005228:	02d00713          	li	a4,45
    8000522c:	fee78823          	sb	a4,-16(a5)
    80005230:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    80005234:	02f05563          	blez	a5,8000525e <printint+0x80>
    80005238:	fd040713          	addi	a4,s0,-48
    8000523c:	00f704b3          	add	s1,a4,a5
    80005240:	fff70913          	addi	s2,a4,-1
    80005244:	993e                	add	s2,s2,a5
    80005246:	37fd                	addiw	a5,a5,-1
    80005248:	1782                	slli	a5,a5,0x20
    8000524a:	9381                	srli	a5,a5,0x20
    8000524c:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    80005250:	fff4c503          	lbu	a0,-1(s1)
    80005254:	da3ff0ef          	jal	ra,80004ff6 <consputc>
  while(--i >= 0)
    80005258:	14fd                	addi	s1,s1,-1
    8000525a:	ff249be3          	bne	s1,s2,80005250 <printint+0x72>
}
    8000525e:	70a2                	ld	ra,40(sp)
    80005260:	7402                	ld	s0,32(sp)
    80005262:	64e2                	ld	s1,24(sp)
    80005264:	6942                	ld	s2,16(sp)
    80005266:	6145                	addi	sp,sp,48
    80005268:	8082                	ret
    x = -xx;
    8000526a:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000526e:	4885                	li	a7,1
    x = -xx;
    80005270:	b749                	j	800051f2 <printint+0x14>

0000000080005272 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    80005272:	7155                	addi	sp,sp,-208
    80005274:	e506                	sd	ra,136(sp)
    80005276:	e122                	sd	s0,128(sp)
    80005278:	fca6                	sd	s1,120(sp)
    8000527a:	f8ca                	sd	s2,112(sp)
    8000527c:	f4ce                	sd	s3,104(sp)
    8000527e:	f0d2                	sd	s4,96(sp)
    80005280:	ecd6                	sd	s5,88(sp)
    80005282:	e8da                	sd	s6,80(sp)
    80005284:	e4de                	sd	s7,72(sp)
    80005286:	e0e2                	sd	s8,64(sp)
    80005288:	fc66                	sd	s9,56(sp)
    8000528a:	f86a                	sd	s10,48(sp)
    8000528c:	f46e                	sd	s11,40(sp)
    8000528e:	0900                	addi	s0,sp,144
    80005290:	8a2a                	mv	s4,a0
    80005292:	e40c                	sd	a1,8(s0)
    80005294:	e810                	sd	a2,16(s0)
    80005296:	ec14                	sd	a3,24(s0)
    80005298:	f018                	sd	a4,32(s0)
    8000529a:	f41c                	sd	a5,40(s0)
    8000529c:	03043823          	sd	a6,48(s0)
    800052a0:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800052a4:	0001c797          	auipc	a5,0x1c
    800052a8:	bfc7a783          	lw	a5,-1028(a5) # 80020ea0 <pr+0x18>
    800052ac:	f6f43c23          	sd	a5,-136(s0)
  if(locking)
    800052b0:	eb9d                	bnez	a5,800052e6 <printf+0x74>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800052b2:	00840793          	addi	a5,s0,8
    800052b6:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800052ba:	00054503          	lbu	a0,0(a0)
    800052be:	24050463          	beqz	a0,80005506 <printf+0x294>
    800052c2:	4981                	li	s3,0
    if(cx != '%'){
    800052c4:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    800052c8:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    800052cc:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800052d0:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    800052d4:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    800052d8:	07000d93          	li	s11,112
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800052dc:	00002b97          	auipc	s7,0x2
    800052e0:	604b8b93          	addi	s7,s7,1540 # 800078e0 <digits>
    800052e4:	a081                	j	80005324 <printf+0xb2>
    acquire(&pr.lock);
    800052e6:	0001c517          	auipc	a0,0x1c
    800052ea:	ba250513          	addi	a0,a0,-1118 # 80020e88 <pr>
    800052ee:	54c000ef          	jal	ra,8000583a <acquire>
  va_start(ap, fmt);
    800052f2:	00840793          	addi	a5,s0,8
    800052f6:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800052fa:	000a4503          	lbu	a0,0(s4)
    800052fe:	f171                	bnez	a0,800052c2 <printf+0x50>
#endif
  }
  va_end(ap);

  if(locking)
    release(&pr.lock);
    80005300:	0001c517          	auipc	a0,0x1c
    80005304:	b8850513          	addi	a0,a0,-1144 # 80020e88 <pr>
    80005308:	5ca000ef          	jal	ra,800058d2 <release>
    8000530c:	aaed                	j	80005506 <printf+0x294>
      consputc(cx);
    8000530e:	ce9ff0ef          	jal	ra,80004ff6 <consputc>
      continue;
    80005312:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80005314:	0014899b          	addiw	s3,s1,1
    80005318:	013a07b3          	add	a5,s4,s3
    8000531c:	0007c503          	lbu	a0,0(a5)
    80005320:	1c050f63          	beqz	a0,800054fe <printf+0x28c>
    if(cx != '%'){
    80005324:	ff5515e3          	bne	a0,s5,8000530e <printf+0x9c>
    i++;
    80005328:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000532c:	009a07b3          	add	a5,s4,s1
    80005330:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80005334:	1c090563          	beqz	s2,800054fe <printf+0x28c>
    80005338:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000533c:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    8000533e:	c789                	beqz	a5,80005348 <printf+0xd6>
    80005340:	009a0733          	add	a4,s4,s1
    80005344:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    80005348:	03690463          	beq	s2,s6,80005370 <printf+0xfe>
    } else if(c0 == 'l' && c1 == 'd'){
    8000534c:	03890e63          	beq	s2,s8,80005388 <printf+0x116>
    } else if(c0 == 'u'){
    80005350:	0b990d63          	beq	s2,s9,8000540a <printf+0x198>
    } else if(c0 == 'x'){
    80005354:	11a90363          	beq	s2,s10,8000545a <printf+0x1e8>
    } else if(c0 == 'p'){
    80005358:	13b90b63          	beq	s2,s11,8000548e <printf+0x21c>
    } else if(c0 == 's'){
    8000535c:	07300793          	li	a5,115
    80005360:	16f90363          	beq	s2,a5,800054c6 <printf+0x254>
    } else if(c0 == '%'){
    80005364:	03591c63          	bne	s2,s5,8000539c <printf+0x12a>
      consputc('%');
    80005368:	8556                	mv	a0,s5
    8000536a:	c8dff0ef          	jal	ra,80004ff6 <consputc>
    8000536e:	b75d                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, int), 10, 1);
    80005370:	f8843783          	ld	a5,-120(s0)
    80005374:	00878713          	addi	a4,a5,8
    80005378:	f8e43423          	sd	a4,-120(s0)
    8000537c:	4605                	li	a2,1
    8000537e:	45a9                	li	a1,10
    80005380:	4388                	lw	a0,0(a5)
    80005382:	e5dff0ef          	jal	ra,800051de <printint>
    80005386:	b779                	j	80005314 <printf+0xa2>
    } else if(c0 == 'l' && c1 == 'd'){
    80005388:	03678163          	beq	a5,s6,800053aa <printf+0x138>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000538c:	03878d63          	beq	a5,s8,800053c6 <printf+0x154>
    } else if(c0 == 'l' && c1 == 'u'){
    80005390:	09978963          	beq	a5,s9,80005422 <printf+0x1b0>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80005394:	03878b63          	beq	a5,s8,800053ca <printf+0x158>
    } else if(c0 == 'l' && c1 == 'x'){
    80005398:	0da78d63          	beq	a5,s10,80005472 <printf+0x200>
      consputc('%');
    8000539c:	8556                	mv	a0,s5
    8000539e:	c59ff0ef          	jal	ra,80004ff6 <consputc>
      consputc(c0);
    800053a2:	854a                	mv	a0,s2
    800053a4:	c53ff0ef          	jal	ra,80004ff6 <consputc>
    800053a8:	b7b5                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 1);
    800053aa:	f8843783          	ld	a5,-120(s0)
    800053ae:	00878713          	addi	a4,a5,8
    800053b2:	f8e43423          	sd	a4,-120(s0)
    800053b6:	4605                	li	a2,1
    800053b8:	45a9                	li	a1,10
    800053ba:	6388                	ld	a0,0(a5)
    800053bc:	e23ff0ef          	jal	ra,800051de <printint>
      i += 1;
    800053c0:	0029849b          	addiw	s1,s3,2
    800053c4:	bf81                	j	80005314 <printf+0xa2>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800053c6:	03668463          	beq	a3,s6,800053ee <printf+0x17c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800053ca:	07968a63          	beq	a3,s9,8000543e <printf+0x1cc>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800053ce:	fda697e3          	bne	a3,s10,8000539c <printf+0x12a>
      printint(va_arg(ap, uint64), 16, 0);
    800053d2:	f8843783          	ld	a5,-120(s0)
    800053d6:	00878713          	addi	a4,a5,8
    800053da:	f8e43423          	sd	a4,-120(s0)
    800053de:	4601                	li	a2,0
    800053e0:	45c1                	li	a1,16
    800053e2:	6388                	ld	a0,0(a5)
    800053e4:	dfbff0ef          	jal	ra,800051de <printint>
      i += 2;
    800053e8:	0039849b          	addiw	s1,s3,3
    800053ec:	b725                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 1);
    800053ee:	f8843783          	ld	a5,-120(s0)
    800053f2:	00878713          	addi	a4,a5,8
    800053f6:	f8e43423          	sd	a4,-120(s0)
    800053fa:	4605                	li	a2,1
    800053fc:	45a9                	li	a1,10
    800053fe:	6388                	ld	a0,0(a5)
    80005400:	ddfff0ef          	jal	ra,800051de <printint>
      i += 2;
    80005404:	0039849b          	addiw	s1,s3,3
    80005408:	b731                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, int), 10, 0);
    8000540a:	f8843783          	ld	a5,-120(s0)
    8000540e:	00878713          	addi	a4,a5,8
    80005412:	f8e43423          	sd	a4,-120(s0)
    80005416:	4601                	li	a2,0
    80005418:	45a9                	li	a1,10
    8000541a:	4388                	lw	a0,0(a5)
    8000541c:	dc3ff0ef          	jal	ra,800051de <printint>
    80005420:	bdd5                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 0);
    80005422:	f8843783          	ld	a5,-120(s0)
    80005426:	00878713          	addi	a4,a5,8
    8000542a:	f8e43423          	sd	a4,-120(s0)
    8000542e:	4601                	li	a2,0
    80005430:	45a9                	li	a1,10
    80005432:	6388                	ld	a0,0(a5)
    80005434:	dabff0ef          	jal	ra,800051de <printint>
      i += 1;
    80005438:	0029849b          	addiw	s1,s3,2
    8000543c:	bde1                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, uint64), 10, 0);
    8000543e:	f8843783          	ld	a5,-120(s0)
    80005442:	00878713          	addi	a4,a5,8
    80005446:	f8e43423          	sd	a4,-120(s0)
    8000544a:	4601                	li	a2,0
    8000544c:	45a9                	li	a1,10
    8000544e:	6388                	ld	a0,0(a5)
    80005450:	d8fff0ef          	jal	ra,800051de <printint>
      i += 2;
    80005454:	0039849b          	addiw	s1,s3,3
    80005458:	bd75                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, int), 16, 0);
    8000545a:	f8843783          	ld	a5,-120(s0)
    8000545e:	00878713          	addi	a4,a5,8
    80005462:	f8e43423          	sd	a4,-120(s0)
    80005466:	4601                	li	a2,0
    80005468:	45c1                	li	a1,16
    8000546a:	4388                	lw	a0,0(a5)
    8000546c:	d73ff0ef          	jal	ra,800051de <printint>
    80005470:	b555                	j	80005314 <printf+0xa2>
      printint(va_arg(ap, uint64), 16, 0);
    80005472:	f8843783          	ld	a5,-120(s0)
    80005476:	00878713          	addi	a4,a5,8
    8000547a:	f8e43423          	sd	a4,-120(s0)
    8000547e:	4601                	li	a2,0
    80005480:	45c1                	li	a1,16
    80005482:	6388                	ld	a0,0(a5)
    80005484:	d5bff0ef          	jal	ra,800051de <printint>
      i += 1;
    80005488:	0029849b          	addiw	s1,s3,2
    8000548c:	b561                	j	80005314 <printf+0xa2>
      printptr(va_arg(ap, uint64));
    8000548e:	f8843783          	ld	a5,-120(s0)
    80005492:	00878713          	addi	a4,a5,8
    80005496:	f8e43423          	sd	a4,-120(s0)
    8000549a:	0007b983          	ld	s3,0(a5)
  consputc('0');
    8000549e:	03000513          	li	a0,48
    800054a2:	b55ff0ef          	jal	ra,80004ff6 <consputc>
  consputc('x');
    800054a6:	856a                	mv	a0,s10
    800054a8:	b4fff0ef          	jal	ra,80004ff6 <consputc>
    800054ac:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800054ae:	03c9d793          	srli	a5,s3,0x3c
    800054b2:	97de                	add	a5,a5,s7
    800054b4:	0007c503          	lbu	a0,0(a5)
    800054b8:	b3fff0ef          	jal	ra,80004ff6 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800054bc:	0992                	slli	s3,s3,0x4
    800054be:	397d                	addiw	s2,s2,-1
    800054c0:	fe0917e3          	bnez	s2,800054ae <printf+0x23c>
    800054c4:	bd81                	j	80005314 <printf+0xa2>
      if((s = va_arg(ap, char*)) == 0)
    800054c6:	f8843783          	ld	a5,-120(s0)
    800054ca:	00878713          	addi	a4,a5,8
    800054ce:	f8e43423          	sd	a4,-120(s0)
    800054d2:	0007b903          	ld	s2,0(a5)
    800054d6:	00090d63          	beqz	s2,800054f0 <printf+0x27e>
      for(; *s; s++)
    800054da:	00094503          	lbu	a0,0(s2)
    800054de:	e2050be3          	beqz	a0,80005314 <printf+0xa2>
        consputc(*s);
    800054e2:	b15ff0ef          	jal	ra,80004ff6 <consputc>
      for(; *s; s++)
    800054e6:	0905                	addi	s2,s2,1
    800054e8:	00094503          	lbu	a0,0(s2)
    800054ec:	f97d                	bnez	a0,800054e2 <printf+0x270>
    800054ee:	b51d                	j	80005314 <printf+0xa2>
        s = "(null)";
    800054f0:	00002917          	auipc	s2,0x2
    800054f4:	3d090913          	addi	s2,s2,976 # 800078c0 <syscalls+0x460>
      for(; *s; s++)
    800054f8:	02800513          	li	a0,40
    800054fc:	b7dd                	j	800054e2 <printf+0x270>
  if(locking)
    800054fe:	f7843783          	ld	a5,-136(s0)
    80005502:	de079fe3          	bnez	a5,80005300 <printf+0x8e>

  return 0;
}
    80005506:	4501                	li	a0,0
    80005508:	60aa                	ld	ra,136(sp)
    8000550a:	640a                	ld	s0,128(sp)
    8000550c:	74e6                	ld	s1,120(sp)
    8000550e:	7946                	ld	s2,112(sp)
    80005510:	79a6                	ld	s3,104(sp)
    80005512:	7a06                	ld	s4,96(sp)
    80005514:	6ae6                	ld	s5,88(sp)
    80005516:	6b46                	ld	s6,80(sp)
    80005518:	6ba6                	ld	s7,72(sp)
    8000551a:	6c06                	ld	s8,64(sp)
    8000551c:	7ce2                	ld	s9,56(sp)
    8000551e:	7d42                	ld	s10,48(sp)
    80005520:	7da2                	ld	s11,40(sp)
    80005522:	6169                	addi	sp,sp,208
    80005524:	8082                	ret

0000000080005526 <panic>:

void
panic(char *s)
{
    80005526:	1101                	addi	sp,sp,-32
    80005528:	ec06                	sd	ra,24(sp)
    8000552a:	e822                	sd	s0,16(sp)
    8000552c:	e426                	sd	s1,8(sp)
    8000552e:	1000                	addi	s0,sp,32
    80005530:	84aa                	mv	s1,a0
  pr.locking = 0;
    80005532:	0001c797          	auipc	a5,0x1c
    80005536:	9607a723          	sw	zero,-1682(a5) # 80020ea0 <pr+0x18>
  printf("panic: ");
    8000553a:	00002517          	auipc	a0,0x2
    8000553e:	38e50513          	addi	a0,a0,910 # 800078c8 <syscalls+0x468>
    80005542:	d31ff0ef          	jal	ra,80005272 <printf>
  printf("%s\n", s);
    80005546:	85a6                	mv	a1,s1
    80005548:	00002517          	auipc	a0,0x2
    8000554c:	38850513          	addi	a0,a0,904 # 800078d0 <syscalls+0x470>
    80005550:	d23ff0ef          	jal	ra,80005272 <printf>
  panicked = 1; // freeze uart output from other CPUs
    80005554:	4785                	li	a5,1
    80005556:	00002717          	auipc	a4,0x2
    8000555a:	44f72323          	sw	a5,1094(a4) # 8000799c <panicked>
  for(;;)
    8000555e:	a001                	j	8000555e <panic+0x38>

0000000080005560 <printfinit>:
    ;
}

void
printfinit(void)
{
    80005560:	1101                	addi	sp,sp,-32
    80005562:	ec06                	sd	ra,24(sp)
    80005564:	e822                	sd	s0,16(sp)
    80005566:	e426                	sd	s1,8(sp)
    80005568:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    8000556a:	0001c497          	auipc	s1,0x1c
    8000556e:	91e48493          	addi	s1,s1,-1762 # 80020e88 <pr>
    80005572:	00002597          	auipc	a1,0x2
    80005576:	36658593          	addi	a1,a1,870 # 800078d8 <syscalls+0x478>
    8000557a:	8526                	mv	a0,s1
    8000557c:	23e000ef          	jal	ra,800057ba <initlock>
  pr.locking = 1;
    80005580:	4785                	li	a5,1
    80005582:	cc9c                	sw	a5,24(s1)
}
    80005584:	60e2                	ld	ra,24(sp)
    80005586:	6442                	ld	s0,16(sp)
    80005588:	64a2                	ld	s1,8(sp)
    8000558a:	6105                	addi	sp,sp,32
    8000558c:	8082                	ret

000000008000558e <uartinit>:

void uartstart();

void
uartinit(void)
{
    8000558e:	1141                	addi	sp,sp,-16
    80005590:	e406                	sd	ra,8(sp)
    80005592:	e022                	sd	s0,0(sp)
    80005594:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80005596:	100007b7          	lui	a5,0x10000
    8000559a:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    8000559e:	f8000713          	li	a4,-128
    800055a2:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800055a6:	470d                	li	a4,3
    800055a8:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800055ac:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800055b0:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800055b4:	469d                	li	a3,7
    800055b6:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800055ba:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    800055be:	00002597          	auipc	a1,0x2
    800055c2:	33a58593          	addi	a1,a1,826 # 800078f8 <digits+0x18>
    800055c6:	0001c517          	auipc	a0,0x1c
    800055ca:	8e250513          	addi	a0,a0,-1822 # 80020ea8 <uart_tx_lock>
    800055ce:	1ec000ef          	jal	ra,800057ba <initlock>
}
    800055d2:	60a2                	ld	ra,8(sp)
    800055d4:	6402                	ld	s0,0(sp)
    800055d6:	0141                	addi	sp,sp,16
    800055d8:	8082                	ret

00000000800055da <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800055da:	1101                	addi	sp,sp,-32
    800055dc:	ec06                	sd	ra,24(sp)
    800055de:	e822                	sd	s0,16(sp)
    800055e0:	e426                	sd	s1,8(sp)
    800055e2:	1000                	addi	s0,sp,32
    800055e4:	84aa                	mv	s1,a0
  push_off();
    800055e6:	214000ef          	jal	ra,800057fa <push_off>

  if(panicked){
    800055ea:	00002797          	auipc	a5,0x2
    800055ee:	3b27a783          	lw	a5,946(a5) # 8000799c <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800055f2:	10000737          	lui	a4,0x10000
  if(panicked){
    800055f6:	c391                	beqz	a5,800055fa <uartputc_sync+0x20>
    for(;;)
    800055f8:	a001                	j	800055f8 <uartputc_sync+0x1e>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800055fa:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    800055fe:	0207f793          	andi	a5,a5,32
    80005602:	dfe5                	beqz	a5,800055fa <uartputc_sync+0x20>
    ;
  WriteReg(THR, c);
    80005604:	0ff4f513          	zext.b	a0,s1
    80005608:	100007b7          	lui	a5,0x10000
    8000560c:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80005610:	26e000ef          	jal	ra,8000587e <pop_off>
}
    80005614:	60e2                	ld	ra,24(sp)
    80005616:	6442                	ld	s0,16(sp)
    80005618:	64a2                	ld	s1,8(sp)
    8000561a:	6105                	addi	sp,sp,32
    8000561c:	8082                	ret

000000008000561e <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    8000561e:	00002797          	auipc	a5,0x2
    80005622:	3827b783          	ld	a5,898(a5) # 800079a0 <uart_tx_r>
    80005626:	00002717          	auipc	a4,0x2
    8000562a:	38273703          	ld	a4,898(a4) # 800079a8 <uart_tx_w>
    8000562e:	06f70c63          	beq	a4,a5,800056a6 <uartstart+0x88>
{
    80005632:	7139                	addi	sp,sp,-64
    80005634:	fc06                	sd	ra,56(sp)
    80005636:	f822                	sd	s0,48(sp)
    80005638:	f426                	sd	s1,40(sp)
    8000563a:	f04a                	sd	s2,32(sp)
    8000563c:	ec4e                	sd	s3,24(sp)
    8000563e:	e852                	sd	s4,16(sp)
    80005640:	e456                	sd	s5,8(sp)
    80005642:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      ReadReg(ISR);
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005644:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80005648:	0001ca17          	auipc	s4,0x1c
    8000564c:	860a0a13          	addi	s4,s4,-1952 # 80020ea8 <uart_tx_lock>
    uart_tx_r += 1;
    80005650:	00002497          	auipc	s1,0x2
    80005654:	35048493          	addi	s1,s1,848 # 800079a0 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80005658:	00002997          	auipc	s3,0x2
    8000565c:	35098993          	addi	s3,s3,848 # 800079a8 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80005660:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    80005664:	02077713          	andi	a4,a4,32
    80005668:	c715                	beqz	a4,80005694 <uartstart+0x76>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000566a:	01f7f713          	andi	a4,a5,31
    8000566e:	9752                	add	a4,a4,s4
    80005670:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    80005674:	0785                	addi	a5,a5,1
    80005676:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80005678:	8526                	mv	a0,s1
    8000567a:	e5dfb0ef          	jal	ra,800014d6 <wakeup>
    
    WriteReg(THR, c);
    8000567e:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    80005682:	609c                	ld	a5,0(s1)
    80005684:	0009b703          	ld	a4,0(s3)
    80005688:	fcf71ce3          	bne	a4,a5,80005660 <uartstart+0x42>
      ReadReg(ISR);
    8000568c:	100007b7          	lui	a5,0x10000
    80005690:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
  }
}
    80005694:	70e2                	ld	ra,56(sp)
    80005696:	7442                	ld	s0,48(sp)
    80005698:	74a2                	ld	s1,40(sp)
    8000569a:	7902                	ld	s2,32(sp)
    8000569c:	69e2                	ld	s3,24(sp)
    8000569e:	6a42                	ld	s4,16(sp)
    800056a0:	6aa2                	ld	s5,8(sp)
    800056a2:	6121                	addi	sp,sp,64
    800056a4:	8082                	ret
      ReadReg(ISR);
    800056a6:	100007b7          	lui	a5,0x10000
    800056aa:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>
      return;
    800056ae:	8082                	ret

00000000800056b0 <uartputc>:
{
    800056b0:	7179                	addi	sp,sp,-48
    800056b2:	f406                	sd	ra,40(sp)
    800056b4:	f022                	sd	s0,32(sp)
    800056b6:	ec26                	sd	s1,24(sp)
    800056b8:	e84a                	sd	s2,16(sp)
    800056ba:	e44e                	sd	s3,8(sp)
    800056bc:	e052                	sd	s4,0(sp)
    800056be:	1800                	addi	s0,sp,48
    800056c0:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800056c2:	0001b517          	auipc	a0,0x1b
    800056c6:	7e650513          	addi	a0,a0,2022 # 80020ea8 <uart_tx_lock>
    800056ca:	170000ef          	jal	ra,8000583a <acquire>
  if(panicked){
    800056ce:	00002797          	auipc	a5,0x2
    800056d2:	2ce7a783          	lw	a5,718(a5) # 8000799c <panicked>
    800056d6:	efbd                	bnez	a5,80005754 <uartputc+0xa4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056d8:	00002717          	auipc	a4,0x2
    800056dc:	2d073703          	ld	a4,720(a4) # 800079a8 <uart_tx_w>
    800056e0:	00002797          	auipc	a5,0x2
    800056e4:	2c07b783          	ld	a5,704(a5) # 800079a0 <uart_tx_r>
    800056e8:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800056ec:	0001b997          	auipc	s3,0x1b
    800056f0:	7bc98993          	addi	s3,s3,1980 # 80020ea8 <uart_tx_lock>
    800056f4:	00002497          	auipc	s1,0x2
    800056f8:	2ac48493          	addi	s1,s1,684 # 800079a0 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800056fc:	00002917          	auipc	s2,0x2
    80005700:	2ac90913          	addi	s2,s2,684 # 800079a8 <uart_tx_w>
    80005704:	00e79d63          	bne	a5,a4,8000571e <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    80005708:	85ce                	mv	a1,s3
    8000570a:	8526                	mv	a0,s1
    8000570c:	d7ffb0ef          	jal	ra,8000148a <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80005710:	00093703          	ld	a4,0(s2)
    80005714:	609c                	ld	a5,0(s1)
    80005716:	02078793          	addi	a5,a5,32
    8000571a:	fee787e3          	beq	a5,a4,80005708 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    8000571e:	0001b497          	auipc	s1,0x1b
    80005722:	78a48493          	addi	s1,s1,1930 # 80020ea8 <uart_tx_lock>
    80005726:	01f77793          	andi	a5,a4,31
    8000572a:	97a6                	add	a5,a5,s1
    8000572c:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80005730:	0705                	addi	a4,a4,1
    80005732:	00002797          	auipc	a5,0x2
    80005736:	26e7bb23          	sd	a4,630(a5) # 800079a8 <uart_tx_w>
  uartstart();
    8000573a:	ee5ff0ef          	jal	ra,8000561e <uartstart>
  release(&uart_tx_lock);
    8000573e:	8526                	mv	a0,s1
    80005740:	192000ef          	jal	ra,800058d2 <release>
}
    80005744:	70a2                	ld	ra,40(sp)
    80005746:	7402                	ld	s0,32(sp)
    80005748:	64e2                	ld	s1,24(sp)
    8000574a:	6942                	ld	s2,16(sp)
    8000574c:	69a2                	ld	s3,8(sp)
    8000574e:	6a02                	ld	s4,0(sp)
    80005750:	6145                	addi	sp,sp,48
    80005752:	8082                	ret
    for(;;)
    80005754:	a001                	j	80005754 <uartputc+0xa4>

0000000080005756 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80005756:	1141                	addi	sp,sp,-16
    80005758:	e422                	sd	s0,8(sp)
    8000575a:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    8000575c:	100007b7          	lui	a5,0x10000
    80005760:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80005764:	8b85                	andi	a5,a5,1
    80005766:	cb91                	beqz	a5,8000577a <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80005768:	100007b7          	lui	a5,0x10000
    8000576c:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    80005770:	0ff57513          	zext.b	a0,a0
  } else {
    return -1;
  }
}
    80005774:	6422                	ld	s0,8(sp)
    80005776:	0141                	addi	sp,sp,16
    80005778:	8082                	ret
    return -1;
    8000577a:	557d                	li	a0,-1
    8000577c:	bfe5                	j	80005774 <uartgetc+0x1e>

000000008000577e <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000577e:	1101                	addi	sp,sp,-32
    80005780:	ec06                	sd	ra,24(sp)
    80005782:	e822                	sd	s0,16(sp)
    80005784:	e426                	sd	s1,8(sp)
    80005786:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80005788:	54fd                	li	s1,-1
    8000578a:	a019                	j	80005790 <uartintr+0x12>
      break;
    consoleintr(c);
    8000578c:	89dff0ef          	jal	ra,80005028 <consoleintr>
    int c = uartgetc();
    80005790:	fc7ff0ef          	jal	ra,80005756 <uartgetc>
    if(c == -1)
    80005794:	fe951ce3          	bne	a0,s1,8000578c <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80005798:	0001b497          	auipc	s1,0x1b
    8000579c:	71048493          	addi	s1,s1,1808 # 80020ea8 <uart_tx_lock>
    800057a0:	8526                	mv	a0,s1
    800057a2:	098000ef          	jal	ra,8000583a <acquire>
  uartstart();
    800057a6:	e79ff0ef          	jal	ra,8000561e <uartstart>
  release(&uart_tx_lock);
    800057aa:	8526                	mv	a0,s1
    800057ac:	126000ef          	jal	ra,800058d2 <release>
}
    800057b0:	60e2                	ld	ra,24(sp)
    800057b2:	6442                	ld	s0,16(sp)
    800057b4:	64a2                	ld	s1,8(sp)
    800057b6:	6105                	addi	sp,sp,32
    800057b8:	8082                	ret

00000000800057ba <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    800057ba:	1141                	addi	sp,sp,-16
    800057bc:	e422                	sd	s0,8(sp)
    800057be:	0800                	addi	s0,sp,16
  lk->name = name;
    800057c0:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    800057c2:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    800057c6:	00053823          	sd	zero,16(a0)
}
    800057ca:	6422                	ld	s0,8(sp)
    800057cc:	0141                	addi	sp,sp,16
    800057ce:	8082                	ret

00000000800057d0 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    800057d0:	411c                	lw	a5,0(a0)
    800057d2:	e399                	bnez	a5,800057d8 <holding+0x8>
    800057d4:	4501                	li	a0,0
  return r;
}
    800057d6:	8082                	ret
{
    800057d8:	1101                	addi	sp,sp,-32
    800057da:	ec06                	sd	ra,24(sp)
    800057dc:	e822                	sd	s0,16(sp)
    800057de:	e426                	sd	s1,8(sp)
    800057e0:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    800057e2:	6904                	ld	s1,16(a0)
    800057e4:	e1efb0ef          	jal	ra,80000e02 <mycpu>
    800057e8:	40a48533          	sub	a0,s1,a0
    800057ec:	00153513          	seqz	a0,a0
}
    800057f0:	60e2                	ld	ra,24(sp)
    800057f2:	6442                	ld	s0,16(sp)
    800057f4:	64a2                	ld	s1,8(sp)
    800057f6:	6105                	addi	sp,sp,32
    800057f8:	8082                	ret

00000000800057fa <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    800057fa:	1101                	addi	sp,sp,-32
    800057fc:	ec06                	sd	ra,24(sp)
    800057fe:	e822                	sd	s0,16(sp)
    80005800:	e426                	sd	s1,8(sp)
    80005802:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80005804:	100024f3          	csrr	s1,sstatus
    80005808:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000580c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000580e:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80005812:	df0fb0ef          	jal	ra,80000e02 <mycpu>
    80005816:	5d3c                	lw	a5,120(a0)
    80005818:	cb99                	beqz	a5,8000582e <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    8000581a:	de8fb0ef          	jal	ra,80000e02 <mycpu>
    8000581e:	5d3c                	lw	a5,120(a0)
    80005820:	2785                	addiw	a5,a5,1
    80005822:	dd3c                	sw	a5,120(a0)
}
    80005824:	60e2                	ld	ra,24(sp)
    80005826:	6442                	ld	s0,16(sp)
    80005828:	64a2                	ld	s1,8(sp)
    8000582a:	6105                	addi	sp,sp,32
    8000582c:	8082                	ret
    mycpu()->intena = old;
    8000582e:	dd4fb0ef          	jal	ra,80000e02 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80005832:	8085                	srli	s1,s1,0x1
    80005834:	8885                	andi	s1,s1,1
    80005836:	dd64                	sw	s1,124(a0)
    80005838:	b7cd                	j	8000581a <push_off+0x20>

000000008000583a <acquire>:
{
    8000583a:	1101                	addi	sp,sp,-32
    8000583c:	ec06                	sd	ra,24(sp)
    8000583e:	e822                	sd	s0,16(sp)
    80005840:	e426                	sd	s1,8(sp)
    80005842:	1000                	addi	s0,sp,32
    80005844:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80005846:	fb5ff0ef          	jal	ra,800057fa <push_off>
  if(holding(lk))
    8000584a:	8526                	mv	a0,s1
    8000584c:	f85ff0ef          	jal	ra,800057d0 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005850:	4705                	li	a4,1
  if(holding(lk))
    80005852:	e105                	bnez	a0,80005872 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80005854:	87ba                	mv	a5,a4
    80005856:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    8000585a:	2781                	sext.w	a5,a5
    8000585c:	ffe5                	bnez	a5,80005854 <acquire+0x1a>
  __sync_synchronize();
    8000585e:	0ff0000f          	fence
  lk->cpu = mycpu();
    80005862:	da0fb0ef          	jal	ra,80000e02 <mycpu>
    80005866:	e888                	sd	a0,16(s1)
}
    80005868:	60e2                	ld	ra,24(sp)
    8000586a:	6442                	ld	s0,16(sp)
    8000586c:	64a2                	ld	s1,8(sp)
    8000586e:	6105                	addi	sp,sp,32
    80005870:	8082                	ret
    panic("acquire");
    80005872:	00002517          	auipc	a0,0x2
    80005876:	08e50513          	addi	a0,a0,142 # 80007900 <digits+0x20>
    8000587a:	cadff0ef          	jal	ra,80005526 <panic>

000000008000587e <pop_off>:

void
pop_off(void)
{
    8000587e:	1141                	addi	sp,sp,-16
    80005880:	e406                	sd	ra,8(sp)
    80005882:	e022                	sd	s0,0(sp)
    80005884:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80005886:	d7cfb0ef          	jal	ra,80000e02 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000588a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000588e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80005890:	e78d                	bnez	a5,800058ba <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80005892:	5d3c                	lw	a5,120(a0)
    80005894:	02f05963          	blez	a5,800058c6 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80005898:	37fd                	addiw	a5,a5,-1
    8000589a:	0007871b          	sext.w	a4,a5
    8000589e:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    800058a0:	eb09                	bnez	a4,800058b2 <pop_off+0x34>
    800058a2:	5d7c                	lw	a5,124(a0)
    800058a4:	c799                	beqz	a5,800058b2 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800058a6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800058aa:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800058ae:	10079073          	csrw	sstatus,a5
    intr_on();
}
    800058b2:	60a2                	ld	ra,8(sp)
    800058b4:	6402                	ld	s0,0(sp)
    800058b6:	0141                	addi	sp,sp,16
    800058b8:	8082                	ret
    panic("pop_off - interruptible");
    800058ba:	00002517          	auipc	a0,0x2
    800058be:	04e50513          	addi	a0,a0,78 # 80007908 <digits+0x28>
    800058c2:	c65ff0ef          	jal	ra,80005526 <panic>
    panic("pop_off");
    800058c6:	00002517          	auipc	a0,0x2
    800058ca:	05a50513          	addi	a0,a0,90 # 80007920 <digits+0x40>
    800058ce:	c59ff0ef          	jal	ra,80005526 <panic>

00000000800058d2 <release>:
{
    800058d2:	1101                	addi	sp,sp,-32
    800058d4:	ec06                	sd	ra,24(sp)
    800058d6:	e822                	sd	s0,16(sp)
    800058d8:	e426                	sd	s1,8(sp)
    800058da:	1000                	addi	s0,sp,32
    800058dc:	84aa                	mv	s1,a0
  if(!holding(lk))
    800058de:	ef3ff0ef          	jal	ra,800057d0 <holding>
    800058e2:	c105                	beqz	a0,80005902 <release+0x30>
  lk->cpu = 0;
    800058e4:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    800058e8:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    800058ec:	0f50000f          	fence	iorw,ow
    800058f0:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    800058f4:	f8bff0ef          	jal	ra,8000587e <pop_off>
}
    800058f8:	60e2                	ld	ra,24(sp)
    800058fa:	6442                	ld	s0,16(sp)
    800058fc:	64a2                	ld	s1,8(sp)
    800058fe:	6105                	addi	sp,sp,32
    80005900:	8082                	ret
    panic("release");
    80005902:	00002517          	auipc	a0,0x2
    80005906:	02650513          	addi	a0,a0,38 # 80007928 <digits+0x48>
    8000590a:	c1dff0ef          	jal	ra,80005526 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
