#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(n < 0) {
    if(shrinkproc(-n) < 0)
      return -1;
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// Added sys_trace function
uint64
sys_trace(void)
{
  int mask;

  argint(0, &mask);

  myproc()->trace_mask = mask;
  return 0;
}

// Added sys_sigalarm
uint64
sys_sigalarm(void)
{
  int ticks;
  uint64 pointer;

  argint(0, &ticks);
  argaddr(1, &pointer);

  myproc()->interval = ticks;
  myproc()->curr_tick = 0;
  myproc()->pointer_to_handler = (void(*)())pointer;
  return 0;
}

// Added sys_sigreturn
uint64
sys_sigreturn(void)
{
  struct proc *p = myproc();
  
  uint64 saved = p->alarm_trapframe.a0;

  *(p->trapframe) = p->alarm_trapframe;

  p->alarm = 0;
  return saved;
} 
