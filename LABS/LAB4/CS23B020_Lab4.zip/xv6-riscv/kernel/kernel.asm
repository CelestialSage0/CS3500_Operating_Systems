
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	9b010113          	addi	sp,sp,-1616 # 800079b0 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04a000ef          	jal	ra,80000060 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004c:	000f4737          	lui	a4,0xf4
    80000050:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000054:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000056:	14d79073          	csrw	0x14d,a5
}
    8000005a:	6422                	ld	s0,8(sp)
    8000005c:	0141                	addi	sp,sp,16
    8000005e:	8082                	ret

0000000080000060 <start>:
{
    80000060:	1141                	addi	sp,sp,-16
    80000062:	e406                	sd	ra,8(sp)
    80000064:	e022                	sd	s0,0(sp)
    80000066:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000068:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006c:	7779                	lui	a4,0xffffe
    8000006e:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd8d27>
    80000072:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000074:	6705                	lui	a4,0x1
    80000076:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007a:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007c:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000080:	00001797          	auipc	a5,0x1
    80000084:	de478793          	addi	a5,a5,-540 # 80000e64 <main>
    80000088:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008c:	4781                	li	a5,0
    8000008e:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000092:	67c1                	lui	a5,0x10
    80000094:	17fd                	addi	a5,a5,-1
    80000096:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009a:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009e:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a2:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a6:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000aa:	57fd                	li	a5,-1
    800000ac:	83a9                	srli	a5,a5,0xa
    800000ae:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b2:	47bd                	li	a5,15
    800000b4:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b8:	f65ff0ef          	jal	ra,8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000bc:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c0:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c2:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c4:	30200073          	mret
}
    800000c8:	60a2                	ld	ra,8(sp)
    800000ca:	6402                	ld	s0,0(sp)
    800000cc:	0141                	addi	sp,sp,16
    800000ce:	8082                	ret

00000000800000d0 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d0:	715d                	addi	sp,sp,-80
    800000d2:	e486                	sd	ra,72(sp)
    800000d4:	e0a2                	sd	s0,64(sp)
    800000d6:	fc26                	sd	s1,56(sp)
    800000d8:	f84a                	sd	s2,48(sp)
    800000da:	f44e                	sd	s3,40(sp)
    800000dc:	f052                	sd	s4,32(sp)
    800000de:	ec56                	sd	s5,24(sp)
    800000e0:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    800000e2:	04c05263          	blez	a2,80000126 <consolewrite+0x56>
    800000e6:	8a2a                	mv	s4,a0
    800000e8:	84ae                	mv	s1,a1
    800000ea:	89b2                	mv	s3,a2
    800000ec:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    800000ee:	5afd                	li	s5,-1
    800000f0:	4685                	li	a3,1
    800000f2:	8626                	mv	a2,s1
    800000f4:	85d2                	mv	a1,s4
    800000f6:	fbf40513          	addi	a0,s0,-65
    800000fa:	14e020ef          	jal	ra,80002248 <either_copyin>
    800000fe:	01550a63          	beq	a0,s5,80000112 <consolewrite+0x42>
      break;
    uartputc(c);
    80000102:	fbf44503          	lbu	a0,-65(s0)
    80000106:	7ec000ef          	jal	ra,800008f2 <uartputc>
  for(i = 0; i < n; i++){
    8000010a:	2905                	addiw	s2,s2,1
    8000010c:	0485                	addi	s1,s1,1
    8000010e:	ff2991e3          	bne	s3,s2,800000f0 <consolewrite+0x20>
  }

  return i;
}
    80000112:	854a                	mv	a0,s2
    80000114:	60a6                	ld	ra,72(sp)
    80000116:	6406                	ld	s0,64(sp)
    80000118:	74e2                	ld	s1,56(sp)
    8000011a:	7942                	ld	s2,48(sp)
    8000011c:	79a2                	ld	s3,40(sp)
    8000011e:	7a02                	ld	s4,32(sp)
    80000120:	6ae2                	ld	s5,24(sp)
    80000122:	6161                	addi	sp,sp,80
    80000124:	8082                	ret
  for(i = 0; i < n; i++){
    80000126:	4901                	li	s2,0
    80000128:	b7ed                	j	80000112 <consolewrite+0x42>

000000008000012a <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000012a:	7159                	addi	sp,sp,-112
    8000012c:	f486                	sd	ra,104(sp)
    8000012e:	f0a2                	sd	s0,96(sp)
    80000130:	eca6                	sd	s1,88(sp)
    80000132:	e8ca                	sd	s2,80(sp)
    80000134:	e4ce                	sd	s3,72(sp)
    80000136:	e0d2                	sd	s4,64(sp)
    80000138:	fc56                	sd	s5,56(sp)
    8000013a:	f85a                	sd	s6,48(sp)
    8000013c:	f45e                	sd	s7,40(sp)
    8000013e:	f062                	sd	s8,32(sp)
    80000140:	ec66                	sd	s9,24(sp)
    80000142:	e86a                	sd	s10,16(sp)
    80000144:	1880                	addi	s0,sp,112
    80000146:	8aaa                	mv	s5,a0
    80000148:	8a2e                	mv	s4,a1
    8000014a:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    8000014c:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80000150:	00010517          	auipc	a0,0x10
    80000154:	86050513          	addi	a0,a0,-1952 # 8000f9b0 <cons>
    80000158:	297000ef          	jal	ra,80000bee <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000015c:	00010497          	auipc	s1,0x10
    80000160:	85448493          	addi	s1,s1,-1964 # 8000f9b0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000164:	00010917          	auipc	s2,0x10
    80000168:	8e490913          	addi	s2,s2,-1820 # 8000fa48 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    8000016c:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    8000016e:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    80000170:	4ca9                	li	s9,10
  while(n > 0){
    80000172:	07305363          	blez	s3,800001d8 <consoleread+0xae>
    while(cons.r == cons.w){
    80000176:	0984a783          	lw	a5,152(s1)
    8000017a:	09c4a703          	lw	a4,156(s1)
    8000017e:	02f71163          	bne	a4,a5,800001a0 <consoleread+0x76>
      if(killed(myproc())){
    80000182:	704010ef          	jal	ra,80001886 <myproc>
    80000186:	755010ef          	jal	ra,800020da <killed>
    8000018a:	e125                	bnez	a0,800001ea <consoleread+0xc0>
      sleep(&cons.r, &cons.lock);
    8000018c:	85a6                	mv	a1,s1
    8000018e:	854a                	mv	a0,s2
    80000190:	513010ef          	jal	ra,80001ea2 <sleep>
    while(cons.r == cons.w){
    80000194:	0984a783          	lw	a5,152(s1)
    80000198:	09c4a703          	lw	a4,156(s1)
    8000019c:	fef703e3          	beq	a4,a5,80000182 <consoleread+0x58>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001a0:	0017871b          	addiw	a4,a5,1
    800001a4:	08e4ac23          	sw	a4,152(s1)
    800001a8:	07f7f713          	andi	a4,a5,127
    800001ac:	9726                	add	a4,a4,s1
    800001ae:	01874703          	lbu	a4,24(a4)
    800001b2:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    800001b6:	057d0f63          	beq	s10,s7,80000214 <consoleread+0xea>
    cbuf = c;
    800001ba:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001be:	4685                	li	a3,1
    800001c0:	f9f40613          	addi	a2,s0,-97
    800001c4:	85d2                	mv	a1,s4
    800001c6:	8556                	mv	a0,s5
    800001c8:	036020ef          	jal	ra,800021fe <either_copyout>
    800001cc:	01850663          	beq	a0,s8,800001d8 <consoleread+0xae>
    dst++;
    800001d0:	0a05                	addi	s4,s4,1
    --n;
    800001d2:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    800001d4:	f99d1fe3          	bne	s10,s9,80000172 <consoleread+0x48>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    800001d8:	0000f517          	auipc	a0,0xf
    800001dc:	7d850513          	addi	a0,a0,2008 # 8000f9b0 <cons>
    800001e0:	2a7000ef          	jal	ra,80000c86 <release>

  return target - n;
    800001e4:	413b053b          	subw	a0,s6,s3
    800001e8:	a801                	j	800001f8 <consoleread+0xce>
        release(&cons.lock);
    800001ea:	0000f517          	auipc	a0,0xf
    800001ee:	7c650513          	addi	a0,a0,1990 # 8000f9b0 <cons>
    800001f2:	295000ef          	jal	ra,80000c86 <release>
        return -1;
    800001f6:	557d                	li	a0,-1
}
    800001f8:	70a6                	ld	ra,104(sp)
    800001fa:	7406                	ld	s0,96(sp)
    800001fc:	64e6                	ld	s1,88(sp)
    800001fe:	6946                	ld	s2,80(sp)
    80000200:	69a6                	ld	s3,72(sp)
    80000202:	6a06                	ld	s4,64(sp)
    80000204:	7ae2                	ld	s5,56(sp)
    80000206:	7b42                	ld	s6,48(sp)
    80000208:	7ba2                	ld	s7,40(sp)
    8000020a:	7c02                	ld	s8,32(sp)
    8000020c:	6ce2                	ld	s9,24(sp)
    8000020e:	6d42                	ld	s10,16(sp)
    80000210:	6165                	addi	sp,sp,112
    80000212:	8082                	ret
      if(n < target){
    80000214:	0009871b          	sext.w	a4,s3
    80000218:	fd6770e3          	bgeu	a4,s6,800001d8 <consoleread+0xae>
        cons.r--;
    8000021c:	00010717          	auipc	a4,0x10
    80000220:	82f72623          	sw	a5,-2004(a4) # 8000fa48 <cons+0x98>
    80000224:	bf55                	j	800001d8 <consoleread+0xae>

0000000080000226 <consputc>:
{
    80000226:	1141                	addi	sp,sp,-16
    80000228:	e406                	sd	ra,8(sp)
    8000022a:	e022                	sd	s0,0(sp)
    8000022c:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    8000022e:	10000793          	li	a5,256
    80000232:	00f50863          	beq	a0,a5,80000242 <consputc+0x1c>
    uartputc_sync(c);
    80000236:	5de000ef          	jal	ra,80000814 <uartputc_sync>
}
    8000023a:	60a2                	ld	ra,8(sp)
    8000023c:	6402                	ld	s0,0(sp)
    8000023e:	0141                	addi	sp,sp,16
    80000240:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000242:	4521                	li	a0,8
    80000244:	5d0000ef          	jal	ra,80000814 <uartputc_sync>
    80000248:	02000513          	li	a0,32
    8000024c:	5c8000ef          	jal	ra,80000814 <uartputc_sync>
    80000250:	4521                	li	a0,8
    80000252:	5c2000ef          	jal	ra,80000814 <uartputc_sync>
    80000256:	b7d5                	j	8000023a <consputc+0x14>

0000000080000258 <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    80000258:	1101                	addi	sp,sp,-32
    8000025a:	ec06                	sd	ra,24(sp)
    8000025c:	e822                	sd	s0,16(sp)
    8000025e:	e426                	sd	s1,8(sp)
    80000260:	e04a                	sd	s2,0(sp)
    80000262:	1000                	addi	s0,sp,32
    80000264:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    80000266:	0000f517          	auipc	a0,0xf
    8000026a:	74a50513          	addi	a0,a0,1866 # 8000f9b0 <cons>
    8000026e:	181000ef          	jal	ra,80000bee <acquire>

  switch(c){
    80000272:	47d5                	li	a5,21
    80000274:	0af48063          	beq	s1,a5,80000314 <consoleintr+0xbc>
    80000278:	0297c663          	blt	a5,s1,800002a4 <consoleintr+0x4c>
    8000027c:	47a1                	li	a5,8
    8000027e:	0cf48f63          	beq	s1,a5,8000035c <consoleintr+0x104>
    80000282:	47c1                	li	a5,16
    80000284:	10f49063          	bne	s1,a5,80000384 <consoleintr+0x12c>
  case C('P'):  // Print process list.
    procdump();
    80000288:	00a020ef          	jal	ra,80002292 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    8000028c:	0000f517          	auipc	a0,0xf
    80000290:	72450513          	addi	a0,a0,1828 # 8000f9b0 <cons>
    80000294:	1f3000ef          	jal	ra,80000c86 <release>
}
    80000298:	60e2                	ld	ra,24(sp)
    8000029a:	6442                	ld	s0,16(sp)
    8000029c:	64a2                	ld	s1,8(sp)
    8000029e:	6902                	ld	s2,0(sp)
    800002a0:	6105                	addi	sp,sp,32
    800002a2:	8082                	ret
  switch(c){
    800002a4:	07f00793          	li	a5,127
    800002a8:	0af48a63          	beq	s1,a5,8000035c <consoleintr+0x104>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002ac:	0000f717          	auipc	a4,0xf
    800002b0:	70470713          	addi	a4,a4,1796 # 8000f9b0 <cons>
    800002b4:	0a072783          	lw	a5,160(a4)
    800002b8:	09872703          	lw	a4,152(a4)
    800002bc:	9f99                	subw	a5,a5,a4
    800002be:	07f00713          	li	a4,127
    800002c2:	fcf765e3          	bltu	a4,a5,8000028c <consoleintr+0x34>
      c = (c == '\r') ? '\n' : c;
    800002c6:	47b5                	li	a5,13
    800002c8:	0cf48163          	beq	s1,a5,8000038a <consoleintr+0x132>
      consputc(c);
    800002cc:	8526                	mv	a0,s1
    800002ce:	f59ff0ef          	jal	ra,80000226 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002d2:	0000f797          	auipc	a5,0xf
    800002d6:	6de78793          	addi	a5,a5,1758 # 8000f9b0 <cons>
    800002da:	0a07a683          	lw	a3,160(a5)
    800002de:	0016871b          	addiw	a4,a3,1
    800002e2:	0007061b          	sext.w	a2,a4
    800002e6:	0ae7a023          	sw	a4,160(a5)
    800002ea:	07f6f693          	andi	a3,a3,127
    800002ee:	97b6                	add	a5,a5,a3
    800002f0:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    800002f4:	47a9                	li	a5,10
    800002f6:	0af48f63          	beq	s1,a5,800003b4 <consoleintr+0x15c>
    800002fa:	4791                	li	a5,4
    800002fc:	0af48c63          	beq	s1,a5,800003b4 <consoleintr+0x15c>
    80000300:	0000f797          	auipc	a5,0xf
    80000304:	7487a783          	lw	a5,1864(a5) # 8000fa48 <cons+0x98>
    80000308:	9f1d                	subw	a4,a4,a5
    8000030a:	08000793          	li	a5,128
    8000030e:	f6f71fe3          	bne	a4,a5,8000028c <consoleintr+0x34>
    80000312:	a04d                	j	800003b4 <consoleintr+0x15c>
    while(cons.e != cons.w &&
    80000314:	0000f717          	auipc	a4,0xf
    80000318:	69c70713          	addi	a4,a4,1692 # 8000f9b0 <cons>
    8000031c:	0a072783          	lw	a5,160(a4)
    80000320:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000324:	0000f497          	auipc	s1,0xf
    80000328:	68c48493          	addi	s1,s1,1676 # 8000f9b0 <cons>
    while(cons.e != cons.w &&
    8000032c:	4929                	li	s2,10
    8000032e:	f4f70fe3          	beq	a4,a5,8000028c <consoleintr+0x34>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000332:	37fd                	addiw	a5,a5,-1
    80000334:	07f7f713          	andi	a4,a5,127
    80000338:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    8000033a:	01874703          	lbu	a4,24(a4)
    8000033e:	f52707e3          	beq	a4,s2,8000028c <consoleintr+0x34>
      cons.e--;
    80000342:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000346:	10000513          	li	a0,256
    8000034a:	eddff0ef          	jal	ra,80000226 <consputc>
    while(cons.e != cons.w &&
    8000034e:	0a04a783          	lw	a5,160(s1)
    80000352:	09c4a703          	lw	a4,156(s1)
    80000356:	fcf71ee3          	bne	a4,a5,80000332 <consoleintr+0xda>
    8000035a:	bf0d                	j	8000028c <consoleintr+0x34>
    if(cons.e != cons.w){
    8000035c:	0000f717          	auipc	a4,0xf
    80000360:	65470713          	addi	a4,a4,1620 # 8000f9b0 <cons>
    80000364:	0a072783          	lw	a5,160(a4)
    80000368:	09c72703          	lw	a4,156(a4)
    8000036c:	f2f700e3          	beq	a4,a5,8000028c <consoleintr+0x34>
      cons.e--;
    80000370:	37fd                	addiw	a5,a5,-1
    80000372:	0000f717          	auipc	a4,0xf
    80000376:	6cf72f23          	sw	a5,1758(a4) # 8000fa50 <cons+0xa0>
      consputc(BACKSPACE);
    8000037a:	10000513          	li	a0,256
    8000037e:	ea9ff0ef          	jal	ra,80000226 <consputc>
    80000382:	b729                	j	8000028c <consoleintr+0x34>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000384:	f00484e3          	beqz	s1,8000028c <consoleintr+0x34>
    80000388:	b715                	j	800002ac <consoleintr+0x54>
      consputc(c);
    8000038a:	4529                	li	a0,10
    8000038c:	e9bff0ef          	jal	ra,80000226 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000390:	0000f797          	auipc	a5,0xf
    80000394:	62078793          	addi	a5,a5,1568 # 8000f9b0 <cons>
    80000398:	0a07a703          	lw	a4,160(a5)
    8000039c:	0017069b          	addiw	a3,a4,1
    800003a0:	0006861b          	sext.w	a2,a3
    800003a4:	0ad7a023          	sw	a3,160(a5)
    800003a8:	07f77713          	andi	a4,a4,127
    800003ac:	97ba                	add	a5,a5,a4
    800003ae:	4729                	li	a4,10
    800003b0:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003b4:	0000f797          	auipc	a5,0xf
    800003b8:	68c7ac23          	sw	a2,1688(a5) # 8000fa4c <cons+0x9c>
        wakeup(&cons.r);
    800003bc:	0000f517          	auipc	a0,0xf
    800003c0:	68c50513          	addi	a0,a0,1676 # 8000fa48 <cons+0x98>
    800003c4:	32b010ef          	jal	ra,80001eee <wakeup>
    800003c8:	b5d1                	j	8000028c <consoleintr+0x34>

00000000800003ca <consoleinit>:

void
consoleinit(void)
{
    800003ca:	1141                	addi	sp,sp,-16
    800003cc:	e406                	sd	ra,8(sp)
    800003ce:	e022                	sd	s0,0(sp)
    800003d0:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800003d2:	00007597          	auipc	a1,0x7
    800003d6:	c3e58593          	addi	a1,a1,-962 # 80007010 <etext+0x10>
    800003da:	0000f517          	auipc	a0,0xf
    800003de:	5d650513          	addi	a0,a0,1494 # 8000f9b0 <cons>
    800003e2:	78c000ef          	jal	ra,80000b6e <initlock>

  uartinit();
    800003e6:	3e2000ef          	jal	ra,800007c8 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    800003ea:	00024797          	auipc	a5,0x24
    800003ee:	55678793          	addi	a5,a5,1366 # 80024940 <devsw>
    800003f2:	00000717          	auipc	a4,0x0
    800003f6:	d3870713          	addi	a4,a4,-712 # 8000012a <consoleread>
    800003fa:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    800003fc:	00000717          	auipc	a4,0x0
    80000400:	cd470713          	addi	a4,a4,-812 # 800000d0 <consolewrite>
    80000404:	ef98                	sd	a4,24(a5)
}
    80000406:	60a2                	ld	ra,8(sp)
    80000408:	6402                	ld	s0,0(sp)
    8000040a:	0141                	addi	sp,sp,16
    8000040c:	8082                	ret

000000008000040e <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    8000040e:	7139                	addi	sp,sp,-64
    80000410:	fc06                	sd	ra,56(sp)
    80000412:	f822                	sd	s0,48(sp)
    80000414:	f426                	sd	s1,40(sp)
    80000416:	f04a                	sd	s2,32(sp)
    80000418:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000041a:	c219                	beqz	a2,80000420 <printint+0x12>
    8000041c:	06054f63          	bltz	a0,8000049a <printint+0x8c>
    x = -xx;
  else
    x = xx;
    80000420:	4881                	li	a7,0
    80000422:	fc840693          	addi	a3,s0,-56

  i = 0;
    80000426:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    80000428:	00007617          	auipc	a2,0x7
    8000042c:	c1060613          	addi	a2,a2,-1008 # 80007038 <digits>
    80000430:	883e                	mv	a6,a5
    80000432:	2785                	addiw	a5,a5,1
    80000434:	02b57733          	remu	a4,a0,a1
    80000438:	9732                	add	a4,a4,a2
    8000043a:	00074703          	lbu	a4,0(a4)
    8000043e:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000442:	872a                	mv	a4,a0
    80000444:	02b55533          	divu	a0,a0,a1
    80000448:	0685                	addi	a3,a3,1
    8000044a:	feb773e3          	bgeu	a4,a1,80000430 <printint+0x22>

  if(sign)
    8000044e:	00088b63          	beqz	a7,80000464 <printint+0x56>
    buf[i++] = '-';
    80000452:	fe040713          	addi	a4,s0,-32
    80000456:	97ba                	add	a5,a5,a4
    80000458:	02d00713          	li	a4,45
    8000045c:	fee78423          	sb	a4,-24(a5)
    80000460:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    80000464:	02f05563          	blez	a5,8000048e <printint+0x80>
    80000468:	fc840713          	addi	a4,s0,-56
    8000046c:	00f704b3          	add	s1,a4,a5
    80000470:	fff70913          	addi	s2,a4,-1
    80000474:	993e                	add	s2,s2,a5
    80000476:	37fd                	addiw	a5,a5,-1
    80000478:	1782                	slli	a5,a5,0x20
    8000047a:	9381                	srli	a5,a5,0x20
    8000047c:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    80000480:	fff4c503          	lbu	a0,-1(s1)
    80000484:	da3ff0ef          	jal	ra,80000226 <consputc>
  while(--i >= 0)
    80000488:	14fd                	addi	s1,s1,-1
    8000048a:	ff249be3          	bne	s1,s2,80000480 <printint+0x72>
}
    8000048e:	70e2                	ld	ra,56(sp)
    80000490:	7442                	ld	s0,48(sp)
    80000492:	74a2                	ld	s1,40(sp)
    80000494:	7902                	ld	s2,32(sp)
    80000496:	6121                	addi	sp,sp,64
    80000498:	8082                	ret
    x = -xx;
    8000049a:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    8000049e:	4885                	li	a7,1
    x = -xx;
    800004a0:	b749                	j	80000422 <printint+0x14>

00000000800004a2 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004a2:	7131                	addi	sp,sp,-192
    800004a4:	fc86                	sd	ra,120(sp)
    800004a6:	f8a2                	sd	s0,112(sp)
    800004a8:	f4a6                	sd	s1,104(sp)
    800004aa:	f0ca                	sd	s2,96(sp)
    800004ac:	ecce                	sd	s3,88(sp)
    800004ae:	e8d2                	sd	s4,80(sp)
    800004b0:	e4d6                	sd	s5,72(sp)
    800004b2:	e0da                	sd	s6,64(sp)
    800004b4:	fc5e                	sd	s7,56(sp)
    800004b6:	f862                	sd	s8,48(sp)
    800004b8:	f466                	sd	s9,40(sp)
    800004ba:	f06a                	sd	s10,32(sp)
    800004bc:	ec6e                	sd	s11,24(sp)
    800004be:	0100                	addi	s0,sp,128
    800004c0:	8a2a                	mv	s4,a0
    800004c2:	e40c                	sd	a1,8(s0)
    800004c4:	e810                	sd	a2,16(s0)
    800004c6:	ec14                	sd	a3,24(s0)
    800004c8:	f018                	sd	a4,32(s0)
    800004ca:	f41c                	sd	a5,40(s0)
    800004cc:	03043823          	sd	a6,48(s0)
    800004d0:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    800004d4:	00007797          	auipc	a5,0x7
    800004d8:	4a07a783          	lw	a5,1184(a5) # 80007974 <panicking>
    800004dc:	cb9d                	beqz	a5,80000512 <printf+0x70>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800004de:	00840793          	addi	a5,s0,8
    800004e2:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    800004e6:	000a4503          	lbu	a0,0(s4)
    800004ea:	24050363          	beqz	a0,80000730 <printf+0x28e>
    800004ee:	4981                	li	s3,0
    if(cx != '%'){
    800004f0:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    800004f4:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    800004f8:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    800004fc:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000500:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000504:	07000d93          	li	s11,112
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000508:	00007b97          	auipc	s7,0x7
    8000050c:	b30b8b93          	addi	s7,s7,-1232 # 80007038 <digits>
    80000510:	a01d                	j	80000536 <printf+0x94>
    acquire(&pr.lock);
    80000512:	0000f517          	auipc	a0,0xf
    80000516:	54650513          	addi	a0,a0,1350 # 8000fa58 <pr>
    8000051a:	6d4000ef          	jal	ra,80000bee <acquire>
    8000051e:	b7c1                	j	800004de <printf+0x3c>
      consputc(cx);
    80000520:	d07ff0ef          	jal	ra,80000226 <consputc>
      continue;
    80000524:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000526:	0014899b          	addiw	s3,s1,1
    8000052a:	013a07b3          	add	a5,s4,s3
    8000052e:	0007c503          	lbu	a0,0(a5)
    80000532:	1e050f63          	beqz	a0,80000730 <printf+0x28e>
    if(cx != '%'){
    80000536:	ff5515e3          	bne	a0,s5,80000520 <printf+0x7e>
    i++;
    8000053a:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    8000053e:	009a07b3          	add	a5,s4,s1
    80000542:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000546:	1e090563          	beqz	s2,80000730 <printf+0x28e>
    8000054a:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    8000054e:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    80000550:	c789                	beqz	a5,8000055a <printf+0xb8>
    80000552:	009a0733          	add	a4,s4,s1
    80000556:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    8000055a:	03690863          	beq	s2,s6,8000058a <printf+0xe8>
    } else if(c0 == 'l' && c1 == 'd'){
    8000055e:	05890263          	beq	s2,s8,800005a2 <printf+0x100>
    } else if(c0 == 'u'){
    80000562:	0d990163          	beq	s2,s9,80000624 <printf+0x182>
    } else if(c0 == 'x'){
    80000566:	11a90863          	beq	s2,s10,80000676 <printf+0x1d4>
    } else if(c0 == 'p'){
    8000056a:	15b90163          	beq	s2,s11,800006ac <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    8000056e:	06300793          	li	a5,99
    80000572:	16f90963          	beq	s2,a5,800006e4 <printf+0x242>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    80000576:	07300793          	li	a5,115
    8000057a:	16f90f63          	beq	s2,a5,800006f8 <printf+0x256>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    8000057e:	03591c63          	bne	s2,s5,800005b6 <printf+0x114>
      consputc('%');
    80000582:	8556                	mv	a0,s5
    80000584:	ca3ff0ef          	jal	ra,80000226 <consputc>
    80000588:	bf79                	j	80000526 <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    8000058a:	f8843783          	ld	a5,-120(s0)
    8000058e:	00878713          	addi	a4,a5,8
    80000592:	f8e43423          	sd	a4,-120(s0)
    80000596:	4605                	li	a2,1
    80000598:	45a9                	li	a1,10
    8000059a:	4388                	lw	a0,0(a5)
    8000059c:	e73ff0ef          	jal	ra,8000040e <printint>
    800005a0:	b759                	j	80000526 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	03678163          	beq	a5,s6,800005c4 <printf+0x122>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005a6:	03878d63          	beq	a5,s8,800005e0 <printf+0x13e>
    } else if(c0 == 'l' && c1 == 'u'){
    800005aa:	09978a63          	beq	a5,s9,8000063e <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800005ae:	03878b63          	beq	a5,s8,800005e4 <printf+0x142>
    } else if(c0 == 'l' && c1 == 'x'){
    800005b2:	0da78f63          	beq	a5,s10,80000690 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    800005b6:	8556                	mv	a0,s5
    800005b8:	c6fff0ef          	jal	ra,80000226 <consputc>
      consputc(c0);
    800005bc:	854a                	mv	a0,s2
    800005be:	c69ff0ef          	jal	ra,80000226 <consputc>
    800005c2:	b795                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    800005c4:	f8843783          	ld	a5,-120(s0)
    800005c8:	00878713          	addi	a4,a5,8
    800005cc:	f8e43423          	sd	a4,-120(s0)
    800005d0:	4605                	li	a2,1
    800005d2:	45a9                	li	a1,10
    800005d4:	6388                	ld	a0,0(a5)
    800005d6:	e39ff0ef          	jal	ra,8000040e <printint>
      i += 1;
    800005da:	0029849b          	addiw	s1,s3,2
    800005de:	b7a1                	j	80000526 <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005e0:	03668463          	beq	a3,s6,80000608 <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800005e4:	07968b63          	beq	a3,s9,8000065a <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800005e8:	fda697e3          	bne	a3,s10,800005b6 <printf+0x114>
      printint(va_arg(ap, uint64), 16, 0);
    800005ec:	f8843783          	ld	a5,-120(s0)
    800005f0:	00878713          	addi	a4,a5,8
    800005f4:	f8e43423          	sd	a4,-120(s0)
    800005f8:	4601                	li	a2,0
    800005fa:	45c1                	li	a1,16
    800005fc:	6388                	ld	a0,0(a5)
    800005fe:	e11ff0ef          	jal	ra,8000040e <printint>
      i += 2;
    80000602:	0039849b          	addiw	s1,s3,3
    80000606:	b705                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    80000608:	f8843783          	ld	a5,-120(s0)
    8000060c:	00878713          	addi	a4,a5,8
    80000610:	f8e43423          	sd	a4,-120(s0)
    80000614:	4605                	li	a2,1
    80000616:	45a9                	li	a1,10
    80000618:	6388                	ld	a0,0(a5)
    8000061a:	df5ff0ef          	jal	ra,8000040e <printint>
      i += 2;
    8000061e:	0039849b          	addiw	s1,s3,3
    80000622:	b711                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint32), 10, 0);
    80000624:	f8843783          	ld	a5,-120(s0)
    80000628:	00878713          	addi	a4,a5,8
    8000062c:	f8e43423          	sd	a4,-120(s0)
    80000630:	4601                	li	a2,0
    80000632:	45a9                	li	a1,10
    80000634:	0007e503          	lwu	a0,0(a5)
    80000638:	dd7ff0ef          	jal	ra,8000040e <printint>
    8000063c:	b5ed                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    8000063e:	f8843783          	ld	a5,-120(s0)
    80000642:	00878713          	addi	a4,a5,8
    80000646:	f8e43423          	sd	a4,-120(s0)
    8000064a:	4601                	li	a2,0
    8000064c:	45a9                	li	a1,10
    8000064e:	6388                	ld	a0,0(a5)
    80000650:	dbfff0ef          	jal	ra,8000040e <printint>
      i += 1;
    80000654:	0029849b          	addiw	s1,s3,2
    80000658:	b5f9                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    8000065a:	f8843783          	ld	a5,-120(s0)
    8000065e:	00878713          	addi	a4,a5,8
    80000662:	f8e43423          	sd	a4,-120(s0)
    80000666:	4601                	li	a2,0
    80000668:	45a9                	li	a1,10
    8000066a:	6388                	ld	a0,0(a5)
    8000066c:	da3ff0ef          	jal	ra,8000040e <printint>
      i += 2;
    80000670:	0039849b          	addiw	s1,s3,3
    80000674:	bd4d                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint32), 16, 0);
    80000676:	f8843783          	ld	a5,-120(s0)
    8000067a:	00878713          	addi	a4,a5,8
    8000067e:	f8e43423          	sd	a4,-120(s0)
    80000682:	4601                	li	a2,0
    80000684:	45c1                	li	a1,16
    80000686:	0007e503          	lwu	a0,0(a5)
    8000068a:	d85ff0ef          	jal	ra,8000040e <printint>
    8000068e:	bd61                	j	80000526 <printf+0x84>
      printint(va_arg(ap, uint64), 16, 0);
    80000690:	f8843783          	ld	a5,-120(s0)
    80000694:	00878713          	addi	a4,a5,8
    80000698:	f8e43423          	sd	a4,-120(s0)
    8000069c:	4601                	li	a2,0
    8000069e:	45c1                	li	a1,16
    800006a0:	6388                	ld	a0,0(a5)
    800006a2:	d6dff0ef          	jal	ra,8000040e <printint>
      i += 1;
    800006a6:	0029849b          	addiw	s1,s3,2
    800006aa:	bdb5                	j	80000526 <printf+0x84>
      printptr(va_arg(ap, uint64));
    800006ac:	f8843783          	ld	a5,-120(s0)
    800006b0:	00878713          	addi	a4,a5,8
    800006b4:	f8e43423          	sd	a4,-120(s0)
    800006b8:	0007b983          	ld	s3,0(a5)
  consputc('0');
    800006bc:	03000513          	li	a0,48
    800006c0:	b67ff0ef          	jal	ra,80000226 <consputc>
  consputc('x');
    800006c4:	856a                	mv	a0,s10
    800006c6:	b61ff0ef          	jal	ra,80000226 <consputc>
    800006ca:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006cc:	03c9d793          	srli	a5,s3,0x3c
    800006d0:	97de                	add	a5,a5,s7
    800006d2:	0007c503          	lbu	a0,0(a5)
    800006d6:	b51ff0ef          	jal	ra,80000226 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006da:	0992                	slli	s3,s3,0x4
    800006dc:	397d                	addiw	s2,s2,-1
    800006de:	fe0917e3          	bnez	s2,800006cc <printf+0x22a>
    800006e2:	b591                	j	80000526 <printf+0x84>
      consputc(va_arg(ap, uint));
    800006e4:	f8843783          	ld	a5,-120(s0)
    800006e8:	00878713          	addi	a4,a5,8
    800006ec:	f8e43423          	sd	a4,-120(s0)
    800006f0:	4388                	lw	a0,0(a5)
    800006f2:	b35ff0ef          	jal	ra,80000226 <consputc>
    800006f6:	bd05                	j	80000526 <printf+0x84>
      if((s = va_arg(ap, char*)) == 0)
    800006f8:	f8843783          	ld	a5,-120(s0)
    800006fc:	00878713          	addi	a4,a5,8
    80000700:	f8e43423          	sd	a4,-120(s0)
    80000704:	0007b903          	ld	s2,0(a5)
    80000708:	00090d63          	beqz	s2,80000722 <printf+0x280>
      for(; *s; s++)
    8000070c:	00094503          	lbu	a0,0(s2)
    80000710:	e0050be3          	beqz	a0,80000526 <printf+0x84>
        consputc(*s);
    80000714:	b13ff0ef          	jal	ra,80000226 <consputc>
      for(; *s; s++)
    80000718:	0905                	addi	s2,s2,1
    8000071a:	00094503          	lbu	a0,0(s2)
    8000071e:	f97d                	bnez	a0,80000714 <printf+0x272>
    80000720:	b519                	j	80000526 <printf+0x84>
        s = "(null)";
    80000722:	00007917          	auipc	s2,0x7
    80000726:	8f690913          	addi	s2,s2,-1802 # 80007018 <etext+0x18>
      for(; *s; s++)
    8000072a:	02800513          	li	a0,40
    8000072e:	b7dd                	j	80000714 <printf+0x272>
    }

  }
  va_end(ap);

  if(panicking == 0)
    80000730:	00007797          	auipc	a5,0x7
    80000734:	2447a783          	lw	a5,580(a5) # 80007974 <panicking>
    80000738:	c38d                	beqz	a5,8000075a <printf+0x2b8>
    release(&pr.lock);

  return 0;
}
    8000073a:	4501                	li	a0,0
    8000073c:	70e6                	ld	ra,120(sp)
    8000073e:	7446                	ld	s0,112(sp)
    80000740:	74a6                	ld	s1,104(sp)
    80000742:	7906                	ld	s2,96(sp)
    80000744:	69e6                	ld	s3,88(sp)
    80000746:	6a46                	ld	s4,80(sp)
    80000748:	6aa6                	ld	s5,72(sp)
    8000074a:	6b06                	ld	s6,64(sp)
    8000074c:	7be2                	ld	s7,56(sp)
    8000074e:	7c42                	ld	s8,48(sp)
    80000750:	7ca2                	ld	s9,40(sp)
    80000752:	7d02                	ld	s10,32(sp)
    80000754:	6de2                	ld	s11,24(sp)
    80000756:	6129                	addi	sp,sp,192
    80000758:	8082                	ret
    release(&pr.lock);
    8000075a:	0000f517          	auipc	a0,0xf
    8000075e:	2fe50513          	addi	a0,a0,766 # 8000fa58 <pr>
    80000762:	524000ef          	jal	ra,80000c86 <release>
  return 0;
    80000766:	bfd1                	j	8000073a <printf+0x298>

0000000080000768 <panic>:

void
panic(char *s)
{
    80000768:	1101                	addi	sp,sp,-32
    8000076a:	ec06                	sd	ra,24(sp)
    8000076c:	e822                	sd	s0,16(sp)
    8000076e:	e426                	sd	s1,8(sp)
    80000770:	e04a                	sd	s2,0(sp)
    80000772:	1000                	addi	s0,sp,32
    80000774:	84aa                	mv	s1,a0
  panicking = 1;
    80000776:	4905                	li	s2,1
    80000778:	00007797          	auipc	a5,0x7
    8000077c:	1f27ae23          	sw	s2,508(a5) # 80007974 <panicking>
  printf("panic: ");
    80000780:	00007517          	auipc	a0,0x7
    80000784:	8a050513          	addi	a0,a0,-1888 # 80007020 <etext+0x20>
    80000788:	d1bff0ef          	jal	ra,800004a2 <printf>
  printf("%s\n", s);
    8000078c:	85a6                	mv	a1,s1
    8000078e:	00007517          	auipc	a0,0x7
    80000792:	89a50513          	addi	a0,a0,-1894 # 80007028 <etext+0x28>
    80000796:	d0dff0ef          	jal	ra,800004a2 <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000079a:	00007797          	auipc	a5,0x7
    8000079e:	1d27ab23          	sw	s2,470(a5) # 80007970 <panicked>
  for(;;)
    800007a2:	a001                	j	800007a2 <panic+0x3a>

00000000800007a4 <printfinit>:
    ;
}

void
printfinit(void)
{
    800007a4:	1141                	addi	sp,sp,-16
    800007a6:	e406                	sd	ra,8(sp)
    800007a8:	e022                	sd	s0,0(sp)
    800007aa:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    800007ac:	00007597          	auipc	a1,0x7
    800007b0:	88458593          	addi	a1,a1,-1916 # 80007030 <etext+0x30>
    800007b4:	0000f517          	auipc	a0,0xf
    800007b8:	2a450513          	addi	a0,a0,676 # 8000fa58 <pr>
    800007bc:	3b2000ef          	jal	ra,80000b6e <initlock>
}
    800007c0:	60a2                	ld	ra,8(sp)
    800007c2:	6402                	ld	s0,0(sp)
    800007c4:	0141                	addi	sp,sp,16
    800007c6:	8082                	ret

00000000800007c8 <uartinit>:

void uartstart();

void
uartinit(void)
{
    800007c8:	1141                	addi	sp,sp,-16
    800007ca:	e406                	sd	ra,8(sp)
    800007cc:	e022                	sd	s0,0(sp)
    800007ce:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007d0:	100007b7          	lui	a5,0x10000
    800007d4:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007d8:	f8000713          	li	a4,-128
    800007dc:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800007e0:	470d                	li	a4,3
    800007e2:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800007e6:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800007ea:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800007ee:	469d                	li	a3,7
    800007f0:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800007f4:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    800007f8:	00007597          	auipc	a1,0x7
    800007fc:	85858593          	addi	a1,a1,-1960 # 80007050 <digits+0x18>
    80000800:	0000f517          	auipc	a0,0xf
    80000804:	27050513          	addi	a0,a0,624 # 8000fa70 <uart_tx_lock>
    80000808:	366000ef          	jal	ra,80000b6e <initlock>
}
    8000080c:	60a2                	ld	ra,8(sp)
    8000080e:	6402                	ld	s0,0(sp)
    80000810:	0141                	addi	sp,sp,16
    80000812:	8082                	ret

0000000080000814 <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000814:	1101                	addi	sp,sp,-32
    80000816:	ec06                	sd	ra,24(sp)
    80000818:	e822                	sd	s0,16(sp)
    8000081a:	e426                	sd	s1,8(sp)
    8000081c:	1000                	addi	s0,sp,32
    8000081e:	84aa                	mv	s1,a0
  if(panicking == 0)
    80000820:	00007797          	auipc	a5,0x7
    80000824:	1547a783          	lw	a5,340(a5) # 80007974 <panicking>
    80000828:	cb89                	beqz	a5,8000083a <uartputc_sync+0x26>
    push_off();

  if(panicked){
    8000082a:	00007797          	auipc	a5,0x7
    8000082e:	1467a783          	lw	a5,326(a5) # 80007970 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000832:	10000737          	lui	a4,0x10000
  if(panicked){
    80000836:	c789                	beqz	a5,80000840 <uartputc_sync+0x2c>
    for(;;)
    80000838:	a001                	j	80000838 <uartputc_sync+0x24>
    push_off();
    8000083a:	374000ef          	jal	ra,80000bae <push_off>
    8000083e:	b7f5                	j	8000082a <uartputc_sync+0x16>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000840:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80000844:	0207f793          	andi	a5,a5,32
    80000848:	dfe5                	beqz	a5,80000840 <uartputc_sync+0x2c>
    ;
  WriteReg(THR, c);
    8000084a:	0ff4f513          	zext.b	a0,s1
    8000084e:	100007b7          	lui	a5,0x10000
    80000852:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    80000856:	00007797          	auipc	a5,0x7
    8000085a:	11e7a783          	lw	a5,286(a5) # 80007974 <panicking>
    8000085e:	c791                	beqz	a5,8000086a <uartputc_sync+0x56>
    pop_off();
}
    80000860:	60e2                	ld	ra,24(sp)
    80000862:	6442                	ld	s0,16(sp)
    80000864:	64a2                	ld	s1,8(sp)
    80000866:	6105                	addi	sp,sp,32
    80000868:	8082                	ret
    pop_off();
    8000086a:	3c8000ef          	jal	ra,80000c32 <pop_off>
}
    8000086e:	bfcd                	j	80000860 <uartputc_sync+0x4c>

0000000080000870 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80000870:	00007797          	auipc	a5,0x7
    80000874:	1087b783          	ld	a5,264(a5) # 80007978 <uart_tx_r>
    80000878:	00007717          	auipc	a4,0x7
    8000087c:	10873703          	ld	a4,264(a4) # 80007980 <uart_tx_w>
    80000880:	06f70863          	beq	a4,a5,800008f0 <uartstart+0x80>
{
    80000884:	7139                	addi	sp,sp,-64
    80000886:	fc06                	sd	ra,56(sp)
    80000888:	f822                	sd	s0,48(sp)
    8000088a:	f426                	sd	s1,40(sp)
    8000088c:	f04a                	sd	s2,32(sp)
    8000088e:	ec4e                	sd	s3,24(sp)
    80000890:	e852                	sd	s4,16(sp)
    80000892:	e456                	sd	s5,8(sp)
    80000894:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80000896:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000089a:	0000fa17          	auipc	s4,0xf
    8000089e:	1d6a0a13          	addi	s4,s4,470 # 8000fa70 <uart_tx_lock>
    uart_tx_r += 1;
    800008a2:	00007497          	auipc	s1,0x7
    800008a6:	0d648493          	addi	s1,s1,214 # 80007978 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    800008aa:	00007997          	auipc	s3,0x7
    800008ae:	0d698993          	addi	s3,s3,214 # 80007980 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    800008b2:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    800008b6:	02077713          	andi	a4,a4,32
    800008ba:	c315                	beqz	a4,800008de <uartstart+0x6e>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    800008bc:	01f7f713          	andi	a4,a5,31
    800008c0:	9752                	add	a4,a4,s4
    800008c2:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    800008c6:	0785                	addi	a5,a5,1
    800008c8:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    800008ca:	8526                	mv	a0,s1
    800008cc:	622010ef          	jal	ra,80001eee <wakeup>
    
    WriteReg(THR, c);
    800008d0:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    800008d4:	609c                	ld	a5,0(s1)
    800008d6:	0009b703          	ld	a4,0(s3)
    800008da:	fcf71ce3          	bne	a4,a5,800008b2 <uartstart+0x42>
  }
}
    800008de:	70e2                	ld	ra,56(sp)
    800008e0:	7442                	ld	s0,48(sp)
    800008e2:	74a2                	ld	s1,40(sp)
    800008e4:	7902                	ld	s2,32(sp)
    800008e6:	69e2                	ld	s3,24(sp)
    800008e8:	6a42                	ld	s4,16(sp)
    800008ea:	6aa2                	ld	s5,8(sp)
    800008ec:	6121                	addi	sp,sp,64
    800008ee:	8082                	ret
    800008f0:	8082                	ret

00000000800008f2 <uartputc>:
{
    800008f2:	7179                	addi	sp,sp,-48
    800008f4:	f406                	sd	ra,40(sp)
    800008f6:	f022                	sd	s0,32(sp)
    800008f8:	ec26                	sd	s1,24(sp)
    800008fa:	e84a                	sd	s2,16(sp)
    800008fc:	e44e                	sd	s3,8(sp)
    800008fe:	e052                	sd	s4,0(sp)
    80000900:	1800                	addi	s0,sp,48
    80000902:	8a2a                	mv	s4,a0
  if(panicking == 0)
    80000904:	00007797          	auipc	a5,0x7
    80000908:	0707a783          	lw	a5,112(a5) # 80007974 <panicking>
    8000090c:	c7d1                	beqz	a5,80000998 <uartputc+0xa6>
  if(panicked){
    8000090e:	00007797          	auipc	a5,0x7
    80000912:	0627a783          	lw	a5,98(a5) # 80007970 <panicked>
    80000916:	ebc1                	bnez	a5,800009a6 <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000918:	00007717          	auipc	a4,0x7
    8000091c:	06873703          	ld	a4,104(a4) # 80007980 <uart_tx_w>
    80000920:	00007797          	auipc	a5,0x7
    80000924:	0587b783          	ld	a5,88(a5) # 80007978 <uart_tx_r>
    80000928:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    8000092c:	0000f997          	auipc	s3,0xf
    80000930:	14498993          	addi	s3,s3,324 # 8000fa70 <uart_tx_lock>
    80000934:	00007497          	auipc	s1,0x7
    80000938:	04448493          	addi	s1,s1,68 # 80007978 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000093c:	00007917          	auipc	s2,0x7
    80000940:	04490913          	addi	s2,s2,68 # 80007980 <uart_tx_w>
    80000944:	00e79d63          	bne	a5,a4,8000095e <uartputc+0x6c>
    sleep(&uart_tx_r, &uart_tx_lock);
    80000948:	85ce                	mv	a1,s3
    8000094a:	8526                	mv	a0,s1
    8000094c:	556010ef          	jal	ra,80001ea2 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000950:	00093703          	ld	a4,0(s2)
    80000954:	609c                	ld	a5,0(s1)
    80000956:	02078793          	addi	a5,a5,32
    8000095a:	fee787e3          	beq	a5,a4,80000948 <uartputc+0x56>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    8000095e:	01f77693          	andi	a3,a4,31
    80000962:	0000f797          	auipc	a5,0xf
    80000966:	10e78793          	addi	a5,a5,270 # 8000fa70 <uart_tx_lock>
    8000096a:	97b6                	add	a5,a5,a3
    8000096c:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80000970:	0705                	addi	a4,a4,1
    80000972:	00007797          	auipc	a5,0x7
    80000976:	00e7b723          	sd	a4,14(a5) # 80007980 <uart_tx_w>
  uartstart();
    8000097a:	ef7ff0ef          	jal	ra,80000870 <uartstart>
  if(panicking == 0)
    8000097e:	00007797          	auipc	a5,0x7
    80000982:	ff67a783          	lw	a5,-10(a5) # 80007974 <panicking>
    80000986:	c38d                	beqz	a5,800009a8 <uartputc+0xb6>
}
    80000988:	70a2                	ld	ra,40(sp)
    8000098a:	7402                	ld	s0,32(sp)
    8000098c:	64e2                	ld	s1,24(sp)
    8000098e:	6942                	ld	s2,16(sp)
    80000990:	69a2                	ld	s3,8(sp)
    80000992:	6a02                	ld	s4,0(sp)
    80000994:	6145                	addi	sp,sp,48
    80000996:	8082                	ret
    acquire(&uart_tx_lock);
    80000998:	0000f517          	auipc	a0,0xf
    8000099c:	0d850513          	addi	a0,a0,216 # 8000fa70 <uart_tx_lock>
    800009a0:	24e000ef          	jal	ra,80000bee <acquire>
    800009a4:	b7ad                	j	8000090e <uartputc+0x1c>
    for(;;)
    800009a6:	a001                	j	800009a6 <uartputc+0xb4>
    release(&uart_tx_lock);
    800009a8:	0000f517          	auipc	a0,0xf
    800009ac:	0c850513          	addi	a0,a0,200 # 8000fa70 <uart_tx_lock>
    800009b0:	2d6000ef          	jal	ra,80000c86 <release>
}
    800009b4:	bfd1                	j	80000988 <uartputc+0x96>

00000000800009b6 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009b6:	1141                	addi	sp,sp,-16
    800009b8:	e422                	sd	s0,8(sp)
    800009ba:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    800009bc:	100007b7          	lui	a5,0x10000
    800009c0:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009c4:	8b85                	andi	a5,a5,1
    800009c6:	cb91                	beqz	a5,800009da <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800009c8:	100007b7          	lui	a5,0x10000
    800009cc:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    800009d0:	0ff57513          	zext.b	a0,a0
  } else {
    return -1;
  }
}
    800009d4:	6422                	ld	s0,8(sp)
    800009d6:	0141                	addi	sp,sp,16
    800009d8:	8082                	ret
    return -1;
    800009da:	557d                	li	a0,-1
    800009dc:	bfe5                	j	800009d4 <uartgetc+0x1e>

00000000800009de <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009de:	1101                	addi	sp,sp,-32
    800009e0:	ec06                	sd	ra,24(sp)
    800009e2:	e822                	sd	s0,16(sp)
    800009e4:	e426                	sd	s1,8(sp)
    800009e6:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009e8:	100007b7          	lui	a5,0x10000
    800009ec:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009f0:	54fd                	li	s1,-1
    800009f2:	a019                	j	800009f8 <uartintr+0x1a>
      break;
    consoleintr(c);
    800009f4:	865ff0ef          	jal	ra,80000258 <consoleintr>
    int c = uartgetc();
    800009f8:	fbfff0ef          	jal	ra,800009b6 <uartgetc>
    if(c == -1)
    800009fc:	fe951ce3          	bne	a0,s1,800009f4 <uartintr+0x16>
  }

  // send buffered characters.
  if(panicking == 0)
    80000a00:	00007797          	auipc	a5,0x7
    80000a04:	f747a783          	lw	a5,-140(a5) # 80007974 <panicking>
    80000a08:	cf89                	beqz	a5,80000a22 <uartintr+0x44>
    acquire(&uart_tx_lock);
  uartstart();
    80000a0a:	e67ff0ef          	jal	ra,80000870 <uartstart>
  if(panicking == 0)
    80000a0e:	00007797          	auipc	a5,0x7
    80000a12:	f667a783          	lw	a5,-154(a5) # 80007974 <panicking>
    80000a16:	cf89                	beqz	a5,80000a30 <uartintr+0x52>
    release(&uart_tx_lock);
}
    80000a18:	60e2                	ld	ra,24(sp)
    80000a1a:	6442                	ld	s0,16(sp)
    80000a1c:	64a2                	ld	s1,8(sp)
    80000a1e:	6105                	addi	sp,sp,32
    80000a20:	8082                	ret
    acquire(&uart_tx_lock);
    80000a22:	0000f517          	auipc	a0,0xf
    80000a26:	04e50513          	addi	a0,a0,78 # 8000fa70 <uart_tx_lock>
    80000a2a:	1c4000ef          	jal	ra,80000bee <acquire>
    80000a2e:	bff1                	j	80000a0a <uartintr+0x2c>
    release(&uart_tx_lock);
    80000a30:	0000f517          	auipc	a0,0xf
    80000a34:	04050513          	addi	a0,a0,64 # 8000fa70 <uart_tx_lock>
    80000a38:	24e000ef          	jal	ra,80000c86 <release>
}
    80000a3c:	bff1                	j	80000a18 <uartintr+0x3a>

0000000080000a3e <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a3e:	1101                	addi	sp,sp,-32
    80000a40:	ec06                	sd	ra,24(sp)
    80000a42:	e822                	sd	s0,16(sp)
    80000a44:	e426                	sd	s1,8(sp)
    80000a46:	e04a                	sd	s2,0(sp)
    80000a48:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a4a:	03451793          	slli	a5,a0,0x34
    80000a4e:	e7a9                	bnez	a5,80000a98 <kfree+0x5a>
    80000a50:	84aa                	mv	s1,a0
    80000a52:	00025797          	auipc	a5,0x25
    80000a56:	08678793          	addi	a5,a5,134 # 80025ad8 <end>
    80000a5a:	02f56f63          	bltu	a0,a5,80000a98 <kfree+0x5a>
    80000a5e:	47c5                	li	a5,17
    80000a60:	07ee                	slli	a5,a5,0x1b
    80000a62:	02f57b63          	bgeu	a0,a5,80000a98 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a66:	6605                	lui	a2,0x1
    80000a68:	4585                	li	a1,1
    80000a6a:	258000ef          	jal	ra,80000cc2 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a6e:	0000f917          	auipc	s2,0xf
    80000a72:	03a90913          	addi	s2,s2,58 # 8000faa8 <kmem>
    80000a76:	854a                	mv	a0,s2
    80000a78:	176000ef          	jal	ra,80000bee <acquire>
  r->next = kmem.freelist;
    80000a7c:	01893783          	ld	a5,24(s2)
    80000a80:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a82:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a86:	854a                	mv	a0,s2
    80000a88:	1fe000ef          	jal	ra,80000c86 <release>
}
    80000a8c:	60e2                	ld	ra,24(sp)
    80000a8e:	6442                	ld	s0,16(sp)
    80000a90:	64a2                	ld	s1,8(sp)
    80000a92:	6902                	ld	s2,0(sp)
    80000a94:	6105                	addi	sp,sp,32
    80000a96:	8082                	ret
    panic("kfree");
    80000a98:	00006517          	auipc	a0,0x6
    80000a9c:	5c050513          	addi	a0,a0,1472 # 80007058 <digits+0x20>
    80000aa0:	cc9ff0ef          	jal	ra,80000768 <panic>

0000000080000aa4 <freerange>:
{
    80000aa4:	7179                	addi	sp,sp,-48
    80000aa6:	f406                	sd	ra,40(sp)
    80000aa8:	f022                	sd	s0,32(sp)
    80000aaa:	ec26                	sd	s1,24(sp)
    80000aac:	e84a                	sd	s2,16(sp)
    80000aae:	e44e                	sd	s3,8(sp)
    80000ab0:	e052                	sd	s4,0(sp)
    80000ab2:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000ab4:	6785                	lui	a5,0x1
    80000ab6:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000aba:	94aa                	add	s1,s1,a0
    80000abc:	757d                	lui	a0,0xfffff
    80000abe:	8ce9                	and	s1,s1,a0
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ac0:	94be                	add	s1,s1,a5
    80000ac2:	0095ec63          	bltu	a1,s1,80000ada <freerange+0x36>
    80000ac6:	892e                	mv	s2,a1
    kfree(p);
    80000ac8:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000aca:	6985                	lui	s3,0x1
    kfree(p);
    80000acc:	01448533          	add	a0,s1,s4
    80000ad0:	f6fff0ef          	jal	ra,80000a3e <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ad4:	94ce                	add	s1,s1,s3
    80000ad6:	fe997be3          	bgeu	s2,s1,80000acc <freerange+0x28>
}
    80000ada:	70a2                	ld	ra,40(sp)
    80000adc:	7402                	ld	s0,32(sp)
    80000ade:	64e2                	ld	s1,24(sp)
    80000ae0:	6942                	ld	s2,16(sp)
    80000ae2:	69a2                	ld	s3,8(sp)
    80000ae4:	6a02                	ld	s4,0(sp)
    80000ae6:	6145                	addi	sp,sp,48
    80000ae8:	8082                	ret

0000000080000aea <kinit>:
{
    80000aea:	1141                	addi	sp,sp,-16
    80000aec:	e406                	sd	ra,8(sp)
    80000aee:	e022                	sd	s0,0(sp)
    80000af0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000af2:	00006597          	auipc	a1,0x6
    80000af6:	56e58593          	addi	a1,a1,1390 # 80007060 <digits+0x28>
    80000afa:	0000f517          	auipc	a0,0xf
    80000afe:	fae50513          	addi	a0,a0,-82 # 8000faa8 <kmem>
    80000b02:	06c000ef          	jal	ra,80000b6e <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b06:	45c5                	li	a1,17
    80000b08:	05ee                	slli	a1,a1,0x1b
    80000b0a:	00025517          	auipc	a0,0x25
    80000b0e:	fce50513          	addi	a0,a0,-50 # 80025ad8 <end>
    80000b12:	f93ff0ef          	jal	ra,80000aa4 <freerange>
}
    80000b16:	60a2                	ld	ra,8(sp)
    80000b18:	6402                	ld	s0,0(sp)
    80000b1a:	0141                	addi	sp,sp,16
    80000b1c:	8082                	ret

0000000080000b1e <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b1e:	1101                	addi	sp,sp,-32
    80000b20:	ec06                	sd	ra,24(sp)
    80000b22:	e822                	sd	s0,16(sp)
    80000b24:	e426                	sd	s1,8(sp)
    80000b26:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b28:	0000f497          	auipc	s1,0xf
    80000b2c:	f8048493          	addi	s1,s1,-128 # 8000faa8 <kmem>
    80000b30:	8526                	mv	a0,s1
    80000b32:	0bc000ef          	jal	ra,80000bee <acquire>
  r = kmem.freelist;
    80000b36:	6c84                	ld	s1,24(s1)
  if(r)
    80000b38:	c485                	beqz	s1,80000b60 <kalloc+0x42>
    kmem.freelist = r->next;
    80000b3a:	609c                	ld	a5,0(s1)
    80000b3c:	0000f517          	auipc	a0,0xf
    80000b40:	f6c50513          	addi	a0,a0,-148 # 8000faa8 <kmem>
    80000b44:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b46:	140000ef          	jal	ra,80000c86 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b4a:	6605                	lui	a2,0x1
    80000b4c:	4595                	li	a1,5
    80000b4e:	8526                	mv	a0,s1
    80000b50:	172000ef          	jal	ra,80000cc2 <memset>
  return (void*)r;
}
    80000b54:	8526                	mv	a0,s1
    80000b56:	60e2                	ld	ra,24(sp)
    80000b58:	6442                	ld	s0,16(sp)
    80000b5a:	64a2                	ld	s1,8(sp)
    80000b5c:	6105                	addi	sp,sp,32
    80000b5e:	8082                	ret
  release(&kmem.lock);
    80000b60:	0000f517          	auipc	a0,0xf
    80000b64:	f4850513          	addi	a0,a0,-184 # 8000faa8 <kmem>
    80000b68:	11e000ef          	jal	ra,80000c86 <release>
  if(r)
    80000b6c:	b7e5                	j	80000b54 <kalloc+0x36>

0000000080000b6e <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b6e:	1141                	addi	sp,sp,-16
    80000b70:	e422                	sd	s0,8(sp)
    80000b72:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b74:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b76:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b7a:	00053823          	sd	zero,16(a0)
}
    80000b7e:	6422                	ld	s0,8(sp)
    80000b80:	0141                	addi	sp,sp,16
    80000b82:	8082                	ret

0000000080000b84 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b84:	411c                	lw	a5,0(a0)
    80000b86:	e399                	bnez	a5,80000b8c <holding+0x8>
    80000b88:	4501                	li	a0,0
  return r;
}
    80000b8a:	8082                	ret
{
    80000b8c:	1101                	addi	sp,sp,-32
    80000b8e:	ec06                	sd	ra,24(sp)
    80000b90:	e822                	sd	s0,16(sp)
    80000b92:	e426                	sd	s1,8(sp)
    80000b94:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b96:	6904                	ld	s1,16(a0)
    80000b98:	4d3000ef          	jal	ra,8000186a <mycpu>
    80000b9c:	40a48533          	sub	a0,s1,a0
    80000ba0:	00153513          	seqz	a0,a0
}
    80000ba4:	60e2                	ld	ra,24(sp)
    80000ba6:	6442                	ld	s0,16(sp)
    80000ba8:	64a2                	ld	s1,8(sp)
    80000baa:	6105                	addi	sp,sp,32
    80000bac:	8082                	ret

0000000080000bae <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bae:	1101                	addi	sp,sp,-32
    80000bb0:	ec06                	sd	ra,24(sp)
    80000bb2:	e822                	sd	s0,16(sp)
    80000bb4:	e426                	sd	s1,8(sp)
    80000bb6:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000bb8:	100024f3          	csrr	s1,sstatus
    80000bbc:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000bc0:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000bc2:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000bc6:	4a5000ef          	jal	ra,8000186a <mycpu>
    80000bca:	5d3c                	lw	a5,120(a0)
    80000bcc:	cb99                	beqz	a5,80000be2 <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bce:	49d000ef          	jal	ra,8000186a <mycpu>
    80000bd2:	5d3c                	lw	a5,120(a0)
    80000bd4:	2785                	addiw	a5,a5,1
    80000bd6:	dd3c                	sw	a5,120(a0)
}
    80000bd8:	60e2                	ld	ra,24(sp)
    80000bda:	6442                	ld	s0,16(sp)
    80000bdc:	64a2                	ld	s1,8(sp)
    80000bde:	6105                	addi	sp,sp,32
    80000be0:	8082                	ret
    mycpu()->intena = old;
    80000be2:	489000ef          	jal	ra,8000186a <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000be6:	8085                	srli	s1,s1,0x1
    80000be8:	8885                	andi	s1,s1,1
    80000bea:	dd64                	sw	s1,124(a0)
    80000bec:	b7cd                	j	80000bce <push_off+0x20>

0000000080000bee <acquire>:
{
    80000bee:	1101                	addi	sp,sp,-32
    80000bf0:	ec06                	sd	ra,24(sp)
    80000bf2:	e822                	sd	s0,16(sp)
    80000bf4:	e426                	sd	s1,8(sp)
    80000bf6:	1000                	addi	s0,sp,32
    80000bf8:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000bfa:	fb5ff0ef          	jal	ra,80000bae <push_off>
  if(holding(lk))
    80000bfe:	8526                	mv	a0,s1
    80000c00:	f85ff0ef          	jal	ra,80000b84 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c04:	4705                	li	a4,1
  if(holding(lk))
    80000c06:	e105                	bnez	a0,80000c26 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c08:	87ba                	mv	a5,a4
    80000c0a:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c0e:	2781                	sext.w	a5,a5
    80000c10:	ffe5                	bnez	a5,80000c08 <acquire+0x1a>
  __sync_synchronize();
    80000c12:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000c16:	455000ef          	jal	ra,8000186a <mycpu>
    80000c1a:	e888                	sd	a0,16(s1)
}
    80000c1c:	60e2                	ld	ra,24(sp)
    80000c1e:	6442                	ld	s0,16(sp)
    80000c20:	64a2                	ld	s1,8(sp)
    80000c22:	6105                	addi	sp,sp,32
    80000c24:	8082                	ret
    panic("acquire");
    80000c26:	00006517          	auipc	a0,0x6
    80000c2a:	44250513          	addi	a0,a0,1090 # 80007068 <digits+0x30>
    80000c2e:	b3bff0ef          	jal	ra,80000768 <panic>

0000000080000c32 <pop_off>:

void
pop_off(void)
{
    80000c32:	1141                	addi	sp,sp,-16
    80000c34:	e406                	sd	ra,8(sp)
    80000c36:	e022                	sd	s0,0(sp)
    80000c38:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c3a:	431000ef          	jal	ra,8000186a <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c3e:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c42:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c44:	e78d                	bnez	a5,80000c6e <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c46:	5d3c                	lw	a5,120(a0)
    80000c48:	02f05963          	blez	a5,80000c7a <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000c4c:	37fd                	addiw	a5,a5,-1
    80000c4e:	0007871b          	sext.w	a4,a5
    80000c52:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c54:	eb09                	bnez	a4,80000c66 <pop_off+0x34>
    80000c56:	5d7c                	lw	a5,124(a0)
    80000c58:	c799                	beqz	a5,80000c66 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c5a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c5e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c62:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c66:	60a2                	ld	ra,8(sp)
    80000c68:	6402                	ld	s0,0(sp)
    80000c6a:	0141                	addi	sp,sp,16
    80000c6c:	8082                	ret
    panic("pop_off - interruptible");
    80000c6e:	00006517          	auipc	a0,0x6
    80000c72:	40250513          	addi	a0,a0,1026 # 80007070 <digits+0x38>
    80000c76:	af3ff0ef          	jal	ra,80000768 <panic>
    panic("pop_off");
    80000c7a:	00006517          	auipc	a0,0x6
    80000c7e:	40e50513          	addi	a0,a0,1038 # 80007088 <digits+0x50>
    80000c82:	ae7ff0ef          	jal	ra,80000768 <panic>

0000000080000c86 <release>:
{
    80000c86:	1101                	addi	sp,sp,-32
    80000c88:	ec06                	sd	ra,24(sp)
    80000c8a:	e822                	sd	s0,16(sp)
    80000c8c:	e426                	sd	s1,8(sp)
    80000c8e:	1000                	addi	s0,sp,32
    80000c90:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c92:	ef3ff0ef          	jal	ra,80000b84 <holding>
    80000c96:	c105                	beqz	a0,80000cb6 <release+0x30>
  lk->cpu = 0;
    80000c98:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000c9c:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000ca0:	0f50000f          	fence	iorw,ow
    80000ca4:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000ca8:	f8bff0ef          	jal	ra,80000c32 <pop_off>
}
    80000cac:	60e2                	ld	ra,24(sp)
    80000cae:	6442                	ld	s0,16(sp)
    80000cb0:	64a2                	ld	s1,8(sp)
    80000cb2:	6105                	addi	sp,sp,32
    80000cb4:	8082                	ret
    panic("release");
    80000cb6:	00006517          	auipc	a0,0x6
    80000cba:	3da50513          	addi	a0,a0,986 # 80007090 <digits+0x58>
    80000cbe:	aabff0ef          	jal	ra,80000768 <panic>

0000000080000cc2 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cc2:	1141                	addi	sp,sp,-16
    80000cc4:	e422                	sd	s0,8(sp)
    80000cc6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000cc8:	ca19                	beqz	a2,80000cde <memset+0x1c>
    80000cca:	87aa                	mv	a5,a0
    80000ccc:	1602                	slli	a2,a2,0x20
    80000cce:	9201                	srli	a2,a2,0x20
    80000cd0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cd4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000cd8:	0785                	addi	a5,a5,1
    80000cda:	fee79de3          	bne	a5,a4,80000cd4 <memset+0x12>
  }
  return dst;
}
    80000cde:	6422                	ld	s0,8(sp)
    80000ce0:	0141                	addi	sp,sp,16
    80000ce2:	8082                	ret

0000000080000ce4 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000ce4:	1141                	addi	sp,sp,-16
    80000ce6:	e422                	sd	s0,8(sp)
    80000ce8:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cea:	ca05                	beqz	a2,80000d1a <memcmp+0x36>
    80000cec:	fff6069b          	addiw	a3,a2,-1
    80000cf0:	1682                	slli	a3,a3,0x20
    80000cf2:	9281                	srli	a3,a3,0x20
    80000cf4:	0685                	addi	a3,a3,1
    80000cf6:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000cf8:	00054783          	lbu	a5,0(a0)
    80000cfc:	0005c703          	lbu	a4,0(a1)
    80000d00:	00e79863          	bne	a5,a4,80000d10 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d04:	0505                	addi	a0,a0,1
    80000d06:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d08:	fed518e3          	bne	a0,a3,80000cf8 <memcmp+0x14>
  }

  return 0;
    80000d0c:	4501                	li	a0,0
    80000d0e:	a019                	j	80000d14 <memcmp+0x30>
      return *s1 - *s2;
    80000d10:	40e7853b          	subw	a0,a5,a4
}
    80000d14:	6422                	ld	s0,8(sp)
    80000d16:	0141                	addi	sp,sp,16
    80000d18:	8082                	ret
  return 0;
    80000d1a:	4501                	li	a0,0
    80000d1c:	bfe5                	j	80000d14 <memcmp+0x30>

0000000080000d1e <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d1e:	1141                	addi	sp,sp,-16
    80000d20:	e422                	sd	s0,8(sp)
    80000d22:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d24:	c205                	beqz	a2,80000d44 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d26:	02a5e263          	bltu	a1,a0,80000d4a <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d2a:	1602                	slli	a2,a2,0x20
    80000d2c:	9201                	srli	a2,a2,0x20
    80000d2e:	00c587b3          	add	a5,a1,a2
{
    80000d32:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d34:	0585                	addi	a1,a1,1
    80000d36:	0705                	addi	a4,a4,1
    80000d38:	fff5c683          	lbu	a3,-1(a1)
    80000d3c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d40:	fef59ae3          	bne	a1,a5,80000d34 <memmove+0x16>

  return dst;
}
    80000d44:	6422                	ld	s0,8(sp)
    80000d46:	0141                	addi	sp,sp,16
    80000d48:	8082                	ret
  if(s < d && s + n > d){
    80000d4a:	02061693          	slli	a3,a2,0x20
    80000d4e:	9281                	srli	a3,a3,0x20
    80000d50:	00d58733          	add	a4,a1,a3
    80000d54:	fce57be3          	bgeu	a0,a4,80000d2a <memmove+0xc>
    d += n;
    80000d58:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d5a:	fff6079b          	addiw	a5,a2,-1
    80000d5e:	1782                	slli	a5,a5,0x20
    80000d60:	9381                	srli	a5,a5,0x20
    80000d62:	fff7c793          	not	a5,a5
    80000d66:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d68:	177d                	addi	a4,a4,-1
    80000d6a:	16fd                	addi	a3,a3,-1
    80000d6c:	00074603          	lbu	a2,0(a4)
    80000d70:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d74:	fee79ae3          	bne	a5,a4,80000d68 <memmove+0x4a>
    80000d78:	b7f1                	j	80000d44 <memmove+0x26>

0000000080000d7a <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d7a:	1141                	addi	sp,sp,-16
    80000d7c:	e406                	sd	ra,8(sp)
    80000d7e:	e022                	sd	s0,0(sp)
    80000d80:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d82:	f9dff0ef          	jal	ra,80000d1e <memmove>
}
    80000d86:	60a2                	ld	ra,8(sp)
    80000d88:	6402                	ld	s0,0(sp)
    80000d8a:	0141                	addi	sp,sp,16
    80000d8c:	8082                	ret

0000000080000d8e <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d8e:	1141                	addi	sp,sp,-16
    80000d90:	e422                	sd	s0,8(sp)
    80000d92:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000d94:	ce11                	beqz	a2,80000db0 <strncmp+0x22>
    80000d96:	00054783          	lbu	a5,0(a0)
    80000d9a:	cf89                	beqz	a5,80000db4 <strncmp+0x26>
    80000d9c:	0005c703          	lbu	a4,0(a1)
    80000da0:	00f71a63          	bne	a4,a5,80000db4 <strncmp+0x26>
    n--, p++, q++;
    80000da4:	367d                	addiw	a2,a2,-1
    80000da6:	0505                	addi	a0,a0,1
    80000da8:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000daa:	f675                	bnez	a2,80000d96 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000dac:	4501                	li	a0,0
    80000dae:	a809                	j	80000dc0 <strncmp+0x32>
    80000db0:	4501                	li	a0,0
    80000db2:	a039                	j	80000dc0 <strncmp+0x32>
  if(n == 0)
    80000db4:	ca09                	beqz	a2,80000dc6 <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000db6:	00054503          	lbu	a0,0(a0)
    80000dba:	0005c783          	lbu	a5,0(a1)
    80000dbe:	9d1d                	subw	a0,a0,a5
}
    80000dc0:	6422                	ld	s0,8(sp)
    80000dc2:	0141                	addi	sp,sp,16
    80000dc4:	8082                	ret
    return 0;
    80000dc6:	4501                	li	a0,0
    80000dc8:	bfe5                	j	80000dc0 <strncmp+0x32>

0000000080000dca <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000dca:	1141                	addi	sp,sp,-16
    80000dcc:	e422                	sd	s0,8(sp)
    80000dce:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000dd0:	872a                	mv	a4,a0
    80000dd2:	8832                	mv	a6,a2
    80000dd4:	367d                	addiw	a2,a2,-1
    80000dd6:	01005963          	blez	a6,80000de8 <strncpy+0x1e>
    80000dda:	0705                	addi	a4,a4,1
    80000ddc:	0005c783          	lbu	a5,0(a1)
    80000de0:	fef70fa3          	sb	a5,-1(a4)
    80000de4:	0585                	addi	a1,a1,1
    80000de6:	f7f5                	bnez	a5,80000dd2 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000de8:	86ba                	mv	a3,a4
    80000dea:	00c05c63          	blez	a2,80000e02 <strncpy+0x38>
    *s++ = 0;
    80000dee:	0685                	addi	a3,a3,1
    80000df0:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000df4:	fff6c793          	not	a5,a3
    80000df8:	9fb9                	addw	a5,a5,a4
    80000dfa:	010787bb          	addw	a5,a5,a6
    80000dfe:	fef048e3          	bgtz	a5,80000dee <strncpy+0x24>
  return os;
}
    80000e02:	6422                	ld	s0,8(sp)
    80000e04:	0141                	addi	sp,sp,16
    80000e06:	8082                	ret

0000000080000e08 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e08:	1141                	addi	sp,sp,-16
    80000e0a:	e422                	sd	s0,8(sp)
    80000e0c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e0e:	02c05363          	blez	a2,80000e34 <safestrcpy+0x2c>
    80000e12:	fff6069b          	addiw	a3,a2,-1
    80000e16:	1682                	slli	a3,a3,0x20
    80000e18:	9281                	srli	a3,a3,0x20
    80000e1a:	96ae                	add	a3,a3,a1
    80000e1c:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e1e:	00d58963          	beq	a1,a3,80000e30 <safestrcpy+0x28>
    80000e22:	0585                	addi	a1,a1,1
    80000e24:	0785                	addi	a5,a5,1
    80000e26:	fff5c703          	lbu	a4,-1(a1)
    80000e2a:	fee78fa3          	sb	a4,-1(a5)
    80000e2e:	fb65                	bnez	a4,80000e1e <safestrcpy+0x16>
    ;
  *s = 0;
    80000e30:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e34:	6422                	ld	s0,8(sp)
    80000e36:	0141                	addi	sp,sp,16
    80000e38:	8082                	ret

0000000080000e3a <strlen>:

int
strlen(const char *s)
{
    80000e3a:	1141                	addi	sp,sp,-16
    80000e3c:	e422                	sd	s0,8(sp)
    80000e3e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e40:	00054783          	lbu	a5,0(a0)
    80000e44:	cf91                	beqz	a5,80000e60 <strlen+0x26>
    80000e46:	0505                	addi	a0,a0,1
    80000e48:	87aa                	mv	a5,a0
    80000e4a:	4685                	li	a3,1
    80000e4c:	9e89                	subw	a3,a3,a0
    80000e4e:	00f6853b          	addw	a0,a3,a5
    80000e52:	0785                	addi	a5,a5,1
    80000e54:	fff7c703          	lbu	a4,-1(a5)
    80000e58:	fb7d                	bnez	a4,80000e4e <strlen+0x14>
    ;
  return n;
}
    80000e5a:	6422                	ld	s0,8(sp)
    80000e5c:	0141                	addi	sp,sp,16
    80000e5e:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e60:	4501                	li	a0,0
    80000e62:	bfe5                	j	80000e5a <strlen+0x20>

0000000080000e64 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e64:	1141                	addi	sp,sp,-16
    80000e66:	e406                	sd	ra,8(sp)
    80000e68:	e022                	sd	s0,0(sp)
    80000e6a:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e6c:	1ef000ef          	jal	ra,8000185a <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e70:	00007717          	auipc	a4,0x7
    80000e74:	b1870713          	addi	a4,a4,-1256 # 80007988 <started>
  if(cpuid() == 0){
    80000e78:	c51d                	beqz	a0,80000ea6 <main+0x42>
    while(started == 0)
    80000e7a:	431c                	lw	a5,0(a4)
    80000e7c:	2781                	sext.w	a5,a5
    80000e7e:	dff5                	beqz	a5,80000e7a <main+0x16>
      ;
    __sync_synchronize();
    80000e80:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e84:	1d7000ef          	jal	ra,8000185a <cpuid>
    80000e88:	85aa                	mv	a1,a0
    80000e8a:	00006517          	auipc	a0,0x6
    80000e8e:	22650513          	addi	a0,a0,550 # 800070b0 <digits+0x78>
    80000e92:	e10ff0ef          	jal	ra,800004a2 <printf>
    kvminithart();    // turn on paging
    80000e96:	080000ef          	jal	ra,80000f16 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000e9a:	52a010ef          	jal	ra,800023c4 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000e9e:	456040ef          	jal	ra,800052f4 <plicinithart>
  }

  scheduler();        
    80000ea2:	669000ef          	jal	ra,80001d0a <scheduler>
    consoleinit();
    80000ea6:	d24ff0ef          	jal	ra,800003ca <consoleinit>
    printfinit();
    80000eaa:	8fbff0ef          	jal	ra,800007a4 <printfinit>
    printf("\n");
    80000eae:	00006517          	auipc	a0,0x6
    80000eb2:	21250513          	addi	a0,a0,530 # 800070c0 <digits+0x88>
    80000eb6:	decff0ef          	jal	ra,800004a2 <printf>
    printf("xv6 kernel is booting\n");
    80000eba:	00006517          	auipc	a0,0x6
    80000ebe:	1de50513          	addi	a0,a0,478 # 80007098 <digits+0x60>
    80000ec2:	de0ff0ef          	jal	ra,800004a2 <printf>
    printf("\n");
    80000ec6:	00006517          	auipc	a0,0x6
    80000eca:	1fa50513          	addi	a0,a0,506 # 800070c0 <digits+0x88>
    80000ece:	dd4ff0ef          	jal	ra,800004a2 <printf>
    kinit();         // physical page allocator
    80000ed2:	c19ff0ef          	jal	ra,80000aea <kinit>
    kvminit();       // create kernel page table
    80000ed6:	2ca000ef          	jal	ra,800011a0 <kvminit>
    kvminithart();   // turn on paging
    80000eda:	03c000ef          	jal	ra,80000f16 <kvminithart>
    procinit();      // process table
    80000ede:	0d5000ef          	jal	ra,800017b2 <procinit>
    trapinit();      // trap vectors
    80000ee2:	4be010ef          	jal	ra,800023a0 <trapinit>
    trapinithart();  // install kernel trap vector
    80000ee6:	4de010ef          	jal	ra,800023c4 <trapinithart>
    plicinit();      // set up interrupt controller
    80000eea:	3f4040ef          	jal	ra,800052de <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000eee:	406040ef          	jal	ra,800052f4 <plicinithart>
    binit();         // buffer cache
    80000ef2:	487010ef          	jal	ra,80002b78 <binit>
    iinit();         // inode table
    80000ef6:	268020ef          	jal	ra,8000315e <iinit>
    fileinit();      // file table
    80000efa:	006030ef          	jal	ra,80003f00 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000efe:	4e6040ef          	jal	ra,800053e4 <virtio_disk_init>
    userinit();      // first user process
    80000f02:	481000ef          	jal	ra,80001b82 <userinit>
    __sync_synchronize();
    80000f06:	0ff0000f          	fence
    started = 1;
    80000f0a:	4785                	li	a5,1
    80000f0c:	00007717          	auipc	a4,0x7
    80000f10:	a6f72e23          	sw	a5,-1412(a4) # 80007988 <started>
    80000f14:	b779                	j	80000ea2 <main+0x3e>

0000000080000f16 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000f16:	1141                	addi	sp,sp,-16
    80000f18:	e422                	sd	s0,8(sp)
    80000f1a:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f1c:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f20:	00007797          	auipc	a5,0x7
    80000f24:	a707b783          	ld	a5,-1424(a5) # 80007990 <kernel_pagetable>
    80000f28:	83b1                	srli	a5,a5,0xc
    80000f2a:	577d                	li	a4,-1
    80000f2c:	177e                	slli	a4,a4,0x3f
    80000f2e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f30:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f34:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f38:	6422                	ld	s0,8(sp)
    80000f3a:	0141                	addi	sp,sp,16
    80000f3c:	8082                	ret

0000000080000f3e <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f3e:	7139                	addi	sp,sp,-64
    80000f40:	fc06                	sd	ra,56(sp)
    80000f42:	f822                	sd	s0,48(sp)
    80000f44:	f426                	sd	s1,40(sp)
    80000f46:	f04a                	sd	s2,32(sp)
    80000f48:	ec4e                	sd	s3,24(sp)
    80000f4a:	e852                	sd	s4,16(sp)
    80000f4c:	e456                	sd	s5,8(sp)
    80000f4e:	e05a                	sd	s6,0(sp)
    80000f50:	0080                	addi	s0,sp,64
    80000f52:	84aa                	mv	s1,a0
    80000f54:	89ae                	mv	s3,a1
    80000f56:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000f58:	57fd                	li	a5,-1
    80000f5a:	83e9                	srli	a5,a5,0x1a
    80000f5c:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000f5e:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000f60:	02b7fc63          	bgeu	a5,a1,80000f98 <walk+0x5a>
    panic("walk");
    80000f64:	00006517          	auipc	a0,0x6
    80000f68:	16450513          	addi	a0,a0,356 # 800070c8 <digits+0x90>
    80000f6c:	ffcff0ef          	jal	ra,80000768 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000f70:	060a8263          	beqz	s5,80000fd4 <walk+0x96>
    80000f74:	babff0ef          	jal	ra,80000b1e <kalloc>
    80000f78:	84aa                	mv	s1,a0
    80000f7a:	c139                	beqz	a0,80000fc0 <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f7c:	6605                	lui	a2,0x1
    80000f7e:	4581                	li	a1,0
    80000f80:	d43ff0ef          	jal	ra,80000cc2 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f84:	00c4d793          	srli	a5,s1,0xc
    80000f88:	07aa                	slli	a5,a5,0xa
    80000f8a:	0017e793          	ori	a5,a5,1
    80000f8e:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000f92:	3a5d                	addiw	s4,s4,-9
    80000f94:	036a0063          	beq	s4,s6,80000fb4 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f98:	0149d933          	srl	s2,s3,s4
    80000f9c:	1ff97913          	andi	s2,s2,511
    80000fa0:	090e                	slli	s2,s2,0x3
    80000fa2:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fa4:	00093483          	ld	s1,0(s2)
    80000fa8:	0014f793          	andi	a5,s1,1
    80000fac:	d3f1                	beqz	a5,80000f70 <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fae:	80a9                	srli	s1,s1,0xa
    80000fb0:	04b2                	slli	s1,s1,0xc
    80000fb2:	b7c5                	j	80000f92 <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000fb4:	00c9d513          	srli	a0,s3,0xc
    80000fb8:	1ff57513          	andi	a0,a0,511
    80000fbc:	050e                	slli	a0,a0,0x3
    80000fbe:	9526                	add	a0,a0,s1
}
    80000fc0:	70e2                	ld	ra,56(sp)
    80000fc2:	7442                	ld	s0,48(sp)
    80000fc4:	74a2                	ld	s1,40(sp)
    80000fc6:	7902                	ld	s2,32(sp)
    80000fc8:	69e2                	ld	s3,24(sp)
    80000fca:	6a42                	ld	s4,16(sp)
    80000fcc:	6aa2                	ld	s5,8(sp)
    80000fce:	6b02                	ld	s6,0(sp)
    80000fd0:	6121                	addi	sp,sp,64
    80000fd2:	8082                	ret
        return 0;
    80000fd4:	4501                	li	a0,0
    80000fd6:	b7ed                	j	80000fc0 <walk+0x82>

0000000080000fd8 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000fd8:	57fd                	li	a5,-1
    80000fda:	83e9                	srli	a5,a5,0x1a
    80000fdc:	00b7f463          	bgeu	a5,a1,80000fe4 <walkaddr+0xc>
    return 0;
    80000fe0:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fe2:	8082                	ret
{
    80000fe4:	1141                	addi	sp,sp,-16
    80000fe6:	e406                	sd	ra,8(sp)
    80000fe8:	e022                	sd	s0,0(sp)
    80000fea:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fec:	4601                	li	a2,0
    80000fee:	f51ff0ef          	jal	ra,80000f3e <walk>
  if(pte == 0)
    80000ff2:	c105                	beqz	a0,80001012 <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000ff4:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000ff6:	0117f693          	andi	a3,a5,17
    80000ffa:	4745                	li	a4,17
    return 0;
    80000ffc:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000ffe:	00e68663          	beq	a3,a4,8000100a <walkaddr+0x32>
}
    80001002:	60a2                	ld	ra,8(sp)
    80001004:	6402                	ld	s0,0(sp)
    80001006:	0141                	addi	sp,sp,16
    80001008:	8082                	ret
  pa = PTE2PA(*pte);
    8000100a:	00a7d513          	srli	a0,a5,0xa
    8000100e:	0532                	slli	a0,a0,0xc
  return pa;
    80001010:	bfcd                	j	80001002 <walkaddr+0x2a>
    return 0;
    80001012:	4501                	li	a0,0
    80001014:	b7fd                	j	80001002 <walkaddr+0x2a>

0000000080001016 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001016:	715d                	addi	sp,sp,-80
    80001018:	e486                	sd	ra,72(sp)
    8000101a:	e0a2                	sd	s0,64(sp)
    8000101c:	fc26                	sd	s1,56(sp)
    8000101e:	f84a                	sd	s2,48(sp)
    80001020:	f44e                	sd	s3,40(sp)
    80001022:	f052                	sd	s4,32(sp)
    80001024:	ec56                	sd	s5,24(sp)
    80001026:	e85a                	sd	s6,16(sp)
    80001028:	e45e                	sd	s7,8(sp)
    8000102a:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000102c:	03459793          	slli	a5,a1,0x34
    80001030:	e7a9                	bnez	a5,8000107a <mappages+0x64>
    80001032:	8aaa                	mv	s5,a0
    80001034:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    80001036:	03461793          	slli	a5,a2,0x34
    8000103a:	e7b1                	bnez	a5,80001086 <mappages+0x70>
    panic("mappages: size not aligned");

  if(size == 0)
    8000103c:	ca39                	beqz	a2,80001092 <mappages+0x7c>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    8000103e:	79fd                	lui	s3,0xfffff
    80001040:	964e                	add	a2,a2,s3
    80001042:	00b609b3          	add	s3,a2,a1
  a = va;
    80001046:	892e                	mv	s2,a1
    80001048:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    8000104c:	6b85                	lui	s7,0x1
    8000104e:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    80001052:	4605                	li	a2,1
    80001054:	85ca                	mv	a1,s2
    80001056:	8556                	mv	a0,s5
    80001058:	ee7ff0ef          	jal	ra,80000f3e <walk>
    8000105c:	c539                	beqz	a0,800010aa <mappages+0x94>
    if(*pte & PTE_V)
    8000105e:	611c                	ld	a5,0(a0)
    80001060:	8b85                	andi	a5,a5,1
    80001062:	ef95                	bnez	a5,8000109e <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001064:	80b1                	srli	s1,s1,0xc
    80001066:	04aa                	slli	s1,s1,0xa
    80001068:	0164e4b3          	or	s1,s1,s6
    8000106c:	0014e493          	ori	s1,s1,1
    80001070:	e104                	sd	s1,0(a0)
    if(a == last)
    80001072:	05390863          	beq	s2,s3,800010c2 <mappages+0xac>
    a += PGSIZE;
    80001076:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001078:	bfd9                	j	8000104e <mappages+0x38>
    panic("mappages: va not aligned");
    8000107a:	00006517          	auipc	a0,0x6
    8000107e:	05650513          	addi	a0,a0,86 # 800070d0 <digits+0x98>
    80001082:	ee6ff0ef          	jal	ra,80000768 <panic>
    panic("mappages: size not aligned");
    80001086:	00006517          	auipc	a0,0x6
    8000108a:	06a50513          	addi	a0,a0,106 # 800070f0 <digits+0xb8>
    8000108e:	edaff0ef          	jal	ra,80000768 <panic>
    panic("mappages: size");
    80001092:	00006517          	auipc	a0,0x6
    80001096:	07e50513          	addi	a0,a0,126 # 80007110 <digits+0xd8>
    8000109a:	eceff0ef          	jal	ra,80000768 <panic>
      panic("mappages: remap");
    8000109e:	00006517          	auipc	a0,0x6
    800010a2:	08250513          	addi	a0,a0,130 # 80007120 <digits+0xe8>
    800010a6:	ec2ff0ef          	jal	ra,80000768 <panic>
      return -1;
    800010aa:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010ac:	60a6                	ld	ra,72(sp)
    800010ae:	6406                	ld	s0,64(sp)
    800010b0:	74e2                	ld	s1,56(sp)
    800010b2:	7942                	ld	s2,48(sp)
    800010b4:	79a2                	ld	s3,40(sp)
    800010b6:	7a02                	ld	s4,32(sp)
    800010b8:	6ae2                	ld	s5,24(sp)
    800010ba:	6b42                	ld	s6,16(sp)
    800010bc:	6ba2                	ld	s7,8(sp)
    800010be:	6161                	addi	sp,sp,80
    800010c0:	8082                	ret
  return 0;
    800010c2:	4501                	li	a0,0
    800010c4:	b7e5                	j	800010ac <mappages+0x96>

00000000800010c6 <kvmmap>:
{
    800010c6:	1141                	addi	sp,sp,-16
    800010c8:	e406                	sd	ra,8(sp)
    800010ca:	e022                	sd	s0,0(sp)
    800010cc:	0800                	addi	s0,sp,16
    800010ce:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010d0:	86b2                	mv	a3,a2
    800010d2:	863e                	mv	a2,a5
    800010d4:	f43ff0ef          	jal	ra,80001016 <mappages>
    800010d8:	e509                	bnez	a0,800010e2 <kvmmap+0x1c>
}
    800010da:	60a2                	ld	ra,8(sp)
    800010dc:	6402                	ld	s0,0(sp)
    800010de:	0141                	addi	sp,sp,16
    800010e0:	8082                	ret
    panic("kvmmap");
    800010e2:	00006517          	auipc	a0,0x6
    800010e6:	04e50513          	addi	a0,a0,78 # 80007130 <digits+0xf8>
    800010ea:	e7eff0ef          	jal	ra,80000768 <panic>

00000000800010ee <kvmmake>:
{
    800010ee:	1101                	addi	sp,sp,-32
    800010f0:	ec06                	sd	ra,24(sp)
    800010f2:	e822                	sd	s0,16(sp)
    800010f4:	e426                	sd	s1,8(sp)
    800010f6:	e04a                	sd	s2,0(sp)
    800010f8:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800010fa:	a25ff0ef          	jal	ra,80000b1e <kalloc>
    800010fe:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001100:	6605                	lui	a2,0x1
    80001102:	4581                	li	a1,0
    80001104:	bbfff0ef          	jal	ra,80000cc2 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001108:	4719                	li	a4,6
    8000110a:	6685                	lui	a3,0x1
    8000110c:	10000637          	lui	a2,0x10000
    80001110:	100005b7          	lui	a1,0x10000
    80001114:	8526                	mv	a0,s1
    80001116:	fb1ff0ef          	jal	ra,800010c6 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000111a:	4719                	li	a4,6
    8000111c:	6685                	lui	a3,0x1
    8000111e:	10001637          	lui	a2,0x10001
    80001122:	100015b7          	lui	a1,0x10001
    80001126:	8526                	mv	a0,s1
    80001128:	f9fff0ef          	jal	ra,800010c6 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000112c:	4719                	li	a4,6
    8000112e:	040006b7          	lui	a3,0x4000
    80001132:	0c000637          	lui	a2,0xc000
    80001136:	0c0005b7          	lui	a1,0xc000
    8000113a:	8526                	mv	a0,s1
    8000113c:	f8bff0ef          	jal	ra,800010c6 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001140:	00006917          	auipc	s2,0x6
    80001144:	ec090913          	addi	s2,s2,-320 # 80007000 <etext>
    80001148:	4729                	li	a4,10
    8000114a:	80006697          	auipc	a3,0x80006
    8000114e:	eb668693          	addi	a3,a3,-330 # 7000 <_entry-0x7fff9000>
    80001152:	4605                	li	a2,1
    80001154:	067e                	slli	a2,a2,0x1f
    80001156:	85b2                	mv	a1,a2
    80001158:	8526                	mv	a0,s1
    8000115a:	f6dff0ef          	jal	ra,800010c6 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    8000115e:	4719                	li	a4,6
    80001160:	46c5                	li	a3,17
    80001162:	06ee                	slli	a3,a3,0x1b
    80001164:	412686b3          	sub	a3,a3,s2
    80001168:	864a                	mv	a2,s2
    8000116a:	85ca                	mv	a1,s2
    8000116c:	8526                	mv	a0,s1
    8000116e:	f59ff0ef          	jal	ra,800010c6 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001172:	4729                	li	a4,10
    80001174:	6685                	lui	a3,0x1
    80001176:	00005617          	auipc	a2,0x5
    8000117a:	e8a60613          	addi	a2,a2,-374 # 80006000 <_trampoline>
    8000117e:	040005b7          	lui	a1,0x4000
    80001182:	15fd                	addi	a1,a1,-1
    80001184:	05b2                	slli	a1,a1,0xc
    80001186:	8526                	mv	a0,s1
    80001188:	f3fff0ef          	jal	ra,800010c6 <kvmmap>
  proc_mapstacks(kpgtbl);
    8000118c:	8526                	mv	a0,s1
    8000118e:	59a000ef          	jal	ra,80001728 <proc_mapstacks>
}
    80001192:	8526                	mv	a0,s1
    80001194:	60e2                	ld	ra,24(sp)
    80001196:	6442                	ld	s0,16(sp)
    80001198:	64a2                	ld	s1,8(sp)
    8000119a:	6902                	ld	s2,0(sp)
    8000119c:	6105                	addi	sp,sp,32
    8000119e:	8082                	ret

00000000800011a0 <kvminit>:
{
    800011a0:	1141                	addi	sp,sp,-16
    800011a2:	e406                	sd	ra,8(sp)
    800011a4:	e022                	sd	s0,0(sp)
    800011a6:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011a8:	f47ff0ef          	jal	ra,800010ee <kvmmake>
    800011ac:	00006797          	auipc	a5,0x6
    800011b0:	7ea7b223          	sd	a0,2020(a5) # 80007990 <kernel_pagetable>
}
    800011b4:	60a2                	ld	ra,8(sp)
    800011b6:	6402                	ld	s0,0(sp)
    800011b8:	0141                	addi	sp,sp,16
    800011ba:	8082                	ret

00000000800011bc <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011bc:	7139                	addi	sp,sp,-64
    800011be:	fc06                	sd	ra,56(sp)
    800011c0:	f822                	sd	s0,48(sp)
    800011c2:	f426                	sd	s1,40(sp)
    800011c4:	f04a                	sd	s2,32(sp)
    800011c6:	ec4e                	sd	s3,24(sp)
    800011c8:	e852                	sd	s4,16(sp)
    800011ca:	e456                	sd	s5,8(sp)
    800011cc:	e05a                	sd	s6,0(sp)
    800011ce:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800011d0:	03459793          	slli	a5,a1,0x34
    800011d4:	e785                	bnez	a5,800011fc <uvmunmap+0x40>
    800011d6:	8a2a                	mv	s4,a0
    800011d8:	892e                	mv	s2,a1
    800011da:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800011dc:	0632                	slli	a2,a2,0xc
    800011de:	00b609b3          	add	s3,a2,a1
    800011e2:	6b05                	lui	s6,0x1
    800011e4:	0335e763          	bltu	a1,s3,80001212 <uvmunmap+0x56>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    800011e8:	70e2                	ld	ra,56(sp)
    800011ea:	7442                	ld	s0,48(sp)
    800011ec:	74a2                	ld	s1,40(sp)
    800011ee:	7902                	ld	s2,32(sp)
    800011f0:	69e2                	ld	s3,24(sp)
    800011f2:	6a42                	ld	s4,16(sp)
    800011f4:	6aa2                	ld	s5,8(sp)
    800011f6:	6b02                	ld	s6,0(sp)
    800011f8:	6121                	addi	sp,sp,64
    800011fa:	8082                	ret
    panic("uvmunmap: not aligned");
    800011fc:	00006517          	auipc	a0,0x6
    80001200:	f3c50513          	addi	a0,a0,-196 # 80007138 <digits+0x100>
    80001204:	d64ff0ef          	jal	ra,80000768 <panic>
    *pte = 0;
    80001208:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000120c:	995a                	add	s2,s2,s6
    8000120e:	fd397de3          	bgeu	s2,s3,800011e8 <uvmunmap+0x2c>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    80001212:	4601                	li	a2,0
    80001214:	85ca                	mv	a1,s2
    80001216:	8552                	mv	a0,s4
    80001218:	d27ff0ef          	jal	ra,80000f3e <walk>
    8000121c:	84aa                	mv	s1,a0
    8000121e:	d57d                	beqz	a0,8000120c <uvmunmap+0x50>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    80001220:	611c                	ld	a5,0(a0)
    80001222:	0017f713          	andi	a4,a5,1
    80001226:	d37d                	beqz	a4,8000120c <uvmunmap+0x50>
    if(do_free){
    80001228:	fe0a80e3          	beqz	s5,80001208 <uvmunmap+0x4c>
      uint64 pa = PTE2PA(*pte);
    8000122c:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    8000122e:	00c79513          	slli	a0,a5,0xc
    80001232:	80dff0ef          	jal	ra,80000a3e <kfree>
    80001236:	bfc9                	j	80001208 <uvmunmap+0x4c>

0000000080001238 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001238:	1101                	addi	sp,sp,-32
    8000123a:	ec06                	sd	ra,24(sp)
    8000123c:	e822                	sd	s0,16(sp)
    8000123e:	e426                	sd	s1,8(sp)
    80001240:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001242:	8ddff0ef          	jal	ra,80000b1e <kalloc>
    80001246:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001248:	c509                	beqz	a0,80001252 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000124a:	6605                	lui	a2,0x1
    8000124c:	4581                	li	a1,0
    8000124e:	a75ff0ef          	jal	ra,80000cc2 <memset>
  return pagetable;
}
    80001252:	8526                	mv	a0,s1
    80001254:	60e2                	ld	ra,24(sp)
    80001256:	6442                	ld	s0,16(sp)
    80001258:	64a2                	ld	s1,8(sp)
    8000125a:	6105                	addi	sp,sp,32
    8000125c:	8082                	ret

000000008000125e <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000125e:	1101                	addi	sp,sp,-32
    80001260:	ec06                	sd	ra,24(sp)
    80001262:	e822                	sd	s0,16(sp)
    80001264:	e426                	sd	s1,8(sp)
    80001266:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80001268:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000126a:	00b67d63          	bgeu	a2,a1,80001284 <uvmdealloc+0x26>
    8000126e:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001270:	6785                	lui	a5,0x1
    80001272:	17fd                	addi	a5,a5,-1
    80001274:	00f60733          	add	a4,a2,a5
    80001278:	767d                	lui	a2,0xfffff
    8000127a:	8f71                	and	a4,a4,a2
    8000127c:	97ae                	add	a5,a5,a1
    8000127e:	8ff1                	and	a5,a5,a2
    80001280:	00f76863          	bltu	a4,a5,80001290 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001284:	8526                	mv	a0,s1
    80001286:	60e2                	ld	ra,24(sp)
    80001288:	6442                	ld	s0,16(sp)
    8000128a:	64a2                	ld	s1,8(sp)
    8000128c:	6105                	addi	sp,sp,32
    8000128e:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001290:	8f99                	sub	a5,a5,a4
    80001292:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001294:	4685                	li	a3,1
    80001296:	0007861b          	sext.w	a2,a5
    8000129a:	85ba                	mv	a1,a4
    8000129c:	f21ff0ef          	jal	ra,800011bc <uvmunmap>
    800012a0:	b7d5                	j	80001284 <uvmdealloc+0x26>

00000000800012a2 <uvmalloc>:
  if(newsz < oldsz)
    800012a2:	08b66963          	bltu	a2,a1,80001334 <uvmalloc+0x92>
{
    800012a6:	7139                	addi	sp,sp,-64
    800012a8:	fc06                	sd	ra,56(sp)
    800012aa:	f822                	sd	s0,48(sp)
    800012ac:	f426                	sd	s1,40(sp)
    800012ae:	f04a                	sd	s2,32(sp)
    800012b0:	ec4e                	sd	s3,24(sp)
    800012b2:	e852                	sd	s4,16(sp)
    800012b4:	e456                	sd	s5,8(sp)
    800012b6:	e05a                	sd	s6,0(sp)
    800012b8:	0080                	addi	s0,sp,64
    800012ba:	8aaa                	mv	s5,a0
    800012bc:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800012be:	6985                	lui	s3,0x1
    800012c0:	19fd                	addi	s3,s3,-1
    800012c2:	95ce                	add	a1,a1,s3
    800012c4:	79fd                	lui	s3,0xfffff
    800012c6:	0135f9b3          	and	s3,a1,s3
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012ca:	06c9f763          	bgeu	s3,a2,80001338 <uvmalloc+0x96>
    800012ce:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012d0:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012d4:	84bff0ef          	jal	ra,80000b1e <kalloc>
    800012d8:	84aa                	mv	s1,a0
    if(mem == 0){
    800012da:	c11d                	beqz	a0,80001300 <uvmalloc+0x5e>
    memset(mem, 0, PGSIZE);
    800012dc:	6605                	lui	a2,0x1
    800012de:	4581                	li	a1,0
    800012e0:	9e3ff0ef          	jal	ra,80000cc2 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012e4:	875a                	mv	a4,s6
    800012e6:	86a6                	mv	a3,s1
    800012e8:	6605                	lui	a2,0x1
    800012ea:	85ca                	mv	a1,s2
    800012ec:	8556                	mv	a0,s5
    800012ee:	d29ff0ef          	jal	ra,80001016 <mappages>
    800012f2:	e51d                	bnez	a0,80001320 <uvmalloc+0x7e>
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012f4:	6785                	lui	a5,0x1
    800012f6:	993e                	add	s2,s2,a5
    800012f8:	fd496ee3          	bltu	s2,s4,800012d4 <uvmalloc+0x32>
  return newsz;
    800012fc:	8552                	mv	a0,s4
    800012fe:	a039                	j	8000130c <uvmalloc+0x6a>
      uvmdealloc(pagetable, a, oldsz);
    80001300:	864e                	mv	a2,s3
    80001302:	85ca                	mv	a1,s2
    80001304:	8556                	mv	a0,s5
    80001306:	f59ff0ef          	jal	ra,8000125e <uvmdealloc>
      return 0;
    8000130a:	4501                	li	a0,0
}
    8000130c:	70e2                	ld	ra,56(sp)
    8000130e:	7442                	ld	s0,48(sp)
    80001310:	74a2                	ld	s1,40(sp)
    80001312:	7902                	ld	s2,32(sp)
    80001314:	69e2                	ld	s3,24(sp)
    80001316:	6a42                	ld	s4,16(sp)
    80001318:	6aa2                	ld	s5,8(sp)
    8000131a:	6b02                	ld	s6,0(sp)
    8000131c:	6121                	addi	sp,sp,64
    8000131e:	8082                	ret
      kfree(mem);
    80001320:	8526                	mv	a0,s1
    80001322:	f1cff0ef          	jal	ra,80000a3e <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001326:	864e                	mv	a2,s3
    80001328:	85ca                	mv	a1,s2
    8000132a:	8556                	mv	a0,s5
    8000132c:	f33ff0ef          	jal	ra,8000125e <uvmdealloc>
      return 0;
    80001330:	4501                	li	a0,0
    80001332:	bfe9                	j	8000130c <uvmalloc+0x6a>
    return oldsz;
    80001334:	852e                	mv	a0,a1
}
    80001336:	8082                	ret
  return newsz;
    80001338:	8532                	mv	a0,a2
    8000133a:	bfc9                	j	8000130c <uvmalloc+0x6a>

000000008000133c <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000133c:	7179                	addi	sp,sp,-48
    8000133e:	f406                	sd	ra,40(sp)
    80001340:	f022                	sd	s0,32(sp)
    80001342:	ec26                	sd	s1,24(sp)
    80001344:	e84a                	sd	s2,16(sp)
    80001346:	e44e                	sd	s3,8(sp)
    80001348:	e052                	sd	s4,0(sp)
    8000134a:	1800                	addi	s0,sp,48
    8000134c:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000134e:	84aa                	mv	s1,a0
    80001350:	6905                	lui	s2,0x1
    80001352:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001354:	4985                	li	s3,1
    80001356:	a811                	j	8000136a <freewalk+0x2e>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80001358:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    8000135a:	0532                	slli	a0,a0,0xc
    8000135c:	fe1ff0ef          	jal	ra,8000133c <freewalk>
      pagetable[i] = 0;
    80001360:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80001364:	04a1                	addi	s1,s1,8
    80001366:	01248f63          	beq	s1,s2,80001384 <freewalk+0x48>
    pte_t pte = pagetable[i];
    8000136a:	6088                	ld	a0,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000136c:	00f57793          	andi	a5,a0,15
    80001370:	ff3784e3          	beq	a5,s3,80001358 <freewalk+0x1c>
    } else if(pte & PTE_V){
    80001374:	8905                	andi	a0,a0,1
    80001376:	d57d                	beqz	a0,80001364 <freewalk+0x28>
      panic("freewalk: leaf");
    80001378:	00006517          	auipc	a0,0x6
    8000137c:	dd850513          	addi	a0,a0,-552 # 80007150 <digits+0x118>
    80001380:	be8ff0ef          	jal	ra,80000768 <panic>
    }
  }
  kfree((void*)pagetable);
    80001384:	8552                	mv	a0,s4
    80001386:	eb8ff0ef          	jal	ra,80000a3e <kfree>
}
    8000138a:	70a2                	ld	ra,40(sp)
    8000138c:	7402                	ld	s0,32(sp)
    8000138e:	64e2                	ld	s1,24(sp)
    80001390:	6942                	ld	s2,16(sp)
    80001392:	69a2                	ld	s3,8(sp)
    80001394:	6a02                	ld	s4,0(sp)
    80001396:	6145                	addi	sp,sp,48
    80001398:	8082                	ret

000000008000139a <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000139a:	1101                	addi	sp,sp,-32
    8000139c:	ec06                	sd	ra,24(sp)
    8000139e:	e822                	sd	s0,16(sp)
    800013a0:	e426                	sd	s1,8(sp)
    800013a2:	1000                	addi	s0,sp,32
    800013a4:	84aa                	mv	s1,a0
  if(sz > 0)
    800013a6:	e989                	bnez	a1,800013b8 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800013a8:	8526                	mv	a0,s1
    800013aa:	f93ff0ef          	jal	ra,8000133c <freewalk>
}
    800013ae:	60e2                	ld	ra,24(sp)
    800013b0:	6442                	ld	s0,16(sp)
    800013b2:	64a2                	ld	s1,8(sp)
    800013b4:	6105                	addi	sp,sp,32
    800013b6:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800013b8:	6605                	lui	a2,0x1
    800013ba:	167d                	addi	a2,a2,-1
    800013bc:	962e                	add	a2,a2,a1
    800013be:	4685                	li	a3,1
    800013c0:	8231                	srli	a2,a2,0xc
    800013c2:	4581                	li	a1,0
    800013c4:	df9ff0ef          	jal	ra,800011bc <uvmunmap>
    800013c8:	b7c5                	j	800013a8 <uvmfree+0xe>

00000000800013ca <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    800013ca:	ce49                	beqz	a2,80001464 <uvmcopy+0x9a>
{
    800013cc:	715d                	addi	sp,sp,-80
    800013ce:	e486                	sd	ra,72(sp)
    800013d0:	e0a2                	sd	s0,64(sp)
    800013d2:	fc26                	sd	s1,56(sp)
    800013d4:	f84a                	sd	s2,48(sp)
    800013d6:	f44e                	sd	s3,40(sp)
    800013d8:	f052                	sd	s4,32(sp)
    800013da:	ec56                	sd	s5,24(sp)
    800013dc:	e85a                	sd	s6,16(sp)
    800013de:	e45e                	sd	s7,8(sp)
    800013e0:	0880                	addi	s0,sp,80
    800013e2:	8aaa                	mv	s5,a0
    800013e4:	8b2e                	mv	s6,a1
    800013e6:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800013e8:	4481                	li	s1,0
    800013ea:	a029                	j	800013f4 <uvmcopy+0x2a>
    800013ec:	6785                	lui	a5,0x1
    800013ee:	94be                	add	s1,s1,a5
    800013f0:	0544fe63          	bgeu	s1,s4,8000144c <uvmcopy+0x82>
    if((pte = walk(old, i, 0)) == 0)
    800013f4:	4601                	li	a2,0
    800013f6:	85a6                	mv	a1,s1
    800013f8:	8556                	mv	a0,s5
    800013fa:	b45ff0ef          	jal	ra,80000f3e <walk>
    800013fe:	d57d                	beqz	a0,800013ec <uvmcopy+0x22>
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
    80001400:	6118                	ld	a4,0(a0)
    80001402:	00177793          	andi	a5,a4,1
    80001406:	d3fd                	beqz	a5,800013ec <uvmcopy+0x22>
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    80001408:	00a75593          	srli	a1,a4,0xa
    8000140c:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    80001410:	3ff77913          	andi	s2,a4,1023
    if((mem = kalloc()) == 0)
    80001414:	f0aff0ef          	jal	ra,80000b1e <kalloc>
    80001418:	89aa                	mv	s3,a0
    8000141a:	c105                	beqz	a0,8000143a <uvmcopy+0x70>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    8000141c:	6605                	lui	a2,0x1
    8000141e:	85de                	mv	a1,s7
    80001420:	8ffff0ef          	jal	ra,80000d1e <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001424:	874a                	mv	a4,s2
    80001426:	86ce                	mv	a3,s3
    80001428:	6605                	lui	a2,0x1
    8000142a:	85a6                	mv	a1,s1
    8000142c:	855a                	mv	a0,s6
    8000142e:	be9ff0ef          	jal	ra,80001016 <mappages>
    80001432:	dd4d                	beqz	a0,800013ec <uvmcopy+0x22>
      kfree(mem);
    80001434:	854e                	mv	a0,s3
    80001436:	e08ff0ef          	jal	ra,80000a3e <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000143a:	4685                	li	a3,1
    8000143c:	00c4d613          	srli	a2,s1,0xc
    80001440:	4581                	li	a1,0
    80001442:	855a                	mv	a0,s6
    80001444:	d79ff0ef          	jal	ra,800011bc <uvmunmap>
  return -1;
    80001448:	557d                	li	a0,-1
    8000144a:	a011                	j	8000144e <uvmcopy+0x84>
  return 0;
    8000144c:	4501                	li	a0,0
}
    8000144e:	60a6                	ld	ra,72(sp)
    80001450:	6406                	ld	s0,64(sp)
    80001452:	74e2                	ld	s1,56(sp)
    80001454:	7942                	ld	s2,48(sp)
    80001456:	79a2                	ld	s3,40(sp)
    80001458:	7a02                	ld	s4,32(sp)
    8000145a:	6ae2                	ld	s5,24(sp)
    8000145c:	6b42                	ld	s6,16(sp)
    8000145e:	6ba2                	ld	s7,8(sp)
    80001460:	6161                	addi	sp,sp,80
    80001462:	8082                	ret
  return 0;
    80001464:	4501                	li	a0,0
}
    80001466:	8082                	ret

0000000080001468 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001468:	1141                	addi	sp,sp,-16
    8000146a:	e406                	sd	ra,8(sp)
    8000146c:	e022                	sd	s0,0(sp)
    8000146e:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001470:	4601                	li	a2,0
    80001472:	acdff0ef          	jal	ra,80000f3e <walk>
  if(pte == 0)
    80001476:	c901                	beqz	a0,80001486 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001478:	611c                	ld	a5,0(a0)
    8000147a:	9bbd                	andi	a5,a5,-17
    8000147c:	e11c                	sd	a5,0(a0)
}
    8000147e:	60a2                	ld	ra,8(sp)
    80001480:	6402                	ld	s0,0(sp)
    80001482:	0141                	addi	sp,sp,16
    80001484:	8082                	ret
    panic("uvmclear");
    80001486:	00006517          	auipc	a0,0x6
    8000148a:	cda50513          	addi	a0,a0,-806 # 80007160 <digits+0x128>
    8000148e:	adaff0ef          	jal	ra,80000768 <panic>

0000000080001492 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001492:	c2d5                	beqz	a3,80001536 <copyinstr+0xa4>
{
    80001494:	715d                	addi	sp,sp,-80
    80001496:	e486                	sd	ra,72(sp)
    80001498:	e0a2                	sd	s0,64(sp)
    8000149a:	fc26                	sd	s1,56(sp)
    8000149c:	f84a                	sd	s2,48(sp)
    8000149e:	f44e                	sd	s3,40(sp)
    800014a0:	f052                	sd	s4,32(sp)
    800014a2:	ec56                	sd	s5,24(sp)
    800014a4:	e85a                	sd	s6,16(sp)
    800014a6:	e45e                	sd	s7,8(sp)
    800014a8:	0880                	addi	s0,sp,80
    800014aa:	8a2a                	mv	s4,a0
    800014ac:	8b2e                	mv	s6,a1
    800014ae:	8bb2                	mv	s7,a2
    800014b0:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    800014b2:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800014b4:	6985                	lui	s3,0x1
    800014b6:	a035                	j	800014e2 <copyinstr+0x50>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800014b8:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800014bc:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800014be:	0017b793          	seqz	a5,a5
    800014c2:	40f00533          	neg	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800014c6:	60a6                	ld	ra,72(sp)
    800014c8:	6406                	ld	s0,64(sp)
    800014ca:	74e2                	ld	s1,56(sp)
    800014cc:	7942                	ld	s2,48(sp)
    800014ce:	79a2                	ld	s3,40(sp)
    800014d0:	7a02                	ld	s4,32(sp)
    800014d2:	6ae2                	ld	s5,24(sp)
    800014d4:	6b42                	ld	s6,16(sp)
    800014d6:	6ba2                	ld	s7,8(sp)
    800014d8:	6161                	addi	sp,sp,80
    800014da:	8082                	ret
    srcva = va0 + PGSIZE;
    800014dc:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    800014e0:	c4b9                	beqz	s1,8000152e <copyinstr+0x9c>
    va0 = PGROUNDDOWN(srcva);
    800014e2:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    800014e6:	85ca                	mv	a1,s2
    800014e8:	8552                	mv	a0,s4
    800014ea:	aefff0ef          	jal	ra,80000fd8 <walkaddr>
    if(pa0 == 0)
    800014ee:	c131                	beqz	a0,80001532 <copyinstr+0xa0>
    n = PGSIZE - (srcva - va0);
    800014f0:	41790833          	sub	a6,s2,s7
    800014f4:	984e                	add	a6,a6,s3
    if(n > max)
    800014f6:	0104f363          	bgeu	s1,a6,800014fc <copyinstr+0x6a>
    800014fa:	8826                	mv	a6,s1
    char *p = (char *) (pa0 + (srcva - va0));
    800014fc:	955e                	add	a0,a0,s7
    800014fe:	41250533          	sub	a0,a0,s2
    while(n > 0){
    80001502:	fc080de3          	beqz	a6,800014dc <copyinstr+0x4a>
    80001506:	985a                	add	a6,a6,s6
    80001508:	87da                	mv	a5,s6
      if(*p == '\0'){
    8000150a:	41650633          	sub	a2,a0,s6
    8000150e:	14fd                	addi	s1,s1,-1
    80001510:	9b26                	add	s6,s6,s1
    80001512:	00f60733          	add	a4,a2,a5
    80001516:	00074703          	lbu	a4,0(a4)
    8000151a:	df59                	beqz	a4,800014b8 <copyinstr+0x26>
        *dst = *p;
    8000151c:	00e78023          	sb	a4,0(a5)
      --max;
    80001520:	40fb04b3          	sub	s1,s6,a5
      dst++;
    80001524:	0785                	addi	a5,a5,1
    while(n > 0){
    80001526:	ff0796e3          	bne	a5,a6,80001512 <copyinstr+0x80>
      dst++;
    8000152a:	8b42                	mv	s6,a6
    8000152c:	bf45                	j	800014dc <copyinstr+0x4a>
    8000152e:	4781                	li	a5,0
    80001530:	b779                	j	800014be <copyinstr+0x2c>
      return -1;
    80001532:	557d                	li	a0,-1
    80001534:	bf49                	j	800014c6 <copyinstr+0x34>
  int got_null = 0;
    80001536:	4781                	li	a5,0
  if(got_null){
    80001538:	0017b793          	seqz	a5,a5
    8000153c:	40f00533          	neg	a0,a5
}
    80001540:	8082                	ret

0000000080001542 <ismapped>:
  return ka;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001542:	1141                	addi	sp,sp,-16
    80001544:	e406                	sd	ra,8(sp)
    80001546:	e022                	sd	s0,0(sp)
    80001548:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    8000154a:	4601                	li	a2,0
    8000154c:	9f3ff0ef          	jal	ra,80000f3e <walk>
  if (pte == 0) {
    80001550:	c519                	beqz	a0,8000155e <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    80001552:	6108                	ld	a0,0(a0)
    return 0;
    80001554:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001556:	60a2                	ld	ra,8(sp)
    80001558:	6402                	ld	s0,0(sp)
    8000155a:	0141                	addi	sp,sp,16
    8000155c:	8082                	ret
    return 0;
    8000155e:	4501                	li	a0,0
    80001560:	bfdd                	j	80001556 <ismapped+0x14>

0000000080001562 <vmfault>:
{
    80001562:	7179                	addi	sp,sp,-48
    80001564:	f406                	sd	ra,40(sp)
    80001566:	f022                	sd	s0,32(sp)
    80001568:	ec26                	sd	s1,24(sp)
    8000156a:	e84a                	sd	s2,16(sp)
    8000156c:	e44e                	sd	s3,8(sp)
    8000156e:	e052                	sd	s4,0(sp)
    80001570:	1800                	addi	s0,sp,48
    80001572:	89aa                	mv	s3,a0
    80001574:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    80001576:	310000ef          	jal	ra,80001886 <myproc>
  if (va >= p->sz)
    8000157a:	653c                	ld	a5,72(a0)
    8000157c:	00f4ec63          	bltu	s1,a5,80001594 <vmfault+0x32>
    return 0;
    80001580:	4981                	li	s3,0
}
    80001582:	854e                	mv	a0,s3
    80001584:	70a2                	ld	ra,40(sp)
    80001586:	7402                	ld	s0,32(sp)
    80001588:	64e2                	ld	s1,24(sp)
    8000158a:	6942                	ld	s2,16(sp)
    8000158c:	69a2                	ld	s3,8(sp)
    8000158e:	6a02                	ld	s4,0(sp)
    80001590:	6145                	addi	sp,sp,48
    80001592:	8082                	ret
    80001594:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    80001596:	75fd                	lui	a1,0xfffff
    80001598:	8ced                	and	s1,s1,a1
  if(ismapped(pagetable, va)) {
    8000159a:	85a6                	mv	a1,s1
    8000159c:	854e                	mv	a0,s3
    8000159e:	fa5ff0ef          	jal	ra,80001542 <ismapped>
    return 0;
    800015a2:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    800015a4:	fd79                	bnez	a0,80001582 <vmfault+0x20>
  ka = (uint64) kalloc();
    800015a6:	d78ff0ef          	jal	ra,80000b1e <kalloc>
    800015aa:	8a2a                	mv	s4,a0
  if(ka == 0)
    800015ac:	d979                	beqz	a0,80001582 <vmfault+0x20>
  ka = (uint64) kalloc();
    800015ae:	89aa                	mv	s3,a0
  memset((void *) ka, 0, PGSIZE);
    800015b0:	6605                	lui	a2,0x1
    800015b2:	4581                	li	a1,0
    800015b4:	f0eff0ef          	jal	ra,80000cc2 <memset>
  if (mappages(p->pagetable, va, PGSIZE, ka, PTE_W|PTE_U|PTE_R) != 0) {
    800015b8:	4759                	li	a4,22
    800015ba:	86d2                	mv	a3,s4
    800015bc:	6605                	lui	a2,0x1
    800015be:	85a6                	mv	a1,s1
    800015c0:	05093503          	ld	a0,80(s2) # 1050 <_entry-0x7fffefb0>
    800015c4:	a53ff0ef          	jal	ra,80001016 <mappages>
    800015c8:	dd4d                	beqz	a0,80001582 <vmfault+0x20>
    kfree((void *)ka);
    800015ca:	8552                	mv	a0,s4
    800015cc:	c72ff0ef          	jal	ra,80000a3e <kfree>
    return 0;
    800015d0:	4981                	li	s3,0
    800015d2:	bf45                	j	80001582 <vmfault+0x20>

00000000800015d4 <copyout>:
  while(len > 0){
    800015d4:	cec1                	beqz	a3,8000166c <copyout+0x98>
{
    800015d6:	711d                	addi	sp,sp,-96
    800015d8:	ec86                	sd	ra,88(sp)
    800015da:	e8a2                	sd	s0,80(sp)
    800015dc:	e4a6                	sd	s1,72(sp)
    800015de:	e0ca                	sd	s2,64(sp)
    800015e0:	fc4e                	sd	s3,56(sp)
    800015e2:	f852                	sd	s4,48(sp)
    800015e4:	f456                	sd	s5,40(sp)
    800015e6:	f05a                	sd	s6,32(sp)
    800015e8:	ec5e                	sd	s7,24(sp)
    800015ea:	e862                	sd	s8,16(sp)
    800015ec:	e466                	sd	s9,8(sp)
    800015ee:	e06a                	sd	s10,0(sp)
    800015f0:	1080                	addi	s0,sp,96
    800015f2:	8c2a                	mv	s8,a0
    800015f4:	8b2e                	mv	s6,a1
    800015f6:	8bb2                	mv	s7,a2
    800015f8:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015fa:	74fd                	lui	s1,0xfffff
    800015fc:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    800015fe:	57fd                	li	a5,-1
    80001600:	83e9                	srli	a5,a5,0x1a
    80001602:	0697e763          	bltu	a5,s1,80001670 <copyout+0x9c>
    80001606:	6d05                	lui	s10,0x1
    80001608:	8cbe                	mv	s9,a5
    8000160a:	a015                	j	8000162e <copyout+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000160c:	409b0533          	sub	a0,s6,s1
    80001610:	0009861b          	sext.w	a2,s3
    80001614:	85de                	mv	a1,s7
    80001616:	954a                	add	a0,a0,s2
    80001618:	f06ff0ef          	jal	ra,80000d1e <memmove>
    len -= n;
    8000161c:	413a0a33          	sub	s4,s4,s3
    src += n;
    80001620:	9bce                	add	s7,s7,s3
  while(len > 0){
    80001622:	040a0363          	beqz	s4,80001668 <copyout+0x94>
    if(va0 >= MAXVA)
    80001626:	055ce763          	bltu	s9,s5,80001674 <copyout+0xa0>
    va0 = PGROUNDDOWN(dstva);
    8000162a:	84d6                	mv	s1,s5
    dstva = va0 + PGSIZE;
    8000162c:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    8000162e:	85a6                	mv	a1,s1
    80001630:	8562                	mv	a0,s8
    80001632:	9a7ff0ef          	jal	ra,80000fd8 <walkaddr>
    80001636:	892a                	mv	s2,a0
    if(pa0 == 0) {
    80001638:	e901                	bnez	a0,80001648 <copyout+0x74>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    8000163a:	4601                	li	a2,0
    8000163c:	85a6                	mv	a1,s1
    8000163e:	8562                	mv	a0,s8
    80001640:	f23ff0ef          	jal	ra,80001562 <vmfault>
    80001644:	892a                	mv	s2,a0
    80001646:	c90d                	beqz	a0,80001678 <copyout+0xa4>
    pte = walk(pagetable, va0, 0);
    80001648:	4601                	li	a2,0
    8000164a:	85a6                	mv	a1,s1
    8000164c:	8562                	mv	a0,s8
    8000164e:	8f1ff0ef          	jal	ra,80000f3e <walk>
    if((*pte & PTE_W) == 0)
    80001652:	611c                	ld	a5,0(a0)
    80001654:	8b91                	andi	a5,a5,4
    80001656:	c39d                	beqz	a5,8000167c <copyout+0xa8>
    n = PGSIZE - (dstva - va0);
    80001658:	01a48ab3          	add	s5,s1,s10
    8000165c:	416a89b3          	sub	s3,s5,s6
    if(n > len)
    80001660:	fb3a76e3          	bgeu	s4,s3,8000160c <copyout+0x38>
    80001664:	89d2                	mv	s3,s4
    80001666:	b75d                	j	8000160c <copyout+0x38>
  return 0;
    80001668:	4501                	li	a0,0
    8000166a:	a811                	j	8000167e <copyout+0xaa>
    8000166c:	4501                	li	a0,0
}
    8000166e:	8082                	ret
      return -1;
    80001670:	557d                	li	a0,-1
    80001672:	a031                	j	8000167e <copyout+0xaa>
    80001674:	557d                	li	a0,-1
    80001676:	a021                	j	8000167e <copyout+0xaa>
        return -1;
    80001678:	557d                	li	a0,-1
    8000167a:	a011                	j	8000167e <copyout+0xaa>
      return -1;
    8000167c:	557d                	li	a0,-1
}
    8000167e:	60e6                	ld	ra,88(sp)
    80001680:	6446                	ld	s0,80(sp)
    80001682:	64a6                	ld	s1,72(sp)
    80001684:	6906                	ld	s2,64(sp)
    80001686:	79e2                	ld	s3,56(sp)
    80001688:	7a42                	ld	s4,48(sp)
    8000168a:	7aa2                	ld	s5,40(sp)
    8000168c:	7b02                	ld	s6,32(sp)
    8000168e:	6be2                	ld	s7,24(sp)
    80001690:	6c42                	ld	s8,16(sp)
    80001692:	6ca2                	ld	s9,8(sp)
    80001694:	6d02                	ld	s10,0(sp)
    80001696:	6125                	addi	sp,sp,96
    80001698:	8082                	ret

000000008000169a <copyin>:
  while(len > 0){
    8000169a:	c6c9                	beqz	a3,80001724 <copyin+0x8a>
{
    8000169c:	715d                	addi	sp,sp,-80
    8000169e:	e486                	sd	ra,72(sp)
    800016a0:	e0a2                	sd	s0,64(sp)
    800016a2:	fc26                	sd	s1,56(sp)
    800016a4:	f84a                	sd	s2,48(sp)
    800016a6:	f44e                	sd	s3,40(sp)
    800016a8:	f052                	sd	s4,32(sp)
    800016aa:	ec56                	sd	s5,24(sp)
    800016ac:	e85a                	sd	s6,16(sp)
    800016ae:	e45e                	sd	s7,8(sp)
    800016b0:	e062                	sd	s8,0(sp)
    800016b2:	0880                	addi	s0,sp,80
    800016b4:	8baa                	mv	s7,a0
    800016b6:	8aae                	mv	s5,a1
    800016b8:	8932                	mv	s2,a2
    800016ba:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    800016bc:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800016be:	6b05                	lui	s6,0x1
    800016c0:	a035                	j	800016ec <copyin+0x52>
    800016c2:	412984b3          	sub	s1,s3,s2
    800016c6:	94da                	add	s1,s1,s6
    if(n > len)
    800016c8:	009a7363          	bgeu	s4,s1,800016ce <copyin+0x34>
    800016cc:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800016ce:	413905b3          	sub	a1,s2,s3
    800016d2:	0004861b          	sext.w	a2,s1
    800016d6:	95aa                	add	a1,a1,a0
    800016d8:	8556                	mv	a0,s5
    800016da:	e44ff0ef          	jal	ra,80000d1e <memmove>
    len -= n;
    800016de:	409a0a33          	sub	s4,s4,s1
    dst += n;
    800016e2:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    800016e4:	01698933          	add	s2,s3,s6
  while(len > 0){
    800016e8:	020a0163          	beqz	s4,8000170a <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    800016ec:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    800016f0:	85ce                	mv	a1,s3
    800016f2:	855e                	mv	a0,s7
    800016f4:	8e5ff0ef          	jal	ra,80000fd8 <walkaddr>
    if(pa0 == 0) {
    800016f8:	f569                	bnez	a0,800016c2 <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800016fa:	4601                	li	a2,0
    800016fc:	85ce                	mv	a1,s3
    800016fe:	855e                	mv	a0,s7
    80001700:	e63ff0ef          	jal	ra,80001562 <vmfault>
    80001704:	fd5d                	bnez	a0,800016c2 <copyin+0x28>
        return -1;
    80001706:	557d                	li	a0,-1
    80001708:	a011                	j	8000170c <copyin+0x72>
  return 0;
    8000170a:	4501                	li	a0,0
}
    8000170c:	60a6                	ld	ra,72(sp)
    8000170e:	6406                	ld	s0,64(sp)
    80001710:	74e2                	ld	s1,56(sp)
    80001712:	7942                	ld	s2,48(sp)
    80001714:	79a2                	ld	s3,40(sp)
    80001716:	7a02                	ld	s4,32(sp)
    80001718:	6ae2                	ld	s5,24(sp)
    8000171a:	6b42                	ld	s6,16(sp)
    8000171c:	6ba2                	ld	s7,8(sp)
    8000171e:	6c02                	ld	s8,0(sp)
    80001720:	6161                	addi	sp,sp,80
    80001722:	8082                	ret
  return 0;
    80001724:	4501                	li	a0,0
}
    80001726:	8082                	ret

0000000080001728 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001728:	7139                	addi	sp,sp,-64
    8000172a:	fc06                	sd	ra,56(sp)
    8000172c:	f822                	sd	s0,48(sp)
    8000172e:	f426                	sd	s1,40(sp)
    80001730:	f04a                	sd	s2,32(sp)
    80001732:	ec4e                	sd	s3,24(sp)
    80001734:	e852                	sd	s4,16(sp)
    80001736:	e456                	sd	s5,8(sp)
    80001738:	e05a                	sd	s6,0(sp)
    8000173a:	0080                	addi	s0,sp,64
    8000173c:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    8000173e:	0000e497          	auipc	s1,0xe
    80001742:	7ba48493          	addi	s1,s1,1978 # 8000fef8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80001746:	8b26                	mv	s6,s1
    80001748:	00006a97          	auipc	s5,0x6
    8000174c:	8b8a8a93          	addi	s5,s5,-1864 # 80007000 <etext>
    80001750:	04000937          	lui	s2,0x4000
    80001754:	197d                	addi	s2,s2,-1
    80001756:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001758:	00019a17          	auipc	s4,0x19
    8000175c:	fa0a0a13          	addi	s4,s4,-96 # 8001a6f8 <tickslock>
    char *pa = kalloc();
    80001760:	bbeff0ef          	jal	ra,80000b1e <kalloc>
    80001764:	862a                	mv	a2,a0
    if(pa == 0)
    80001766:	c121                	beqz	a0,800017a6 <proc_mapstacks+0x7e>
    uint64 va = KSTACK((int) (p - proc));
    80001768:	416485b3          	sub	a1,s1,s6
    8000176c:	8595                	srai	a1,a1,0x5
    8000176e:	000ab783          	ld	a5,0(s5)
    80001772:	02f585b3          	mul	a1,a1,a5
    80001776:	2585                	addiw	a1,a1,1
    80001778:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000177c:	4719                	li	a4,6
    8000177e:	6685                	lui	a3,0x1
    80001780:	40b905b3          	sub	a1,s2,a1
    80001784:	854e                	mv	a0,s3
    80001786:	941ff0ef          	jal	ra,800010c6 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000178a:	2a048493          	addi	s1,s1,672
    8000178e:	fd4499e3          	bne	s1,s4,80001760 <proc_mapstacks+0x38>
  }
}
    80001792:	70e2                	ld	ra,56(sp)
    80001794:	7442                	ld	s0,48(sp)
    80001796:	74a2                	ld	s1,40(sp)
    80001798:	7902                	ld	s2,32(sp)
    8000179a:	69e2                	ld	s3,24(sp)
    8000179c:	6a42                	ld	s4,16(sp)
    8000179e:	6aa2                	ld	s5,8(sp)
    800017a0:	6b02                	ld	s6,0(sp)
    800017a2:	6121                	addi	sp,sp,64
    800017a4:	8082                	ret
      panic("kalloc");
    800017a6:	00006517          	auipc	a0,0x6
    800017aa:	9ca50513          	addi	a0,a0,-1590 # 80007170 <digits+0x138>
    800017ae:	fbbfe0ef          	jal	ra,80000768 <panic>

00000000800017b2 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017b2:	7139                	addi	sp,sp,-64
    800017b4:	fc06                	sd	ra,56(sp)
    800017b6:	f822                	sd	s0,48(sp)
    800017b8:	f426                	sd	s1,40(sp)
    800017ba:	f04a                	sd	s2,32(sp)
    800017bc:	ec4e                	sd	s3,24(sp)
    800017be:	e852                	sd	s4,16(sp)
    800017c0:	e456                	sd	s5,8(sp)
    800017c2:	e05a                	sd	s6,0(sp)
    800017c4:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    800017c6:	00006597          	auipc	a1,0x6
    800017ca:	9b258593          	addi	a1,a1,-1614 # 80007178 <digits+0x140>
    800017ce:	0000e517          	auipc	a0,0xe
    800017d2:	2fa50513          	addi	a0,a0,762 # 8000fac8 <pid_lock>
    800017d6:	b98ff0ef          	jal	ra,80000b6e <initlock>
  initlock(&wait_lock, "wait_lock");
    800017da:	00006597          	auipc	a1,0x6
    800017de:	9a658593          	addi	a1,a1,-1626 # 80007180 <digits+0x148>
    800017e2:	0000e517          	auipc	a0,0xe
    800017e6:	2fe50513          	addi	a0,a0,766 # 8000fae0 <wait_lock>
    800017ea:	b84ff0ef          	jal	ra,80000b6e <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    800017ee:	0000e497          	auipc	s1,0xe
    800017f2:	70a48493          	addi	s1,s1,1802 # 8000fef8 <proc>
      initlock(&p->lock, "proc");
    800017f6:	00006b17          	auipc	s6,0x6
    800017fa:	99ab0b13          	addi	s6,s6,-1638 # 80007190 <digits+0x158>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    800017fe:	8aa6                	mv	s5,s1
    80001800:	00006a17          	auipc	s4,0x6
    80001804:	800a0a13          	addi	s4,s4,-2048 # 80007000 <etext>
    80001808:	04000937          	lui	s2,0x4000
    8000180c:	197d                	addi	s2,s2,-1
    8000180e:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001810:	00019997          	auipc	s3,0x19
    80001814:	ee898993          	addi	s3,s3,-280 # 8001a6f8 <tickslock>
      initlock(&p->lock, "proc");
    80001818:	85da                	mv	a1,s6
    8000181a:	8526                	mv	a0,s1
    8000181c:	b52ff0ef          	jal	ra,80000b6e <initlock>
      p->state = UNUSED;
    80001820:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001824:	415487b3          	sub	a5,s1,s5
    80001828:	8795                	srai	a5,a5,0x5
    8000182a:	000a3703          	ld	a4,0(s4)
    8000182e:	02e787b3          	mul	a5,a5,a4
    80001832:	2785                	addiw	a5,a5,1
    80001834:	00d7979b          	slliw	a5,a5,0xd
    80001838:	40f907b3          	sub	a5,s2,a5
    8000183c:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    8000183e:	2a048493          	addi	s1,s1,672
    80001842:	fd349be3          	bne	s1,s3,80001818 <procinit+0x66>
  }
}
    80001846:	70e2                	ld	ra,56(sp)
    80001848:	7442                	ld	s0,48(sp)
    8000184a:	74a2                	ld	s1,40(sp)
    8000184c:	7902                	ld	s2,32(sp)
    8000184e:	69e2                	ld	s3,24(sp)
    80001850:	6a42                	ld	s4,16(sp)
    80001852:	6aa2                	ld	s5,8(sp)
    80001854:	6b02                	ld	s6,0(sp)
    80001856:	6121                	addi	sp,sp,64
    80001858:	8082                	ret

000000008000185a <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    8000185a:	1141                	addi	sp,sp,-16
    8000185c:	e422                	sd	s0,8(sp)
    8000185e:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001860:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001862:	2501                	sext.w	a0,a0
    80001864:	6422                	ld	s0,8(sp)
    80001866:	0141                	addi	sp,sp,16
    80001868:	8082                	ret

000000008000186a <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    8000186a:	1141                	addi	sp,sp,-16
    8000186c:	e422                	sd	s0,8(sp)
    8000186e:	0800                	addi	s0,sp,16
    80001870:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001872:	2781                	sext.w	a5,a5
    80001874:	079e                	slli	a5,a5,0x7
  return c;
}
    80001876:	0000e517          	auipc	a0,0xe
    8000187a:	28250513          	addi	a0,a0,642 # 8000faf8 <cpus>
    8000187e:	953e                	add	a0,a0,a5
    80001880:	6422                	ld	s0,8(sp)
    80001882:	0141                	addi	sp,sp,16
    80001884:	8082                	ret

0000000080001886 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001886:	1101                	addi	sp,sp,-32
    80001888:	ec06                	sd	ra,24(sp)
    8000188a:	e822                	sd	s0,16(sp)
    8000188c:	e426                	sd	s1,8(sp)
    8000188e:	1000                	addi	s0,sp,32
  push_off();
    80001890:	b1eff0ef          	jal	ra,80000bae <push_off>
    80001894:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001896:	2781                	sext.w	a5,a5
    80001898:	079e                	slli	a5,a5,0x7
    8000189a:	0000e717          	auipc	a4,0xe
    8000189e:	22e70713          	addi	a4,a4,558 # 8000fac8 <pid_lock>
    800018a2:	97ba                	add	a5,a5,a4
    800018a4:	7b84                	ld	s1,48(a5)
  pop_off();
    800018a6:	b8cff0ef          	jal	ra,80000c32 <pop_off>
  return p;
}
    800018aa:	8526                	mv	a0,s1
    800018ac:	60e2                	ld	ra,24(sp)
    800018ae:	6442                	ld	s0,16(sp)
    800018b0:	64a2                	ld	s1,8(sp)
    800018b2:	6105                	addi	sp,sp,32
    800018b4:	8082                	ret

00000000800018b6 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800018b6:	7179                	addi	sp,sp,-48
    800018b8:	f406                	sd	ra,40(sp)
    800018ba:	f022                	sd	s0,32(sp)
    800018bc:	ec26                	sd	s1,24(sp)
    800018be:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    800018c0:	fc7ff0ef          	jal	ra,80001886 <myproc>
    800018c4:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    800018c6:	bc0ff0ef          	jal	ra,80000c86 <release>

  if (first) {
    800018ca:	00006797          	auipc	a5,0x6
    800018ce:	0967a783          	lw	a5,150(a5) # 80007960 <first.1>
    800018d2:	cf8d                	beqz	a5,8000190c <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    800018d4:	4505                	li	a0,1
    800018d6:	01d010ef          	jal	ra,800030f2 <fsinit>

    first = 0;
    800018da:	00006797          	auipc	a5,0x6
    800018de:	0807a323          	sw	zero,134(a5) # 80007960 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    800018e2:	0ff0000f          	fence

    // We can invoke exec() now that file system is initialized.
    // Put the return value (argc) of exec into a0.
    p->trapframe->a0 = exec("/init", (char *[]){ "/init", 0 });
    800018e6:	00006517          	auipc	a0,0x6
    800018ea:	8b250513          	addi	a0,a0,-1870 # 80007198 <digits+0x160>
    800018ee:	fca43823          	sd	a0,-48(s0)
    800018f2:	fc043c23          	sd	zero,-40(s0)
    800018f6:	fd040593          	addi	a1,s0,-48
    800018fa:	471020ef          	jal	ra,8000456a <exec>
    800018fe:	6cbc                	ld	a5,88(s1)
    80001900:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001902:	6cbc                	ld	a5,88(s1)
    80001904:	7bb8                	ld	a4,112(a5)
    80001906:	57fd                	li	a5,-1
    80001908:	02f70d63          	beq	a4,a5,80001942 <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    8000190c:	2d1000ef          	jal	ra,800023dc <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001910:	68a8                	ld	a0,80(s1)
    80001912:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001914:	04000737          	lui	a4,0x4000
    80001918:	00004797          	auipc	a5,0x4
    8000191c:	78478793          	addi	a5,a5,1924 # 8000609c <userret>
    80001920:	00004697          	auipc	a3,0x4
    80001924:	6e068693          	addi	a3,a3,1760 # 80006000 <_trampoline>
    80001928:	8f95                	sub	a5,a5,a3
    8000192a:	177d                	addi	a4,a4,-1
    8000192c:	0732                	slli	a4,a4,0xc
    8000192e:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001930:	577d                	li	a4,-1
    80001932:	177e                	slli	a4,a4,0x3f
    80001934:	8d59                	or	a0,a0,a4
    80001936:	9782                	jalr	a5
}
    80001938:	70a2                	ld	ra,40(sp)
    8000193a:	7402                	ld	s0,32(sp)
    8000193c:	64e2                	ld	s1,24(sp)
    8000193e:	6145                	addi	sp,sp,48
    80001940:	8082                	ret
      panic("exec");
    80001942:	00006517          	auipc	a0,0x6
    80001946:	85e50513          	addi	a0,a0,-1954 # 800071a0 <digits+0x168>
    8000194a:	e1ffe0ef          	jal	ra,80000768 <panic>

000000008000194e <allocpid>:
{
    8000194e:	1101                	addi	sp,sp,-32
    80001950:	ec06                	sd	ra,24(sp)
    80001952:	e822                	sd	s0,16(sp)
    80001954:	e426                	sd	s1,8(sp)
    80001956:	e04a                	sd	s2,0(sp)
    80001958:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    8000195a:	0000e917          	auipc	s2,0xe
    8000195e:	16e90913          	addi	s2,s2,366 # 8000fac8 <pid_lock>
    80001962:	854a                	mv	a0,s2
    80001964:	a8aff0ef          	jal	ra,80000bee <acquire>
  pid = nextpid;
    80001968:	00006797          	auipc	a5,0x6
    8000196c:	ffc78793          	addi	a5,a5,-4 # 80007964 <nextpid>
    80001970:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001972:	0014871b          	addiw	a4,s1,1
    80001976:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001978:	854a                	mv	a0,s2
    8000197a:	b0cff0ef          	jal	ra,80000c86 <release>
}
    8000197e:	8526                	mv	a0,s1
    80001980:	60e2                	ld	ra,24(sp)
    80001982:	6442                	ld	s0,16(sp)
    80001984:	64a2                	ld	s1,8(sp)
    80001986:	6902                	ld	s2,0(sp)
    80001988:	6105                	addi	sp,sp,32
    8000198a:	8082                	ret

000000008000198c <proc_pagetable>:
{
    8000198c:	1101                	addi	sp,sp,-32
    8000198e:	ec06                	sd	ra,24(sp)
    80001990:	e822                	sd	s0,16(sp)
    80001992:	e426                	sd	s1,8(sp)
    80001994:	e04a                	sd	s2,0(sp)
    80001996:	1000                	addi	s0,sp,32
    80001998:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    8000199a:	89fff0ef          	jal	ra,80001238 <uvmcreate>
    8000199e:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800019a0:	cd05                	beqz	a0,800019d8 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800019a2:	4729                	li	a4,10
    800019a4:	00004697          	auipc	a3,0x4
    800019a8:	65c68693          	addi	a3,a3,1628 # 80006000 <_trampoline>
    800019ac:	6605                	lui	a2,0x1
    800019ae:	040005b7          	lui	a1,0x4000
    800019b2:	15fd                	addi	a1,a1,-1
    800019b4:	05b2                	slli	a1,a1,0xc
    800019b6:	e60ff0ef          	jal	ra,80001016 <mappages>
    800019ba:	02054663          	bltz	a0,800019e6 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    800019be:	4719                	li	a4,6
    800019c0:	05893683          	ld	a3,88(s2)
    800019c4:	6605                	lui	a2,0x1
    800019c6:	020005b7          	lui	a1,0x2000
    800019ca:	15fd                	addi	a1,a1,-1
    800019cc:	05b6                	slli	a1,a1,0xd
    800019ce:	8526                	mv	a0,s1
    800019d0:	e46ff0ef          	jal	ra,80001016 <mappages>
    800019d4:	00054f63          	bltz	a0,800019f2 <proc_pagetable+0x66>
}
    800019d8:	8526                	mv	a0,s1
    800019da:	60e2                	ld	ra,24(sp)
    800019dc:	6442                	ld	s0,16(sp)
    800019de:	64a2                	ld	s1,8(sp)
    800019e0:	6902                	ld	s2,0(sp)
    800019e2:	6105                	addi	sp,sp,32
    800019e4:	8082                	ret
    uvmfree(pagetable, 0);
    800019e6:	4581                	li	a1,0
    800019e8:	8526                	mv	a0,s1
    800019ea:	9b1ff0ef          	jal	ra,8000139a <uvmfree>
    return 0;
    800019ee:	4481                	li	s1,0
    800019f0:	b7e5                	j	800019d8 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    800019f2:	4681                	li	a3,0
    800019f4:	4605                	li	a2,1
    800019f6:	040005b7          	lui	a1,0x4000
    800019fa:	15fd                	addi	a1,a1,-1
    800019fc:	05b2                	slli	a1,a1,0xc
    800019fe:	8526                	mv	a0,s1
    80001a00:	fbcff0ef          	jal	ra,800011bc <uvmunmap>
    uvmfree(pagetable, 0);
    80001a04:	4581                	li	a1,0
    80001a06:	8526                	mv	a0,s1
    80001a08:	993ff0ef          	jal	ra,8000139a <uvmfree>
    return 0;
    80001a0c:	4481                	li	s1,0
    80001a0e:	b7e9                	j	800019d8 <proc_pagetable+0x4c>

0000000080001a10 <proc_freepagetable>:
{
    80001a10:	1101                	addi	sp,sp,-32
    80001a12:	ec06                	sd	ra,24(sp)
    80001a14:	e822                	sd	s0,16(sp)
    80001a16:	e426                	sd	s1,8(sp)
    80001a18:	e04a                	sd	s2,0(sp)
    80001a1a:	1000                	addi	s0,sp,32
    80001a1c:	84aa                	mv	s1,a0
    80001a1e:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a20:	4681                	li	a3,0
    80001a22:	4605                	li	a2,1
    80001a24:	040005b7          	lui	a1,0x4000
    80001a28:	15fd                	addi	a1,a1,-1
    80001a2a:	05b2                	slli	a1,a1,0xc
    80001a2c:	f90ff0ef          	jal	ra,800011bc <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a30:	4681                	li	a3,0
    80001a32:	4605                	li	a2,1
    80001a34:	020005b7          	lui	a1,0x2000
    80001a38:	15fd                	addi	a1,a1,-1
    80001a3a:	05b6                	slli	a1,a1,0xd
    80001a3c:	8526                	mv	a0,s1
    80001a3e:	f7eff0ef          	jal	ra,800011bc <uvmunmap>
  uvmfree(pagetable, sz);
    80001a42:	85ca                	mv	a1,s2
    80001a44:	8526                	mv	a0,s1
    80001a46:	955ff0ef          	jal	ra,8000139a <uvmfree>
}
    80001a4a:	60e2                	ld	ra,24(sp)
    80001a4c:	6442                	ld	s0,16(sp)
    80001a4e:	64a2                	ld	s1,8(sp)
    80001a50:	6902                	ld	s2,0(sp)
    80001a52:	6105                	addi	sp,sp,32
    80001a54:	8082                	ret

0000000080001a56 <freeproc>:
{
    80001a56:	1101                	addi	sp,sp,-32
    80001a58:	ec06                	sd	ra,24(sp)
    80001a5a:	e822                	sd	s0,16(sp)
    80001a5c:	e426                	sd	s1,8(sp)
    80001a5e:	1000                	addi	s0,sp,32
    80001a60:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001a62:	6d28                	ld	a0,88(a0)
    80001a64:	c119                	beqz	a0,80001a6a <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001a66:	fd9fe0ef          	jal	ra,80000a3e <kfree>
  p->trapframe = 0;
    80001a6a:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001a6e:	68a8                	ld	a0,80(s1)
    80001a70:	c501                	beqz	a0,80001a78 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001a72:	64ac                	ld	a1,72(s1)
    80001a74:	f9dff0ef          	jal	ra,80001a10 <proc_freepagetable>
  p->pagetable = 0;
    80001a78:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001a7c:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001a80:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001a84:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001a88:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001a8c:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001a90:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001a94:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001a98:	0004ac23          	sw	zero,24(s1)
}
    80001a9c:	60e2                	ld	ra,24(sp)
    80001a9e:	6442                	ld	s0,16(sp)
    80001aa0:	64a2                	ld	s1,8(sp)
    80001aa2:	6105                	addi	sp,sp,32
    80001aa4:	8082                	ret

0000000080001aa6 <allocproc>:
{
    80001aa6:	1101                	addi	sp,sp,-32
    80001aa8:	ec06                	sd	ra,24(sp)
    80001aaa:	e822                	sd	s0,16(sp)
    80001aac:	e426                	sd	s1,8(sp)
    80001aae:	e04a                	sd	s2,0(sp)
    80001ab0:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ab2:	0000e497          	auipc	s1,0xe
    80001ab6:	44648493          	addi	s1,s1,1094 # 8000fef8 <proc>
    80001aba:	00019917          	auipc	s2,0x19
    80001abe:	c3e90913          	addi	s2,s2,-962 # 8001a6f8 <tickslock>
    acquire(&p->lock);
    80001ac2:	8526                	mv	a0,s1
    80001ac4:	92aff0ef          	jal	ra,80000bee <acquire>
    if(p->state == UNUSED) {
    80001ac8:	4c9c                	lw	a5,24(s1)
    80001aca:	cb91                	beqz	a5,80001ade <allocproc+0x38>
      release(&p->lock);
    80001acc:	8526                	mv	a0,s1
    80001ace:	9b8ff0ef          	jal	ra,80000c86 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ad2:	2a048493          	addi	s1,s1,672
    80001ad6:	ff2496e3          	bne	s1,s2,80001ac2 <allocproc+0x1c>
  return 0;
    80001ada:	4481                	li	s1,0
    80001adc:	a8a5                	j	80001b54 <allocproc+0xae>
  p->pid = allocpid();
    80001ade:	e71ff0ef          	jal	ra,8000194e <allocpid>
    80001ae2:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001ae4:	4785                	li	a5,1
    80001ae6:	cc9c                	sw	a5,24(s1)
   p->interval = 0;
    80001ae8:	1604a423          	sw	zero,360(s1)
   p->curr_tick = 0;
    80001aec:	1604a623          	sw	zero,364(s1)
   p->pointer_to_handler = 0;
    80001af0:	1604b823          	sd	zero,368(s1)
   p->alarm = 0;
    80001af4:	1604ac23          	sw	zero,376(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001af8:	826ff0ef          	jal	ra,80000b1e <kalloc>
    80001afc:	892a                	mv	s2,a0
    80001afe:	eca8                	sd	a0,88(s1)
    80001b00:	c12d                	beqz	a0,80001b62 <allocproc+0xbc>
  p->alarm_trapframe = *(p->trapframe);
    80001b02:	87aa                	mv	a5,a0
    80001b04:	18048713          	addi	a4,s1,384
    80001b08:	12050913          	addi	s2,a0,288
    80001b0c:	6388                	ld	a0,0(a5)
    80001b0e:	678c                	ld	a1,8(a5)
    80001b10:	6b90                	ld	a2,16(a5)
    80001b12:	6f94                	ld	a3,24(a5)
    80001b14:	e308                	sd	a0,0(a4)
    80001b16:	e70c                	sd	a1,8(a4)
    80001b18:	eb10                	sd	a2,16(a4)
    80001b1a:	ef14                	sd	a3,24(a4)
    80001b1c:	02078793          	addi	a5,a5,32
    80001b20:	02070713          	addi	a4,a4,32 # 4000020 <_entry-0x7bffffe0>
    80001b24:	ff2794e3          	bne	a5,s2,80001b0c <allocproc+0x66>
  p->pagetable = proc_pagetable(p);
    80001b28:	8526                	mv	a0,s1
    80001b2a:	e63ff0ef          	jal	ra,8000198c <proc_pagetable>
    80001b2e:	892a                	mv	s2,a0
    80001b30:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b32:	c121                	beqz	a0,80001b72 <allocproc+0xcc>
  memset(&p->context, 0, sizeof(p->context));
    80001b34:	07000613          	li	a2,112
    80001b38:	4581                	li	a1,0
    80001b3a:	06048513          	addi	a0,s1,96
    80001b3e:	984ff0ef          	jal	ra,80000cc2 <memset>
  p->context.ra = (uint64)forkret;
    80001b42:	00000797          	auipc	a5,0x0
    80001b46:	d7478793          	addi	a5,a5,-652 # 800018b6 <forkret>
    80001b4a:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b4c:	60bc                	ld	a5,64(s1)
    80001b4e:	6705                	lui	a4,0x1
    80001b50:	97ba                	add	a5,a5,a4
    80001b52:	f4bc                	sd	a5,104(s1)
}
    80001b54:	8526                	mv	a0,s1
    80001b56:	60e2                	ld	ra,24(sp)
    80001b58:	6442                	ld	s0,16(sp)
    80001b5a:	64a2                	ld	s1,8(sp)
    80001b5c:	6902                	ld	s2,0(sp)
    80001b5e:	6105                	addi	sp,sp,32
    80001b60:	8082                	ret
    freeproc(p);
    80001b62:	8526                	mv	a0,s1
    80001b64:	ef3ff0ef          	jal	ra,80001a56 <freeproc>
    release(&p->lock);
    80001b68:	8526                	mv	a0,s1
    80001b6a:	91cff0ef          	jal	ra,80000c86 <release>
    return 0;
    80001b6e:	84ca                	mv	s1,s2
    80001b70:	b7d5                	j	80001b54 <allocproc+0xae>
    freeproc(p);
    80001b72:	8526                	mv	a0,s1
    80001b74:	ee3ff0ef          	jal	ra,80001a56 <freeproc>
    release(&p->lock);
    80001b78:	8526                	mv	a0,s1
    80001b7a:	90cff0ef          	jal	ra,80000c86 <release>
    return 0;
    80001b7e:	84ca                	mv	s1,s2
    80001b80:	bfd1                	j	80001b54 <allocproc+0xae>

0000000080001b82 <userinit>:
{
    80001b82:	1101                	addi	sp,sp,-32
    80001b84:	ec06                	sd	ra,24(sp)
    80001b86:	e822                	sd	s0,16(sp)
    80001b88:	e426                	sd	s1,8(sp)
    80001b8a:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b8c:	f1bff0ef          	jal	ra,80001aa6 <allocproc>
    80001b90:	84aa                	mv	s1,a0
  initproc = p;
    80001b92:	00006797          	auipc	a5,0x6
    80001b96:	e0a7b323          	sd	a0,-506(a5) # 80007998 <initproc>
  p->cwd = namei("/");
    80001b9a:	00005517          	auipc	a0,0x5
    80001b9e:	60e50513          	addi	a0,a0,1550 # 800071a8 <digits+0x170>
    80001ba2:	62f010ef          	jal	ra,800039d0 <namei>
    80001ba6:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001baa:	478d                	li	a5,3
    80001bac:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bae:	8526                	mv	a0,s1
    80001bb0:	8d6ff0ef          	jal	ra,80000c86 <release>
}
    80001bb4:	60e2                	ld	ra,24(sp)
    80001bb6:	6442                	ld	s0,16(sp)
    80001bb8:	64a2                	ld	s1,8(sp)
    80001bba:	6105                	addi	sp,sp,32
    80001bbc:	8082                	ret

0000000080001bbe <shrinkproc>:
{
    80001bbe:	1101                	addi	sp,sp,-32
    80001bc0:	ec06                	sd	ra,24(sp)
    80001bc2:	e822                	sd	s0,16(sp)
    80001bc4:	e426                	sd	s1,8(sp)
    80001bc6:	e04a                	sd	s2,0(sp)
    80001bc8:	1000                	addi	s0,sp,32
    80001bca:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001bcc:	cbbff0ef          	jal	ra,80001886 <myproc>
  if(n > p->sz)
    80001bd0:	652c                	ld	a1,72(a0)
    80001bd2:	0325e063          	bltu	a1,s2,80001bf2 <shrinkproc+0x34>
    80001bd6:	84aa                	mv	s1,a0
  sz = uvmdealloc(p->pagetable, sz, sz - n);
    80001bd8:	41258633          	sub	a2,a1,s2
    80001bdc:	6928                	ld	a0,80(a0)
    80001bde:	e80ff0ef          	jal	ra,8000125e <uvmdealloc>
  p->sz = sz;
    80001be2:	e4a8                	sd	a0,72(s1)
  return 0;
    80001be4:	4501                	li	a0,0
}
    80001be6:	60e2                	ld	ra,24(sp)
    80001be8:	6442                	ld	s0,16(sp)
    80001bea:	64a2                	ld	s1,8(sp)
    80001bec:	6902                	ld	s2,0(sp)
    80001bee:	6105                	addi	sp,sp,32
    80001bf0:	8082                	ret
    return -1;
    80001bf2:	557d                	li	a0,-1
    80001bf4:	bfcd                	j	80001be6 <shrinkproc+0x28>

0000000080001bf6 <fork>:
{
    80001bf6:	7139                	addi	sp,sp,-64
    80001bf8:	fc06                	sd	ra,56(sp)
    80001bfa:	f822                	sd	s0,48(sp)
    80001bfc:	f426                	sd	s1,40(sp)
    80001bfe:	f04a                	sd	s2,32(sp)
    80001c00:	ec4e                	sd	s3,24(sp)
    80001c02:	e852                	sd	s4,16(sp)
    80001c04:	e456                	sd	s5,8(sp)
    80001c06:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c08:	c7fff0ef          	jal	ra,80001886 <myproc>
    80001c0c:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c0e:	e99ff0ef          	jal	ra,80001aa6 <allocproc>
    80001c12:	0e050a63          	beqz	a0,80001d06 <fork+0x110>
    80001c16:	89aa                	mv	s3,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c18:	048ab603          	ld	a2,72(s5)
    80001c1c:	692c                	ld	a1,80(a0)
    80001c1e:	050ab503          	ld	a0,80(s5)
    80001c22:	fa8ff0ef          	jal	ra,800013ca <uvmcopy>
    80001c26:	04054c63          	bltz	a0,80001c7e <fork+0x88>
  np->sz = p->sz;
    80001c2a:	048ab783          	ld	a5,72(s5)
    80001c2e:	04f9b423          	sd	a5,72(s3)
 np->trace_mask = p->trace_mask;
    80001c32:	034aa783          	lw	a5,52(s5)
    80001c36:	02f9aa23          	sw	a5,52(s3)
  *(np->trapframe) = *(p->trapframe);
    80001c3a:	058ab683          	ld	a3,88(s5)
    80001c3e:	87b6                	mv	a5,a3
    80001c40:	0589b703          	ld	a4,88(s3)
    80001c44:	12068693          	addi	a3,a3,288
    80001c48:	0007b803          	ld	a6,0(a5)
    80001c4c:	6788                	ld	a0,8(a5)
    80001c4e:	6b8c                	ld	a1,16(a5)
    80001c50:	6f90                	ld	a2,24(a5)
    80001c52:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c56:	e708                	sd	a0,8(a4)
    80001c58:	eb0c                	sd	a1,16(a4)
    80001c5a:	ef10                	sd	a2,24(a4)
    80001c5c:	02078793          	addi	a5,a5,32
    80001c60:	02070713          	addi	a4,a4,32
    80001c64:	fed792e3          	bne	a5,a3,80001c48 <fork+0x52>
  np->trapframe->a0 = 0;
    80001c68:	0589b783          	ld	a5,88(s3)
    80001c6c:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001c70:	0d0a8493          	addi	s1,s5,208
    80001c74:	0d098913          	addi	s2,s3,208
    80001c78:	150a8a13          	addi	s4,s5,336
    80001c7c:	a829                	j	80001c96 <fork+0xa0>
    freeproc(np);
    80001c7e:	854e                	mv	a0,s3
    80001c80:	dd7ff0ef          	jal	ra,80001a56 <freeproc>
    release(&np->lock);
    80001c84:	854e                	mv	a0,s3
    80001c86:	800ff0ef          	jal	ra,80000c86 <release>
    return -1;
    80001c8a:	597d                	li	s2,-1
    80001c8c:	a09d                	j	80001cf2 <fork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001c8e:	04a1                	addi	s1,s1,8
    80001c90:	0921                	addi	s2,s2,8
    80001c92:	01448963          	beq	s1,s4,80001ca4 <fork+0xae>
    if(p->ofile[i])
    80001c96:	6088                	ld	a0,0(s1)
    80001c98:	d97d                	beqz	a0,80001c8e <fork+0x98>
      np->ofile[i] = filedup(p->ofile[i]);
    80001c9a:	2e8020ef          	jal	ra,80003f82 <filedup>
    80001c9e:	00a93023          	sd	a0,0(s2)
    80001ca2:	b7f5                	j	80001c8e <fork+0x98>
  np->cwd = idup(p->cwd);
    80001ca4:	150ab503          	ld	a0,336(s5)
    80001ca8:	640010ef          	jal	ra,800032e8 <idup>
    80001cac:	14a9b823          	sd	a0,336(s3)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cb0:	4641                	li	a2,16
    80001cb2:	158a8593          	addi	a1,s5,344
    80001cb6:	15898513          	addi	a0,s3,344
    80001cba:	94eff0ef          	jal	ra,80000e08 <safestrcpy>
  pid = np->pid;
    80001cbe:	0309a903          	lw	s2,48(s3)
  release(&np->lock);
    80001cc2:	854e                	mv	a0,s3
    80001cc4:	fc3fe0ef          	jal	ra,80000c86 <release>
  acquire(&wait_lock);
    80001cc8:	0000e497          	auipc	s1,0xe
    80001ccc:	e1848493          	addi	s1,s1,-488 # 8000fae0 <wait_lock>
    80001cd0:	8526                	mv	a0,s1
    80001cd2:	f1dfe0ef          	jal	ra,80000bee <acquire>
  np->parent = p;
    80001cd6:	0359bc23          	sd	s5,56(s3)
  release(&wait_lock);
    80001cda:	8526                	mv	a0,s1
    80001cdc:	fabfe0ef          	jal	ra,80000c86 <release>
  acquire(&np->lock);
    80001ce0:	854e                	mv	a0,s3
    80001ce2:	f0dfe0ef          	jal	ra,80000bee <acquire>
  np->state = RUNNABLE;
    80001ce6:	478d                	li	a5,3
    80001ce8:	00f9ac23          	sw	a5,24(s3)
  release(&np->lock);
    80001cec:	854e                	mv	a0,s3
    80001cee:	f99fe0ef          	jal	ra,80000c86 <release>
}
    80001cf2:	854a                	mv	a0,s2
    80001cf4:	70e2                	ld	ra,56(sp)
    80001cf6:	7442                	ld	s0,48(sp)
    80001cf8:	74a2                	ld	s1,40(sp)
    80001cfa:	7902                	ld	s2,32(sp)
    80001cfc:	69e2                	ld	s3,24(sp)
    80001cfe:	6a42                	ld	s4,16(sp)
    80001d00:	6aa2                	ld	s5,8(sp)
    80001d02:	6121                	addi	sp,sp,64
    80001d04:	8082                	ret
    return -1;
    80001d06:	597d                	li	s2,-1
    80001d08:	b7ed                	j	80001cf2 <fork+0xfc>

0000000080001d0a <scheduler>:
{
    80001d0a:	715d                	addi	sp,sp,-80
    80001d0c:	e486                	sd	ra,72(sp)
    80001d0e:	e0a2                	sd	s0,64(sp)
    80001d10:	fc26                	sd	s1,56(sp)
    80001d12:	f84a                	sd	s2,48(sp)
    80001d14:	f44e                	sd	s3,40(sp)
    80001d16:	f052                	sd	s4,32(sp)
    80001d18:	ec56                	sd	s5,24(sp)
    80001d1a:	e85a                	sd	s6,16(sp)
    80001d1c:	e45e                	sd	s7,8(sp)
    80001d1e:	e062                	sd	s8,0(sp)
    80001d20:	0880                	addi	s0,sp,80
    80001d22:	8792                	mv	a5,tp
  int id = r_tp();
    80001d24:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d26:	00779b13          	slli	s6,a5,0x7
    80001d2a:	0000e717          	auipc	a4,0xe
    80001d2e:	d9e70713          	addi	a4,a4,-610 # 8000fac8 <pid_lock>
    80001d32:	975a                	add	a4,a4,s6
    80001d34:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d38:	0000e717          	auipc	a4,0xe
    80001d3c:	dc870713          	addi	a4,a4,-568 # 8000fb00 <cpus+0x8>
    80001d40:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001d42:	4c11                	li	s8,4
        c->proc = p;
    80001d44:	079e                	slli	a5,a5,0x7
    80001d46:	0000ea17          	auipc	s4,0xe
    80001d4a:	d82a0a13          	addi	s4,s4,-638 # 8000fac8 <pid_lock>
    80001d4e:	9a3e                	add	s4,s4,a5
        found = 1;
    80001d50:	4b85                	li	s7,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d52:	00019997          	auipc	s3,0x19
    80001d56:	9a698993          	addi	s3,s3,-1626 # 8001a6f8 <tickslock>
    80001d5a:	a83d                	j	80001d98 <scheduler+0x8e>
      release(&p->lock);
    80001d5c:	8526                	mv	a0,s1
    80001d5e:	f29fe0ef          	jal	ra,80000c86 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d62:	2a048493          	addi	s1,s1,672
    80001d66:	03348563          	beq	s1,s3,80001d90 <scheduler+0x86>
      acquire(&p->lock);
    80001d6a:	8526                	mv	a0,s1
    80001d6c:	e83fe0ef          	jal	ra,80000bee <acquire>
      if(p->state == RUNNABLE) {
    80001d70:	4c9c                	lw	a5,24(s1)
    80001d72:	ff2795e3          	bne	a5,s2,80001d5c <scheduler+0x52>
        p->state = RUNNING;
    80001d76:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001d7a:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001d7e:	06048593          	addi	a1,s1,96
    80001d82:	855a                	mv	a0,s6
    80001d84:	5b2000ef          	jal	ra,80002336 <swtch>
        c->proc = 0;
    80001d88:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001d8c:	8ade                	mv	s5,s7
    80001d8e:	b7f9                	j	80001d5c <scheduler+0x52>
    if(found == 0) {
    80001d90:	000a9463          	bnez	s5,80001d98 <scheduler+0x8e>
      asm volatile("wfi");
    80001d94:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001d98:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001d9c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001da0:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001da4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001da8:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001daa:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001dae:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001db0:	0000e497          	auipc	s1,0xe
    80001db4:	14848493          	addi	s1,s1,328 # 8000fef8 <proc>
      if(p->state == RUNNABLE) {
    80001db8:	490d                	li	s2,3
    80001dba:	bf45                	j	80001d6a <scheduler+0x60>

0000000080001dbc <sched>:
{
    80001dbc:	7179                	addi	sp,sp,-48
    80001dbe:	f406                	sd	ra,40(sp)
    80001dc0:	f022                	sd	s0,32(sp)
    80001dc2:	ec26                	sd	s1,24(sp)
    80001dc4:	e84a                	sd	s2,16(sp)
    80001dc6:	e44e                	sd	s3,8(sp)
    80001dc8:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001dca:	abdff0ef          	jal	ra,80001886 <myproc>
    80001dce:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001dd0:	db5fe0ef          	jal	ra,80000b84 <holding>
    80001dd4:	c92d                	beqz	a0,80001e46 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001dd6:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001dd8:	2781                	sext.w	a5,a5
    80001dda:	079e                	slli	a5,a5,0x7
    80001ddc:	0000e717          	auipc	a4,0xe
    80001de0:	cec70713          	addi	a4,a4,-788 # 8000fac8 <pid_lock>
    80001de4:	97ba                	add	a5,a5,a4
    80001de6:	0a87a703          	lw	a4,168(a5)
    80001dea:	4785                	li	a5,1
    80001dec:	06f71363          	bne	a4,a5,80001e52 <sched+0x96>
  if(p->state == RUNNING)
    80001df0:	4c98                	lw	a4,24(s1)
    80001df2:	4791                	li	a5,4
    80001df4:	06f70563          	beq	a4,a5,80001e5e <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001df8:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001dfc:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001dfe:	e7b5                	bnez	a5,80001e6a <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e00:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e02:	0000e917          	auipc	s2,0xe
    80001e06:	cc690913          	addi	s2,s2,-826 # 8000fac8 <pid_lock>
    80001e0a:	2781                	sext.w	a5,a5
    80001e0c:	079e                	slli	a5,a5,0x7
    80001e0e:	97ca                	add	a5,a5,s2
    80001e10:	0ac7a983          	lw	s3,172(a5)
    80001e14:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e16:	2781                	sext.w	a5,a5
    80001e18:	079e                	slli	a5,a5,0x7
    80001e1a:	0000e597          	auipc	a1,0xe
    80001e1e:	ce658593          	addi	a1,a1,-794 # 8000fb00 <cpus+0x8>
    80001e22:	95be                	add	a1,a1,a5
    80001e24:	06048513          	addi	a0,s1,96
    80001e28:	50e000ef          	jal	ra,80002336 <swtch>
    80001e2c:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e2e:	2781                	sext.w	a5,a5
    80001e30:	079e                	slli	a5,a5,0x7
    80001e32:	97ca                	add	a5,a5,s2
    80001e34:	0b37a623          	sw	s3,172(a5)
}
    80001e38:	70a2                	ld	ra,40(sp)
    80001e3a:	7402                	ld	s0,32(sp)
    80001e3c:	64e2                	ld	s1,24(sp)
    80001e3e:	6942                	ld	s2,16(sp)
    80001e40:	69a2                	ld	s3,8(sp)
    80001e42:	6145                	addi	sp,sp,48
    80001e44:	8082                	ret
    panic("sched p->lock");
    80001e46:	00005517          	auipc	a0,0x5
    80001e4a:	36a50513          	addi	a0,a0,874 # 800071b0 <digits+0x178>
    80001e4e:	91bfe0ef          	jal	ra,80000768 <panic>
    panic("sched locks");
    80001e52:	00005517          	auipc	a0,0x5
    80001e56:	36e50513          	addi	a0,a0,878 # 800071c0 <digits+0x188>
    80001e5a:	90ffe0ef          	jal	ra,80000768 <panic>
    panic("sched RUNNING");
    80001e5e:	00005517          	auipc	a0,0x5
    80001e62:	37250513          	addi	a0,a0,882 # 800071d0 <digits+0x198>
    80001e66:	903fe0ef          	jal	ra,80000768 <panic>
    panic("sched interruptible");
    80001e6a:	00005517          	auipc	a0,0x5
    80001e6e:	37650513          	addi	a0,a0,886 # 800071e0 <digits+0x1a8>
    80001e72:	8f7fe0ef          	jal	ra,80000768 <panic>

0000000080001e76 <yield>:
{
    80001e76:	1101                	addi	sp,sp,-32
    80001e78:	ec06                	sd	ra,24(sp)
    80001e7a:	e822                	sd	s0,16(sp)
    80001e7c:	e426                	sd	s1,8(sp)
    80001e7e:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001e80:	a07ff0ef          	jal	ra,80001886 <myproc>
    80001e84:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001e86:	d69fe0ef          	jal	ra,80000bee <acquire>
  p->state = RUNNABLE;
    80001e8a:	478d                	li	a5,3
    80001e8c:	cc9c                	sw	a5,24(s1)
  sched();
    80001e8e:	f2fff0ef          	jal	ra,80001dbc <sched>
  release(&p->lock);
    80001e92:	8526                	mv	a0,s1
    80001e94:	df3fe0ef          	jal	ra,80000c86 <release>
}
    80001e98:	60e2                	ld	ra,24(sp)
    80001e9a:	6442                	ld	s0,16(sp)
    80001e9c:	64a2                	ld	s1,8(sp)
    80001e9e:	6105                	addi	sp,sp,32
    80001ea0:	8082                	ret

0000000080001ea2 <sleep>:

// Sleep on wait channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001ea2:	7179                	addi	sp,sp,-48
    80001ea4:	f406                	sd	ra,40(sp)
    80001ea6:	f022                	sd	s0,32(sp)
    80001ea8:	ec26                	sd	s1,24(sp)
    80001eaa:	e84a                	sd	s2,16(sp)
    80001eac:	e44e                	sd	s3,8(sp)
    80001eae:	1800                	addi	s0,sp,48
    80001eb0:	89aa                	mv	s3,a0
    80001eb2:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001eb4:	9d3ff0ef          	jal	ra,80001886 <myproc>
    80001eb8:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001eba:	d35fe0ef          	jal	ra,80000bee <acquire>
  release(lk);
    80001ebe:	854a                	mv	a0,s2
    80001ec0:	dc7fe0ef          	jal	ra,80000c86 <release>

  // Go to sleep.
  p->chan = chan;
    80001ec4:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001ec8:	4789                	li	a5,2
    80001eca:	cc9c                	sw	a5,24(s1)

  sched();
    80001ecc:	ef1ff0ef          	jal	ra,80001dbc <sched>

  // Tidy up.
  p->chan = 0;
    80001ed0:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001ed4:	8526                	mv	a0,s1
    80001ed6:	db1fe0ef          	jal	ra,80000c86 <release>
  acquire(lk);
    80001eda:	854a                	mv	a0,s2
    80001edc:	d13fe0ef          	jal	ra,80000bee <acquire>
}
    80001ee0:	70a2                	ld	ra,40(sp)
    80001ee2:	7402                	ld	s0,32(sp)
    80001ee4:	64e2                	ld	s1,24(sp)
    80001ee6:	6942                	ld	s2,16(sp)
    80001ee8:	69a2                	ld	s3,8(sp)
    80001eea:	6145                	addi	sp,sp,48
    80001eec:	8082                	ret

0000000080001eee <wakeup>:

// Wake up all processes sleeping on wait channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001eee:	7139                	addi	sp,sp,-64
    80001ef0:	fc06                	sd	ra,56(sp)
    80001ef2:	f822                	sd	s0,48(sp)
    80001ef4:	f426                	sd	s1,40(sp)
    80001ef6:	f04a                	sd	s2,32(sp)
    80001ef8:	ec4e                	sd	s3,24(sp)
    80001efa:	e852                	sd	s4,16(sp)
    80001efc:	e456                	sd	s5,8(sp)
    80001efe:	0080                	addi	s0,sp,64
    80001f00:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f02:	0000e497          	auipc	s1,0xe
    80001f06:	ff648493          	addi	s1,s1,-10 # 8000fef8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f0a:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f0c:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f0e:	00018917          	auipc	s2,0x18
    80001f12:	7ea90913          	addi	s2,s2,2026 # 8001a6f8 <tickslock>
    80001f16:	a801                	j	80001f26 <wakeup+0x38>
      }
      release(&p->lock);
    80001f18:	8526                	mv	a0,s1
    80001f1a:	d6dfe0ef          	jal	ra,80000c86 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f1e:	2a048493          	addi	s1,s1,672
    80001f22:	03248263          	beq	s1,s2,80001f46 <wakeup+0x58>
    if(p != myproc()){
    80001f26:	961ff0ef          	jal	ra,80001886 <myproc>
    80001f2a:	fea48ae3          	beq	s1,a0,80001f1e <wakeup+0x30>
      acquire(&p->lock);
    80001f2e:	8526                	mv	a0,s1
    80001f30:	cbffe0ef          	jal	ra,80000bee <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001f34:	4c9c                	lw	a5,24(s1)
    80001f36:	ff3791e3          	bne	a5,s3,80001f18 <wakeup+0x2a>
    80001f3a:	709c                	ld	a5,32(s1)
    80001f3c:	fd479ee3          	bne	a5,s4,80001f18 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001f40:	0154ac23          	sw	s5,24(s1)
    80001f44:	bfd1                	j	80001f18 <wakeup+0x2a>
    }
  }
}
    80001f46:	70e2                	ld	ra,56(sp)
    80001f48:	7442                	ld	s0,48(sp)
    80001f4a:	74a2                	ld	s1,40(sp)
    80001f4c:	7902                	ld	s2,32(sp)
    80001f4e:	69e2                	ld	s3,24(sp)
    80001f50:	6a42                	ld	s4,16(sp)
    80001f52:	6aa2                	ld	s5,8(sp)
    80001f54:	6121                	addi	sp,sp,64
    80001f56:	8082                	ret

0000000080001f58 <reparent>:
{
    80001f58:	7179                	addi	sp,sp,-48
    80001f5a:	f406                	sd	ra,40(sp)
    80001f5c:	f022                	sd	s0,32(sp)
    80001f5e:	ec26                	sd	s1,24(sp)
    80001f60:	e84a                	sd	s2,16(sp)
    80001f62:	e44e                	sd	s3,8(sp)
    80001f64:	e052                	sd	s4,0(sp)
    80001f66:	1800                	addi	s0,sp,48
    80001f68:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001f6a:	0000e497          	auipc	s1,0xe
    80001f6e:	f8e48493          	addi	s1,s1,-114 # 8000fef8 <proc>
      pp->parent = initproc;
    80001f72:	00006a17          	auipc	s4,0x6
    80001f76:	a26a0a13          	addi	s4,s4,-1498 # 80007998 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001f7a:	00018997          	auipc	s3,0x18
    80001f7e:	77e98993          	addi	s3,s3,1918 # 8001a6f8 <tickslock>
    80001f82:	a029                	j	80001f8c <reparent+0x34>
    80001f84:	2a048493          	addi	s1,s1,672
    80001f88:	01348b63          	beq	s1,s3,80001f9e <reparent+0x46>
    if(pp->parent == p){
    80001f8c:	7c9c                	ld	a5,56(s1)
    80001f8e:	ff279be3          	bne	a5,s2,80001f84 <reparent+0x2c>
      pp->parent = initproc;
    80001f92:	000a3503          	ld	a0,0(s4)
    80001f96:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001f98:	f57ff0ef          	jal	ra,80001eee <wakeup>
    80001f9c:	b7e5                	j	80001f84 <reparent+0x2c>
}
    80001f9e:	70a2                	ld	ra,40(sp)
    80001fa0:	7402                	ld	s0,32(sp)
    80001fa2:	64e2                	ld	s1,24(sp)
    80001fa4:	6942                	ld	s2,16(sp)
    80001fa6:	69a2                	ld	s3,8(sp)
    80001fa8:	6a02                	ld	s4,0(sp)
    80001faa:	6145                	addi	sp,sp,48
    80001fac:	8082                	ret

0000000080001fae <exit>:
{
    80001fae:	7179                	addi	sp,sp,-48
    80001fb0:	f406                	sd	ra,40(sp)
    80001fb2:	f022                	sd	s0,32(sp)
    80001fb4:	ec26                	sd	s1,24(sp)
    80001fb6:	e84a                	sd	s2,16(sp)
    80001fb8:	e44e                	sd	s3,8(sp)
    80001fba:	e052                	sd	s4,0(sp)
    80001fbc:	1800                	addi	s0,sp,48
    80001fbe:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001fc0:	8c7ff0ef          	jal	ra,80001886 <myproc>
    80001fc4:	89aa                	mv	s3,a0
  if(p == initproc)
    80001fc6:	00006797          	auipc	a5,0x6
    80001fca:	9d27b783          	ld	a5,-1582(a5) # 80007998 <initproc>
    80001fce:	0d050493          	addi	s1,a0,208
    80001fd2:	15050913          	addi	s2,a0,336
    80001fd6:	00a79f63          	bne	a5,a0,80001ff4 <exit+0x46>
    panic("init exiting");
    80001fda:	00005517          	auipc	a0,0x5
    80001fde:	21e50513          	addi	a0,a0,542 # 800071f8 <digits+0x1c0>
    80001fe2:	f86fe0ef          	jal	ra,80000768 <panic>
      fileclose(f);
    80001fe6:	7e3010ef          	jal	ra,80003fc8 <fileclose>
      p->ofile[fd] = 0;
    80001fea:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    80001fee:	04a1                	addi	s1,s1,8
    80001ff0:	01248563          	beq	s1,s2,80001ffa <exit+0x4c>
    if(p->ofile[fd]){
    80001ff4:	6088                	ld	a0,0(s1)
    80001ff6:	f965                	bnez	a0,80001fe6 <exit+0x38>
    80001ff8:	bfdd                	j	80001fee <exit+0x40>
  begin_op();
    80001ffa:	3b3010ef          	jal	ra,80003bac <begin_op>
  iput(p->cwd);
    80001ffe:	1509b503          	ld	a0,336(s3)
    80002002:	49a010ef          	jal	ra,8000349c <iput>
  end_op();
    80002006:	417010ef          	jal	ra,80003c1c <end_op>
  p->cwd = 0;
    8000200a:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000200e:	0000e497          	auipc	s1,0xe
    80002012:	ad248493          	addi	s1,s1,-1326 # 8000fae0 <wait_lock>
    80002016:	8526                	mv	a0,s1
    80002018:	bd7fe0ef          	jal	ra,80000bee <acquire>
  reparent(p);
    8000201c:	854e                	mv	a0,s3
    8000201e:	f3bff0ef          	jal	ra,80001f58 <reparent>
  wakeup(p->parent);
    80002022:	0389b503          	ld	a0,56(s3)
    80002026:	ec9ff0ef          	jal	ra,80001eee <wakeup>
  acquire(&p->lock);
    8000202a:	854e                	mv	a0,s3
    8000202c:	bc3fe0ef          	jal	ra,80000bee <acquire>
  p->xstate = status;
    80002030:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002034:	4795                	li	a5,5
    80002036:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    8000203a:	8526                	mv	a0,s1
    8000203c:	c4bfe0ef          	jal	ra,80000c86 <release>
  sched();
    80002040:	d7dff0ef          	jal	ra,80001dbc <sched>
  panic("zombie exit");
    80002044:	00005517          	auipc	a0,0x5
    80002048:	1c450513          	addi	a0,a0,452 # 80007208 <digits+0x1d0>
    8000204c:	f1cfe0ef          	jal	ra,80000768 <panic>

0000000080002050 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002050:	7179                	addi	sp,sp,-48
    80002052:	f406                	sd	ra,40(sp)
    80002054:	f022                	sd	s0,32(sp)
    80002056:	ec26                	sd	s1,24(sp)
    80002058:	e84a                	sd	s2,16(sp)
    8000205a:	e44e                	sd	s3,8(sp)
    8000205c:	1800                	addi	s0,sp,48
    8000205e:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002060:	0000e497          	auipc	s1,0xe
    80002064:	e9848493          	addi	s1,s1,-360 # 8000fef8 <proc>
    80002068:	00018997          	auipc	s3,0x18
    8000206c:	69098993          	addi	s3,s3,1680 # 8001a6f8 <tickslock>
    acquire(&p->lock);
    80002070:	8526                	mv	a0,s1
    80002072:	b7dfe0ef          	jal	ra,80000bee <acquire>
    if(p->pid == pid){
    80002076:	589c                	lw	a5,48(s1)
    80002078:	01278b63          	beq	a5,s2,8000208e <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000207c:	8526                	mv	a0,s1
    8000207e:	c09fe0ef          	jal	ra,80000c86 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002082:	2a048493          	addi	s1,s1,672
    80002086:	ff3495e3          	bne	s1,s3,80002070 <kill+0x20>
  }
  return -1;
    8000208a:	557d                	li	a0,-1
    8000208c:	a819                	j	800020a2 <kill+0x52>
      p->killed = 1;
    8000208e:	4785                	li	a5,1
    80002090:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002092:	4c98                	lw	a4,24(s1)
    80002094:	4789                	li	a5,2
    80002096:	00f70d63          	beq	a4,a5,800020b0 <kill+0x60>
      release(&p->lock);
    8000209a:	8526                	mv	a0,s1
    8000209c:	bebfe0ef          	jal	ra,80000c86 <release>
      return 0;
    800020a0:	4501                	li	a0,0
}
    800020a2:	70a2                	ld	ra,40(sp)
    800020a4:	7402                	ld	s0,32(sp)
    800020a6:	64e2                	ld	s1,24(sp)
    800020a8:	6942                	ld	s2,16(sp)
    800020aa:	69a2                	ld	s3,8(sp)
    800020ac:	6145                	addi	sp,sp,48
    800020ae:	8082                	ret
        p->state = RUNNABLE;
    800020b0:	478d                	li	a5,3
    800020b2:	cc9c                	sw	a5,24(s1)
    800020b4:	b7dd                	j	8000209a <kill+0x4a>

00000000800020b6 <setkilled>:

void
setkilled(struct proc *p)
{
    800020b6:	1101                	addi	sp,sp,-32
    800020b8:	ec06                	sd	ra,24(sp)
    800020ba:	e822                	sd	s0,16(sp)
    800020bc:	e426                	sd	s1,8(sp)
    800020be:	1000                	addi	s0,sp,32
    800020c0:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020c2:	b2dfe0ef          	jal	ra,80000bee <acquire>
  p->killed = 1;
    800020c6:	4785                	li	a5,1
    800020c8:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800020ca:	8526                	mv	a0,s1
    800020cc:	bbbfe0ef          	jal	ra,80000c86 <release>
}
    800020d0:	60e2                	ld	ra,24(sp)
    800020d2:	6442                	ld	s0,16(sp)
    800020d4:	64a2                	ld	s1,8(sp)
    800020d6:	6105                	addi	sp,sp,32
    800020d8:	8082                	ret

00000000800020da <killed>:

int
killed(struct proc *p)
{
    800020da:	1101                	addi	sp,sp,-32
    800020dc:	ec06                	sd	ra,24(sp)
    800020de:	e822                	sd	s0,16(sp)
    800020e0:	e426                	sd	s1,8(sp)
    800020e2:	e04a                	sd	s2,0(sp)
    800020e4:	1000                	addi	s0,sp,32
    800020e6:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800020e8:	b07fe0ef          	jal	ra,80000bee <acquire>
  k = p->killed;
    800020ec:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800020f0:	8526                	mv	a0,s1
    800020f2:	b95fe0ef          	jal	ra,80000c86 <release>
  return k;
}
    800020f6:	854a                	mv	a0,s2
    800020f8:	60e2                	ld	ra,24(sp)
    800020fa:	6442                	ld	s0,16(sp)
    800020fc:	64a2                	ld	s1,8(sp)
    800020fe:	6902                	ld	s2,0(sp)
    80002100:	6105                	addi	sp,sp,32
    80002102:	8082                	ret

0000000080002104 <wait>:
{
    80002104:	715d                	addi	sp,sp,-80
    80002106:	e486                	sd	ra,72(sp)
    80002108:	e0a2                	sd	s0,64(sp)
    8000210a:	fc26                	sd	s1,56(sp)
    8000210c:	f84a                	sd	s2,48(sp)
    8000210e:	f44e                	sd	s3,40(sp)
    80002110:	f052                	sd	s4,32(sp)
    80002112:	ec56                	sd	s5,24(sp)
    80002114:	e85a                	sd	s6,16(sp)
    80002116:	e45e                	sd	s7,8(sp)
    80002118:	e062                	sd	s8,0(sp)
    8000211a:	0880                	addi	s0,sp,80
    8000211c:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    8000211e:	f68ff0ef          	jal	ra,80001886 <myproc>
    80002122:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002124:	0000e517          	auipc	a0,0xe
    80002128:	9bc50513          	addi	a0,a0,-1604 # 8000fae0 <wait_lock>
    8000212c:	ac3fe0ef          	jal	ra,80000bee <acquire>
    havekids = 0;
    80002130:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    80002132:	4a15                	li	s4,5
        havekids = 1;
    80002134:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002136:	00018997          	auipc	s3,0x18
    8000213a:	5c298993          	addi	s3,s3,1474 # 8001a6f8 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000213e:	0000ec17          	auipc	s8,0xe
    80002142:	9a2c0c13          	addi	s8,s8,-1630 # 8000fae0 <wait_lock>
    havekids = 0;
    80002146:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002148:	0000e497          	auipc	s1,0xe
    8000214c:	db048493          	addi	s1,s1,-592 # 8000fef8 <proc>
    80002150:	a899                	j	800021a6 <wait+0xa2>
          pid = pp->pid;
    80002152:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002156:	000b0c63          	beqz	s6,8000216e <wait+0x6a>
    8000215a:	4691                	li	a3,4
    8000215c:	02c48613          	addi	a2,s1,44
    80002160:	85da                	mv	a1,s6
    80002162:	05093503          	ld	a0,80(s2)
    80002166:	c6eff0ef          	jal	ra,800015d4 <copyout>
    8000216a:	00054f63          	bltz	a0,80002188 <wait+0x84>
          freeproc(pp);
    8000216e:	8526                	mv	a0,s1
    80002170:	8e7ff0ef          	jal	ra,80001a56 <freeproc>
          release(&pp->lock);
    80002174:	8526                	mv	a0,s1
    80002176:	b11fe0ef          	jal	ra,80000c86 <release>
          release(&wait_lock);
    8000217a:	0000e517          	auipc	a0,0xe
    8000217e:	96650513          	addi	a0,a0,-1690 # 8000fae0 <wait_lock>
    80002182:	b05fe0ef          	jal	ra,80000c86 <release>
          return pid;
    80002186:	a891                	j	800021da <wait+0xd6>
            release(&pp->lock);
    80002188:	8526                	mv	a0,s1
    8000218a:	afdfe0ef          	jal	ra,80000c86 <release>
            release(&wait_lock);
    8000218e:	0000e517          	auipc	a0,0xe
    80002192:	95250513          	addi	a0,a0,-1710 # 8000fae0 <wait_lock>
    80002196:	af1fe0ef          	jal	ra,80000c86 <release>
            return -1;
    8000219a:	59fd                	li	s3,-1
    8000219c:	a83d                	j	800021da <wait+0xd6>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000219e:	2a048493          	addi	s1,s1,672
    800021a2:	03348063          	beq	s1,s3,800021c2 <wait+0xbe>
      if(pp->parent == p){
    800021a6:	7c9c                	ld	a5,56(s1)
    800021a8:	ff279be3          	bne	a5,s2,8000219e <wait+0x9a>
        acquire(&pp->lock);
    800021ac:	8526                	mv	a0,s1
    800021ae:	a41fe0ef          	jal	ra,80000bee <acquire>
        if(pp->state == ZOMBIE){
    800021b2:	4c9c                	lw	a5,24(s1)
    800021b4:	f9478fe3          	beq	a5,s4,80002152 <wait+0x4e>
        release(&pp->lock);
    800021b8:	8526                	mv	a0,s1
    800021ba:	acdfe0ef          	jal	ra,80000c86 <release>
        havekids = 1;
    800021be:	8756                	mv	a4,s5
    800021c0:	bff9                	j	8000219e <wait+0x9a>
    if(!havekids || killed(p)){
    800021c2:	c709                	beqz	a4,800021cc <wait+0xc8>
    800021c4:	854a                	mv	a0,s2
    800021c6:	f15ff0ef          	jal	ra,800020da <killed>
    800021ca:	c50d                	beqz	a0,800021f4 <wait+0xf0>
      release(&wait_lock);
    800021cc:	0000e517          	auipc	a0,0xe
    800021d0:	91450513          	addi	a0,a0,-1772 # 8000fae0 <wait_lock>
    800021d4:	ab3fe0ef          	jal	ra,80000c86 <release>
      return -1;
    800021d8:	59fd                	li	s3,-1
}
    800021da:	854e                	mv	a0,s3
    800021dc:	60a6                	ld	ra,72(sp)
    800021de:	6406                	ld	s0,64(sp)
    800021e0:	74e2                	ld	s1,56(sp)
    800021e2:	7942                	ld	s2,48(sp)
    800021e4:	79a2                	ld	s3,40(sp)
    800021e6:	7a02                	ld	s4,32(sp)
    800021e8:	6ae2                	ld	s5,24(sp)
    800021ea:	6b42                	ld	s6,16(sp)
    800021ec:	6ba2                	ld	s7,8(sp)
    800021ee:	6c02                	ld	s8,0(sp)
    800021f0:	6161                	addi	sp,sp,80
    800021f2:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800021f4:	85e2                	mv	a1,s8
    800021f6:	854a                	mv	a0,s2
    800021f8:	cabff0ef          	jal	ra,80001ea2 <sleep>
    havekids = 0;
    800021fc:	b7a9                	j	80002146 <wait+0x42>

00000000800021fe <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800021fe:	7179                	addi	sp,sp,-48
    80002200:	f406                	sd	ra,40(sp)
    80002202:	f022                	sd	s0,32(sp)
    80002204:	ec26                	sd	s1,24(sp)
    80002206:	e84a                	sd	s2,16(sp)
    80002208:	e44e                	sd	s3,8(sp)
    8000220a:	e052                	sd	s4,0(sp)
    8000220c:	1800                	addi	s0,sp,48
    8000220e:	84aa                	mv	s1,a0
    80002210:	892e                	mv	s2,a1
    80002212:	89b2                	mv	s3,a2
    80002214:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002216:	e70ff0ef          	jal	ra,80001886 <myproc>
  if(user_dst){
    8000221a:	cc99                	beqz	s1,80002238 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    8000221c:	86d2                	mv	a3,s4
    8000221e:	864e                	mv	a2,s3
    80002220:	85ca                	mv	a1,s2
    80002222:	6928                	ld	a0,80(a0)
    80002224:	bb0ff0ef          	jal	ra,800015d4 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002228:	70a2                	ld	ra,40(sp)
    8000222a:	7402                	ld	s0,32(sp)
    8000222c:	64e2                	ld	s1,24(sp)
    8000222e:	6942                	ld	s2,16(sp)
    80002230:	69a2                	ld	s3,8(sp)
    80002232:	6a02                	ld	s4,0(sp)
    80002234:	6145                	addi	sp,sp,48
    80002236:	8082                	ret
    memmove((char *)dst, src, len);
    80002238:	000a061b          	sext.w	a2,s4
    8000223c:	85ce                	mv	a1,s3
    8000223e:	854a                	mv	a0,s2
    80002240:	adffe0ef          	jal	ra,80000d1e <memmove>
    return 0;
    80002244:	8526                	mv	a0,s1
    80002246:	b7cd                	j	80002228 <either_copyout+0x2a>

0000000080002248 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002248:	7179                	addi	sp,sp,-48
    8000224a:	f406                	sd	ra,40(sp)
    8000224c:	f022                	sd	s0,32(sp)
    8000224e:	ec26                	sd	s1,24(sp)
    80002250:	e84a                	sd	s2,16(sp)
    80002252:	e44e                	sd	s3,8(sp)
    80002254:	e052                	sd	s4,0(sp)
    80002256:	1800                	addi	s0,sp,48
    80002258:	892a                	mv	s2,a0
    8000225a:	84ae                	mv	s1,a1
    8000225c:	89b2                	mv	s3,a2
    8000225e:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002260:	e26ff0ef          	jal	ra,80001886 <myproc>
  if(user_src){
    80002264:	cc99                	beqz	s1,80002282 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80002266:	86d2                	mv	a3,s4
    80002268:	864e                	mv	a2,s3
    8000226a:	85ca                	mv	a1,s2
    8000226c:	6928                	ld	a0,80(a0)
    8000226e:	c2cff0ef          	jal	ra,8000169a <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002272:	70a2                	ld	ra,40(sp)
    80002274:	7402                	ld	s0,32(sp)
    80002276:	64e2                	ld	s1,24(sp)
    80002278:	6942                	ld	s2,16(sp)
    8000227a:	69a2                	ld	s3,8(sp)
    8000227c:	6a02                	ld	s4,0(sp)
    8000227e:	6145                	addi	sp,sp,48
    80002280:	8082                	ret
    memmove(dst, (char*)src, len);
    80002282:	000a061b          	sext.w	a2,s4
    80002286:	85ce                	mv	a1,s3
    80002288:	854a                	mv	a0,s2
    8000228a:	a95fe0ef          	jal	ra,80000d1e <memmove>
    return 0;
    8000228e:	8526                	mv	a0,s1
    80002290:	b7cd                	j	80002272 <either_copyin+0x2a>

0000000080002292 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002292:	715d                	addi	sp,sp,-80
    80002294:	e486                	sd	ra,72(sp)
    80002296:	e0a2                	sd	s0,64(sp)
    80002298:	fc26                	sd	s1,56(sp)
    8000229a:	f84a                	sd	s2,48(sp)
    8000229c:	f44e                	sd	s3,40(sp)
    8000229e:	f052                	sd	s4,32(sp)
    800022a0:	ec56                	sd	s5,24(sp)
    800022a2:	e85a                	sd	s6,16(sp)
    800022a4:	e45e                	sd	s7,8(sp)
    800022a6:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800022a8:	00005517          	auipc	a0,0x5
    800022ac:	e1850513          	addi	a0,a0,-488 # 800070c0 <digits+0x88>
    800022b0:	9f2fe0ef          	jal	ra,800004a2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800022b4:	0000e497          	auipc	s1,0xe
    800022b8:	d9c48493          	addi	s1,s1,-612 # 80010050 <proc+0x158>
    800022bc:	00018917          	auipc	s2,0x18
    800022c0:	59490913          	addi	s2,s2,1428 # 8001a850 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800022c4:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800022c6:	00005997          	auipc	s3,0x5
    800022ca:	f5298993          	addi	s3,s3,-174 # 80007218 <digits+0x1e0>
    printf("%d %s %s", p->pid, state, p->name);
    800022ce:	00005a97          	auipc	s5,0x5
    800022d2:	f52a8a93          	addi	s5,s5,-174 # 80007220 <digits+0x1e8>
    printf("\n");
    800022d6:	00005a17          	auipc	s4,0x5
    800022da:	deaa0a13          	addi	s4,s4,-534 # 800070c0 <digits+0x88>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800022de:	00005b97          	auipc	s7,0x5
    800022e2:	f82b8b93          	addi	s7,s7,-126 # 80007260 <states.0>
    800022e6:	a829                	j	80002300 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800022e8:	ed86a583          	lw	a1,-296(a3)
    800022ec:	8556                	mv	a0,s5
    800022ee:	9b4fe0ef          	jal	ra,800004a2 <printf>
    printf("\n");
    800022f2:	8552                	mv	a0,s4
    800022f4:	9aefe0ef          	jal	ra,800004a2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800022f8:	2a048493          	addi	s1,s1,672
    800022fc:	03248263          	beq	s1,s2,80002320 <procdump+0x8e>
    if(p->state == UNUSED)
    80002300:	86a6                	mv	a3,s1
    80002302:	ec04a783          	lw	a5,-320(s1)
    80002306:	dbed                	beqz	a5,800022f8 <procdump+0x66>
      state = "???";
    80002308:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000230a:	fcfb6fe3          	bltu	s6,a5,800022e8 <procdump+0x56>
    8000230e:	02079713          	slli	a4,a5,0x20
    80002312:	01d75793          	srli	a5,a4,0x1d
    80002316:	97de                	add	a5,a5,s7
    80002318:	6390                	ld	a2,0(a5)
    8000231a:	f679                	bnez	a2,800022e8 <procdump+0x56>
      state = "???";
    8000231c:	864e                	mv	a2,s3
    8000231e:	b7e9                	j	800022e8 <procdump+0x56>
  }
}
    80002320:	60a6                	ld	ra,72(sp)
    80002322:	6406                	ld	s0,64(sp)
    80002324:	74e2                	ld	s1,56(sp)
    80002326:	7942                	ld	s2,48(sp)
    80002328:	79a2                	ld	s3,40(sp)
    8000232a:	7a02                	ld	s4,32(sp)
    8000232c:	6ae2                	ld	s5,24(sp)
    8000232e:	6b42                	ld	s6,16(sp)
    80002330:	6ba2                	ld	s7,8(sp)
    80002332:	6161                	addi	sp,sp,80
    80002334:	8082                	ret

0000000080002336 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002336:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    8000233a:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    8000233e:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002340:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002342:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    80002346:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    8000234a:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    8000234e:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002352:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002356:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    8000235a:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    8000235e:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002362:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002366:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    8000236a:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    8000236e:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002372:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002374:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002376:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    8000237a:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    8000237e:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002382:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002386:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    8000238a:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    8000238e:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002392:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002396:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8000239a:	0685bd83          	ld	s11,104(a1)
        
        ret
    8000239e:	8082                	ret

00000000800023a0 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800023a0:	1141                	addi	sp,sp,-16
    800023a2:	e406                	sd	ra,8(sp)
    800023a4:	e022                	sd	s0,0(sp)
    800023a6:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800023a8:	00005597          	auipc	a1,0x5
    800023ac:	ee858593          	addi	a1,a1,-280 # 80007290 <states.0+0x30>
    800023b0:	00018517          	auipc	a0,0x18
    800023b4:	34850513          	addi	a0,a0,840 # 8001a6f8 <tickslock>
    800023b8:	fb6fe0ef          	jal	ra,80000b6e <initlock>
}
    800023bc:	60a2                	ld	ra,8(sp)
    800023be:	6402                	ld	s0,0(sp)
    800023c0:	0141                	addi	sp,sp,16
    800023c2:	8082                	ret

00000000800023c4 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800023c4:	1141                	addi	sp,sp,-16
    800023c6:	e422                	sd	s0,8(sp)
    800023c8:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    800023ca:	00003797          	auipc	a5,0x3
    800023ce:	eb678793          	addi	a5,a5,-330 # 80005280 <kernelvec>
    800023d2:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800023d6:	6422                	ld	s0,8(sp)
    800023d8:	0141                	addi	sp,sp,16
    800023da:	8082                	ret

00000000800023dc <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800023dc:	1141                	addi	sp,sp,-16
    800023de:	e406                	sd	ra,8(sp)
    800023e0:	e022                	sd	s0,0(sp)
    800023e2:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800023e4:	ca2ff0ef          	jal	ra,80001886 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800023e8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800023ec:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800023ee:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800023f2:	04000737          	lui	a4,0x4000
    800023f6:	00004797          	auipc	a5,0x4
    800023fa:	c0a78793          	addi	a5,a5,-1014 # 80006000 <_trampoline>
    800023fe:	00004697          	auipc	a3,0x4
    80002402:	c0268693          	addi	a3,a3,-1022 # 80006000 <_trampoline>
    80002406:	8f95                	sub	a5,a5,a3
    80002408:	177d                	addi	a4,a4,-1
    8000240a:	0732                	slli	a4,a4,0xc
    8000240c:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000240e:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002412:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002414:	18002773          	csrr	a4,satp
    80002418:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000241a:	6d38                	ld	a4,88(a0)
    8000241c:	613c                	ld	a5,64(a0)
    8000241e:	6685                	lui	a3,0x1
    80002420:	97b6                	add	a5,a5,a3
    80002422:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002424:	6d3c                	ld	a5,88(a0)
    80002426:	00000717          	auipc	a4,0x0
    8000242a:	0f470713          	addi	a4,a4,244 # 8000251a <usertrap>
    8000242e:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002430:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002432:	8712                	mv	a4,tp
    80002434:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002436:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000243a:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000243e:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002442:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002446:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002448:	6f9c                	ld	a5,24(a5)
    8000244a:	14179073          	csrw	sepc,a5
}
    8000244e:	60a2                	ld	ra,8(sp)
    80002450:	6402                	ld	s0,0(sp)
    80002452:	0141                	addi	sp,sp,16
    80002454:	8082                	ret

0000000080002456 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002456:	1101                	addi	sp,sp,-32
    80002458:	ec06                	sd	ra,24(sp)
    8000245a:	e822                	sd	s0,16(sp)
    8000245c:	e426                	sd	s1,8(sp)
    8000245e:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    80002460:	bfaff0ef          	jal	ra,8000185a <cpuid>
    80002464:	cd19                	beqz	a0,80002482 <clockintr+0x2c>
  asm volatile("csrr %0, time" : "=r" (x) );
    80002466:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000246a:	000f4737          	lui	a4,0xf4
    8000246e:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002472:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002474:	14d79073          	csrw	0x14d,a5
}
    80002478:	60e2                	ld	ra,24(sp)
    8000247a:	6442                	ld	s0,16(sp)
    8000247c:	64a2                	ld	s1,8(sp)
    8000247e:	6105                	addi	sp,sp,32
    80002480:	8082                	ret
    acquire(&tickslock);
    80002482:	00018497          	auipc	s1,0x18
    80002486:	27648493          	addi	s1,s1,630 # 8001a6f8 <tickslock>
    8000248a:	8526                	mv	a0,s1
    8000248c:	f62fe0ef          	jal	ra,80000bee <acquire>
    ticks++;
    80002490:	00005517          	auipc	a0,0x5
    80002494:	51050513          	addi	a0,a0,1296 # 800079a0 <ticks>
    80002498:	411c                	lw	a5,0(a0)
    8000249a:	2785                	addiw	a5,a5,1
    8000249c:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    8000249e:	a51ff0ef          	jal	ra,80001eee <wakeup>
    release(&tickslock);
    800024a2:	8526                	mv	a0,s1
    800024a4:	fe2fe0ef          	jal	ra,80000c86 <release>
    800024a8:	bf7d                	j	80002466 <clockintr+0x10>

00000000800024aa <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800024aa:	1101                	addi	sp,sp,-32
    800024ac:	ec06                	sd	ra,24(sp)
    800024ae:	e822                	sd	s0,16(sp)
    800024b0:	e426                	sd	s1,8(sp)
    800024b2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    800024b4:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    800024b8:	57fd                	li	a5,-1
    800024ba:	17fe                	slli	a5,a5,0x3f
    800024bc:	07a5                	addi	a5,a5,9
    800024be:	00f70d63          	beq	a4,a5,800024d8 <devintr+0x2e>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    800024c2:	57fd                	li	a5,-1
    800024c4:	17fe                	slli	a5,a5,0x3f
    800024c6:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800024c8:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    800024ca:	04f70463          	beq	a4,a5,80002512 <devintr+0x68>
  }
}
    800024ce:	60e2                	ld	ra,24(sp)
    800024d0:	6442                	ld	s0,16(sp)
    800024d2:	64a2                	ld	s1,8(sp)
    800024d4:	6105                	addi	sp,sp,32
    800024d6:	8082                	ret
    int irq = plic_claim();
    800024d8:	651020ef          	jal	ra,80005328 <plic_claim>
    800024dc:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    800024de:	47a9                	li	a5,10
    800024e0:	02f50363          	beq	a0,a5,80002506 <devintr+0x5c>
    } else if(irq == VIRTIO0_IRQ){
    800024e4:	4785                	li	a5,1
    800024e6:	02f50363          	beq	a0,a5,8000250c <devintr+0x62>
    return 1;
    800024ea:	4505                	li	a0,1
    } else if(irq){
    800024ec:	d0ed                	beqz	s1,800024ce <devintr+0x24>
      printf("unexpected interrupt irq=%d\n", irq);
    800024ee:	85a6                	mv	a1,s1
    800024f0:	00005517          	auipc	a0,0x5
    800024f4:	da850513          	addi	a0,a0,-600 # 80007298 <states.0+0x38>
    800024f8:	fabfd0ef          	jal	ra,800004a2 <printf>
      plic_complete(irq);
    800024fc:	8526                	mv	a0,s1
    800024fe:	64b020ef          	jal	ra,80005348 <plic_complete>
    return 1;
    80002502:	4505                	li	a0,1
    80002504:	b7e9                	j	800024ce <devintr+0x24>
      uartintr();
    80002506:	cd8fe0ef          	jal	ra,800009de <uartintr>
    8000250a:	bfcd                	j	800024fc <devintr+0x52>
      virtio_disk_intr();
    8000250c:	2ac030ef          	jal	ra,800057b8 <virtio_disk_intr>
    80002510:	b7f5                	j	800024fc <devintr+0x52>
    clockintr();
    80002512:	f45ff0ef          	jal	ra,80002456 <clockintr>
    return 2;
    80002516:	4509                	li	a0,2
    80002518:	bf5d                	j	800024ce <devintr+0x24>

000000008000251a <usertrap>:
{
    8000251a:	1101                	addi	sp,sp,-32
    8000251c:	ec06                	sd	ra,24(sp)
    8000251e:	e822                	sd	s0,16(sp)
    80002520:	e426                	sd	s1,8(sp)
    80002522:	e04a                	sd	s2,0(sp)
    80002524:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002526:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    8000252a:	1007f793          	andi	a5,a5,256
    8000252e:	eba5                	bnez	a5,8000259e <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002530:	00003797          	auipc	a5,0x3
    80002534:	d5078793          	addi	a5,a5,-688 # 80005280 <kernelvec>
    80002538:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000253c:	b4aff0ef          	jal	ra,80001886 <myproc>
    80002540:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002542:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002544:	14102773          	csrr	a4,sepc
    80002548:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000254a:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    8000254e:	47a1                	li	a5,8
    80002550:	04f70d63          	beq	a4,a5,800025aa <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    80002554:	f57ff0ef          	jal	ra,800024aa <devintr>
    80002558:	892a                	mv	s2,a0
    8000255a:	e945                	bnez	a0,8000260a <usertrap+0xf0>
    8000255c:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002560:	47bd                	li	a5,15
    80002562:	08f70863          	beq	a4,a5,800025f2 <usertrap+0xd8>
    80002566:	14202773          	csrr	a4,scause
    8000256a:	47b5                	li	a5,13
    8000256c:	08f70363          	beq	a4,a5,800025f2 <usertrap+0xd8>
    80002570:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002574:	5890                	lw	a2,48(s1)
    80002576:	00005517          	auipc	a0,0x5
    8000257a:	d6250513          	addi	a0,a0,-670 # 800072d8 <states.0+0x78>
    8000257e:	f25fd0ef          	jal	ra,800004a2 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002582:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002586:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000258a:	00005517          	auipc	a0,0x5
    8000258e:	d7e50513          	addi	a0,a0,-642 # 80007308 <states.0+0xa8>
    80002592:	f11fd0ef          	jal	ra,800004a2 <printf>
    setkilled(p);
    80002596:	8526                	mv	a0,s1
    80002598:	b1fff0ef          	jal	ra,800020b6 <setkilled>
    8000259c:	a035                	j	800025c8 <usertrap+0xae>
    panic("usertrap: not from user mode");
    8000259e:	00005517          	auipc	a0,0x5
    800025a2:	d1a50513          	addi	a0,a0,-742 # 800072b8 <states.0+0x58>
    800025a6:	9c2fe0ef          	jal	ra,80000768 <panic>
    if(killed(p))
    800025aa:	b31ff0ef          	jal	ra,800020da <killed>
    800025ae:	ed15                	bnez	a0,800025ea <usertrap+0xd0>
    p->trapframe->epc += 4;
    800025b0:	6cb8                	ld	a4,88(s1)
    800025b2:	6f1c                	ld	a5,24(a4)
    800025b4:	0791                	addi	a5,a5,4
    800025b6:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025b8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800025bc:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800025c0:	10079073          	csrw	sstatus,a5
    syscall();
    800025c4:	2aa000ef          	jal	ra,8000286e <syscall>
  if(killed(p))
    800025c8:	8526                	mv	a0,s1
    800025ca:	b11ff0ef          	jal	ra,800020da <killed>
    800025ce:	e139                	bnez	a0,80002614 <usertrap+0xfa>
  prepare_return();
    800025d0:	e0dff0ef          	jal	ra,800023dc <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800025d4:	68a8                	ld	a0,80(s1)
    800025d6:	8131                	srli	a0,a0,0xc
    800025d8:	57fd                	li	a5,-1
    800025da:	17fe                	slli	a5,a5,0x3f
    800025dc:	8d5d                	or	a0,a0,a5
}
    800025de:	60e2                	ld	ra,24(sp)
    800025e0:	6442                	ld	s0,16(sp)
    800025e2:	64a2                	ld	s1,8(sp)
    800025e4:	6902                	ld	s2,0(sp)
    800025e6:	6105                	addi	sp,sp,32
    800025e8:	8082                	ret
      exit(-1);
    800025ea:	557d                	li	a0,-1
    800025ec:	9c3ff0ef          	jal	ra,80001fae <exit>
    800025f0:	b7c1                	j	800025b0 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    800025f2:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    800025f6:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    800025fa:	164d                	addi	a2,a2,-13
    800025fc:	00163613          	seqz	a2,a2
    80002600:	68a8                	ld	a0,80(s1)
    80002602:	f61fe0ef          	jal	ra,80001562 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002606:	f169                	bnez	a0,800025c8 <usertrap+0xae>
    80002608:	b7a5                	j	80002570 <usertrap+0x56>
  if(killed(p))
    8000260a:	8526                	mv	a0,s1
    8000260c:	acfff0ef          	jal	ra,800020da <killed>
    80002610:	c511                	beqz	a0,8000261c <usertrap+0x102>
    80002612:	a011                	j	80002616 <usertrap+0xfc>
    80002614:	4901                	li	s2,0
    exit(-1);
    80002616:	557d                	li	a0,-1
    80002618:	997ff0ef          	jal	ra,80001fae <exit>
  if(which_dev==2){
    8000261c:	4789                	li	a5,2
    8000261e:	faf919e3          	bne	s2,a5,800025d0 <usertrap+0xb6>
    struct proc *p = myproc();
    80002622:	a64ff0ef          	jal	ra,80001886 <myproc>
    if(p->interval>0 && !p->alarm){
    80002626:	16852783          	lw	a5,360(a0)
    8000262a:	04f05e63          	blez	a5,80002686 <usertrap+0x16c>
    8000262e:	17852703          	lw	a4,376(a0)
    80002632:	eb31                	bnez	a4,80002686 <usertrap+0x16c>
     p->curr_tick++;
    80002634:	16c52703          	lw	a4,364(a0)
    80002638:	2705                	addiw	a4,a4,1
    8000263a:	0007069b          	sext.w	a3,a4
    8000263e:	16e52623          	sw	a4,364(a0)
     if(p->curr_tick >= p->interval){
    80002642:	04f6c263          	blt	a3,a5,80002686 <usertrap+0x16c>
      p->alarm_trapframe = *(p->trapframe);
    80002646:	05853303          	ld	t1,88(a0)
    8000264a:	879a                	mv	a5,t1
    8000264c:	18050713          	addi	a4,a0,384
    80002650:	12030893          	addi	a7,t1,288
    80002654:	0007b803          	ld	a6,0(a5)
    80002658:	678c                	ld	a1,8(a5)
    8000265a:	6b90                	ld	a2,16(a5)
    8000265c:	6f94                	ld	a3,24(a5)
    8000265e:	01073023          	sd	a6,0(a4)
    80002662:	e70c                	sd	a1,8(a4)
    80002664:	eb10                	sd	a2,16(a4)
    80002666:	ef14                	sd	a3,24(a4)
    80002668:	02078793          	addi	a5,a5,32
    8000266c:	02070713          	addi	a4,a4,32
    80002670:	ff1792e3          	bne	a5,a7,80002654 <usertrap+0x13a>
      p->trapframe->epc = (uint64)p->pointer_to_handler;
    80002674:	17053783          	ld	a5,368(a0)
    80002678:	00f33c23          	sd	a5,24(t1)
      p->alarm = 1;
    8000267c:	4785                	li	a5,1
    8000267e:	16f52c23          	sw	a5,376(a0)
      p->curr_tick = 0;
    80002682:	16052623          	sw	zero,364(a0)
    yield();
    80002686:	ff0ff0ef          	jal	ra,80001e76 <yield>
    8000268a:	b799                	j	800025d0 <usertrap+0xb6>

000000008000268c <kerneltrap>:
{
    8000268c:	7179                	addi	sp,sp,-48
    8000268e:	f406                	sd	ra,40(sp)
    80002690:	f022                	sd	s0,32(sp)
    80002692:	ec26                	sd	s1,24(sp)
    80002694:	e84a                	sd	s2,16(sp)
    80002696:	e44e                	sd	s3,8(sp)
    80002698:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000269a:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000269e:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800026a2:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    800026a6:	1004f793          	andi	a5,s1,256
    800026aa:	c795                	beqz	a5,800026d6 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800026ac:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800026b0:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800026b2:	eb85                	bnez	a5,800026e2 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    800026b4:	df7ff0ef          	jal	ra,800024aa <devintr>
    800026b8:	c91d                	beqz	a0,800026ee <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    800026ba:	4789                	li	a5,2
    800026bc:	04f50a63          	beq	a0,a5,80002710 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800026c0:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800026c4:	10049073          	csrw	sstatus,s1
}
    800026c8:	70a2                	ld	ra,40(sp)
    800026ca:	7402                	ld	s0,32(sp)
    800026cc:	64e2                	ld	s1,24(sp)
    800026ce:	6942                	ld	s2,16(sp)
    800026d0:	69a2                	ld	s3,8(sp)
    800026d2:	6145                	addi	sp,sp,48
    800026d4:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800026d6:	00005517          	auipc	a0,0x5
    800026da:	c5a50513          	addi	a0,a0,-934 # 80007330 <states.0+0xd0>
    800026de:	88afe0ef          	jal	ra,80000768 <panic>
    panic("kerneltrap: interrupts enabled");
    800026e2:	00005517          	auipc	a0,0x5
    800026e6:	c7650513          	addi	a0,a0,-906 # 80007358 <states.0+0xf8>
    800026ea:	87efe0ef          	jal	ra,80000768 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026ee:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026f2:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800026f6:	85ce                	mv	a1,s3
    800026f8:	00005517          	auipc	a0,0x5
    800026fc:	c8050513          	addi	a0,a0,-896 # 80007378 <states.0+0x118>
    80002700:	da3fd0ef          	jal	ra,800004a2 <printf>
    panic("kerneltrap");
    80002704:	00005517          	auipc	a0,0x5
    80002708:	c9c50513          	addi	a0,a0,-868 # 800073a0 <states.0+0x140>
    8000270c:	85cfe0ef          	jal	ra,80000768 <panic>
  if(which_dev == 2 && myproc() != 0)
    80002710:	976ff0ef          	jal	ra,80001886 <myproc>
    80002714:	d555                	beqz	a0,800026c0 <kerneltrap+0x34>
    yield();
    80002716:	f60ff0ef          	jal	ra,80001e76 <yield>
    8000271a:	b75d                	j	800026c0 <kerneltrap+0x34>

000000008000271c <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    8000271c:	1101                	addi	sp,sp,-32
    8000271e:	ec06                	sd	ra,24(sp)
    80002720:	e822                	sd	s0,16(sp)
    80002722:	e426                	sd	s1,8(sp)
    80002724:	1000                	addi	s0,sp,32
    80002726:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002728:	95eff0ef          	jal	ra,80001886 <myproc>
  switch (n) {
    8000272c:	4795                	li	a5,5
    8000272e:	0497e163          	bltu	a5,s1,80002770 <argraw+0x54>
    80002732:	048a                	slli	s1,s1,0x2
    80002734:	00005717          	auipc	a4,0x5
    80002738:	d5c70713          	addi	a4,a4,-676 # 80007490 <states.0+0x230>
    8000273c:	94ba                	add	s1,s1,a4
    8000273e:	409c                	lw	a5,0(s1)
    80002740:	97ba                	add	a5,a5,a4
    80002742:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002744:	6d3c                	ld	a5,88(a0)
    80002746:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002748:	60e2                	ld	ra,24(sp)
    8000274a:	6442                	ld	s0,16(sp)
    8000274c:	64a2                	ld	s1,8(sp)
    8000274e:	6105                	addi	sp,sp,32
    80002750:	8082                	ret
    return p->trapframe->a1;
    80002752:	6d3c                	ld	a5,88(a0)
    80002754:	7fa8                	ld	a0,120(a5)
    80002756:	bfcd                	j	80002748 <argraw+0x2c>
    return p->trapframe->a2;
    80002758:	6d3c                	ld	a5,88(a0)
    8000275a:	63c8                	ld	a0,128(a5)
    8000275c:	b7f5                	j	80002748 <argraw+0x2c>
    return p->trapframe->a3;
    8000275e:	6d3c                	ld	a5,88(a0)
    80002760:	67c8                	ld	a0,136(a5)
    80002762:	b7dd                	j	80002748 <argraw+0x2c>
    return p->trapframe->a4;
    80002764:	6d3c                	ld	a5,88(a0)
    80002766:	6bc8                	ld	a0,144(a5)
    80002768:	b7c5                	j	80002748 <argraw+0x2c>
    return p->trapframe->a5;
    8000276a:	6d3c                	ld	a5,88(a0)
    8000276c:	6fc8                	ld	a0,152(a5)
    8000276e:	bfe9                	j	80002748 <argraw+0x2c>
  panic("argraw");
    80002770:	00005517          	auipc	a0,0x5
    80002774:	c4050513          	addi	a0,a0,-960 # 800073b0 <states.0+0x150>
    80002778:	ff1fd0ef          	jal	ra,80000768 <panic>

000000008000277c <fetchaddr>:
{
    8000277c:	1101                	addi	sp,sp,-32
    8000277e:	ec06                	sd	ra,24(sp)
    80002780:	e822                	sd	s0,16(sp)
    80002782:	e426                	sd	s1,8(sp)
    80002784:	e04a                	sd	s2,0(sp)
    80002786:	1000                	addi	s0,sp,32
    80002788:	84aa                	mv	s1,a0
    8000278a:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000278c:	8faff0ef          	jal	ra,80001886 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002790:	653c                	ld	a5,72(a0)
    80002792:	02f4f663          	bgeu	s1,a5,800027be <fetchaddr+0x42>
    80002796:	00848713          	addi	a4,s1,8
    8000279a:	02e7e463          	bltu	a5,a4,800027c2 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000279e:	46a1                	li	a3,8
    800027a0:	8626                	mv	a2,s1
    800027a2:	85ca                	mv	a1,s2
    800027a4:	6928                	ld	a0,80(a0)
    800027a6:	ef5fe0ef          	jal	ra,8000169a <copyin>
    800027aa:	00a03533          	snez	a0,a0
    800027ae:	40a00533          	neg	a0,a0
}
    800027b2:	60e2                	ld	ra,24(sp)
    800027b4:	6442                	ld	s0,16(sp)
    800027b6:	64a2                	ld	s1,8(sp)
    800027b8:	6902                	ld	s2,0(sp)
    800027ba:	6105                	addi	sp,sp,32
    800027bc:	8082                	ret
    return -1;
    800027be:	557d                	li	a0,-1
    800027c0:	bfcd                	j	800027b2 <fetchaddr+0x36>
    800027c2:	557d                	li	a0,-1
    800027c4:	b7fd                	j	800027b2 <fetchaddr+0x36>

00000000800027c6 <fetchstr>:
{
    800027c6:	7179                	addi	sp,sp,-48
    800027c8:	f406                	sd	ra,40(sp)
    800027ca:	f022                	sd	s0,32(sp)
    800027cc:	ec26                	sd	s1,24(sp)
    800027ce:	e84a                	sd	s2,16(sp)
    800027d0:	e44e                	sd	s3,8(sp)
    800027d2:	1800                	addi	s0,sp,48
    800027d4:	892a                	mv	s2,a0
    800027d6:	84ae                	mv	s1,a1
    800027d8:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    800027da:	8acff0ef          	jal	ra,80001886 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    800027de:	86ce                	mv	a3,s3
    800027e0:	864a                	mv	a2,s2
    800027e2:	85a6                	mv	a1,s1
    800027e4:	6928                	ld	a0,80(a0)
    800027e6:	cadfe0ef          	jal	ra,80001492 <copyinstr>
    800027ea:	00054c63          	bltz	a0,80002802 <fetchstr+0x3c>
  return strlen(buf);
    800027ee:	8526                	mv	a0,s1
    800027f0:	e4afe0ef          	jal	ra,80000e3a <strlen>
}
    800027f4:	70a2                	ld	ra,40(sp)
    800027f6:	7402                	ld	s0,32(sp)
    800027f8:	64e2                	ld	s1,24(sp)
    800027fa:	6942                	ld	s2,16(sp)
    800027fc:	69a2                	ld	s3,8(sp)
    800027fe:	6145                	addi	sp,sp,48
    80002800:	8082                	ret
    return -1;
    80002802:	557d                	li	a0,-1
    80002804:	bfc5                	j	800027f4 <fetchstr+0x2e>

0000000080002806 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002806:	1101                	addi	sp,sp,-32
    80002808:	ec06                	sd	ra,24(sp)
    8000280a:	e822                	sd	s0,16(sp)
    8000280c:	e426                	sd	s1,8(sp)
    8000280e:	1000                	addi	s0,sp,32
    80002810:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002812:	f0bff0ef          	jal	ra,8000271c <argraw>
    80002816:	c088                	sw	a0,0(s1)
}
    80002818:	60e2                	ld	ra,24(sp)
    8000281a:	6442                	ld	s0,16(sp)
    8000281c:	64a2                	ld	s1,8(sp)
    8000281e:	6105                	addi	sp,sp,32
    80002820:	8082                	ret

0000000080002822 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002822:	1101                	addi	sp,sp,-32
    80002824:	ec06                	sd	ra,24(sp)
    80002826:	e822                	sd	s0,16(sp)
    80002828:	e426                	sd	s1,8(sp)
    8000282a:	1000                	addi	s0,sp,32
    8000282c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000282e:	eefff0ef          	jal	ra,8000271c <argraw>
    80002832:	e088                	sd	a0,0(s1)
}
    80002834:	60e2                	ld	ra,24(sp)
    80002836:	6442                	ld	s0,16(sp)
    80002838:	64a2                	ld	s1,8(sp)
    8000283a:	6105                	addi	sp,sp,32
    8000283c:	8082                	ret

000000008000283e <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    8000283e:	7179                	addi	sp,sp,-48
    80002840:	f406                	sd	ra,40(sp)
    80002842:	f022                	sd	s0,32(sp)
    80002844:	ec26                	sd	s1,24(sp)
    80002846:	e84a                	sd	s2,16(sp)
    80002848:	1800                	addi	s0,sp,48
    8000284a:	84ae                	mv	s1,a1
    8000284c:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    8000284e:	fd840593          	addi	a1,s0,-40
    80002852:	fd1ff0ef          	jal	ra,80002822 <argaddr>
  return fetchstr(addr, buf, max);
    80002856:	864a                	mv	a2,s2
    80002858:	85a6                	mv	a1,s1
    8000285a:	fd843503          	ld	a0,-40(s0)
    8000285e:	f69ff0ef          	jal	ra,800027c6 <fetchstr>
}
    80002862:	70a2                	ld	ra,40(sp)
    80002864:	7402                	ld	s0,32(sp)
    80002866:	64e2                	ld	s1,24(sp)
    80002868:	6942                	ld	s2,16(sp)
    8000286a:	6145                	addi	sp,sp,48
    8000286c:	8082                	ret

000000008000286e <syscall>:
  [SYS_trace]   "trace" // add your new syscall name here
};

void
syscall(void)
{
    8000286e:	7179                	addi	sp,sp,-48
    80002870:	f406                	sd	ra,40(sp)
    80002872:	f022                	sd	s0,32(sp)
    80002874:	ec26                	sd	s1,24(sp)
    80002876:	e84a                	sd	s2,16(sp)
    80002878:	e44e                	sd	s3,8(sp)
    8000287a:	1800                	addi	s0,sp,48
  int num;
  struct proc *p = myproc();
    8000287c:	80aff0ef          	jal	ra,80001886 <myproc>
    80002880:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002882:	05853903          	ld	s2,88(a0)
    80002886:	0a893783          	ld	a5,168(s2)
    8000288a:	0007899b          	sext.w	s3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    8000288e:	37fd                	addiw	a5,a5,-1
    80002890:	475d                	li	a4,23
    80002892:	04f76563          	bltu	a4,a5,800028dc <syscall+0x6e>
    80002896:	00399713          	slli	a4,s3,0x3
    8000289a:	00005797          	auipc	a5,0x5
    8000289e:	c0e78793          	addi	a5,a5,-1010 # 800074a8 <syscalls>
    800028a2:	97ba                	add	a5,a5,a4
    800028a4:	639c                	ld	a5,0(a5)
    800028a6:	cb9d                	beqz	a5,800028dc <syscall+0x6e>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    800028a8:	9782                	jalr	a5
    800028aa:	06a93823          	sd	a0,112(s2)

        // Trace checking and printing
    if((p->trace_mask) & (1<<num)){
    800028ae:	58dc                	lw	a5,52(s1)
    800028b0:	4137d7bb          	sraw	a5,a5,s3
    800028b4:	8b85                	andi	a5,a5,1
    800028b6:	c3a1                	beqz	a5,800028f6 <syscall+0x88>
     printf("%d: syscall %s -> %ld\n", p->pid, syscall_names[num], p->trapframe->a0);
    800028b8:	6cb8                	ld	a4,88(s1)
    800028ba:	098e                	slli	s3,s3,0x3
    800028bc:	00005797          	auipc	a5,0x5
    800028c0:	bec78793          	addi	a5,a5,-1044 # 800074a8 <syscalls>
    800028c4:	99be                	add	s3,s3,a5
    800028c6:	7b34                	ld	a3,112(a4)
    800028c8:	0c89b603          	ld	a2,200(s3)
    800028cc:	588c                	lw	a1,48(s1)
    800028ce:	00005517          	auipc	a0,0x5
    800028d2:	aea50513          	addi	a0,a0,-1302 # 800073b8 <states.0+0x158>
    800028d6:	bcdfd0ef          	jal	ra,800004a2 <printf>
    800028da:	a831                	j	800028f6 <syscall+0x88>
    }
  } else {
    printf("%d %s: unknown sys call %d\n",
    800028dc:	86ce                	mv	a3,s3
    800028de:	15848613          	addi	a2,s1,344
    800028e2:	588c                	lw	a1,48(s1)
    800028e4:	00005517          	auipc	a0,0x5
    800028e8:	aec50513          	addi	a0,a0,-1300 # 800073d0 <states.0+0x170>
    800028ec:	bb7fd0ef          	jal	ra,800004a2 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    800028f0:	6cbc                	ld	a5,88(s1)
    800028f2:	577d                	li	a4,-1
    800028f4:	fbb8                	sd	a4,112(a5)
  }
}
    800028f6:	70a2                	ld	ra,40(sp)
    800028f8:	7402                	ld	s0,32(sp)
    800028fa:	64e2                	ld	s1,24(sp)
    800028fc:	6942                	ld	s2,16(sp)
    800028fe:	69a2                	ld	s3,8(sp)
    80002900:	6145                	addi	sp,sp,48
    80002902:	8082                	ret

0000000080002904 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002904:	1101                	addi	sp,sp,-32
    80002906:	ec06                	sd	ra,24(sp)
    80002908:	e822                	sd	s0,16(sp)
    8000290a:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    8000290c:	fec40593          	addi	a1,s0,-20
    80002910:	4501                	li	a0,0
    80002912:	ef5ff0ef          	jal	ra,80002806 <argint>
  exit(n);
    80002916:	fec42503          	lw	a0,-20(s0)
    8000291a:	e94ff0ef          	jal	ra,80001fae <exit>
  return 0;  // not reached
}
    8000291e:	4501                	li	a0,0
    80002920:	60e2                	ld	ra,24(sp)
    80002922:	6442                	ld	s0,16(sp)
    80002924:	6105                	addi	sp,sp,32
    80002926:	8082                	ret

0000000080002928 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002928:	1141                	addi	sp,sp,-16
    8000292a:	e406                	sd	ra,8(sp)
    8000292c:	e022                	sd	s0,0(sp)
    8000292e:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002930:	f57fe0ef          	jal	ra,80001886 <myproc>
}
    80002934:	5908                	lw	a0,48(a0)
    80002936:	60a2                	ld	ra,8(sp)
    80002938:	6402                	ld	s0,0(sp)
    8000293a:	0141                	addi	sp,sp,16
    8000293c:	8082                	ret

000000008000293e <sys_fork>:

uint64
sys_fork(void)
{
    8000293e:	1141                	addi	sp,sp,-16
    80002940:	e406                	sd	ra,8(sp)
    80002942:	e022                	sd	s0,0(sp)
    80002944:	0800                	addi	s0,sp,16
  return fork();
    80002946:	ab0ff0ef          	jal	ra,80001bf6 <fork>
}
    8000294a:	60a2                	ld	ra,8(sp)
    8000294c:	6402                	ld	s0,0(sp)
    8000294e:	0141                	addi	sp,sp,16
    80002950:	8082                	ret

0000000080002952 <sys_wait>:

uint64
sys_wait(void)
{
    80002952:	1101                	addi	sp,sp,-32
    80002954:	ec06                	sd	ra,24(sp)
    80002956:	e822                	sd	s0,16(sp)
    80002958:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    8000295a:	fe840593          	addi	a1,s0,-24
    8000295e:	4501                	li	a0,0
    80002960:	ec3ff0ef          	jal	ra,80002822 <argaddr>
  return wait(p);
    80002964:	fe843503          	ld	a0,-24(s0)
    80002968:	f9cff0ef          	jal	ra,80002104 <wait>
}
    8000296c:	60e2                	ld	ra,24(sp)
    8000296e:	6442                	ld	s0,16(sp)
    80002970:	6105                	addi	sp,sp,32
    80002972:	8082                	ret

0000000080002974 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002974:	7179                	addi	sp,sp,-48
    80002976:	f406                	sd	ra,40(sp)
    80002978:	f022                	sd	s0,32(sp)
    8000297a:	ec26                	sd	s1,24(sp)
    8000297c:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    8000297e:	fdc40593          	addi	a1,s0,-36
    80002982:	4501                	li	a0,0
    80002984:	e83ff0ef          	jal	ra,80002806 <argint>
  addr = myproc()->sz;
    80002988:	efffe0ef          	jal	ra,80001886 <myproc>
    8000298c:	6524                	ld	s1,72(a0)
  if(n < 0) {
    8000298e:	fdc42503          	lw	a0,-36(s0)
    80002992:	00054f63          	bltz	a0,800029b0 <sys_sbrk+0x3c>
      return -1;
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    myproc()->sz += n;
    80002996:	ef1fe0ef          	jal	ra,80001886 <myproc>
    8000299a:	fdc42703          	lw	a4,-36(s0)
    8000299e:	653c                	ld	a5,72(a0)
    800029a0:	97ba                	add	a5,a5,a4
    800029a2:	e53c                	sd	a5,72(a0)
  }
  return addr;
}
    800029a4:	8526                	mv	a0,s1
    800029a6:	70a2                	ld	ra,40(sp)
    800029a8:	7402                	ld	s0,32(sp)
    800029aa:	64e2                	ld	s1,24(sp)
    800029ac:	6145                	addi	sp,sp,48
    800029ae:	8082                	ret
    if(shrinkproc(-n) < 0)
    800029b0:	40a0053b          	negw	a0,a0
    800029b4:	a0aff0ef          	jal	ra,80001bbe <shrinkproc>
    800029b8:	fe0556e3          	bgez	a0,800029a4 <sys_sbrk+0x30>
      return -1;
    800029bc:	54fd                	li	s1,-1
    800029be:	b7dd                	j	800029a4 <sys_sbrk+0x30>

00000000800029c0 <sys_sleep>:

uint64
sys_sleep(void)
{
    800029c0:	7139                	addi	sp,sp,-64
    800029c2:	fc06                	sd	ra,56(sp)
    800029c4:	f822                	sd	s0,48(sp)
    800029c6:	f426                	sd	s1,40(sp)
    800029c8:	f04a                	sd	s2,32(sp)
    800029ca:	ec4e                	sd	s3,24(sp)
    800029cc:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    800029ce:	fcc40593          	addi	a1,s0,-52
    800029d2:	4501                	li	a0,0
    800029d4:	e33ff0ef          	jal	ra,80002806 <argint>
  if(n < 0)
    800029d8:	fcc42783          	lw	a5,-52(s0)
    800029dc:	0607c563          	bltz	a5,80002a46 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    800029e0:	00018517          	auipc	a0,0x18
    800029e4:	d1850513          	addi	a0,a0,-744 # 8001a6f8 <tickslock>
    800029e8:	a06fe0ef          	jal	ra,80000bee <acquire>
  ticks0 = ticks;
    800029ec:	00005917          	auipc	s2,0x5
    800029f0:	fb492903          	lw	s2,-76(s2) # 800079a0 <ticks>
  while(ticks - ticks0 < n){
    800029f4:	fcc42783          	lw	a5,-52(s0)
    800029f8:	cb8d                	beqz	a5,80002a2a <sys_sleep+0x6a>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    800029fa:	00018997          	auipc	s3,0x18
    800029fe:	cfe98993          	addi	s3,s3,-770 # 8001a6f8 <tickslock>
    80002a02:	00005497          	auipc	s1,0x5
    80002a06:	f9e48493          	addi	s1,s1,-98 # 800079a0 <ticks>
    if(killed(myproc())){
    80002a0a:	e7dfe0ef          	jal	ra,80001886 <myproc>
    80002a0e:	eccff0ef          	jal	ra,800020da <killed>
    80002a12:	ed0d                	bnez	a0,80002a4c <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    80002a14:	85ce                	mv	a1,s3
    80002a16:	8526                	mv	a0,s1
    80002a18:	c8aff0ef          	jal	ra,80001ea2 <sleep>
  while(ticks - ticks0 < n){
    80002a1c:	409c                	lw	a5,0(s1)
    80002a1e:	412787bb          	subw	a5,a5,s2
    80002a22:	fcc42703          	lw	a4,-52(s0)
    80002a26:	fee7e2e3          	bltu	a5,a4,80002a0a <sys_sleep+0x4a>
  }
  release(&tickslock);
    80002a2a:	00018517          	auipc	a0,0x18
    80002a2e:	cce50513          	addi	a0,a0,-818 # 8001a6f8 <tickslock>
    80002a32:	a54fe0ef          	jal	ra,80000c86 <release>
  return 0;
    80002a36:	4501                	li	a0,0
}
    80002a38:	70e2                	ld	ra,56(sp)
    80002a3a:	7442                	ld	s0,48(sp)
    80002a3c:	74a2                	ld	s1,40(sp)
    80002a3e:	7902                	ld	s2,32(sp)
    80002a40:	69e2                	ld	s3,24(sp)
    80002a42:	6121                	addi	sp,sp,64
    80002a44:	8082                	ret
    n = 0;
    80002a46:	fc042623          	sw	zero,-52(s0)
    80002a4a:	bf59                	j	800029e0 <sys_sleep+0x20>
      release(&tickslock);
    80002a4c:	00018517          	auipc	a0,0x18
    80002a50:	cac50513          	addi	a0,a0,-852 # 8001a6f8 <tickslock>
    80002a54:	a32fe0ef          	jal	ra,80000c86 <release>
      return -1;
    80002a58:	557d                	li	a0,-1
    80002a5a:	bff9                	j	80002a38 <sys_sleep+0x78>

0000000080002a5c <sys_kill>:

uint64
sys_kill(void)
{
    80002a5c:	1101                	addi	sp,sp,-32
    80002a5e:	ec06                	sd	ra,24(sp)
    80002a60:	e822                	sd	s0,16(sp)
    80002a62:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002a64:	fec40593          	addi	a1,s0,-20
    80002a68:	4501                	li	a0,0
    80002a6a:	d9dff0ef          	jal	ra,80002806 <argint>
  return kill(pid);
    80002a6e:	fec42503          	lw	a0,-20(s0)
    80002a72:	ddeff0ef          	jal	ra,80002050 <kill>
}
    80002a76:	60e2                	ld	ra,24(sp)
    80002a78:	6442                	ld	s0,16(sp)
    80002a7a:	6105                	addi	sp,sp,32
    80002a7c:	8082                	ret

0000000080002a7e <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002a7e:	1101                	addi	sp,sp,-32
    80002a80:	ec06                	sd	ra,24(sp)
    80002a82:	e822                	sd	s0,16(sp)
    80002a84:	e426                	sd	s1,8(sp)
    80002a86:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002a88:	00018517          	auipc	a0,0x18
    80002a8c:	c7050513          	addi	a0,a0,-912 # 8001a6f8 <tickslock>
    80002a90:	95efe0ef          	jal	ra,80000bee <acquire>
  xticks = ticks;
    80002a94:	00005497          	auipc	s1,0x5
    80002a98:	f0c4a483          	lw	s1,-244(s1) # 800079a0 <ticks>
  release(&tickslock);
    80002a9c:	00018517          	auipc	a0,0x18
    80002aa0:	c5c50513          	addi	a0,a0,-932 # 8001a6f8 <tickslock>
    80002aa4:	9e2fe0ef          	jal	ra,80000c86 <release>
  return xticks;
}
    80002aa8:	02049513          	slli	a0,s1,0x20
    80002aac:	9101                	srli	a0,a0,0x20
    80002aae:	60e2                	ld	ra,24(sp)
    80002ab0:	6442                	ld	s0,16(sp)
    80002ab2:	64a2                	ld	s1,8(sp)
    80002ab4:	6105                	addi	sp,sp,32
    80002ab6:	8082                	ret

0000000080002ab8 <sys_trace>:

// Added sys_trace function
uint64
sys_trace(void)
{
    80002ab8:	1101                	addi	sp,sp,-32
    80002aba:	ec06                	sd	ra,24(sp)
    80002abc:	e822                	sd	s0,16(sp)
    80002abe:	1000                	addi	s0,sp,32
  int mask;

  argint(0, &mask);
    80002ac0:	fec40593          	addi	a1,s0,-20
    80002ac4:	4501                	li	a0,0
    80002ac6:	d41ff0ef          	jal	ra,80002806 <argint>

  myproc()->trace_mask = mask;
    80002aca:	dbdfe0ef          	jal	ra,80001886 <myproc>
    80002ace:	fec42783          	lw	a5,-20(s0)
    80002ad2:	d95c                	sw	a5,52(a0)
  return 0;
}
    80002ad4:	4501                	li	a0,0
    80002ad6:	60e2                	ld	ra,24(sp)
    80002ad8:	6442                	ld	s0,16(sp)
    80002ada:	6105                	addi	sp,sp,32
    80002adc:	8082                	ret

0000000080002ade <sys_sigalarm>:

// Added sys_sigalarm
uint64
sys_sigalarm(void)
{
    80002ade:	7179                	addi	sp,sp,-48
    80002ae0:	f406                	sd	ra,40(sp)
    80002ae2:	f022                	sd	s0,32(sp)
    80002ae4:	ec26                	sd	s1,24(sp)
    80002ae6:	1800                	addi	s0,sp,48
  int ticks;
  uint64 pointer;

  argint(0, &ticks);
    80002ae8:	fdc40593          	addi	a1,s0,-36
    80002aec:	4501                	li	a0,0
    80002aee:	d19ff0ef          	jal	ra,80002806 <argint>
  argaddr(1, &pointer);
    80002af2:	fd040593          	addi	a1,s0,-48
    80002af6:	4505                	li	a0,1
    80002af8:	d2bff0ef          	jal	ra,80002822 <argaddr>

  myproc()->interval = ticks;
    80002afc:	d8bfe0ef          	jal	ra,80001886 <myproc>
    80002b00:	fdc42783          	lw	a5,-36(s0)
    80002b04:	16f52423          	sw	a5,360(a0)
  myproc()->curr_tick = 0;
    80002b08:	d7ffe0ef          	jal	ra,80001886 <myproc>
    80002b0c:	16052623          	sw	zero,364(a0)
  myproc()->pointer_to_handler = (void(*)())pointer;
    80002b10:	fd043483          	ld	s1,-48(s0)
    80002b14:	d73fe0ef          	jal	ra,80001886 <myproc>
    80002b18:	16953823          	sd	s1,368(a0)
  return 0;
}
    80002b1c:	4501                	li	a0,0
    80002b1e:	70a2                	ld	ra,40(sp)
    80002b20:	7402                	ld	s0,32(sp)
    80002b22:	64e2                	ld	s1,24(sp)
    80002b24:	6145                	addi	sp,sp,48
    80002b26:	8082                	ret

0000000080002b28 <sys_sigreturn>:

// Added sys_sigreturn
uint64
sys_sigreturn(void)
{
    80002b28:	1141                	addi	sp,sp,-16
    80002b2a:	e406                	sd	ra,8(sp)
    80002b2c:	e022                	sd	s0,0(sp)
    80002b2e:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002b30:	d57fe0ef          	jal	ra,80001886 <myproc>
    80002b34:	87aa                	mv	a5,a0
  
  uint64 saved = p->alarm_trapframe.a0;
    80002b36:	1f053503          	ld	a0,496(a0)

  *(p->trapframe) = p->alarm_trapframe;
    80002b3a:	18078713          	addi	a4,a5,384
    80002b3e:	6fb4                	ld	a3,88(a5)
    80002b40:	2a078613          	addi	a2,a5,672
    80002b44:	00073303          	ld	t1,0(a4)
    80002b48:	00873883          	ld	a7,8(a4)
    80002b4c:	01073803          	ld	a6,16(a4)
    80002b50:	6f0c                	ld	a1,24(a4)
    80002b52:	0066b023          	sd	t1,0(a3) # 1000 <_entry-0x7ffff000>
    80002b56:	0116b423          	sd	a7,8(a3)
    80002b5a:	0106b823          	sd	a6,16(a3)
    80002b5e:	ee8c                	sd	a1,24(a3)
    80002b60:	02070713          	addi	a4,a4,32
    80002b64:	02068693          	addi	a3,a3,32
    80002b68:	fcc71ee3          	bne	a4,a2,80002b44 <sys_sigreturn+0x1c>

  p->alarm = 0;
    80002b6c:	1607ac23          	sw	zero,376(a5)
  return saved;
} 
    80002b70:	60a2                	ld	ra,8(sp)
    80002b72:	6402                	ld	s0,0(sp)
    80002b74:	0141                	addi	sp,sp,16
    80002b76:	8082                	ret

0000000080002b78 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002b78:	7179                	addi	sp,sp,-48
    80002b7a:	f406                	sd	ra,40(sp)
    80002b7c:	f022                	sd	s0,32(sp)
    80002b7e:	ec26                	sd	s1,24(sp)
    80002b80:	e84a                	sd	s2,16(sp)
    80002b82:	e44e                	sd	s3,8(sp)
    80002b84:	e052                	sd	s4,0(sp)
    80002b86:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002b88:	00005597          	auipc	a1,0x5
    80002b8c:	aa058593          	addi	a1,a1,-1376 # 80007628 <syscall_names+0xb8>
    80002b90:	00018517          	auipc	a0,0x18
    80002b94:	b8050513          	addi	a0,a0,-1152 # 8001a710 <bcache>
    80002b98:	fd7fd0ef          	jal	ra,80000b6e <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002b9c:	00020797          	auipc	a5,0x20
    80002ba0:	b7478793          	addi	a5,a5,-1164 # 80022710 <bcache+0x8000>
    80002ba4:	00020717          	auipc	a4,0x20
    80002ba8:	dd470713          	addi	a4,a4,-556 # 80022978 <bcache+0x8268>
    80002bac:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002bb0:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002bb4:	00018497          	auipc	s1,0x18
    80002bb8:	b7448493          	addi	s1,s1,-1164 # 8001a728 <bcache+0x18>
    b->next = bcache.head.next;
    80002bbc:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002bbe:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002bc0:	00005a17          	auipc	s4,0x5
    80002bc4:	a70a0a13          	addi	s4,s4,-1424 # 80007630 <syscall_names+0xc0>
    b->next = bcache.head.next;
    80002bc8:	2b893783          	ld	a5,696(s2)
    80002bcc:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002bce:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002bd2:	85d2                	mv	a1,s4
    80002bd4:	01048513          	addi	a0,s1,16
    80002bd8:	22a010ef          	jal	ra,80003e02 <initsleeplock>
    bcache.head.next->prev = b;
    80002bdc:	2b893783          	ld	a5,696(s2)
    80002be0:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002be2:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002be6:	45848493          	addi	s1,s1,1112
    80002bea:	fd349fe3          	bne	s1,s3,80002bc8 <binit+0x50>
  }
}
    80002bee:	70a2                	ld	ra,40(sp)
    80002bf0:	7402                	ld	s0,32(sp)
    80002bf2:	64e2                	ld	s1,24(sp)
    80002bf4:	6942                	ld	s2,16(sp)
    80002bf6:	69a2                	ld	s3,8(sp)
    80002bf8:	6a02                	ld	s4,0(sp)
    80002bfa:	6145                	addi	sp,sp,48
    80002bfc:	8082                	ret

0000000080002bfe <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002bfe:	7179                	addi	sp,sp,-48
    80002c00:	f406                	sd	ra,40(sp)
    80002c02:	f022                	sd	s0,32(sp)
    80002c04:	ec26                	sd	s1,24(sp)
    80002c06:	e84a                	sd	s2,16(sp)
    80002c08:	e44e                	sd	s3,8(sp)
    80002c0a:	1800                	addi	s0,sp,48
    80002c0c:	892a                	mv	s2,a0
    80002c0e:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c10:	00018517          	auipc	a0,0x18
    80002c14:	b0050513          	addi	a0,a0,-1280 # 8001a710 <bcache>
    80002c18:	fd7fd0ef          	jal	ra,80000bee <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002c1c:	00020497          	auipc	s1,0x20
    80002c20:	dac4b483          	ld	s1,-596(s1) # 800229c8 <bcache+0x82b8>
    80002c24:	00020797          	auipc	a5,0x20
    80002c28:	d5478793          	addi	a5,a5,-684 # 80022978 <bcache+0x8268>
    80002c2c:	02f48b63          	beq	s1,a5,80002c62 <bread+0x64>
    80002c30:	873e                	mv	a4,a5
    80002c32:	a021                	j	80002c3a <bread+0x3c>
    80002c34:	68a4                	ld	s1,80(s1)
    80002c36:	02e48663          	beq	s1,a4,80002c62 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002c3a:	449c                	lw	a5,8(s1)
    80002c3c:	ff279ce3          	bne	a5,s2,80002c34 <bread+0x36>
    80002c40:	44dc                	lw	a5,12(s1)
    80002c42:	ff3799e3          	bne	a5,s3,80002c34 <bread+0x36>
      b->refcnt++;
    80002c46:	40bc                	lw	a5,64(s1)
    80002c48:	2785                	addiw	a5,a5,1
    80002c4a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c4c:	00018517          	auipc	a0,0x18
    80002c50:	ac450513          	addi	a0,a0,-1340 # 8001a710 <bcache>
    80002c54:	832fe0ef          	jal	ra,80000c86 <release>
      acquiresleep(&b->lock);
    80002c58:	01048513          	addi	a0,s1,16
    80002c5c:	1dc010ef          	jal	ra,80003e38 <acquiresleep>
      return b;
    80002c60:	a889                	j	80002cb2 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c62:	00020497          	auipc	s1,0x20
    80002c66:	d5e4b483          	ld	s1,-674(s1) # 800229c0 <bcache+0x82b0>
    80002c6a:	00020797          	auipc	a5,0x20
    80002c6e:	d0e78793          	addi	a5,a5,-754 # 80022978 <bcache+0x8268>
    80002c72:	00f48863          	beq	s1,a5,80002c82 <bread+0x84>
    80002c76:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002c78:	40bc                	lw	a5,64(s1)
    80002c7a:	cb91                	beqz	a5,80002c8e <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c7c:	64a4                	ld	s1,72(s1)
    80002c7e:	fee49de3          	bne	s1,a4,80002c78 <bread+0x7a>
  panic("bget: no buffers");
    80002c82:	00005517          	auipc	a0,0x5
    80002c86:	9b650513          	addi	a0,a0,-1610 # 80007638 <syscall_names+0xc8>
    80002c8a:	adffd0ef          	jal	ra,80000768 <panic>
      b->dev = dev;
    80002c8e:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002c92:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002c96:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002c9a:	4785                	li	a5,1
    80002c9c:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c9e:	00018517          	auipc	a0,0x18
    80002ca2:	a7250513          	addi	a0,a0,-1422 # 8001a710 <bcache>
    80002ca6:	fe1fd0ef          	jal	ra,80000c86 <release>
      acquiresleep(&b->lock);
    80002caa:	01048513          	addi	a0,s1,16
    80002cae:	18a010ef          	jal	ra,80003e38 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002cb2:	409c                	lw	a5,0(s1)
    80002cb4:	cb89                	beqz	a5,80002cc6 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002cb6:	8526                	mv	a0,s1
    80002cb8:	70a2                	ld	ra,40(sp)
    80002cba:	7402                	ld	s0,32(sp)
    80002cbc:	64e2                	ld	s1,24(sp)
    80002cbe:	6942                	ld	s2,16(sp)
    80002cc0:	69a2                	ld	s3,8(sp)
    80002cc2:	6145                	addi	sp,sp,48
    80002cc4:	8082                	ret
    virtio_disk_rw(b, 0);
    80002cc6:	4581                	li	a1,0
    80002cc8:	8526                	mv	a0,s1
    80002cca:	0d3020ef          	jal	ra,8000559c <virtio_disk_rw>
    b->valid = 1;
    80002cce:	4785                	li	a5,1
    80002cd0:	c09c                	sw	a5,0(s1)
  return b;
    80002cd2:	b7d5                	j	80002cb6 <bread+0xb8>

0000000080002cd4 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002cd4:	1101                	addi	sp,sp,-32
    80002cd6:	ec06                	sd	ra,24(sp)
    80002cd8:	e822                	sd	s0,16(sp)
    80002cda:	e426                	sd	s1,8(sp)
    80002cdc:	1000                	addi	s0,sp,32
    80002cde:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002ce0:	0541                	addi	a0,a0,16
    80002ce2:	1d4010ef          	jal	ra,80003eb6 <holdingsleep>
    80002ce6:	c911                	beqz	a0,80002cfa <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002ce8:	4585                	li	a1,1
    80002cea:	8526                	mv	a0,s1
    80002cec:	0b1020ef          	jal	ra,8000559c <virtio_disk_rw>
}
    80002cf0:	60e2                	ld	ra,24(sp)
    80002cf2:	6442                	ld	s0,16(sp)
    80002cf4:	64a2                	ld	s1,8(sp)
    80002cf6:	6105                	addi	sp,sp,32
    80002cf8:	8082                	ret
    panic("bwrite");
    80002cfa:	00005517          	auipc	a0,0x5
    80002cfe:	95650513          	addi	a0,a0,-1706 # 80007650 <syscall_names+0xe0>
    80002d02:	a67fd0ef          	jal	ra,80000768 <panic>

0000000080002d06 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002d06:	1101                	addi	sp,sp,-32
    80002d08:	ec06                	sd	ra,24(sp)
    80002d0a:	e822                	sd	s0,16(sp)
    80002d0c:	e426                	sd	s1,8(sp)
    80002d0e:	e04a                	sd	s2,0(sp)
    80002d10:	1000                	addi	s0,sp,32
    80002d12:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002d14:	01050913          	addi	s2,a0,16
    80002d18:	854a                	mv	a0,s2
    80002d1a:	19c010ef          	jal	ra,80003eb6 <holdingsleep>
    80002d1e:	c13d                	beqz	a0,80002d84 <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
    80002d20:	854a                	mv	a0,s2
    80002d22:	15c010ef          	jal	ra,80003e7e <releasesleep>

  acquire(&bcache.lock);
    80002d26:	00018517          	auipc	a0,0x18
    80002d2a:	9ea50513          	addi	a0,a0,-1558 # 8001a710 <bcache>
    80002d2e:	ec1fd0ef          	jal	ra,80000bee <acquire>
  b->refcnt--;
    80002d32:	40bc                	lw	a5,64(s1)
    80002d34:	37fd                	addiw	a5,a5,-1
    80002d36:	0007871b          	sext.w	a4,a5
    80002d3a:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002d3c:	eb05                	bnez	a4,80002d6c <brelse+0x66>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002d3e:	68bc                	ld	a5,80(s1)
    80002d40:	64b8                	ld	a4,72(s1)
    80002d42:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    80002d44:	64bc                	ld	a5,72(s1)
    80002d46:	68b8                	ld	a4,80(s1)
    80002d48:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002d4a:	00020797          	auipc	a5,0x20
    80002d4e:	9c678793          	addi	a5,a5,-1594 # 80022710 <bcache+0x8000>
    80002d52:	2b87b703          	ld	a4,696(a5)
    80002d56:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d58:	00020717          	auipc	a4,0x20
    80002d5c:	c2070713          	addi	a4,a4,-992 # 80022978 <bcache+0x8268>
    80002d60:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d62:	2b87b703          	ld	a4,696(a5)
    80002d66:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d68:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002d6c:	00018517          	auipc	a0,0x18
    80002d70:	9a450513          	addi	a0,a0,-1628 # 8001a710 <bcache>
    80002d74:	f13fd0ef          	jal	ra,80000c86 <release>
}
    80002d78:	60e2                	ld	ra,24(sp)
    80002d7a:	6442                	ld	s0,16(sp)
    80002d7c:	64a2                	ld	s1,8(sp)
    80002d7e:	6902                	ld	s2,0(sp)
    80002d80:	6105                	addi	sp,sp,32
    80002d82:	8082                	ret
    panic("brelse");
    80002d84:	00005517          	auipc	a0,0x5
    80002d88:	8d450513          	addi	a0,a0,-1836 # 80007658 <syscall_names+0xe8>
    80002d8c:	9ddfd0ef          	jal	ra,80000768 <panic>

0000000080002d90 <bpin>:

void
bpin(struct buf *b) {
    80002d90:	1101                	addi	sp,sp,-32
    80002d92:	ec06                	sd	ra,24(sp)
    80002d94:	e822                	sd	s0,16(sp)
    80002d96:	e426                	sd	s1,8(sp)
    80002d98:	1000                	addi	s0,sp,32
    80002d9a:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002d9c:	00018517          	auipc	a0,0x18
    80002da0:	97450513          	addi	a0,a0,-1676 # 8001a710 <bcache>
    80002da4:	e4bfd0ef          	jal	ra,80000bee <acquire>
  b->refcnt++;
    80002da8:	40bc                	lw	a5,64(s1)
    80002daa:	2785                	addiw	a5,a5,1
    80002dac:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002dae:	00018517          	auipc	a0,0x18
    80002db2:	96250513          	addi	a0,a0,-1694 # 8001a710 <bcache>
    80002db6:	ed1fd0ef          	jal	ra,80000c86 <release>
}
    80002dba:	60e2                	ld	ra,24(sp)
    80002dbc:	6442                	ld	s0,16(sp)
    80002dbe:	64a2                	ld	s1,8(sp)
    80002dc0:	6105                	addi	sp,sp,32
    80002dc2:	8082                	ret

0000000080002dc4 <bunpin>:

void
bunpin(struct buf *b) {
    80002dc4:	1101                	addi	sp,sp,-32
    80002dc6:	ec06                	sd	ra,24(sp)
    80002dc8:	e822                	sd	s0,16(sp)
    80002dca:	e426                	sd	s1,8(sp)
    80002dcc:	1000                	addi	s0,sp,32
    80002dce:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002dd0:	00018517          	auipc	a0,0x18
    80002dd4:	94050513          	addi	a0,a0,-1728 # 8001a710 <bcache>
    80002dd8:	e17fd0ef          	jal	ra,80000bee <acquire>
  b->refcnt--;
    80002ddc:	40bc                	lw	a5,64(s1)
    80002dde:	37fd                	addiw	a5,a5,-1
    80002de0:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002de2:	00018517          	auipc	a0,0x18
    80002de6:	92e50513          	addi	a0,a0,-1746 # 8001a710 <bcache>
    80002dea:	e9dfd0ef          	jal	ra,80000c86 <release>
}
    80002dee:	60e2                	ld	ra,24(sp)
    80002df0:	6442                	ld	s0,16(sp)
    80002df2:	64a2                	ld	s1,8(sp)
    80002df4:	6105                	addi	sp,sp,32
    80002df6:	8082                	ret

0000000080002df8 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002df8:	1101                	addi	sp,sp,-32
    80002dfa:	ec06                	sd	ra,24(sp)
    80002dfc:	e822                	sd	s0,16(sp)
    80002dfe:	e426                	sd	s1,8(sp)
    80002e00:	e04a                	sd	s2,0(sp)
    80002e02:	1000                	addi	s0,sp,32
    80002e04:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002e06:	00d5d59b          	srliw	a1,a1,0xd
    80002e0a:	00020797          	auipc	a5,0x20
    80002e0e:	fe27a783          	lw	a5,-30(a5) # 80022dec <sb+0x1c>
    80002e12:	9dbd                	addw	a1,a1,a5
    80002e14:	debff0ef          	jal	ra,80002bfe <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002e18:	0074f713          	andi	a4,s1,7
    80002e1c:	4785                	li	a5,1
    80002e1e:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    80002e22:	14ce                	slli	s1,s1,0x33
    80002e24:	90d9                	srli	s1,s1,0x36
    80002e26:	00950733          	add	a4,a0,s1
    80002e2a:	05874703          	lbu	a4,88(a4)
    80002e2e:	00e7f6b3          	and	a3,a5,a4
    80002e32:	c29d                	beqz	a3,80002e58 <bfree+0x60>
    80002e34:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002e36:	94aa                	add	s1,s1,a0
    80002e38:	fff7c793          	not	a5,a5
    80002e3c:	8ff9                	and	a5,a5,a4
    80002e3e:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    80002e42:	6ef000ef          	jal	ra,80003d30 <log_write>
  brelse(bp);
    80002e46:	854a                	mv	a0,s2
    80002e48:	ebfff0ef          	jal	ra,80002d06 <brelse>
}
    80002e4c:	60e2                	ld	ra,24(sp)
    80002e4e:	6442                	ld	s0,16(sp)
    80002e50:	64a2                	ld	s1,8(sp)
    80002e52:	6902                	ld	s2,0(sp)
    80002e54:	6105                	addi	sp,sp,32
    80002e56:	8082                	ret
    panic("freeing free block");
    80002e58:	00005517          	auipc	a0,0x5
    80002e5c:	80850513          	addi	a0,a0,-2040 # 80007660 <syscall_names+0xf0>
    80002e60:	909fd0ef          	jal	ra,80000768 <panic>

0000000080002e64 <balloc>:
{
    80002e64:	711d                	addi	sp,sp,-96
    80002e66:	ec86                	sd	ra,88(sp)
    80002e68:	e8a2                	sd	s0,80(sp)
    80002e6a:	e4a6                	sd	s1,72(sp)
    80002e6c:	e0ca                	sd	s2,64(sp)
    80002e6e:	fc4e                	sd	s3,56(sp)
    80002e70:	f852                	sd	s4,48(sp)
    80002e72:	f456                	sd	s5,40(sp)
    80002e74:	f05a                	sd	s6,32(sp)
    80002e76:	ec5e                	sd	s7,24(sp)
    80002e78:	e862                	sd	s8,16(sp)
    80002e7a:	e466                	sd	s9,8(sp)
    80002e7c:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80002e7e:	00020797          	auipc	a5,0x20
    80002e82:	f567a783          	lw	a5,-170(a5) # 80022dd4 <sb+0x4>
    80002e86:	0e078163          	beqz	a5,80002f68 <balloc+0x104>
    80002e8a:	8baa                	mv	s7,a0
    80002e8c:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002e8e:	00020b17          	auipc	s6,0x20
    80002e92:	f42b0b13          	addi	s6,s6,-190 # 80022dd0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e96:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80002e98:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e9a:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002e9c:	6c89                	lui	s9,0x2
    80002e9e:	a0b5                	j	80002f0a <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002ea0:	974a                	add	a4,a4,s2
    80002ea2:	8fd5                	or	a5,a5,a3
    80002ea4:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    80002ea8:	854a                	mv	a0,s2
    80002eaa:	687000ef          	jal	ra,80003d30 <log_write>
        brelse(bp);
    80002eae:	854a                	mv	a0,s2
    80002eb0:	e57ff0ef          	jal	ra,80002d06 <brelse>
  bp = bread(dev, bno);
    80002eb4:	85a6                	mv	a1,s1
    80002eb6:	855e                	mv	a0,s7
    80002eb8:	d47ff0ef          	jal	ra,80002bfe <bread>
    80002ebc:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002ebe:	40000613          	li	a2,1024
    80002ec2:	4581                	li	a1,0
    80002ec4:	05850513          	addi	a0,a0,88
    80002ec8:	dfbfd0ef          	jal	ra,80000cc2 <memset>
  log_write(bp);
    80002ecc:	854a                	mv	a0,s2
    80002ece:	663000ef          	jal	ra,80003d30 <log_write>
  brelse(bp);
    80002ed2:	854a                	mv	a0,s2
    80002ed4:	e33ff0ef          	jal	ra,80002d06 <brelse>
}
    80002ed8:	8526                	mv	a0,s1
    80002eda:	60e6                	ld	ra,88(sp)
    80002edc:	6446                	ld	s0,80(sp)
    80002ede:	64a6                	ld	s1,72(sp)
    80002ee0:	6906                	ld	s2,64(sp)
    80002ee2:	79e2                	ld	s3,56(sp)
    80002ee4:	7a42                	ld	s4,48(sp)
    80002ee6:	7aa2                	ld	s5,40(sp)
    80002ee8:	7b02                	ld	s6,32(sp)
    80002eea:	6be2                	ld	s7,24(sp)
    80002eec:	6c42                	ld	s8,16(sp)
    80002eee:	6ca2                	ld	s9,8(sp)
    80002ef0:	6125                	addi	sp,sp,96
    80002ef2:	8082                	ret
    brelse(bp);
    80002ef4:	854a                	mv	a0,s2
    80002ef6:	e11ff0ef          	jal	ra,80002d06 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002efa:	015c87bb          	addw	a5,s9,s5
    80002efe:	00078a9b          	sext.w	s5,a5
    80002f02:	004b2703          	lw	a4,4(s6)
    80002f06:	06eaf163          	bgeu	s5,a4,80002f68 <balloc+0x104>
    bp = bread(dev, BBLOCK(b, sb));
    80002f0a:	41fad79b          	sraiw	a5,s5,0x1f
    80002f0e:	0137d79b          	srliw	a5,a5,0x13
    80002f12:	015787bb          	addw	a5,a5,s5
    80002f16:	40d7d79b          	sraiw	a5,a5,0xd
    80002f1a:	01cb2583          	lw	a1,28(s6)
    80002f1e:	9dbd                	addw	a1,a1,a5
    80002f20:	855e                	mv	a0,s7
    80002f22:	cddff0ef          	jal	ra,80002bfe <bread>
    80002f26:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f28:	004b2503          	lw	a0,4(s6)
    80002f2c:	000a849b          	sext.w	s1,s5
    80002f30:	8662                	mv	a2,s8
    80002f32:	fca4f1e3          	bgeu	s1,a0,80002ef4 <balloc+0x90>
      m = 1 << (bi % 8);
    80002f36:	41f6579b          	sraiw	a5,a2,0x1f
    80002f3a:	01d7d69b          	srliw	a3,a5,0x1d
    80002f3e:	00c6873b          	addw	a4,a3,a2
    80002f42:	00777793          	andi	a5,a4,7
    80002f46:	9f95                	subw	a5,a5,a3
    80002f48:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002f4c:	4037571b          	sraiw	a4,a4,0x3
    80002f50:	00e906b3          	add	a3,s2,a4
    80002f54:	0586c683          	lbu	a3,88(a3)
    80002f58:	00d7f5b3          	and	a1,a5,a3
    80002f5c:	d1b1                	beqz	a1,80002ea0 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f5e:	2605                	addiw	a2,a2,1
    80002f60:	2485                	addiw	s1,s1,1
    80002f62:	fd4618e3          	bne	a2,s4,80002f32 <balloc+0xce>
    80002f66:	b779                	j	80002ef4 <balloc+0x90>
  printf("balloc: out of blocks\n");
    80002f68:	00004517          	auipc	a0,0x4
    80002f6c:	71050513          	addi	a0,a0,1808 # 80007678 <syscall_names+0x108>
    80002f70:	d32fd0ef          	jal	ra,800004a2 <printf>
  return 0;
    80002f74:	4481                	li	s1,0
    80002f76:	b78d                	j	80002ed8 <balloc+0x74>

0000000080002f78 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002f78:	7179                	addi	sp,sp,-48
    80002f7a:	f406                	sd	ra,40(sp)
    80002f7c:	f022                	sd	s0,32(sp)
    80002f7e:	ec26                	sd	s1,24(sp)
    80002f80:	e84a                	sd	s2,16(sp)
    80002f82:	e44e                	sd	s3,8(sp)
    80002f84:	e052                	sd	s4,0(sp)
    80002f86:	1800                	addi	s0,sp,48
    80002f88:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002f8a:	47ad                	li	a5,11
    80002f8c:	02b7e663          	bltu	a5,a1,80002fb8 <bmap+0x40>
    if((addr = ip->addrs[bn]) == 0){
    80002f90:	02059793          	slli	a5,a1,0x20
    80002f94:	01e7d593          	srli	a1,a5,0x1e
    80002f98:	00b504b3          	add	s1,a0,a1
    80002f9c:	0504a903          	lw	s2,80(s1)
    80002fa0:	06091663          	bnez	s2,8000300c <bmap+0x94>
      addr = balloc(ip->dev);
    80002fa4:	4108                	lw	a0,0(a0)
    80002fa6:	ebfff0ef          	jal	ra,80002e64 <balloc>
    80002faa:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002fae:	04090f63          	beqz	s2,8000300c <bmap+0x94>
        return 0;
      ip->addrs[bn] = addr;
    80002fb2:	0524a823          	sw	s2,80(s1)
    80002fb6:	a899                	j	8000300c <bmap+0x94>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002fb8:	ff45849b          	addiw	s1,a1,-12
    80002fbc:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80002fc0:	0ff00793          	li	a5,255
    80002fc4:	06e7eb63          	bltu	a5,a4,8000303a <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002fc8:	08052903          	lw	s2,128(a0)
    80002fcc:	00091b63          	bnez	s2,80002fe2 <bmap+0x6a>
      addr = balloc(ip->dev);
    80002fd0:	4108                	lw	a0,0(a0)
    80002fd2:	e93ff0ef          	jal	ra,80002e64 <balloc>
    80002fd6:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80002fda:	02090963          	beqz	s2,8000300c <bmap+0x94>
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002fde:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80002fe2:	85ca                	mv	a1,s2
    80002fe4:	0009a503          	lw	a0,0(s3)
    80002fe8:	c17ff0ef          	jal	ra,80002bfe <bread>
    80002fec:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002fee:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002ff2:	02049713          	slli	a4,s1,0x20
    80002ff6:	01e75593          	srli	a1,a4,0x1e
    80002ffa:	00b784b3          	add	s1,a5,a1
    80002ffe:	0004a903          	lw	s2,0(s1)
    80003002:	00090e63          	beqz	s2,8000301e <bmap+0xa6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003006:	8552                	mv	a0,s4
    80003008:	cffff0ef          	jal	ra,80002d06 <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    8000300c:	854a                	mv	a0,s2
    8000300e:	70a2                	ld	ra,40(sp)
    80003010:	7402                	ld	s0,32(sp)
    80003012:	64e2                	ld	s1,24(sp)
    80003014:	6942                	ld	s2,16(sp)
    80003016:	69a2                	ld	s3,8(sp)
    80003018:	6a02                	ld	s4,0(sp)
    8000301a:	6145                	addi	sp,sp,48
    8000301c:	8082                	ret
      addr = balloc(ip->dev);
    8000301e:	0009a503          	lw	a0,0(s3)
    80003022:	e43ff0ef          	jal	ra,80002e64 <balloc>
    80003026:	0005091b          	sext.w	s2,a0
      if(addr){
    8000302a:	fc090ee3          	beqz	s2,80003006 <bmap+0x8e>
        a[bn] = addr;
    8000302e:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80003032:	8552                	mv	a0,s4
    80003034:	4fd000ef          	jal	ra,80003d30 <log_write>
    80003038:	b7f9                	j	80003006 <bmap+0x8e>
  panic("bmap: out of range");
    8000303a:	00004517          	auipc	a0,0x4
    8000303e:	65650513          	addi	a0,a0,1622 # 80007690 <syscall_names+0x120>
    80003042:	f26fd0ef          	jal	ra,80000768 <panic>

0000000080003046 <iget>:
{
    80003046:	7179                	addi	sp,sp,-48
    80003048:	f406                	sd	ra,40(sp)
    8000304a:	f022                	sd	s0,32(sp)
    8000304c:	ec26                	sd	s1,24(sp)
    8000304e:	e84a                	sd	s2,16(sp)
    80003050:	e44e                	sd	s3,8(sp)
    80003052:	e052                	sd	s4,0(sp)
    80003054:	1800                	addi	s0,sp,48
    80003056:	89aa                	mv	s3,a0
    80003058:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000305a:	00020517          	auipc	a0,0x20
    8000305e:	d9650513          	addi	a0,a0,-618 # 80022df0 <itable>
    80003062:	b8dfd0ef          	jal	ra,80000bee <acquire>
  empty = 0;
    80003066:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003068:	00020497          	auipc	s1,0x20
    8000306c:	da048493          	addi	s1,s1,-608 # 80022e08 <itable+0x18>
    80003070:	00022697          	auipc	a3,0x22
    80003074:	82868693          	addi	a3,a3,-2008 # 80024898 <log>
    80003078:	a039                	j	80003086 <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    8000307a:	02090963          	beqz	s2,800030ac <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000307e:	08848493          	addi	s1,s1,136
    80003082:	02d48863          	beq	s1,a3,800030b2 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80003086:	449c                	lw	a5,8(s1)
    80003088:	fef059e3          	blez	a5,8000307a <iget+0x34>
    8000308c:	4098                	lw	a4,0(s1)
    8000308e:	ff3716e3          	bne	a4,s3,8000307a <iget+0x34>
    80003092:	40d8                	lw	a4,4(s1)
    80003094:	ff4713e3          	bne	a4,s4,8000307a <iget+0x34>
      ip->ref++;
    80003098:	2785                	addiw	a5,a5,1
    8000309a:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    8000309c:	00020517          	auipc	a0,0x20
    800030a0:	d5450513          	addi	a0,a0,-684 # 80022df0 <itable>
    800030a4:	be3fd0ef          	jal	ra,80000c86 <release>
      return ip;
    800030a8:	8926                	mv	s2,s1
    800030aa:	a02d                	j	800030d4 <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800030ac:	fbe9                	bnez	a5,8000307e <iget+0x38>
    800030ae:	8926                	mv	s2,s1
    800030b0:	b7f9                	j	8000307e <iget+0x38>
  if(empty == 0)
    800030b2:	02090a63          	beqz	s2,800030e6 <iget+0xa0>
  ip->dev = dev;
    800030b6:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800030ba:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800030be:	4785                	li	a5,1
    800030c0:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    800030c4:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800030c8:	00020517          	auipc	a0,0x20
    800030cc:	d2850513          	addi	a0,a0,-728 # 80022df0 <itable>
    800030d0:	bb7fd0ef          	jal	ra,80000c86 <release>
}
    800030d4:	854a                	mv	a0,s2
    800030d6:	70a2                	ld	ra,40(sp)
    800030d8:	7402                	ld	s0,32(sp)
    800030da:	64e2                	ld	s1,24(sp)
    800030dc:	6942                	ld	s2,16(sp)
    800030de:	69a2                	ld	s3,8(sp)
    800030e0:	6a02                	ld	s4,0(sp)
    800030e2:	6145                	addi	sp,sp,48
    800030e4:	8082                	ret
    panic("iget: no inodes");
    800030e6:	00004517          	auipc	a0,0x4
    800030ea:	5c250513          	addi	a0,a0,1474 # 800076a8 <syscall_names+0x138>
    800030ee:	e7afd0ef          	jal	ra,80000768 <panic>

00000000800030f2 <fsinit>:
fsinit(int dev) {
    800030f2:	7179                	addi	sp,sp,-48
    800030f4:	f406                	sd	ra,40(sp)
    800030f6:	f022                	sd	s0,32(sp)
    800030f8:	ec26                	sd	s1,24(sp)
    800030fa:	e84a                	sd	s2,16(sp)
    800030fc:	e44e                	sd	s3,8(sp)
    800030fe:	1800                	addi	s0,sp,48
    80003100:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003102:	4585                	li	a1,1
    80003104:	afbff0ef          	jal	ra,80002bfe <bread>
    80003108:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000310a:	00020997          	auipc	s3,0x20
    8000310e:	cc698993          	addi	s3,s3,-826 # 80022dd0 <sb>
    80003112:	02000613          	li	a2,32
    80003116:	05850593          	addi	a1,a0,88
    8000311a:	854e                	mv	a0,s3
    8000311c:	c03fd0ef          	jal	ra,80000d1e <memmove>
  brelse(bp);
    80003120:	8526                	mv	a0,s1
    80003122:	be5ff0ef          	jal	ra,80002d06 <brelse>
  if(sb.magic != FSMAGIC)
    80003126:	0009a703          	lw	a4,0(s3)
    8000312a:	102037b7          	lui	a5,0x10203
    8000312e:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003132:	02f71063          	bne	a4,a5,80003152 <fsinit+0x60>
  initlog(dev, &sb);
    80003136:	00020597          	auipc	a1,0x20
    8000313a:	c9a58593          	addi	a1,a1,-870 # 80022dd0 <sb>
    8000313e:	854a                	mv	a0,s2
    80003140:	1db000ef          	jal	ra,80003b1a <initlog>
}
    80003144:	70a2                	ld	ra,40(sp)
    80003146:	7402                	ld	s0,32(sp)
    80003148:	64e2                	ld	s1,24(sp)
    8000314a:	6942                	ld	s2,16(sp)
    8000314c:	69a2                	ld	s3,8(sp)
    8000314e:	6145                	addi	sp,sp,48
    80003150:	8082                	ret
    panic("invalid file system");
    80003152:	00004517          	auipc	a0,0x4
    80003156:	56650513          	addi	a0,a0,1382 # 800076b8 <syscall_names+0x148>
    8000315a:	e0efd0ef          	jal	ra,80000768 <panic>

000000008000315e <iinit>:
{
    8000315e:	7179                	addi	sp,sp,-48
    80003160:	f406                	sd	ra,40(sp)
    80003162:	f022                	sd	s0,32(sp)
    80003164:	ec26                	sd	s1,24(sp)
    80003166:	e84a                	sd	s2,16(sp)
    80003168:	e44e                	sd	s3,8(sp)
    8000316a:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000316c:	00004597          	auipc	a1,0x4
    80003170:	56458593          	addi	a1,a1,1380 # 800076d0 <syscall_names+0x160>
    80003174:	00020517          	auipc	a0,0x20
    80003178:	c7c50513          	addi	a0,a0,-900 # 80022df0 <itable>
    8000317c:	9f3fd0ef          	jal	ra,80000b6e <initlock>
  for(i = 0; i < NINODE; i++) {
    80003180:	00020497          	auipc	s1,0x20
    80003184:	c9848493          	addi	s1,s1,-872 # 80022e18 <itable+0x28>
    80003188:	00021997          	auipc	s3,0x21
    8000318c:	72098993          	addi	s3,s3,1824 # 800248a8 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003190:	00004917          	auipc	s2,0x4
    80003194:	54890913          	addi	s2,s2,1352 # 800076d8 <syscall_names+0x168>
    80003198:	85ca                	mv	a1,s2
    8000319a:	8526                	mv	a0,s1
    8000319c:	467000ef          	jal	ra,80003e02 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800031a0:	08848493          	addi	s1,s1,136
    800031a4:	ff349ae3          	bne	s1,s3,80003198 <iinit+0x3a>
}
    800031a8:	70a2                	ld	ra,40(sp)
    800031aa:	7402                	ld	s0,32(sp)
    800031ac:	64e2                	ld	s1,24(sp)
    800031ae:	6942                	ld	s2,16(sp)
    800031b0:	69a2                	ld	s3,8(sp)
    800031b2:	6145                	addi	sp,sp,48
    800031b4:	8082                	ret

00000000800031b6 <ialloc>:
{
    800031b6:	715d                	addi	sp,sp,-80
    800031b8:	e486                	sd	ra,72(sp)
    800031ba:	e0a2                	sd	s0,64(sp)
    800031bc:	fc26                	sd	s1,56(sp)
    800031be:	f84a                	sd	s2,48(sp)
    800031c0:	f44e                	sd	s3,40(sp)
    800031c2:	f052                	sd	s4,32(sp)
    800031c4:	ec56                	sd	s5,24(sp)
    800031c6:	e85a                	sd	s6,16(sp)
    800031c8:	e45e                	sd	s7,8(sp)
    800031ca:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    800031cc:	00020717          	auipc	a4,0x20
    800031d0:	c1072703          	lw	a4,-1008(a4) # 80022ddc <sb+0xc>
    800031d4:	4785                	li	a5,1
    800031d6:	04e7f663          	bgeu	a5,a4,80003222 <ialloc+0x6c>
    800031da:	8aaa                	mv	s5,a0
    800031dc:	8bae                	mv	s7,a1
    800031de:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    800031e0:	00020a17          	auipc	s4,0x20
    800031e4:	bf0a0a13          	addi	s4,s4,-1040 # 80022dd0 <sb>
    800031e8:	00048b1b          	sext.w	s6,s1
    800031ec:	0044d793          	srli	a5,s1,0x4
    800031f0:	018a2583          	lw	a1,24(s4)
    800031f4:	9dbd                	addw	a1,a1,a5
    800031f6:	8556                	mv	a0,s5
    800031f8:	a07ff0ef          	jal	ra,80002bfe <bread>
    800031fc:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800031fe:	05850993          	addi	s3,a0,88
    80003202:	00f4f793          	andi	a5,s1,15
    80003206:	079a                	slli	a5,a5,0x6
    80003208:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000320a:	00099783          	lh	a5,0(s3)
    8000320e:	cf85                	beqz	a5,80003246 <ialloc+0x90>
    brelse(bp);
    80003210:	af7ff0ef          	jal	ra,80002d06 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80003214:	0485                	addi	s1,s1,1
    80003216:	00ca2703          	lw	a4,12(s4)
    8000321a:	0004879b          	sext.w	a5,s1
    8000321e:	fce7e5e3          	bltu	a5,a4,800031e8 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    80003222:	00004517          	auipc	a0,0x4
    80003226:	4be50513          	addi	a0,a0,1214 # 800076e0 <syscall_names+0x170>
    8000322a:	a78fd0ef          	jal	ra,800004a2 <printf>
  return 0;
    8000322e:	4501                	li	a0,0
}
    80003230:	60a6                	ld	ra,72(sp)
    80003232:	6406                	ld	s0,64(sp)
    80003234:	74e2                	ld	s1,56(sp)
    80003236:	7942                	ld	s2,48(sp)
    80003238:	79a2                	ld	s3,40(sp)
    8000323a:	7a02                	ld	s4,32(sp)
    8000323c:	6ae2                	ld	s5,24(sp)
    8000323e:	6b42                	ld	s6,16(sp)
    80003240:	6ba2                	ld	s7,8(sp)
    80003242:	6161                	addi	sp,sp,80
    80003244:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003246:	04000613          	li	a2,64
    8000324a:	4581                	li	a1,0
    8000324c:	854e                	mv	a0,s3
    8000324e:	a75fd0ef          	jal	ra,80000cc2 <memset>
      dip->type = type;
    80003252:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003256:	854a                	mv	a0,s2
    80003258:	2d9000ef          	jal	ra,80003d30 <log_write>
      brelse(bp);
    8000325c:	854a                	mv	a0,s2
    8000325e:	aa9ff0ef          	jal	ra,80002d06 <brelse>
      return iget(dev, inum);
    80003262:	85da                	mv	a1,s6
    80003264:	8556                	mv	a0,s5
    80003266:	de1ff0ef          	jal	ra,80003046 <iget>
    8000326a:	b7d9                	j	80003230 <ialloc+0x7a>

000000008000326c <iupdate>:
{
    8000326c:	1101                	addi	sp,sp,-32
    8000326e:	ec06                	sd	ra,24(sp)
    80003270:	e822                	sd	s0,16(sp)
    80003272:	e426                	sd	s1,8(sp)
    80003274:	e04a                	sd	s2,0(sp)
    80003276:	1000                	addi	s0,sp,32
    80003278:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000327a:	415c                	lw	a5,4(a0)
    8000327c:	0047d79b          	srliw	a5,a5,0x4
    80003280:	00020597          	auipc	a1,0x20
    80003284:	b685a583          	lw	a1,-1176(a1) # 80022de8 <sb+0x18>
    80003288:	9dbd                	addw	a1,a1,a5
    8000328a:	4108                	lw	a0,0(a0)
    8000328c:	973ff0ef          	jal	ra,80002bfe <bread>
    80003290:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003292:	05850793          	addi	a5,a0,88
    80003296:	40c8                	lw	a0,4(s1)
    80003298:	893d                	andi	a0,a0,15
    8000329a:	051a                	slli	a0,a0,0x6
    8000329c:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    8000329e:	04449703          	lh	a4,68(s1)
    800032a2:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    800032a6:	04649703          	lh	a4,70(s1)
    800032aa:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    800032ae:	04849703          	lh	a4,72(s1)
    800032b2:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    800032b6:	04a49703          	lh	a4,74(s1)
    800032ba:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    800032be:	44f8                	lw	a4,76(s1)
    800032c0:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800032c2:	03400613          	li	a2,52
    800032c6:	05048593          	addi	a1,s1,80
    800032ca:	0531                	addi	a0,a0,12
    800032cc:	a53fd0ef          	jal	ra,80000d1e <memmove>
  log_write(bp);
    800032d0:	854a                	mv	a0,s2
    800032d2:	25f000ef          	jal	ra,80003d30 <log_write>
  brelse(bp);
    800032d6:	854a                	mv	a0,s2
    800032d8:	a2fff0ef          	jal	ra,80002d06 <brelse>
}
    800032dc:	60e2                	ld	ra,24(sp)
    800032de:	6442                	ld	s0,16(sp)
    800032e0:	64a2                	ld	s1,8(sp)
    800032e2:	6902                	ld	s2,0(sp)
    800032e4:	6105                	addi	sp,sp,32
    800032e6:	8082                	ret

00000000800032e8 <idup>:
{
    800032e8:	1101                	addi	sp,sp,-32
    800032ea:	ec06                	sd	ra,24(sp)
    800032ec:	e822                	sd	s0,16(sp)
    800032ee:	e426                	sd	s1,8(sp)
    800032f0:	1000                	addi	s0,sp,32
    800032f2:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800032f4:	00020517          	auipc	a0,0x20
    800032f8:	afc50513          	addi	a0,a0,-1284 # 80022df0 <itable>
    800032fc:	8f3fd0ef          	jal	ra,80000bee <acquire>
  ip->ref++;
    80003300:	449c                	lw	a5,8(s1)
    80003302:	2785                	addiw	a5,a5,1
    80003304:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003306:	00020517          	auipc	a0,0x20
    8000330a:	aea50513          	addi	a0,a0,-1302 # 80022df0 <itable>
    8000330e:	979fd0ef          	jal	ra,80000c86 <release>
}
    80003312:	8526                	mv	a0,s1
    80003314:	60e2                	ld	ra,24(sp)
    80003316:	6442                	ld	s0,16(sp)
    80003318:	64a2                	ld	s1,8(sp)
    8000331a:	6105                	addi	sp,sp,32
    8000331c:	8082                	ret

000000008000331e <ilock>:
{
    8000331e:	1101                	addi	sp,sp,-32
    80003320:	ec06                	sd	ra,24(sp)
    80003322:	e822                	sd	s0,16(sp)
    80003324:	e426                	sd	s1,8(sp)
    80003326:	e04a                	sd	s2,0(sp)
    80003328:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000332a:	c105                	beqz	a0,8000334a <ilock+0x2c>
    8000332c:	84aa                	mv	s1,a0
    8000332e:	451c                	lw	a5,8(a0)
    80003330:	00f05d63          	blez	a5,8000334a <ilock+0x2c>
  acquiresleep(&ip->lock);
    80003334:	0541                	addi	a0,a0,16
    80003336:	303000ef          	jal	ra,80003e38 <acquiresleep>
  if(ip->valid == 0){
    8000333a:	40bc                	lw	a5,64(s1)
    8000333c:	cf89                	beqz	a5,80003356 <ilock+0x38>
}
    8000333e:	60e2                	ld	ra,24(sp)
    80003340:	6442                	ld	s0,16(sp)
    80003342:	64a2                	ld	s1,8(sp)
    80003344:	6902                	ld	s2,0(sp)
    80003346:	6105                	addi	sp,sp,32
    80003348:	8082                	ret
    panic("ilock");
    8000334a:	00004517          	auipc	a0,0x4
    8000334e:	3ae50513          	addi	a0,a0,942 # 800076f8 <syscall_names+0x188>
    80003352:	c16fd0ef          	jal	ra,80000768 <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003356:	40dc                	lw	a5,4(s1)
    80003358:	0047d79b          	srliw	a5,a5,0x4
    8000335c:	00020597          	auipc	a1,0x20
    80003360:	a8c5a583          	lw	a1,-1396(a1) # 80022de8 <sb+0x18>
    80003364:	9dbd                	addw	a1,a1,a5
    80003366:	4088                	lw	a0,0(s1)
    80003368:	897ff0ef          	jal	ra,80002bfe <bread>
    8000336c:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000336e:	05850593          	addi	a1,a0,88
    80003372:	40dc                	lw	a5,4(s1)
    80003374:	8bbd                	andi	a5,a5,15
    80003376:	079a                	slli	a5,a5,0x6
    80003378:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    8000337a:	00059783          	lh	a5,0(a1)
    8000337e:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003382:	00259783          	lh	a5,2(a1)
    80003386:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    8000338a:	00459783          	lh	a5,4(a1)
    8000338e:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003392:	00659783          	lh	a5,6(a1)
    80003396:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    8000339a:	459c                	lw	a5,8(a1)
    8000339c:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000339e:	03400613          	li	a2,52
    800033a2:	05b1                	addi	a1,a1,12
    800033a4:	05048513          	addi	a0,s1,80
    800033a8:	977fd0ef          	jal	ra,80000d1e <memmove>
    brelse(bp);
    800033ac:	854a                	mv	a0,s2
    800033ae:	959ff0ef          	jal	ra,80002d06 <brelse>
    ip->valid = 1;
    800033b2:	4785                	li	a5,1
    800033b4:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800033b6:	04449783          	lh	a5,68(s1)
    800033ba:	f3d1                	bnez	a5,8000333e <ilock+0x20>
      panic("ilock: no type");
    800033bc:	00004517          	auipc	a0,0x4
    800033c0:	34450513          	addi	a0,a0,836 # 80007700 <syscall_names+0x190>
    800033c4:	ba4fd0ef          	jal	ra,80000768 <panic>

00000000800033c8 <iunlock>:
{
    800033c8:	1101                	addi	sp,sp,-32
    800033ca:	ec06                	sd	ra,24(sp)
    800033cc:	e822                	sd	s0,16(sp)
    800033ce:	e426                	sd	s1,8(sp)
    800033d0:	e04a                	sd	s2,0(sp)
    800033d2:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800033d4:	c505                	beqz	a0,800033fc <iunlock+0x34>
    800033d6:	84aa                	mv	s1,a0
    800033d8:	01050913          	addi	s2,a0,16
    800033dc:	854a                	mv	a0,s2
    800033de:	2d9000ef          	jal	ra,80003eb6 <holdingsleep>
    800033e2:	cd09                	beqz	a0,800033fc <iunlock+0x34>
    800033e4:	449c                	lw	a5,8(s1)
    800033e6:	00f05b63          	blez	a5,800033fc <iunlock+0x34>
  releasesleep(&ip->lock);
    800033ea:	854a                	mv	a0,s2
    800033ec:	293000ef          	jal	ra,80003e7e <releasesleep>
}
    800033f0:	60e2                	ld	ra,24(sp)
    800033f2:	6442                	ld	s0,16(sp)
    800033f4:	64a2                	ld	s1,8(sp)
    800033f6:	6902                	ld	s2,0(sp)
    800033f8:	6105                	addi	sp,sp,32
    800033fa:	8082                	ret
    panic("iunlock");
    800033fc:	00004517          	auipc	a0,0x4
    80003400:	31450513          	addi	a0,a0,788 # 80007710 <syscall_names+0x1a0>
    80003404:	b64fd0ef          	jal	ra,80000768 <panic>

0000000080003408 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003408:	7179                	addi	sp,sp,-48
    8000340a:	f406                	sd	ra,40(sp)
    8000340c:	f022                	sd	s0,32(sp)
    8000340e:	ec26                	sd	s1,24(sp)
    80003410:	e84a                	sd	s2,16(sp)
    80003412:	e44e                	sd	s3,8(sp)
    80003414:	e052                	sd	s4,0(sp)
    80003416:	1800                	addi	s0,sp,48
    80003418:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    8000341a:	05050493          	addi	s1,a0,80
    8000341e:	08050913          	addi	s2,a0,128
    80003422:	a021                	j	8000342a <itrunc+0x22>
    80003424:	0491                	addi	s1,s1,4
    80003426:	01248b63          	beq	s1,s2,8000343c <itrunc+0x34>
    if(ip->addrs[i]){
    8000342a:	408c                	lw	a1,0(s1)
    8000342c:	dde5                	beqz	a1,80003424 <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    8000342e:	0009a503          	lw	a0,0(s3)
    80003432:	9c7ff0ef          	jal	ra,80002df8 <bfree>
      ip->addrs[i] = 0;
    80003436:	0004a023          	sw	zero,0(s1)
    8000343a:	b7ed                	j	80003424 <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    8000343c:	0809a583          	lw	a1,128(s3)
    80003440:	ed91                	bnez	a1,8000345c <itrunc+0x54>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003442:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003446:	854e                	mv	a0,s3
    80003448:	e25ff0ef          	jal	ra,8000326c <iupdate>
}
    8000344c:	70a2                	ld	ra,40(sp)
    8000344e:	7402                	ld	s0,32(sp)
    80003450:	64e2                	ld	s1,24(sp)
    80003452:	6942                	ld	s2,16(sp)
    80003454:	69a2                	ld	s3,8(sp)
    80003456:	6a02                	ld	s4,0(sp)
    80003458:	6145                	addi	sp,sp,48
    8000345a:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000345c:	0009a503          	lw	a0,0(s3)
    80003460:	f9eff0ef          	jal	ra,80002bfe <bread>
    80003464:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003466:	05850493          	addi	s1,a0,88
    8000346a:	45850913          	addi	s2,a0,1112
    8000346e:	a021                	j	80003476 <itrunc+0x6e>
    80003470:	0491                	addi	s1,s1,4
    80003472:	01248963          	beq	s1,s2,80003484 <itrunc+0x7c>
      if(a[j])
    80003476:	408c                	lw	a1,0(s1)
    80003478:	dde5                	beqz	a1,80003470 <itrunc+0x68>
        bfree(ip->dev, a[j]);
    8000347a:	0009a503          	lw	a0,0(s3)
    8000347e:	97bff0ef          	jal	ra,80002df8 <bfree>
    80003482:	b7fd                	j	80003470 <itrunc+0x68>
    brelse(bp);
    80003484:	8552                	mv	a0,s4
    80003486:	881ff0ef          	jal	ra,80002d06 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    8000348a:	0809a583          	lw	a1,128(s3)
    8000348e:	0009a503          	lw	a0,0(s3)
    80003492:	967ff0ef          	jal	ra,80002df8 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003496:	0809a023          	sw	zero,128(s3)
    8000349a:	b765                	j	80003442 <itrunc+0x3a>

000000008000349c <iput>:
{
    8000349c:	1101                	addi	sp,sp,-32
    8000349e:	ec06                	sd	ra,24(sp)
    800034a0:	e822                	sd	s0,16(sp)
    800034a2:	e426                	sd	s1,8(sp)
    800034a4:	e04a                	sd	s2,0(sp)
    800034a6:	1000                	addi	s0,sp,32
    800034a8:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800034aa:	00020517          	auipc	a0,0x20
    800034ae:	94650513          	addi	a0,a0,-1722 # 80022df0 <itable>
    800034b2:	f3cfd0ef          	jal	ra,80000bee <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800034b6:	4498                	lw	a4,8(s1)
    800034b8:	4785                	li	a5,1
    800034ba:	02f70163          	beq	a4,a5,800034dc <iput+0x40>
  ip->ref--;
    800034be:	449c                	lw	a5,8(s1)
    800034c0:	37fd                	addiw	a5,a5,-1
    800034c2:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034c4:	00020517          	auipc	a0,0x20
    800034c8:	92c50513          	addi	a0,a0,-1748 # 80022df0 <itable>
    800034cc:	fbafd0ef          	jal	ra,80000c86 <release>
}
    800034d0:	60e2                	ld	ra,24(sp)
    800034d2:	6442                	ld	s0,16(sp)
    800034d4:	64a2                	ld	s1,8(sp)
    800034d6:	6902                	ld	s2,0(sp)
    800034d8:	6105                	addi	sp,sp,32
    800034da:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800034dc:	40bc                	lw	a5,64(s1)
    800034de:	d3e5                	beqz	a5,800034be <iput+0x22>
    800034e0:	04a49783          	lh	a5,74(s1)
    800034e4:	ffe9                	bnez	a5,800034be <iput+0x22>
    acquiresleep(&ip->lock);
    800034e6:	01048913          	addi	s2,s1,16
    800034ea:	854a                	mv	a0,s2
    800034ec:	14d000ef          	jal	ra,80003e38 <acquiresleep>
    release(&itable.lock);
    800034f0:	00020517          	auipc	a0,0x20
    800034f4:	90050513          	addi	a0,a0,-1792 # 80022df0 <itable>
    800034f8:	f8efd0ef          	jal	ra,80000c86 <release>
    itrunc(ip);
    800034fc:	8526                	mv	a0,s1
    800034fe:	f0bff0ef          	jal	ra,80003408 <itrunc>
    ip->type = 0;
    80003502:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003506:	8526                	mv	a0,s1
    80003508:	d65ff0ef          	jal	ra,8000326c <iupdate>
    ip->valid = 0;
    8000350c:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003510:	854a                	mv	a0,s2
    80003512:	16d000ef          	jal	ra,80003e7e <releasesleep>
    acquire(&itable.lock);
    80003516:	00020517          	auipc	a0,0x20
    8000351a:	8da50513          	addi	a0,a0,-1830 # 80022df0 <itable>
    8000351e:	ed0fd0ef          	jal	ra,80000bee <acquire>
    80003522:	bf71                	j	800034be <iput+0x22>

0000000080003524 <iunlockput>:
{
    80003524:	1101                	addi	sp,sp,-32
    80003526:	ec06                	sd	ra,24(sp)
    80003528:	e822                	sd	s0,16(sp)
    8000352a:	e426                	sd	s1,8(sp)
    8000352c:	1000                	addi	s0,sp,32
    8000352e:	84aa                	mv	s1,a0
  iunlock(ip);
    80003530:	e99ff0ef          	jal	ra,800033c8 <iunlock>
  iput(ip);
    80003534:	8526                	mv	a0,s1
    80003536:	f67ff0ef          	jal	ra,8000349c <iput>
}
    8000353a:	60e2                	ld	ra,24(sp)
    8000353c:	6442                	ld	s0,16(sp)
    8000353e:	64a2                	ld	s1,8(sp)
    80003540:	6105                	addi	sp,sp,32
    80003542:	8082                	ret

0000000080003544 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003544:	1141                	addi	sp,sp,-16
    80003546:	e422                	sd	s0,8(sp)
    80003548:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    8000354a:	411c                	lw	a5,0(a0)
    8000354c:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000354e:	415c                	lw	a5,4(a0)
    80003550:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003552:	04451783          	lh	a5,68(a0)
    80003556:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    8000355a:	04a51783          	lh	a5,74(a0)
    8000355e:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003562:	04c56783          	lwu	a5,76(a0)
    80003566:	e99c                	sd	a5,16(a1)
}
    80003568:	6422                	ld	s0,8(sp)
    8000356a:	0141                	addi	sp,sp,16
    8000356c:	8082                	ret

000000008000356e <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    8000356e:	457c                	lw	a5,76(a0)
    80003570:	0cd7ef63          	bltu	a5,a3,8000364e <readi+0xe0>
{
    80003574:	7159                	addi	sp,sp,-112
    80003576:	f486                	sd	ra,104(sp)
    80003578:	f0a2                	sd	s0,96(sp)
    8000357a:	eca6                	sd	s1,88(sp)
    8000357c:	e8ca                	sd	s2,80(sp)
    8000357e:	e4ce                	sd	s3,72(sp)
    80003580:	e0d2                	sd	s4,64(sp)
    80003582:	fc56                	sd	s5,56(sp)
    80003584:	f85a                	sd	s6,48(sp)
    80003586:	f45e                	sd	s7,40(sp)
    80003588:	f062                	sd	s8,32(sp)
    8000358a:	ec66                	sd	s9,24(sp)
    8000358c:	e86a                	sd	s10,16(sp)
    8000358e:	e46e                	sd	s11,8(sp)
    80003590:	1880                	addi	s0,sp,112
    80003592:	8b2a                	mv	s6,a0
    80003594:	8bae                	mv	s7,a1
    80003596:	8a32                	mv	s4,a2
    80003598:	84b6                	mv	s1,a3
    8000359a:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    8000359c:	9f35                	addw	a4,a4,a3
    return 0;
    8000359e:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    800035a0:	08d76663          	bltu	a4,a3,8000362c <readi+0xbe>
  if(off + n > ip->size)
    800035a4:	00e7f463          	bgeu	a5,a4,800035ac <readi+0x3e>
    n = ip->size - off;
    800035a8:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800035ac:	080a8f63          	beqz	s5,8000364a <readi+0xdc>
    800035b0:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800035b2:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800035b6:	5c7d                	li	s8,-1
    800035b8:	a80d                	j	800035ea <readi+0x7c>
    800035ba:	020d1d93          	slli	s11,s10,0x20
    800035be:	020ddd93          	srli	s11,s11,0x20
    800035c2:	05890793          	addi	a5,s2,88
    800035c6:	86ee                	mv	a3,s11
    800035c8:	963e                	add	a2,a2,a5
    800035ca:	85d2                	mv	a1,s4
    800035cc:	855e                	mv	a0,s7
    800035ce:	c31fe0ef          	jal	ra,800021fe <either_copyout>
    800035d2:	05850763          	beq	a0,s8,80003620 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800035d6:	854a                	mv	a0,s2
    800035d8:	f2eff0ef          	jal	ra,80002d06 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800035dc:	013d09bb          	addw	s3,s10,s3
    800035e0:	009d04bb          	addw	s1,s10,s1
    800035e4:	9a6e                	add	s4,s4,s11
    800035e6:	0559f163          	bgeu	s3,s5,80003628 <readi+0xba>
    uint addr = bmap(ip, off/BSIZE);
    800035ea:	00a4d59b          	srliw	a1,s1,0xa
    800035ee:	855a                	mv	a0,s6
    800035f0:	989ff0ef          	jal	ra,80002f78 <bmap>
    800035f4:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    800035f8:	c985                	beqz	a1,80003628 <readi+0xba>
    bp = bread(ip->dev, addr);
    800035fa:	000b2503          	lw	a0,0(s6)
    800035fe:	e00ff0ef          	jal	ra,80002bfe <bread>
    80003602:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003604:	3ff4f613          	andi	a2,s1,1023
    80003608:	40cc87bb          	subw	a5,s9,a2
    8000360c:	413a873b          	subw	a4,s5,s3
    80003610:	8d3e                	mv	s10,a5
    80003612:	2781                	sext.w	a5,a5
    80003614:	0007069b          	sext.w	a3,a4
    80003618:	faf6f1e3          	bgeu	a3,a5,800035ba <readi+0x4c>
    8000361c:	8d3a                	mv	s10,a4
    8000361e:	bf71                	j	800035ba <readi+0x4c>
      brelse(bp);
    80003620:	854a                	mv	a0,s2
    80003622:	ee4ff0ef          	jal	ra,80002d06 <brelse>
      tot = -1;
    80003626:	59fd                	li	s3,-1
  }
  return tot;
    80003628:	0009851b          	sext.w	a0,s3
}
    8000362c:	70a6                	ld	ra,104(sp)
    8000362e:	7406                	ld	s0,96(sp)
    80003630:	64e6                	ld	s1,88(sp)
    80003632:	6946                	ld	s2,80(sp)
    80003634:	69a6                	ld	s3,72(sp)
    80003636:	6a06                	ld	s4,64(sp)
    80003638:	7ae2                	ld	s5,56(sp)
    8000363a:	7b42                	ld	s6,48(sp)
    8000363c:	7ba2                	ld	s7,40(sp)
    8000363e:	7c02                	ld	s8,32(sp)
    80003640:	6ce2                	ld	s9,24(sp)
    80003642:	6d42                	ld	s10,16(sp)
    80003644:	6da2                	ld	s11,8(sp)
    80003646:	6165                	addi	sp,sp,112
    80003648:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000364a:	89d6                	mv	s3,s5
    8000364c:	bff1                	j	80003628 <readi+0xba>
    return 0;
    8000364e:	4501                	li	a0,0
}
    80003650:	8082                	ret

0000000080003652 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003652:	457c                	lw	a5,76(a0)
    80003654:	0ed7ea63          	bltu	a5,a3,80003748 <writei+0xf6>
{
    80003658:	7159                	addi	sp,sp,-112
    8000365a:	f486                	sd	ra,104(sp)
    8000365c:	f0a2                	sd	s0,96(sp)
    8000365e:	eca6                	sd	s1,88(sp)
    80003660:	e8ca                	sd	s2,80(sp)
    80003662:	e4ce                	sd	s3,72(sp)
    80003664:	e0d2                	sd	s4,64(sp)
    80003666:	fc56                	sd	s5,56(sp)
    80003668:	f85a                	sd	s6,48(sp)
    8000366a:	f45e                	sd	s7,40(sp)
    8000366c:	f062                	sd	s8,32(sp)
    8000366e:	ec66                	sd	s9,24(sp)
    80003670:	e86a                	sd	s10,16(sp)
    80003672:	e46e                	sd	s11,8(sp)
    80003674:	1880                	addi	s0,sp,112
    80003676:	8aaa                	mv	s5,a0
    80003678:	8bae                	mv	s7,a1
    8000367a:	8a32                	mv	s4,a2
    8000367c:	8936                	mv	s2,a3
    8000367e:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003680:	00e687bb          	addw	a5,a3,a4
    80003684:	0cd7e463          	bltu	a5,a3,8000374c <writei+0xfa>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003688:	00043737          	lui	a4,0x43
    8000368c:	0cf76263          	bltu	a4,a5,80003750 <writei+0xfe>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003690:	0a0b0a63          	beqz	s6,80003744 <writei+0xf2>
    80003694:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003696:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000369a:	5c7d                	li	s8,-1
    8000369c:	a825                	j	800036d4 <writei+0x82>
    8000369e:	020d1d93          	slli	s11,s10,0x20
    800036a2:	020ddd93          	srli	s11,s11,0x20
    800036a6:	05848793          	addi	a5,s1,88
    800036aa:	86ee                	mv	a3,s11
    800036ac:	8652                	mv	a2,s4
    800036ae:	85de                	mv	a1,s7
    800036b0:	953e                	add	a0,a0,a5
    800036b2:	b97fe0ef          	jal	ra,80002248 <either_copyin>
    800036b6:	05850a63          	beq	a0,s8,8000370a <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    800036ba:	8526                	mv	a0,s1
    800036bc:	674000ef          	jal	ra,80003d30 <log_write>
    brelse(bp);
    800036c0:	8526                	mv	a0,s1
    800036c2:	e44ff0ef          	jal	ra,80002d06 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800036c6:	013d09bb          	addw	s3,s10,s3
    800036ca:	012d093b          	addw	s2,s10,s2
    800036ce:	9a6e                	add	s4,s4,s11
    800036d0:	0569f063          	bgeu	s3,s6,80003710 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    800036d4:	00a9559b          	srliw	a1,s2,0xa
    800036d8:	8556                	mv	a0,s5
    800036da:	89fff0ef          	jal	ra,80002f78 <bmap>
    800036de:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    800036e2:	c59d                	beqz	a1,80003710 <writei+0xbe>
    bp = bread(ip->dev, addr);
    800036e4:	000aa503          	lw	a0,0(s5)
    800036e8:	d16ff0ef          	jal	ra,80002bfe <bread>
    800036ec:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800036ee:	3ff97513          	andi	a0,s2,1023
    800036f2:	40ac87bb          	subw	a5,s9,a0
    800036f6:	413b073b          	subw	a4,s6,s3
    800036fa:	8d3e                	mv	s10,a5
    800036fc:	2781                	sext.w	a5,a5
    800036fe:	0007069b          	sext.w	a3,a4
    80003702:	f8f6fee3          	bgeu	a3,a5,8000369e <writei+0x4c>
    80003706:	8d3a                	mv	s10,a4
    80003708:	bf59                	j	8000369e <writei+0x4c>
      brelse(bp);
    8000370a:	8526                	mv	a0,s1
    8000370c:	dfaff0ef          	jal	ra,80002d06 <brelse>
  }

  if(off > ip->size)
    80003710:	04caa783          	lw	a5,76(s5)
    80003714:	0127f463          	bgeu	a5,s2,8000371c <writei+0xca>
    ip->size = off;
    80003718:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    8000371c:	8556                	mv	a0,s5
    8000371e:	b4fff0ef          	jal	ra,8000326c <iupdate>

  return tot;
    80003722:	0009851b          	sext.w	a0,s3
}
    80003726:	70a6                	ld	ra,104(sp)
    80003728:	7406                	ld	s0,96(sp)
    8000372a:	64e6                	ld	s1,88(sp)
    8000372c:	6946                	ld	s2,80(sp)
    8000372e:	69a6                	ld	s3,72(sp)
    80003730:	6a06                	ld	s4,64(sp)
    80003732:	7ae2                	ld	s5,56(sp)
    80003734:	7b42                	ld	s6,48(sp)
    80003736:	7ba2                	ld	s7,40(sp)
    80003738:	7c02                	ld	s8,32(sp)
    8000373a:	6ce2                	ld	s9,24(sp)
    8000373c:	6d42                	ld	s10,16(sp)
    8000373e:	6da2                	ld	s11,8(sp)
    80003740:	6165                	addi	sp,sp,112
    80003742:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003744:	89da                	mv	s3,s6
    80003746:	bfd9                	j	8000371c <writei+0xca>
    return -1;
    80003748:	557d                	li	a0,-1
}
    8000374a:	8082                	ret
    return -1;
    8000374c:	557d                	li	a0,-1
    8000374e:	bfe1                	j	80003726 <writei+0xd4>
    return -1;
    80003750:	557d                	li	a0,-1
    80003752:	bfd1                	j	80003726 <writei+0xd4>

0000000080003754 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003754:	1141                	addi	sp,sp,-16
    80003756:	e406                	sd	ra,8(sp)
    80003758:	e022                	sd	s0,0(sp)
    8000375a:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    8000375c:	4639                	li	a2,14
    8000375e:	e30fd0ef          	jal	ra,80000d8e <strncmp>
}
    80003762:	60a2                	ld	ra,8(sp)
    80003764:	6402                	ld	s0,0(sp)
    80003766:	0141                	addi	sp,sp,16
    80003768:	8082                	ret

000000008000376a <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    8000376a:	7139                	addi	sp,sp,-64
    8000376c:	fc06                	sd	ra,56(sp)
    8000376e:	f822                	sd	s0,48(sp)
    80003770:	f426                	sd	s1,40(sp)
    80003772:	f04a                	sd	s2,32(sp)
    80003774:	ec4e                	sd	s3,24(sp)
    80003776:	e852                	sd	s4,16(sp)
    80003778:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    8000377a:	04451703          	lh	a4,68(a0)
    8000377e:	4785                	li	a5,1
    80003780:	00f71a63          	bne	a4,a5,80003794 <dirlookup+0x2a>
    80003784:	892a                	mv	s2,a0
    80003786:	89ae                	mv	s3,a1
    80003788:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    8000378a:	457c                	lw	a5,76(a0)
    8000378c:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000378e:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003790:	e39d                	bnez	a5,800037b6 <dirlookup+0x4c>
    80003792:	a095                	j	800037f6 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003794:	00004517          	auipc	a0,0x4
    80003798:	f8450513          	addi	a0,a0,-124 # 80007718 <syscall_names+0x1a8>
    8000379c:	fcdfc0ef          	jal	ra,80000768 <panic>
      panic("dirlookup read");
    800037a0:	00004517          	auipc	a0,0x4
    800037a4:	f9050513          	addi	a0,a0,-112 # 80007730 <syscall_names+0x1c0>
    800037a8:	fc1fc0ef          	jal	ra,80000768 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800037ac:	24c1                	addiw	s1,s1,16
    800037ae:	04c92783          	lw	a5,76(s2)
    800037b2:	04f4f163          	bgeu	s1,a5,800037f4 <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800037b6:	4741                	li	a4,16
    800037b8:	86a6                	mv	a3,s1
    800037ba:	fc040613          	addi	a2,s0,-64
    800037be:	4581                	li	a1,0
    800037c0:	854a                	mv	a0,s2
    800037c2:	dadff0ef          	jal	ra,8000356e <readi>
    800037c6:	47c1                	li	a5,16
    800037c8:	fcf51ce3          	bne	a0,a5,800037a0 <dirlookup+0x36>
    if(de.inum == 0)
    800037cc:	fc045783          	lhu	a5,-64(s0)
    800037d0:	dff1                	beqz	a5,800037ac <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    800037d2:	fc240593          	addi	a1,s0,-62
    800037d6:	854e                	mv	a0,s3
    800037d8:	f7dff0ef          	jal	ra,80003754 <namecmp>
    800037dc:	f961                	bnez	a0,800037ac <dirlookup+0x42>
      if(poff)
    800037de:	000a0463          	beqz	s4,800037e6 <dirlookup+0x7c>
        *poff = off;
    800037e2:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    800037e6:	fc045583          	lhu	a1,-64(s0)
    800037ea:	00092503          	lw	a0,0(s2)
    800037ee:	859ff0ef          	jal	ra,80003046 <iget>
    800037f2:	a011                	j	800037f6 <dirlookup+0x8c>
  return 0;
    800037f4:	4501                	li	a0,0
}
    800037f6:	70e2                	ld	ra,56(sp)
    800037f8:	7442                	ld	s0,48(sp)
    800037fa:	74a2                	ld	s1,40(sp)
    800037fc:	7902                	ld	s2,32(sp)
    800037fe:	69e2                	ld	s3,24(sp)
    80003800:	6a42                	ld	s4,16(sp)
    80003802:	6121                	addi	sp,sp,64
    80003804:	8082                	ret

0000000080003806 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003806:	711d                	addi	sp,sp,-96
    80003808:	ec86                	sd	ra,88(sp)
    8000380a:	e8a2                	sd	s0,80(sp)
    8000380c:	e4a6                	sd	s1,72(sp)
    8000380e:	e0ca                	sd	s2,64(sp)
    80003810:	fc4e                	sd	s3,56(sp)
    80003812:	f852                	sd	s4,48(sp)
    80003814:	f456                	sd	s5,40(sp)
    80003816:	f05a                	sd	s6,32(sp)
    80003818:	ec5e                	sd	s7,24(sp)
    8000381a:	e862                	sd	s8,16(sp)
    8000381c:	e466                	sd	s9,8(sp)
    8000381e:	1080                	addi	s0,sp,96
    80003820:	84aa                	mv	s1,a0
    80003822:	8aae                	mv	s5,a1
    80003824:	8a32                	mv	s4,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003826:	00054703          	lbu	a4,0(a0)
    8000382a:	02f00793          	li	a5,47
    8000382e:	00f70f63          	beq	a4,a5,8000384c <namex+0x46>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003832:	854fe0ef          	jal	ra,80001886 <myproc>
    80003836:	15053503          	ld	a0,336(a0)
    8000383a:	aafff0ef          	jal	ra,800032e8 <idup>
    8000383e:	89aa                	mv	s3,a0
  while(*path == '/')
    80003840:	02f00913          	li	s2,47
  len = path - s;
    80003844:	4b01                	li	s6,0
  if(len >= DIRSIZ)
    80003846:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003848:	4b85                	li	s7,1
    8000384a:	a861                	j	800038e2 <namex+0xdc>
    ip = iget(ROOTDEV, ROOTINO);
    8000384c:	4585                	li	a1,1
    8000384e:	4505                	li	a0,1
    80003850:	ff6ff0ef          	jal	ra,80003046 <iget>
    80003854:	89aa                	mv	s3,a0
    80003856:	b7ed                	j	80003840 <namex+0x3a>
      iunlockput(ip);
    80003858:	854e                	mv	a0,s3
    8000385a:	ccbff0ef          	jal	ra,80003524 <iunlockput>
      return 0;
    8000385e:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003860:	854e                	mv	a0,s3
    80003862:	60e6                	ld	ra,88(sp)
    80003864:	6446                	ld	s0,80(sp)
    80003866:	64a6                	ld	s1,72(sp)
    80003868:	6906                	ld	s2,64(sp)
    8000386a:	79e2                	ld	s3,56(sp)
    8000386c:	7a42                	ld	s4,48(sp)
    8000386e:	7aa2                	ld	s5,40(sp)
    80003870:	7b02                	ld	s6,32(sp)
    80003872:	6be2                	ld	s7,24(sp)
    80003874:	6c42                	ld	s8,16(sp)
    80003876:	6ca2                	ld	s9,8(sp)
    80003878:	6125                	addi	sp,sp,96
    8000387a:	8082                	ret
      iunlock(ip);
    8000387c:	854e                	mv	a0,s3
    8000387e:	b4bff0ef          	jal	ra,800033c8 <iunlock>
      return ip;
    80003882:	bff9                	j	80003860 <namex+0x5a>
      iunlockput(ip);
    80003884:	854e                	mv	a0,s3
    80003886:	c9fff0ef          	jal	ra,80003524 <iunlockput>
      return 0;
    8000388a:	89e6                	mv	s3,s9
    8000388c:	bfd1                	j	80003860 <namex+0x5a>
  len = path - s;
    8000388e:	40b48633          	sub	a2,s1,a1
    80003892:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003896:	079c5c63          	bge	s8,s9,8000390e <namex+0x108>
    memmove(name, s, DIRSIZ);
    8000389a:	4639                	li	a2,14
    8000389c:	8552                	mv	a0,s4
    8000389e:	c80fd0ef          	jal	ra,80000d1e <memmove>
  while(*path == '/')
    800038a2:	0004c783          	lbu	a5,0(s1)
    800038a6:	01279763          	bne	a5,s2,800038b4 <namex+0xae>
    path++;
    800038aa:	0485                	addi	s1,s1,1
  while(*path == '/')
    800038ac:	0004c783          	lbu	a5,0(s1)
    800038b0:	ff278de3          	beq	a5,s2,800038aa <namex+0xa4>
    ilock(ip);
    800038b4:	854e                	mv	a0,s3
    800038b6:	a69ff0ef          	jal	ra,8000331e <ilock>
    if(ip->type != T_DIR){
    800038ba:	04499783          	lh	a5,68(s3)
    800038be:	f9779de3          	bne	a5,s7,80003858 <namex+0x52>
    if(nameiparent && *path == '\0'){
    800038c2:	000a8563          	beqz	s5,800038cc <namex+0xc6>
    800038c6:	0004c783          	lbu	a5,0(s1)
    800038ca:	dbcd                	beqz	a5,8000387c <namex+0x76>
    if((next = dirlookup(ip, name, 0)) == 0){
    800038cc:	865a                	mv	a2,s6
    800038ce:	85d2                	mv	a1,s4
    800038d0:	854e                	mv	a0,s3
    800038d2:	e99ff0ef          	jal	ra,8000376a <dirlookup>
    800038d6:	8caa                	mv	s9,a0
    800038d8:	d555                	beqz	a0,80003884 <namex+0x7e>
    iunlockput(ip);
    800038da:	854e                	mv	a0,s3
    800038dc:	c49ff0ef          	jal	ra,80003524 <iunlockput>
    ip = next;
    800038e0:	89e6                	mv	s3,s9
  while(*path == '/')
    800038e2:	0004c783          	lbu	a5,0(s1)
    800038e6:	05279363          	bne	a5,s2,8000392c <namex+0x126>
    path++;
    800038ea:	0485                	addi	s1,s1,1
  while(*path == '/')
    800038ec:	0004c783          	lbu	a5,0(s1)
    800038f0:	ff278de3          	beq	a5,s2,800038ea <namex+0xe4>
  if(*path == 0)
    800038f4:	c78d                	beqz	a5,8000391e <namex+0x118>
    path++;
    800038f6:	85a6                	mv	a1,s1
  len = path - s;
    800038f8:	8cda                	mv	s9,s6
    800038fa:	865a                	mv	a2,s6
  while(*path != '/' && *path != 0)
    800038fc:	01278963          	beq	a5,s2,8000390e <namex+0x108>
    80003900:	d7d9                	beqz	a5,8000388e <namex+0x88>
    path++;
    80003902:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80003904:	0004c783          	lbu	a5,0(s1)
    80003908:	ff279ce3          	bne	a5,s2,80003900 <namex+0xfa>
    8000390c:	b749                	j	8000388e <namex+0x88>
    memmove(name, s, len);
    8000390e:	2601                	sext.w	a2,a2
    80003910:	8552                	mv	a0,s4
    80003912:	c0cfd0ef          	jal	ra,80000d1e <memmove>
    name[len] = 0;
    80003916:	9cd2                	add	s9,s9,s4
    80003918:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    8000391c:	b759                	j	800038a2 <namex+0x9c>
  if(nameiparent){
    8000391e:	f40a81e3          	beqz	s5,80003860 <namex+0x5a>
    iput(ip);
    80003922:	854e                	mv	a0,s3
    80003924:	b79ff0ef          	jal	ra,8000349c <iput>
    return 0;
    80003928:	4981                	li	s3,0
    8000392a:	bf1d                	j	80003860 <namex+0x5a>
  if(*path == 0)
    8000392c:	dbed                	beqz	a5,8000391e <namex+0x118>
  while(*path != '/' && *path != 0)
    8000392e:	0004c783          	lbu	a5,0(s1)
    80003932:	85a6                	mv	a1,s1
    80003934:	b7f1                	j	80003900 <namex+0xfa>

0000000080003936 <dirlink>:
{
    80003936:	7139                	addi	sp,sp,-64
    80003938:	fc06                	sd	ra,56(sp)
    8000393a:	f822                	sd	s0,48(sp)
    8000393c:	f426                	sd	s1,40(sp)
    8000393e:	f04a                	sd	s2,32(sp)
    80003940:	ec4e                	sd	s3,24(sp)
    80003942:	e852                	sd	s4,16(sp)
    80003944:	0080                	addi	s0,sp,64
    80003946:	892a                	mv	s2,a0
    80003948:	8a2e                	mv	s4,a1
    8000394a:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    8000394c:	4601                	li	a2,0
    8000394e:	e1dff0ef          	jal	ra,8000376a <dirlookup>
    80003952:	e52d                	bnez	a0,800039bc <dirlink+0x86>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003954:	04c92483          	lw	s1,76(s2)
    80003958:	c48d                	beqz	s1,80003982 <dirlink+0x4c>
    8000395a:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000395c:	4741                	li	a4,16
    8000395e:	86a6                	mv	a3,s1
    80003960:	fc040613          	addi	a2,s0,-64
    80003964:	4581                	li	a1,0
    80003966:	854a                	mv	a0,s2
    80003968:	c07ff0ef          	jal	ra,8000356e <readi>
    8000396c:	47c1                	li	a5,16
    8000396e:	04f51b63          	bne	a0,a5,800039c4 <dirlink+0x8e>
    if(de.inum == 0)
    80003972:	fc045783          	lhu	a5,-64(s0)
    80003976:	c791                	beqz	a5,80003982 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003978:	24c1                	addiw	s1,s1,16
    8000397a:	04c92783          	lw	a5,76(s2)
    8000397e:	fcf4efe3          	bltu	s1,a5,8000395c <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003982:	4639                	li	a2,14
    80003984:	85d2                	mv	a1,s4
    80003986:	fc240513          	addi	a0,s0,-62
    8000398a:	c40fd0ef          	jal	ra,80000dca <strncpy>
  de.inum = inum;
    8000398e:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003992:	4741                	li	a4,16
    80003994:	86a6                	mv	a3,s1
    80003996:	fc040613          	addi	a2,s0,-64
    8000399a:	4581                	li	a1,0
    8000399c:	854a                	mv	a0,s2
    8000399e:	cb5ff0ef          	jal	ra,80003652 <writei>
    800039a2:	1541                	addi	a0,a0,-16
    800039a4:	00a03533          	snez	a0,a0
    800039a8:	40a00533          	neg	a0,a0
}
    800039ac:	70e2                	ld	ra,56(sp)
    800039ae:	7442                	ld	s0,48(sp)
    800039b0:	74a2                	ld	s1,40(sp)
    800039b2:	7902                	ld	s2,32(sp)
    800039b4:	69e2                	ld	s3,24(sp)
    800039b6:	6a42                	ld	s4,16(sp)
    800039b8:	6121                	addi	sp,sp,64
    800039ba:	8082                	ret
    iput(ip);
    800039bc:	ae1ff0ef          	jal	ra,8000349c <iput>
    return -1;
    800039c0:	557d                	li	a0,-1
    800039c2:	b7ed                	j	800039ac <dirlink+0x76>
      panic("dirlink read");
    800039c4:	00004517          	auipc	a0,0x4
    800039c8:	d7c50513          	addi	a0,a0,-644 # 80007740 <syscall_names+0x1d0>
    800039cc:	d9dfc0ef          	jal	ra,80000768 <panic>

00000000800039d0 <namei>:

struct inode*
namei(char *path)
{
    800039d0:	1101                	addi	sp,sp,-32
    800039d2:	ec06                	sd	ra,24(sp)
    800039d4:	e822                	sd	s0,16(sp)
    800039d6:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    800039d8:	fe040613          	addi	a2,s0,-32
    800039dc:	4581                	li	a1,0
    800039de:	e29ff0ef          	jal	ra,80003806 <namex>
}
    800039e2:	60e2                	ld	ra,24(sp)
    800039e4:	6442                	ld	s0,16(sp)
    800039e6:	6105                	addi	sp,sp,32
    800039e8:	8082                	ret

00000000800039ea <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    800039ea:	1141                	addi	sp,sp,-16
    800039ec:	e406                	sd	ra,8(sp)
    800039ee:	e022                	sd	s0,0(sp)
    800039f0:	0800                	addi	s0,sp,16
    800039f2:	862e                	mv	a2,a1
  return namex(path, 1, name);
    800039f4:	4585                	li	a1,1
    800039f6:	e11ff0ef          	jal	ra,80003806 <namex>
}
    800039fa:	60a2                	ld	ra,8(sp)
    800039fc:	6402                	ld	s0,0(sp)
    800039fe:	0141                	addi	sp,sp,16
    80003a00:	8082                	ret

0000000080003a02 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003a02:	1101                	addi	sp,sp,-32
    80003a04:	ec06                	sd	ra,24(sp)
    80003a06:	e822                	sd	s0,16(sp)
    80003a08:	e426                	sd	s1,8(sp)
    80003a0a:	e04a                	sd	s2,0(sp)
    80003a0c:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003a0e:	00021917          	auipc	s2,0x21
    80003a12:	e8a90913          	addi	s2,s2,-374 # 80024898 <log>
    80003a16:	01892583          	lw	a1,24(s2)
    80003a1a:	02892503          	lw	a0,40(s2)
    80003a1e:	9e0ff0ef          	jal	ra,80002bfe <bread>
    80003a22:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003a24:	02c92683          	lw	a3,44(s2)
    80003a28:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003a2a:	02d05863          	blez	a3,80003a5a <write_head+0x58>
    80003a2e:	00021797          	auipc	a5,0x21
    80003a32:	e9a78793          	addi	a5,a5,-358 # 800248c8 <log+0x30>
    80003a36:	05c50713          	addi	a4,a0,92
    80003a3a:	36fd                	addiw	a3,a3,-1
    80003a3c:	02069613          	slli	a2,a3,0x20
    80003a40:	01e65693          	srli	a3,a2,0x1e
    80003a44:	00021617          	auipc	a2,0x21
    80003a48:	e8860613          	addi	a2,a2,-376 # 800248cc <log+0x34>
    80003a4c:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80003a4e:	4390                	lw	a2,0(a5)
    80003a50:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003a52:	0791                	addi	a5,a5,4
    80003a54:	0711                	addi	a4,a4,4
    80003a56:	fed79ce3          	bne	a5,a3,80003a4e <write_head+0x4c>
  }
  bwrite(buf);
    80003a5a:	8526                	mv	a0,s1
    80003a5c:	a78ff0ef          	jal	ra,80002cd4 <bwrite>
  brelse(buf);
    80003a60:	8526                	mv	a0,s1
    80003a62:	aa4ff0ef          	jal	ra,80002d06 <brelse>
}
    80003a66:	60e2                	ld	ra,24(sp)
    80003a68:	6442                	ld	s0,16(sp)
    80003a6a:	64a2                	ld	s1,8(sp)
    80003a6c:	6902                	ld	s2,0(sp)
    80003a6e:	6105                	addi	sp,sp,32
    80003a70:	8082                	ret

0000000080003a72 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003a72:	00021797          	auipc	a5,0x21
    80003a76:	e527a783          	lw	a5,-430(a5) # 800248c4 <log+0x2c>
    80003a7a:	08f05f63          	blez	a5,80003b18 <install_trans+0xa6>
{
    80003a7e:	7139                	addi	sp,sp,-64
    80003a80:	fc06                	sd	ra,56(sp)
    80003a82:	f822                	sd	s0,48(sp)
    80003a84:	f426                	sd	s1,40(sp)
    80003a86:	f04a                	sd	s2,32(sp)
    80003a88:	ec4e                	sd	s3,24(sp)
    80003a8a:	e852                	sd	s4,16(sp)
    80003a8c:	e456                	sd	s5,8(sp)
    80003a8e:	e05a                	sd	s6,0(sp)
    80003a90:	0080                	addi	s0,sp,64
    80003a92:	8b2a                	mv	s6,a0
    80003a94:	00021a97          	auipc	s5,0x21
    80003a98:	e34a8a93          	addi	s5,s5,-460 # 800248c8 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003a9c:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003a9e:	00021997          	auipc	s3,0x21
    80003aa2:	dfa98993          	addi	s3,s3,-518 # 80024898 <log>
    80003aa6:	a829                	j	80003ac0 <install_trans+0x4e>
    brelse(lbuf);
    80003aa8:	854a                	mv	a0,s2
    80003aaa:	a5cff0ef          	jal	ra,80002d06 <brelse>
    brelse(dbuf);
    80003aae:	8526                	mv	a0,s1
    80003ab0:	a56ff0ef          	jal	ra,80002d06 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ab4:	2a05                	addiw	s4,s4,1
    80003ab6:	0a91                	addi	s5,s5,4
    80003ab8:	02c9a783          	lw	a5,44(s3)
    80003abc:	04fa5463          	bge	s4,a5,80003b04 <install_trans+0x92>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003ac0:	0189a583          	lw	a1,24(s3)
    80003ac4:	014585bb          	addw	a1,a1,s4
    80003ac8:	2585                	addiw	a1,a1,1
    80003aca:	0289a503          	lw	a0,40(s3)
    80003ace:	930ff0ef          	jal	ra,80002bfe <bread>
    80003ad2:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003ad4:	000aa583          	lw	a1,0(s5)
    80003ad8:	0289a503          	lw	a0,40(s3)
    80003adc:	922ff0ef          	jal	ra,80002bfe <bread>
    80003ae0:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003ae2:	40000613          	li	a2,1024
    80003ae6:	05890593          	addi	a1,s2,88
    80003aea:	05850513          	addi	a0,a0,88
    80003aee:	a30fd0ef          	jal	ra,80000d1e <memmove>
    bwrite(dbuf);  // write dst to disk
    80003af2:	8526                	mv	a0,s1
    80003af4:	9e0ff0ef          	jal	ra,80002cd4 <bwrite>
    if(recovering == 0)
    80003af8:	fa0b18e3          	bnez	s6,80003aa8 <install_trans+0x36>
      bunpin(dbuf);
    80003afc:	8526                	mv	a0,s1
    80003afe:	ac6ff0ef          	jal	ra,80002dc4 <bunpin>
    80003b02:	b75d                	j	80003aa8 <install_trans+0x36>
}
    80003b04:	70e2                	ld	ra,56(sp)
    80003b06:	7442                	ld	s0,48(sp)
    80003b08:	74a2                	ld	s1,40(sp)
    80003b0a:	7902                	ld	s2,32(sp)
    80003b0c:	69e2                	ld	s3,24(sp)
    80003b0e:	6a42                	ld	s4,16(sp)
    80003b10:	6aa2                	ld	s5,8(sp)
    80003b12:	6b02                	ld	s6,0(sp)
    80003b14:	6121                	addi	sp,sp,64
    80003b16:	8082                	ret
    80003b18:	8082                	ret

0000000080003b1a <initlog>:
{
    80003b1a:	7179                	addi	sp,sp,-48
    80003b1c:	f406                	sd	ra,40(sp)
    80003b1e:	f022                	sd	s0,32(sp)
    80003b20:	ec26                	sd	s1,24(sp)
    80003b22:	e84a                	sd	s2,16(sp)
    80003b24:	e44e                	sd	s3,8(sp)
    80003b26:	1800                	addi	s0,sp,48
    80003b28:	892a                	mv	s2,a0
    80003b2a:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003b2c:	00021497          	auipc	s1,0x21
    80003b30:	d6c48493          	addi	s1,s1,-660 # 80024898 <log>
    80003b34:	00004597          	auipc	a1,0x4
    80003b38:	c1c58593          	addi	a1,a1,-996 # 80007750 <syscall_names+0x1e0>
    80003b3c:	8526                	mv	a0,s1
    80003b3e:	830fd0ef          	jal	ra,80000b6e <initlock>
  log.start = sb->logstart;
    80003b42:	0149a583          	lw	a1,20(s3)
    80003b46:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80003b48:	0109a783          	lw	a5,16(s3)
    80003b4c:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003b4e:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003b52:	854a                	mv	a0,s2
    80003b54:	8aaff0ef          	jal	ra,80002bfe <bread>
  log.lh.n = lh->n;
    80003b58:	4d34                	lw	a3,88(a0)
    80003b5a:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003b5c:	02d05663          	blez	a3,80003b88 <initlog+0x6e>
    80003b60:	05c50793          	addi	a5,a0,92
    80003b64:	00021717          	auipc	a4,0x21
    80003b68:	d6470713          	addi	a4,a4,-668 # 800248c8 <log+0x30>
    80003b6c:	36fd                	addiw	a3,a3,-1
    80003b6e:	02069613          	slli	a2,a3,0x20
    80003b72:	01e65693          	srli	a3,a2,0x1e
    80003b76:	06050613          	addi	a2,a0,96
    80003b7a:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    80003b7c:	4390                	lw	a2,0(a5)
    80003b7e:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003b80:	0791                	addi	a5,a5,4
    80003b82:	0711                	addi	a4,a4,4
    80003b84:	fed79ce3          	bne	a5,a3,80003b7c <initlog+0x62>
  brelse(buf);
    80003b88:	97eff0ef          	jal	ra,80002d06 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003b8c:	4505                	li	a0,1
    80003b8e:	ee5ff0ef          	jal	ra,80003a72 <install_trans>
  log.lh.n = 0;
    80003b92:	00021797          	auipc	a5,0x21
    80003b96:	d207a923          	sw	zero,-718(a5) # 800248c4 <log+0x2c>
  write_head(); // clear the log
    80003b9a:	e69ff0ef          	jal	ra,80003a02 <write_head>
}
    80003b9e:	70a2                	ld	ra,40(sp)
    80003ba0:	7402                	ld	s0,32(sp)
    80003ba2:	64e2                	ld	s1,24(sp)
    80003ba4:	6942                	ld	s2,16(sp)
    80003ba6:	69a2                	ld	s3,8(sp)
    80003ba8:	6145                	addi	sp,sp,48
    80003baa:	8082                	ret

0000000080003bac <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003bac:	1101                	addi	sp,sp,-32
    80003bae:	ec06                	sd	ra,24(sp)
    80003bb0:	e822                	sd	s0,16(sp)
    80003bb2:	e426                	sd	s1,8(sp)
    80003bb4:	e04a                	sd	s2,0(sp)
    80003bb6:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003bb8:	00021517          	auipc	a0,0x21
    80003bbc:	ce050513          	addi	a0,a0,-800 # 80024898 <log>
    80003bc0:	82efd0ef          	jal	ra,80000bee <acquire>
  while(1){
    if(log.committing){
    80003bc4:	00021497          	auipc	s1,0x21
    80003bc8:	cd448493          	addi	s1,s1,-812 # 80024898 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003bcc:	4979                	li	s2,30
    80003bce:	a029                	j	80003bd8 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003bd0:	85a6                	mv	a1,s1
    80003bd2:	8526                	mv	a0,s1
    80003bd4:	acefe0ef          	jal	ra,80001ea2 <sleep>
    if(log.committing){
    80003bd8:	50dc                	lw	a5,36(s1)
    80003bda:	fbfd                	bnez	a5,80003bd0 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003bdc:	509c                	lw	a5,32(s1)
    80003bde:	0017871b          	addiw	a4,a5,1
    80003be2:	0007069b          	sext.w	a3,a4
    80003be6:	0027179b          	slliw	a5,a4,0x2
    80003bea:	9fb9                	addw	a5,a5,a4
    80003bec:	0017979b          	slliw	a5,a5,0x1
    80003bf0:	54d8                	lw	a4,44(s1)
    80003bf2:	9fb9                	addw	a5,a5,a4
    80003bf4:	00f95763          	bge	s2,a5,80003c02 <begin_op+0x56>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003bf8:	85a6                	mv	a1,s1
    80003bfa:	8526                	mv	a0,s1
    80003bfc:	aa6fe0ef          	jal	ra,80001ea2 <sleep>
    80003c00:	bfe1                	j	80003bd8 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003c02:	00021517          	auipc	a0,0x21
    80003c06:	c9650513          	addi	a0,a0,-874 # 80024898 <log>
    80003c0a:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80003c0c:	87afd0ef          	jal	ra,80000c86 <release>
      break;
    }
  }
}
    80003c10:	60e2                	ld	ra,24(sp)
    80003c12:	6442                	ld	s0,16(sp)
    80003c14:	64a2                	ld	s1,8(sp)
    80003c16:	6902                	ld	s2,0(sp)
    80003c18:	6105                	addi	sp,sp,32
    80003c1a:	8082                	ret

0000000080003c1c <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003c1c:	7139                	addi	sp,sp,-64
    80003c1e:	fc06                	sd	ra,56(sp)
    80003c20:	f822                	sd	s0,48(sp)
    80003c22:	f426                	sd	s1,40(sp)
    80003c24:	f04a                	sd	s2,32(sp)
    80003c26:	ec4e                	sd	s3,24(sp)
    80003c28:	e852                	sd	s4,16(sp)
    80003c2a:	e456                	sd	s5,8(sp)
    80003c2c:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003c2e:	00021497          	auipc	s1,0x21
    80003c32:	c6a48493          	addi	s1,s1,-918 # 80024898 <log>
    80003c36:	8526                	mv	a0,s1
    80003c38:	fb7fc0ef          	jal	ra,80000bee <acquire>
  log.outstanding -= 1;
    80003c3c:	509c                	lw	a5,32(s1)
    80003c3e:	37fd                	addiw	a5,a5,-1
    80003c40:	0007891b          	sext.w	s2,a5
    80003c44:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003c46:	50dc                	lw	a5,36(s1)
    80003c48:	ef9d                	bnez	a5,80003c86 <end_op+0x6a>
    panic("log.committing");
  if(log.outstanding == 0){
    80003c4a:	04091463          	bnez	s2,80003c92 <end_op+0x76>
    do_commit = 1;
    log.committing = 1;
    80003c4e:	00021497          	auipc	s1,0x21
    80003c52:	c4a48493          	addi	s1,s1,-950 # 80024898 <log>
    80003c56:	4785                	li	a5,1
    80003c58:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003c5a:	8526                	mv	a0,s1
    80003c5c:	82afd0ef          	jal	ra,80000c86 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003c60:	54dc                	lw	a5,44(s1)
    80003c62:	04f04b63          	bgtz	a5,80003cb8 <end_op+0x9c>
    acquire(&log.lock);
    80003c66:	00021497          	auipc	s1,0x21
    80003c6a:	c3248493          	addi	s1,s1,-974 # 80024898 <log>
    80003c6e:	8526                	mv	a0,s1
    80003c70:	f7ffc0ef          	jal	ra,80000bee <acquire>
    log.committing = 0;
    80003c74:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    80003c78:	8526                	mv	a0,s1
    80003c7a:	a74fe0ef          	jal	ra,80001eee <wakeup>
    release(&log.lock);
    80003c7e:	8526                	mv	a0,s1
    80003c80:	806fd0ef          	jal	ra,80000c86 <release>
}
    80003c84:	a00d                	j	80003ca6 <end_op+0x8a>
    panic("log.committing");
    80003c86:	00004517          	auipc	a0,0x4
    80003c8a:	ad250513          	addi	a0,a0,-1326 # 80007758 <syscall_names+0x1e8>
    80003c8e:	adbfc0ef          	jal	ra,80000768 <panic>
    wakeup(&log);
    80003c92:	00021497          	auipc	s1,0x21
    80003c96:	c0648493          	addi	s1,s1,-1018 # 80024898 <log>
    80003c9a:	8526                	mv	a0,s1
    80003c9c:	a52fe0ef          	jal	ra,80001eee <wakeup>
  release(&log.lock);
    80003ca0:	8526                	mv	a0,s1
    80003ca2:	fe5fc0ef          	jal	ra,80000c86 <release>
}
    80003ca6:	70e2                	ld	ra,56(sp)
    80003ca8:	7442                	ld	s0,48(sp)
    80003caa:	74a2                	ld	s1,40(sp)
    80003cac:	7902                	ld	s2,32(sp)
    80003cae:	69e2                	ld	s3,24(sp)
    80003cb0:	6a42                	ld	s4,16(sp)
    80003cb2:	6aa2                	ld	s5,8(sp)
    80003cb4:	6121                	addi	sp,sp,64
    80003cb6:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    80003cb8:	00021a97          	auipc	s5,0x21
    80003cbc:	c10a8a93          	addi	s5,s5,-1008 # 800248c8 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003cc0:	00021a17          	auipc	s4,0x21
    80003cc4:	bd8a0a13          	addi	s4,s4,-1064 # 80024898 <log>
    80003cc8:	018a2583          	lw	a1,24(s4)
    80003ccc:	012585bb          	addw	a1,a1,s2
    80003cd0:	2585                	addiw	a1,a1,1
    80003cd2:	028a2503          	lw	a0,40(s4)
    80003cd6:	f29fe0ef          	jal	ra,80002bfe <bread>
    80003cda:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003cdc:	000aa583          	lw	a1,0(s5)
    80003ce0:	028a2503          	lw	a0,40(s4)
    80003ce4:	f1bfe0ef          	jal	ra,80002bfe <bread>
    80003ce8:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003cea:	40000613          	li	a2,1024
    80003cee:	05850593          	addi	a1,a0,88
    80003cf2:	05848513          	addi	a0,s1,88
    80003cf6:	828fd0ef          	jal	ra,80000d1e <memmove>
    bwrite(to);  // write the log
    80003cfa:	8526                	mv	a0,s1
    80003cfc:	fd9fe0ef          	jal	ra,80002cd4 <bwrite>
    brelse(from);
    80003d00:	854e                	mv	a0,s3
    80003d02:	804ff0ef          	jal	ra,80002d06 <brelse>
    brelse(to);
    80003d06:	8526                	mv	a0,s1
    80003d08:	ffffe0ef          	jal	ra,80002d06 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d0c:	2905                	addiw	s2,s2,1
    80003d0e:	0a91                	addi	s5,s5,4
    80003d10:	02ca2783          	lw	a5,44(s4)
    80003d14:	faf94ae3          	blt	s2,a5,80003cc8 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003d18:	cebff0ef          	jal	ra,80003a02 <write_head>
    install_trans(0); // Now install writes to home locations
    80003d1c:	4501                	li	a0,0
    80003d1e:	d55ff0ef          	jal	ra,80003a72 <install_trans>
    log.lh.n = 0;
    80003d22:	00021797          	auipc	a5,0x21
    80003d26:	ba07a123          	sw	zero,-1118(a5) # 800248c4 <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003d2a:	cd9ff0ef          	jal	ra,80003a02 <write_head>
    80003d2e:	bf25                	j	80003c66 <end_op+0x4a>

0000000080003d30 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003d30:	1101                	addi	sp,sp,-32
    80003d32:	ec06                	sd	ra,24(sp)
    80003d34:	e822                	sd	s0,16(sp)
    80003d36:	e426                	sd	s1,8(sp)
    80003d38:	e04a                	sd	s2,0(sp)
    80003d3a:	1000                	addi	s0,sp,32
    80003d3c:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003d3e:	00021917          	auipc	s2,0x21
    80003d42:	b5a90913          	addi	s2,s2,-1190 # 80024898 <log>
    80003d46:	854a                	mv	a0,s2
    80003d48:	ea7fc0ef          	jal	ra,80000bee <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003d4c:	02c92603          	lw	a2,44(s2)
    80003d50:	47f5                	li	a5,29
    80003d52:	06c7c363          	blt	a5,a2,80003db8 <log_write+0x88>
    80003d56:	00021797          	auipc	a5,0x21
    80003d5a:	b5e7a783          	lw	a5,-1186(a5) # 800248b4 <log+0x1c>
    80003d5e:	37fd                	addiw	a5,a5,-1
    80003d60:	04f65c63          	bge	a2,a5,80003db8 <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003d64:	00021797          	auipc	a5,0x21
    80003d68:	b547a783          	lw	a5,-1196(a5) # 800248b8 <log+0x20>
    80003d6c:	04f05c63          	blez	a5,80003dc4 <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003d70:	4781                	li	a5,0
    80003d72:	04c05f63          	blez	a2,80003dd0 <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003d76:	44cc                	lw	a1,12(s1)
    80003d78:	00021717          	auipc	a4,0x21
    80003d7c:	b5070713          	addi	a4,a4,-1200 # 800248c8 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003d80:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003d82:	4314                	lw	a3,0(a4)
    80003d84:	04b68663          	beq	a3,a1,80003dd0 <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    80003d88:	2785                	addiw	a5,a5,1
    80003d8a:	0711                	addi	a4,a4,4
    80003d8c:	fef61be3          	bne	a2,a5,80003d82 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003d90:	0621                	addi	a2,a2,8
    80003d92:	060a                	slli	a2,a2,0x2
    80003d94:	00021797          	auipc	a5,0x21
    80003d98:	b0478793          	addi	a5,a5,-1276 # 80024898 <log>
    80003d9c:	963e                	add	a2,a2,a5
    80003d9e:	44dc                	lw	a5,12(s1)
    80003da0:	ca1c                	sw	a5,16(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003da2:	8526                	mv	a0,s1
    80003da4:	fedfe0ef          	jal	ra,80002d90 <bpin>
    log.lh.n++;
    80003da8:	00021717          	auipc	a4,0x21
    80003dac:	af070713          	addi	a4,a4,-1296 # 80024898 <log>
    80003db0:	575c                	lw	a5,44(a4)
    80003db2:	2785                	addiw	a5,a5,1
    80003db4:	d75c                	sw	a5,44(a4)
    80003db6:	a815                	j	80003dea <log_write+0xba>
    panic("too big a transaction");
    80003db8:	00004517          	auipc	a0,0x4
    80003dbc:	9b050513          	addi	a0,a0,-1616 # 80007768 <syscall_names+0x1f8>
    80003dc0:	9a9fc0ef          	jal	ra,80000768 <panic>
    panic("log_write outside of trans");
    80003dc4:	00004517          	auipc	a0,0x4
    80003dc8:	9bc50513          	addi	a0,a0,-1604 # 80007780 <syscall_names+0x210>
    80003dcc:	99dfc0ef          	jal	ra,80000768 <panic>
  log.lh.block[i] = b->blockno;
    80003dd0:	00878713          	addi	a4,a5,8
    80003dd4:	00271693          	slli	a3,a4,0x2
    80003dd8:	00021717          	auipc	a4,0x21
    80003ddc:	ac070713          	addi	a4,a4,-1344 # 80024898 <log>
    80003de0:	9736                	add	a4,a4,a3
    80003de2:	44d4                	lw	a3,12(s1)
    80003de4:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003de6:	faf60ee3          	beq	a2,a5,80003da2 <log_write+0x72>
  }
  release(&log.lock);
    80003dea:	00021517          	auipc	a0,0x21
    80003dee:	aae50513          	addi	a0,a0,-1362 # 80024898 <log>
    80003df2:	e95fc0ef          	jal	ra,80000c86 <release>
}
    80003df6:	60e2                	ld	ra,24(sp)
    80003df8:	6442                	ld	s0,16(sp)
    80003dfa:	64a2                	ld	s1,8(sp)
    80003dfc:	6902                	ld	s2,0(sp)
    80003dfe:	6105                	addi	sp,sp,32
    80003e00:	8082                	ret

0000000080003e02 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003e02:	1101                	addi	sp,sp,-32
    80003e04:	ec06                	sd	ra,24(sp)
    80003e06:	e822                	sd	s0,16(sp)
    80003e08:	e426                	sd	s1,8(sp)
    80003e0a:	e04a                	sd	s2,0(sp)
    80003e0c:	1000                	addi	s0,sp,32
    80003e0e:	84aa                	mv	s1,a0
    80003e10:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003e12:	00004597          	auipc	a1,0x4
    80003e16:	98e58593          	addi	a1,a1,-1650 # 800077a0 <syscall_names+0x230>
    80003e1a:	0521                	addi	a0,a0,8
    80003e1c:	d53fc0ef          	jal	ra,80000b6e <initlock>
  lk->name = name;
    80003e20:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003e24:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003e28:	0204a423          	sw	zero,40(s1)
}
    80003e2c:	60e2                	ld	ra,24(sp)
    80003e2e:	6442                	ld	s0,16(sp)
    80003e30:	64a2                	ld	s1,8(sp)
    80003e32:	6902                	ld	s2,0(sp)
    80003e34:	6105                	addi	sp,sp,32
    80003e36:	8082                	ret

0000000080003e38 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003e38:	1101                	addi	sp,sp,-32
    80003e3a:	ec06                	sd	ra,24(sp)
    80003e3c:	e822                	sd	s0,16(sp)
    80003e3e:	e426                	sd	s1,8(sp)
    80003e40:	e04a                	sd	s2,0(sp)
    80003e42:	1000                	addi	s0,sp,32
    80003e44:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003e46:	00850913          	addi	s2,a0,8
    80003e4a:	854a                	mv	a0,s2
    80003e4c:	da3fc0ef          	jal	ra,80000bee <acquire>
  while (lk->locked) {
    80003e50:	409c                	lw	a5,0(s1)
    80003e52:	c799                	beqz	a5,80003e60 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003e54:	85ca                	mv	a1,s2
    80003e56:	8526                	mv	a0,s1
    80003e58:	84afe0ef          	jal	ra,80001ea2 <sleep>
  while (lk->locked) {
    80003e5c:	409c                	lw	a5,0(s1)
    80003e5e:	fbfd                	bnez	a5,80003e54 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003e60:	4785                	li	a5,1
    80003e62:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003e64:	a23fd0ef          	jal	ra,80001886 <myproc>
    80003e68:	591c                	lw	a5,48(a0)
    80003e6a:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003e6c:	854a                	mv	a0,s2
    80003e6e:	e19fc0ef          	jal	ra,80000c86 <release>
}
    80003e72:	60e2                	ld	ra,24(sp)
    80003e74:	6442                	ld	s0,16(sp)
    80003e76:	64a2                	ld	s1,8(sp)
    80003e78:	6902                	ld	s2,0(sp)
    80003e7a:	6105                	addi	sp,sp,32
    80003e7c:	8082                	ret

0000000080003e7e <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003e7e:	1101                	addi	sp,sp,-32
    80003e80:	ec06                	sd	ra,24(sp)
    80003e82:	e822                	sd	s0,16(sp)
    80003e84:	e426                	sd	s1,8(sp)
    80003e86:	e04a                	sd	s2,0(sp)
    80003e88:	1000                	addi	s0,sp,32
    80003e8a:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003e8c:	00850913          	addi	s2,a0,8
    80003e90:	854a                	mv	a0,s2
    80003e92:	d5dfc0ef          	jal	ra,80000bee <acquire>
  lk->locked = 0;
    80003e96:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003e9a:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003e9e:	8526                	mv	a0,s1
    80003ea0:	84efe0ef          	jal	ra,80001eee <wakeup>
  release(&lk->lk);
    80003ea4:	854a                	mv	a0,s2
    80003ea6:	de1fc0ef          	jal	ra,80000c86 <release>
}
    80003eaa:	60e2                	ld	ra,24(sp)
    80003eac:	6442                	ld	s0,16(sp)
    80003eae:	64a2                	ld	s1,8(sp)
    80003eb0:	6902                	ld	s2,0(sp)
    80003eb2:	6105                	addi	sp,sp,32
    80003eb4:	8082                	ret

0000000080003eb6 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003eb6:	7179                	addi	sp,sp,-48
    80003eb8:	f406                	sd	ra,40(sp)
    80003eba:	f022                	sd	s0,32(sp)
    80003ebc:	ec26                	sd	s1,24(sp)
    80003ebe:	e84a                	sd	s2,16(sp)
    80003ec0:	e44e                	sd	s3,8(sp)
    80003ec2:	1800                	addi	s0,sp,48
    80003ec4:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003ec6:	00850913          	addi	s2,a0,8
    80003eca:	854a                	mv	a0,s2
    80003ecc:	d23fc0ef          	jal	ra,80000bee <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003ed0:	409c                	lw	a5,0(s1)
    80003ed2:	ef89                	bnez	a5,80003eec <holdingsleep+0x36>
    80003ed4:	4481                	li	s1,0
  release(&lk->lk);
    80003ed6:	854a                	mv	a0,s2
    80003ed8:	daffc0ef          	jal	ra,80000c86 <release>
  return r;
}
    80003edc:	8526                	mv	a0,s1
    80003ede:	70a2                	ld	ra,40(sp)
    80003ee0:	7402                	ld	s0,32(sp)
    80003ee2:	64e2                	ld	s1,24(sp)
    80003ee4:	6942                	ld	s2,16(sp)
    80003ee6:	69a2                	ld	s3,8(sp)
    80003ee8:	6145                	addi	sp,sp,48
    80003eea:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80003eec:	0284a983          	lw	s3,40(s1)
    80003ef0:	997fd0ef          	jal	ra,80001886 <myproc>
    80003ef4:	5904                	lw	s1,48(a0)
    80003ef6:	413484b3          	sub	s1,s1,s3
    80003efa:	0014b493          	seqz	s1,s1
    80003efe:	bfe1                	j	80003ed6 <holdingsleep+0x20>

0000000080003f00 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003f00:	1141                	addi	sp,sp,-16
    80003f02:	e406                	sd	ra,8(sp)
    80003f04:	e022                	sd	s0,0(sp)
    80003f06:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003f08:	00004597          	auipc	a1,0x4
    80003f0c:	8a858593          	addi	a1,a1,-1880 # 800077b0 <syscall_names+0x240>
    80003f10:	00021517          	auipc	a0,0x21
    80003f14:	ad050513          	addi	a0,a0,-1328 # 800249e0 <ftable>
    80003f18:	c57fc0ef          	jal	ra,80000b6e <initlock>
}
    80003f1c:	60a2                	ld	ra,8(sp)
    80003f1e:	6402                	ld	s0,0(sp)
    80003f20:	0141                	addi	sp,sp,16
    80003f22:	8082                	ret

0000000080003f24 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003f24:	1101                	addi	sp,sp,-32
    80003f26:	ec06                	sd	ra,24(sp)
    80003f28:	e822                	sd	s0,16(sp)
    80003f2a:	e426                	sd	s1,8(sp)
    80003f2c:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003f2e:	00021517          	auipc	a0,0x21
    80003f32:	ab250513          	addi	a0,a0,-1358 # 800249e0 <ftable>
    80003f36:	cb9fc0ef          	jal	ra,80000bee <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003f3a:	00021497          	auipc	s1,0x21
    80003f3e:	abe48493          	addi	s1,s1,-1346 # 800249f8 <ftable+0x18>
    80003f42:	00022717          	auipc	a4,0x22
    80003f46:	a5670713          	addi	a4,a4,-1450 # 80025998 <disk>
    if(f->ref == 0){
    80003f4a:	40dc                	lw	a5,4(s1)
    80003f4c:	cf89                	beqz	a5,80003f66 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003f4e:	02848493          	addi	s1,s1,40
    80003f52:	fee49ce3          	bne	s1,a4,80003f4a <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003f56:	00021517          	auipc	a0,0x21
    80003f5a:	a8a50513          	addi	a0,a0,-1398 # 800249e0 <ftable>
    80003f5e:	d29fc0ef          	jal	ra,80000c86 <release>
  return 0;
    80003f62:	4481                	li	s1,0
    80003f64:	a809                	j	80003f76 <filealloc+0x52>
      f->ref = 1;
    80003f66:	4785                	li	a5,1
    80003f68:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003f6a:	00021517          	auipc	a0,0x21
    80003f6e:	a7650513          	addi	a0,a0,-1418 # 800249e0 <ftable>
    80003f72:	d15fc0ef          	jal	ra,80000c86 <release>
}
    80003f76:	8526                	mv	a0,s1
    80003f78:	60e2                	ld	ra,24(sp)
    80003f7a:	6442                	ld	s0,16(sp)
    80003f7c:	64a2                	ld	s1,8(sp)
    80003f7e:	6105                	addi	sp,sp,32
    80003f80:	8082                	ret

0000000080003f82 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003f82:	1101                	addi	sp,sp,-32
    80003f84:	ec06                	sd	ra,24(sp)
    80003f86:	e822                	sd	s0,16(sp)
    80003f88:	e426                	sd	s1,8(sp)
    80003f8a:	1000                	addi	s0,sp,32
    80003f8c:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003f8e:	00021517          	auipc	a0,0x21
    80003f92:	a5250513          	addi	a0,a0,-1454 # 800249e0 <ftable>
    80003f96:	c59fc0ef          	jal	ra,80000bee <acquire>
  if(f->ref < 1)
    80003f9a:	40dc                	lw	a5,4(s1)
    80003f9c:	02f05063          	blez	a5,80003fbc <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003fa0:	2785                	addiw	a5,a5,1
    80003fa2:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003fa4:	00021517          	auipc	a0,0x21
    80003fa8:	a3c50513          	addi	a0,a0,-1476 # 800249e0 <ftable>
    80003fac:	cdbfc0ef          	jal	ra,80000c86 <release>
  return f;
}
    80003fb0:	8526                	mv	a0,s1
    80003fb2:	60e2                	ld	ra,24(sp)
    80003fb4:	6442                	ld	s0,16(sp)
    80003fb6:	64a2                	ld	s1,8(sp)
    80003fb8:	6105                	addi	sp,sp,32
    80003fba:	8082                	ret
    panic("filedup");
    80003fbc:	00003517          	auipc	a0,0x3
    80003fc0:	7fc50513          	addi	a0,a0,2044 # 800077b8 <syscall_names+0x248>
    80003fc4:	fa4fc0ef          	jal	ra,80000768 <panic>

0000000080003fc8 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003fc8:	7139                	addi	sp,sp,-64
    80003fca:	fc06                	sd	ra,56(sp)
    80003fcc:	f822                	sd	s0,48(sp)
    80003fce:	f426                	sd	s1,40(sp)
    80003fd0:	f04a                	sd	s2,32(sp)
    80003fd2:	ec4e                	sd	s3,24(sp)
    80003fd4:	e852                	sd	s4,16(sp)
    80003fd6:	e456                	sd	s5,8(sp)
    80003fd8:	0080                	addi	s0,sp,64
    80003fda:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003fdc:	00021517          	auipc	a0,0x21
    80003fe0:	a0450513          	addi	a0,a0,-1532 # 800249e0 <ftable>
    80003fe4:	c0bfc0ef          	jal	ra,80000bee <acquire>
  if(f->ref < 1)
    80003fe8:	40dc                	lw	a5,4(s1)
    80003fea:	04f05963          	blez	a5,8000403c <fileclose+0x74>
    panic("fileclose");
  if(--f->ref > 0){
    80003fee:	37fd                	addiw	a5,a5,-1
    80003ff0:	0007871b          	sext.w	a4,a5
    80003ff4:	c0dc                	sw	a5,4(s1)
    80003ff6:	04e04963          	bgtz	a4,80004048 <fileclose+0x80>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003ffa:	0004a903          	lw	s2,0(s1)
    80003ffe:	0094ca83          	lbu	s5,9(s1)
    80004002:	0104ba03          	ld	s4,16(s1)
    80004006:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000400a:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000400e:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004012:	00021517          	auipc	a0,0x21
    80004016:	9ce50513          	addi	a0,a0,-1586 # 800249e0 <ftable>
    8000401a:	c6dfc0ef          	jal	ra,80000c86 <release>

  if(ff.type == FD_PIPE){
    8000401e:	4785                	li	a5,1
    80004020:	04f90363          	beq	s2,a5,80004066 <fileclose+0x9e>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004024:	3979                	addiw	s2,s2,-2
    80004026:	4785                	li	a5,1
    80004028:	0327e663          	bltu	a5,s2,80004054 <fileclose+0x8c>
    begin_op();
    8000402c:	b81ff0ef          	jal	ra,80003bac <begin_op>
    iput(ff.ip);
    80004030:	854e                	mv	a0,s3
    80004032:	c6aff0ef          	jal	ra,8000349c <iput>
    end_op();
    80004036:	be7ff0ef          	jal	ra,80003c1c <end_op>
    8000403a:	a829                	j	80004054 <fileclose+0x8c>
    panic("fileclose");
    8000403c:	00003517          	auipc	a0,0x3
    80004040:	78450513          	addi	a0,a0,1924 # 800077c0 <syscall_names+0x250>
    80004044:	f24fc0ef          	jal	ra,80000768 <panic>
    release(&ftable.lock);
    80004048:	00021517          	auipc	a0,0x21
    8000404c:	99850513          	addi	a0,a0,-1640 # 800249e0 <ftable>
    80004050:	c37fc0ef          	jal	ra,80000c86 <release>
  }
}
    80004054:	70e2                	ld	ra,56(sp)
    80004056:	7442                	ld	s0,48(sp)
    80004058:	74a2                	ld	s1,40(sp)
    8000405a:	7902                	ld	s2,32(sp)
    8000405c:	69e2                	ld	s3,24(sp)
    8000405e:	6a42                	ld	s4,16(sp)
    80004060:	6aa2                	ld	s5,8(sp)
    80004062:	6121                	addi	sp,sp,64
    80004064:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004066:	85d6                	mv	a1,s5
    80004068:	8552                	mv	a0,s4
    8000406a:	2ec000ef          	jal	ra,80004356 <pipeclose>
    8000406e:	b7dd                	j	80004054 <fileclose+0x8c>

0000000080004070 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004070:	715d                	addi	sp,sp,-80
    80004072:	e486                	sd	ra,72(sp)
    80004074:	e0a2                	sd	s0,64(sp)
    80004076:	fc26                	sd	s1,56(sp)
    80004078:	f84a                	sd	s2,48(sp)
    8000407a:	f44e                	sd	s3,40(sp)
    8000407c:	0880                	addi	s0,sp,80
    8000407e:	84aa                	mv	s1,a0
    80004080:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80004082:	805fd0ef          	jal	ra,80001886 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004086:	409c                	lw	a5,0(s1)
    80004088:	37f9                	addiw	a5,a5,-2
    8000408a:	4705                	li	a4,1
    8000408c:	02f76f63          	bltu	a4,a5,800040ca <filestat+0x5a>
    80004090:	892a                	mv	s2,a0
    ilock(f->ip);
    80004092:	6c88                	ld	a0,24(s1)
    80004094:	a8aff0ef          	jal	ra,8000331e <ilock>
    stati(f->ip, &st);
    80004098:	fb840593          	addi	a1,s0,-72
    8000409c:	6c88                	ld	a0,24(s1)
    8000409e:	ca6ff0ef          	jal	ra,80003544 <stati>
    iunlock(f->ip);
    800040a2:	6c88                	ld	a0,24(s1)
    800040a4:	b24ff0ef          	jal	ra,800033c8 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800040a8:	46e1                	li	a3,24
    800040aa:	fb840613          	addi	a2,s0,-72
    800040ae:	85ce                	mv	a1,s3
    800040b0:	05093503          	ld	a0,80(s2)
    800040b4:	d20fd0ef          	jal	ra,800015d4 <copyout>
    800040b8:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    800040bc:	60a6                	ld	ra,72(sp)
    800040be:	6406                	ld	s0,64(sp)
    800040c0:	74e2                	ld	s1,56(sp)
    800040c2:	7942                	ld	s2,48(sp)
    800040c4:	79a2                	ld	s3,40(sp)
    800040c6:	6161                	addi	sp,sp,80
    800040c8:	8082                	ret
  return -1;
    800040ca:	557d                	li	a0,-1
    800040cc:	bfc5                	j	800040bc <filestat+0x4c>

00000000800040ce <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800040ce:	7179                	addi	sp,sp,-48
    800040d0:	f406                	sd	ra,40(sp)
    800040d2:	f022                	sd	s0,32(sp)
    800040d4:	ec26                	sd	s1,24(sp)
    800040d6:	e84a                	sd	s2,16(sp)
    800040d8:	e44e                	sd	s3,8(sp)
    800040da:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800040dc:	00854783          	lbu	a5,8(a0)
    800040e0:	cbc1                	beqz	a5,80004170 <fileread+0xa2>
    800040e2:	84aa                	mv	s1,a0
    800040e4:	89ae                	mv	s3,a1
    800040e6:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    800040e8:	411c                	lw	a5,0(a0)
    800040ea:	4705                	li	a4,1
    800040ec:	04e78363          	beq	a5,a4,80004132 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800040f0:	470d                	li	a4,3
    800040f2:	04e78563          	beq	a5,a4,8000413c <fileread+0x6e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800040f6:	4709                	li	a4,2
    800040f8:	06e79663          	bne	a5,a4,80004164 <fileread+0x96>
    ilock(f->ip);
    800040fc:	6d08                	ld	a0,24(a0)
    800040fe:	a20ff0ef          	jal	ra,8000331e <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004102:	874a                	mv	a4,s2
    80004104:	5094                	lw	a3,32(s1)
    80004106:	864e                	mv	a2,s3
    80004108:	4585                	li	a1,1
    8000410a:	6c88                	ld	a0,24(s1)
    8000410c:	c62ff0ef          	jal	ra,8000356e <readi>
    80004110:	892a                	mv	s2,a0
    80004112:	00a05563          	blez	a0,8000411c <fileread+0x4e>
      f->off += r;
    80004116:	509c                	lw	a5,32(s1)
    80004118:	9fa9                	addw	a5,a5,a0
    8000411a:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000411c:	6c88                	ld	a0,24(s1)
    8000411e:	aaaff0ef          	jal	ra,800033c8 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    80004122:	854a                	mv	a0,s2
    80004124:	70a2                	ld	ra,40(sp)
    80004126:	7402                	ld	s0,32(sp)
    80004128:	64e2                	ld	s1,24(sp)
    8000412a:	6942                	ld	s2,16(sp)
    8000412c:	69a2                	ld	s3,8(sp)
    8000412e:	6145                	addi	sp,sp,48
    80004130:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004132:	6908                	ld	a0,16(a0)
    80004134:	34e000ef          	jal	ra,80004482 <piperead>
    80004138:	892a                	mv	s2,a0
    8000413a:	b7e5                	j	80004122 <fileread+0x54>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000413c:	02451783          	lh	a5,36(a0)
    80004140:	03079693          	slli	a3,a5,0x30
    80004144:	92c1                	srli	a3,a3,0x30
    80004146:	4725                	li	a4,9
    80004148:	02d76663          	bltu	a4,a3,80004174 <fileread+0xa6>
    8000414c:	0792                	slli	a5,a5,0x4
    8000414e:	00020717          	auipc	a4,0x20
    80004152:	7f270713          	addi	a4,a4,2034 # 80024940 <devsw>
    80004156:	97ba                	add	a5,a5,a4
    80004158:	639c                	ld	a5,0(a5)
    8000415a:	cf99                	beqz	a5,80004178 <fileread+0xaa>
    r = devsw[f->major].read(1, addr, n);
    8000415c:	4505                	li	a0,1
    8000415e:	9782                	jalr	a5
    80004160:	892a                	mv	s2,a0
    80004162:	b7c1                	j	80004122 <fileread+0x54>
    panic("fileread");
    80004164:	00003517          	auipc	a0,0x3
    80004168:	66c50513          	addi	a0,a0,1644 # 800077d0 <syscall_names+0x260>
    8000416c:	dfcfc0ef          	jal	ra,80000768 <panic>
    return -1;
    80004170:	597d                	li	s2,-1
    80004172:	bf45                	j	80004122 <fileread+0x54>
      return -1;
    80004174:	597d                	li	s2,-1
    80004176:	b775                	j	80004122 <fileread+0x54>
    80004178:	597d                	li	s2,-1
    8000417a:	b765                	j	80004122 <fileread+0x54>

000000008000417c <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    8000417c:	715d                	addi	sp,sp,-80
    8000417e:	e486                	sd	ra,72(sp)
    80004180:	e0a2                	sd	s0,64(sp)
    80004182:	fc26                	sd	s1,56(sp)
    80004184:	f84a                	sd	s2,48(sp)
    80004186:	f44e                	sd	s3,40(sp)
    80004188:	f052                	sd	s4,32(sp)
    8000418a:	ec56                	sd	s5,24(sp)
    8000418c:	e85a                	sd	s6,16(sp)
    8000418e:	e45e                	sd	s7,8(sp)
    80004190:	e062                	sd	s8,0(sp)
    80004192:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    80004194:	00954783          	lbu	a5,9(a0)
    80004198:	0e078863          	beqz	a5,80004288 <filewrite+0x10c>
    8000419c:	892a                	mv	s2,a0
    8000419e:	8aae                	mv	s5,a1
    800041a0:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800041a2:	411c                	lw	a5,0(a0)
    800041a4:	4705                	li	a4,1
    800041a6:	02e78263          	beq	a5,a4,800041ca <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800041aa:	470d                	li	a4,3
    800041ac:	02e78463          	beq	a5,a4,800041d4 <filewrite+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800041b0:	4709                	li	a4,2
    800041b2:	0ce79563          	bne	a5,a4,8000427c <filewrite+0x100>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800041b6:	0ac05163          	blez	a2,80004258 <filewrite+0xdc>
    int i = 0;
    800041ba:	4981                	li	s3,0
    800041bc:	6b05                	lui	s6,0x1
    800041be:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    800041c2:	6b85                	lui	s7,0x1
    800041c4:	c00b8b9b          	addiw	s7,s7,-1024
    800041c8:	a041                	j	80004248 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800041ca:	6908                	ld	a0,16(a0)
    800041cc:	1e2000ef          	jal	ra,800043ae <pipewrite>
    800041d0:	8a2a                	mv	s4,a0
    800041d2:	a071                	j	8000425e <filewrite+0xe2>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800041d4:	02451783          	lh	a5,36(a0)
    800041d8:	03079693          	slli	a3,a5,0x30
    800041dc:	92c1                	srli	a3,a3,0x30
    800041de:	4725                	li	a4,9
    800041e0:	0ad76663          	bltu	a4,a3,8000428c <filewrite+0x110>
    800041e4:	0792                	slli	a5,a5,0x4
    800041e6:	00020717          	auipc	a4,0x20
    800041ea:	75a70713          	addi	a4,a4,1882 # 80024940 <devsw>
    800041ee:	97ba                	add	a5,a5,a4
    800041f0:	679c                	ld	a5,8(a5)
    800041f2:	cfd9                	beqz	a5,80004290 <filewrite+0x114>
    ret = devsw[f->major].write(1, addr, n);
    800041f4:	4505                	li	a0,1
    800041f6:	9782                	jalr	a5
    800041f8:	8a2a                	mv	s4,a0
    800041fa:	a095                	j	8000425e <filewrite+0xe2>
    800041fc:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    80004200:	9adff0ef          	jal	ra,80003bac <begin_op>
      ilock(f->ip);
    80004204:	01893503          	ld	a0,24(s2)
    80004208:	916ff0ef          	jal	ra,8000331e <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000420c:	8762                	mv	a4,s8
    8000420e:	02092683          	lw	a3,32(s2)
    80004212:	01598633          	add	a2,s3,s5
    80004216:	4585                	li	a1,1
    80004218:	01893503          	ld	a0,24(s2)
    8000421c:	c36ff0ef          	jal	ra,80003652 <writei>
    80004220:	84aa                	mv	s1,a0
    80004222:	00a05763          	blez	a0,80004230 <filewrite+0xb4>
        f->off += r;
    80004226:	02092783          	lw	a5,32(s2)
    8000422a:	9fa9                	addw	a5,a5,a0
    8000422c:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004230:	01893503          	ld	a0,24(s2)
    80004234:	994ff0ef          	jal	ra,800033c8 <iunlock>
      end_op();
    80004238:	9e5ff0ef          	jal	ra,80003c1c <end_op>

      if(r != n1){
    8000423c:	009c1f63          	bne	s8,s1,8000425a <filewrite+0xde>
        // error from writei
        break;
      }
      i += r;
    80004240:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80004244:	0149db63          	bge	s3,s4,8000425a <filewrite+0xde>
      int n1 = n - i;
    80004248:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    8000424c:	84be                	mv	s1,a5
    8000424e:	2781                	sext.w	a5,a5
    80004250:	fafb56e3          	bge	s6,a5,800041fc <filewrite+0x80>
    80004254:	84de                	mv	s1,s7
    80004256:	b75d                	j	800041fc <filewrite+0x80>
    int i = 0;
    80004258:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    8000425a:	013a1f63          	bne	s4,s3,80004278 <filewrite+0xfc>
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000425e:	8552                	mv	a0,s4
    80004260:	60a6                	ld	ra,72(sp)
    80004262:	6406                	ld	s0,64(sp)
    80004264:	74e2                	ld	s1,56(sp)
    80004266:	7942                	ld	s2,48(sp)
    80004268:	79a2                	ld	s3,40(sp)
    8000426a:	7a02                	ld	s4,32(sp)
    8000426c:	6ae2                	ld	s5,24(sp)
    8000426e:	6b42                	ld	s6,16(sp)
    80004270:	6ba2                	ld	s7,8(sp)
    80004272:	6c02                	ld	s8,0(sp)
    80004274:	6161                	addi	sp,sp,80
    80004276:	8082                	ret
    ret = (i == n ? n : -1);
    80004278:	5a7d                	li	s4,-1
    8000427a:	b7d5                	j	8000425e <filewrite+0xe2>
    panic("filewrite");
    8000427c:	00003517          	auipc	a0,0x3
    80004280:	56450513          	addi	a0,a0,1380 # 800077e0 <syscall_names+0x270>
    80004284:	ce4fc0ef          	jal	ra,80000768 <panic>
    return -1;
    80004288:	5a7d                	li	s4,-1
    8000428a:	bfd1                	j	8000425e <filewrite+0xe2>
      return -1;
    8000428c:	5a7d                	li	s4,-1
    8000428e:	bfc1                	j	8000425e <filewrite+0xe2>
    80004290:	5a7d                	li	s4,-1
    80004292:	b7f1                	j	8000425e <filewrite+0xe2>

0000000080004294 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004294:	7179                	addi	sp,sp,-48
    80004296:	f406                	sd	ra,40(sp)
    80004298:	f022                	sd	s0,32(sp)
    8000429a:	ec26                	sd	s1,24(sp)
    8000429c:	e84a                	sd	s2,16(sp)
    8000429e:	e44e                	sd	s3,8(sp)
    800042a0:	e052                	sd	s4,0(sp)
    800042a2:	1800                	addi	s0,sp,48
    800042a4:	84aa                	mv	s1,a0
    800042a6:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800042a8:	0005b023          	sd	zero,0(a1)
    800042ac:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800042b0:	c75ff0ef          	jal	ra,80003f24 <filealloc>
    800042b4:	e088                	sd	a0,0(s1)
    800042b6:	cd35                	beqz	a0,80004332 <pipealloc+0x9e>
    800042b8:	c6dff0ef          	jal	ra,80003f24 <filealloc>
    800042bc:	00aa3023          	sd	a0,0(s4)
    800042c0:	c52d                	beqz	a0,8000432a <pipealloc+0x96>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800042c2:	85dfc0ef          	jal	ra,80000b1e <kalloc>
    800042c6:	892a                	mv	s2,a0
    800042c8:	cd31                	beqz	a0,80004324 <pipealloc+0x90>
    goto bad;
  pi->readopen = 1;
    800042ca:	4985                	li	s3,1
    800042cc:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800042d0:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800042d4:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800042d8:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800042dc:	00003597          	auipc	a1,0x3
    800042e0:	12c58593          	addi	a1,a1,300 # 80007408 <states.0+0x1a8>
    800042e4:	88bfc0ef          	jal	ra,80000b6e <initlock>
  (*f0)->type = FD_PIPE;
    800042e8:	609c                	ld	a5,0(s1)
    800042ea:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800042ee:	609c                	ld	a5,0(s1)
    800042f0:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800042f4:	609c                	ld	a5,0(s1)
    800042f6:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800042fa:	609c                	ld	a5,0(s1)
    800042fc:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004300:	000a3783          	ld	a5,0(s4)
    80004304:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004308:	000a3783          	ld	a5,0(s4)
    8000430c:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004310:	000a3783          	ld	a5,0(s4)
    80004314:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004318:	000a3783          	ld	a5,0(s4)
    8000431c:	0127b823          	sd	s2,16(a5)
  return 0;
    80004320:	4501                	li	a0,0
    80004322:	a005                	j	80004342 <pipealloc+0xae>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004324:	6088                	ld	a0,0(s1)
    80004326:	e501                	bnez	a0,8000432e <pipealloc+0x9a>
    80004328:	a029                	j	80004332 <pipealloc+0x9e>
    8000432a:	6088                	ld	a0,0(s1)
    8000432c:	c11d                	beqz	a0,80004352 <pipealloc+0xbe>
    fileclose(*f0);
    8000432e:	c9bff0ef          	jal	ra,80003fc8 <fileclose>
  if(*f1)
    80004332:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004336:	557d                	li	a0,-1
  if(*f1)
    80004338:	c789                	beqz	a5,80004342 <pipealloc+0xae>
    fileclose(*f1);
    8000433a:	853e                	mv	a0,a5
    8000433c:	c8dff0ef          	jal	ra,80003fc8 <fileclose>
  return -1;
    80004340:	557d                	li	a0,-1
}
    80004342:	70a2                	ld	ra,40(sp)
    80004344:	7402                	ld	s0,32(sp)
    80004346:	64e2                	ld	s1,24(sp)
    80004348:	6942                	ld	s2,16(sp)
    8000434a:	69a2                	ld	s3,8(sp)
    8000434c:	6a02                	ld	s4,0(sp)
    8000434e:	6145                	addi	sp,sp,48
    80004350:	8082                	ret
  return -1;
    80004352:	557d                	li	a0,-1
    80004354:	b7fd                	j	80004342 <pipealloc+0xae>

0000000080004356 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004356:	1101                	addi	sp,sp,-32
    80004358:	ec06                	sd	ra,24(sp)
    8000435a:	e822                	sd	s0,16(sp)
    8000435c:	e426                	sd	s1,8(sp)
    8000435e:	e04a                	sd	s2,0(sp)
    80004360:	1000                	addi	s0,sp,32
    80004362:	84aa                	mv	s1,a0
    80004364:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004366:	889fc0ef          	jal	ra,80000bee <acquire>
  if(writable){
    8000436a:	02090763          	beqz	s2,80004398 <pipeclose+0x42>
    pi->writeopen = 0;
    8000436e:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004372:	21848513          	addi	a0,s1,536
    80004376:	b79fd0ef          	jal	ra,80001eee <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    8000437a:	2204b783          	ld	a5,544(s1)
    8000437e:	e785                	bnez	a5,800043a6 <pipeclose+0x50>
    release(&pi->lock);
    80004380:	8526                	mv	a0,s1
    80004382:	905fc0ef          	jal	ra,80000c86 <release>
    kfree((char*)pi);
    80004386:	8526                	mv	a0,s1
    80004388:	eb6fc0ef          	jal	ra,80000a3e <kfree>
  } else
    release(&pi->lock);
}
    8000438c:	60e2                	ld	ra,24(sp)
    8000438e:	6442                	ld	s0,16(sp)
    80004390:	64a2                	ld	s1,8(sp)
    80004392:	6902                	ld	s2,0(sp)
    80004394:	6105                	addi	sp,sp,32
    80004396:	8082                	ret
    pi->readopen = 0;
    80004398:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    8000439c:	21c48513          	addi	a0,s1,540
    800043a0:	b4ffd0ef          	jal	ra,80001eee <wakeup>
    800043a4:	bfd9                	j	8000437a <pipeclose+0x24>
    release(&pi->lock);
    800043a6:	8526                	mv	a0,s1
    800043a8:	8dffc0ef          	jal	ra,80000c86 <release>
}
    800043ac:	b7c5                	j	8000438c <pipeclose+0x36>

00000000800043ae <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800043ae:	711d                	addi	sp,sp,-96
    800043b0:	ec86                	sd	ra,88(sp)
    800043b2:	e8a2                	sd	s0,80(sp)
    800043b4:	e4a6                	sd	s1,72(sp)
    800043b6:	e0ca                	sd	s2,64(sp)
    800043b8:	fc4e                	sd	s3,56(sp)
    800043ba:	f852                	sd	s4,48(sp)
    800043bc:	f456                	sd	s5,40(sp)
    800043be:	f05a                	sd	s6,32(sp)
    800043c0:	ec5e                	sd	s7,24(sp)
    800043c2:	e862                	sd	s8,16(sp)
    800043c4:	1080                	addi	s0,sp,96
    800043c6:	84aa                	mv	s1,a0
    800043c8:	8aae                	mv	s5,a1
    800043ca:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800043cc:	cbafd0ef          	jal	ra,80001886 <myproc>
    800043d0:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800043d2:	8526                	mv	a0,s1
    800043d4:	81bfc0ef          	jal	ra,80000bee <acquire>
  while(i < n){
    800043d8:	09405c63          	blez	s4,80004470 <pipewrite+0xc2>
  int i = 0;
    800043dc:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800043de:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800043e0:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    800043e4:	21c48b93          	addi	s7,s1,540
    800043e8:	a81d                	j	8000441e <pipewrite+0x70>
      release(&pi->lock);
    800043ea:	8526                	mv	a0,s1
    800043ec:	89bfc0ef          	jal	ra,80000c86 <release>
      return -1;
    800043f0:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800043f2:	854a                	mv	a0,s2
    800043f4:	60e6                	ld	ra,88(sp)
    800043f6:	6446                	ld	s0,80(sp)
    800043f8:	64a6                	ld	s1,72(sp)
    800043fa:	6906                	ld	s2,64(sp)
    800043fc:	79e2                	ld	s3,56(sp)
    800043fe:	7a42                	ld	s4,48(sp)
    80004400:	7aa2                	ld	s5,40(sp)
    80004402:	7b02                	ld	s6,32(sp)
    80004404:	6be2                	ld	s7,24(sp)
    80004406:	6c42                	ld	s8,16(sp)
    80004408:	6125                	addi	sp,sp,96
    8000440a:	8082                	ret
      wakeup(&pi->nread);
    8000440c:	8562                	mv	a0,s8
    8000440e:	ae1fd0ef          	jal	ra,80001eee <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004412:	85a6                	mv	a1,s1
    80004414:	855e                	mv	a0,s7
    80004416:	a8dfd0ef          	jal	ra,80001ea2 <sleep>
  while(i < n){
    8000441a:	05495c63          	bge	s2,s4,80004472 <pipewrite+0xc4>
    if(pi->readopen == 0 || killed(pr)){
    8000441e:	2204a783          	lw	a5,544(s1)
    80004422:	d7e1                	beqz	a5,800043ea <pipewrite+0x3c>
    80004424:	854e                	mv	a0,s3
    80004426:	cb5fd0ef          	jal	ra,800020da <killed>
    8000442a:	f161                	bnez	a0,800043ea <pipewrite+0x3c>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    8000442c:	2184a783          	lw	a5,536(s1)
    80004430:	21c4a703          	lw	a4,540(s1)
    80004434:	2007879b          	addiw	a5,a5,512
    80004438:	fcf70ae3          	beq	a4,a5,8000440c <pipewrite+0x5e>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000443c:	4685                	li	a3,1
    8000443e:	01590633          	add	a2,s2,s5
    80004442:	faf40593          	addi	a1,s0,-81
    80004446:	0509b503          	ld	a0,80(s3)
    8000444a:	a50fd0ef          	jal	ra,8000169a <copyin>
    8000444e:	03650263          	beq	a0,s6,80004472 <pipewrite+0xc4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004452:	21c4a783          	lw	a5,540(s1)
    80004456:	0017871b          	addiw	a4,a5,1
    8000445a:	20e4ae23          	sw	a4,540(s1)
    8000445e:	1ff7f793          	andi	a5,a5,511
    80004462:	97a6                	add	a5,a5,s1
    80004464:	faf44703          	lbu	a4,-81(s0)
    80004468:	00e78c23          	sb	a4,24(a5)
      i++;
    8000446c:	2905                	addiw	s2,s2,1
    8000446e:	b775                	j	8000441a <pipewrite+0x6c>
  int i = 0;
    80004470:	4901                	li	s2,0
  wakeup(&pi->nread);
    80004472:	21848513          	addi	a0,s1,536
    80004476:	a79fd0ef          	jal	ra,80001eee <wakeup>
  release(&pi->lock);
    8000447a:	8526                	mv	a0,s1
    8000447c:	80bfc0ef          	jal	ra,80000c86 <release>
  return i;
    80004480:	bf8d                	j	800043f2 <pipewrite+0x44>

0000000080004482 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004482:	715d                	addi	sp,sp,-80
    80004484:	e486                	sd	ra,72(sp)
    80004486:	e0a2                	sd	s0,64(sp)
    80004488:	fc26                	sd	s1,56(sp)
    8000448a:	f84a                	sd	s2,48(sp)
    8000448c:	f44e                	sd	s3,40(sp)
    8000448e:	f052                	sd	s4,32(sp)
    80004490:	ec56                	sd	s5,24(sp)
    80004492:	e85a                	sd	s6,16(sp)
    80004494:	0880                	addi	s0,sp,80
    80004496:	84aa                	mv	s1,a0
    80004498:	892e                	mv	s2,a1
    8000449a:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000449c:	beafd0ef          	jal	ra,80001886 <myproc>
    800044a0:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800044a2:	8526                	mv	a0,s1
    800044a4:	f4afc0ef          	jal	ra,80000bee <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800044a8:	2184a703          	lw	a4,536(s1)
    800044ac:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800044b0:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800044b4:	02f71363          	bne	a4,a5,800044da <piperead+0x58>
    800044b8:	2244a783          	lw	a5,548(s1)
    800044bc:	cf99                	beqz	a5,800044da <piperead+0x58>
    if(killed(pr)){
    800044be:	8552                	mv	a0,s4
    800044c0:	c1bfd0ef          	jal	ra,800020da <killed>
    800044c4:	e141                	bnez	a0,80004544 <piperead+0xc2>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800044c6:	85a6                	mv	a1,s1
    800044c8:	854e                	mv	a0,s3
    800044ca:	9d9fd0ef          	jal	ra,80001ea2 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800044ce:	2184a703          	lw	a4,536(s1)
    800044d2:	21c4a783          	lw	a5,540(s1)
    800044d6:	fef701e3          	beq	a4,a5,800044b8 <piperead+0x36>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800044da:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800044dc:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800044de:	05505163          	blez	s5,80004520 <piperead+0x9e>
    if(pi->nread == pi->nwrite)
    800044e2:	2184a783          	lw	a5,536(s1)
    800044e6:	21c4a703          	lw	a4,540(s1)
    800044ea:	02f70b63          	beq	a4,a5,80004520 <piperead+0x9e>
    ch = pi->data[pi->nread++ % PIPESIZE];
    800044ee:	0017871b          	addiw	a4,a5,1
    800044f2:	20e4ac23          	sw	a4,536(s1)
    800044f6:	1ff7f793          	andi	a5,a5,511
    800044fa:	97a6                	add	a5,a5,s1
    800044fc:	0187c783          	lbu	a5,24(a5)
    80004500:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004504:	4685                	li	a3,1
    80004506:	fbf40613          	addi	a2,s0,-65
    8000450a:	85ca                	mv	a1,s2
    8000450c:	050a3503          	ld	a0,80(s4)
    80004510:	8c4fd0ef          	jal	ra,800015d4 <copyout>
    80004514:	01650663          	beq	a0,s6,80004520 <piperead+0x9e>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004518:	2985                	addiw	s3,s3,1
    8000451a:	0905                	addi	s2,s2,1
    8000451c:	fd3a93e3          	bne	s5,s3,800044e2 <piperead+0x60>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004520:	21c48513          	addi	a0,s1,540
    80004524:	9cbfd0ef          	jal	ra,80001eee <wakeup>
  release(&pi->lock);
    80004528:	8526                	mv	a0,s1
    8000452a:	f5cfc0ef          	jal	ra,80000c86 <release>
  return i;
}
    8000452e:	854e                	mv	a0,s3
    80004530:	60a6                	ld	ra,72(sp)
    80004532:	6406                	ld	s0,64(sp)
    80004534:	74e2                	ld	s1,56(sp)
    80004536:	7942                	ld	s2,48(sp)
    80004538:	79a2                	ld	s3,40(sp)
    8000453a:	7a02                	ld	s4,32(sp)
    8000453c:	6ae2                	ld	s5,24(sp)
    8000453e:	6b42                	ld	s6,16(sp)
    80004540:	6161                	addi	sp,sp,80
    80004542:	8082                	ret
      release(&pi->lock);
    80004544:	8526                	mv	a0,s1
    80004546:	f40fc0ef          	jal	ra,80000c86 <release>
      return -1;
    8000454a:	59fd                	li	s3,-1
    8000454c:	b7cd                	j	8000452e <piperead+0xac>

000000008000454e <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    8000454e:	1141                	addi	sp,sp,-16
    80004550:	e422                	sd	s0,8(sp)
    80004552:	0800                	addi	s0,sp,16
    80004554:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004556:	8905                	andi	a0,a0,1
    80004558:	c111                	beqz	a0,8000455c <flags2perm+0xe>
      perm = PTE_X;
    8000455a:	4521                	li	a0,8
    if(flags & 0x2)
    8000455c:	8b89                	andi	a5,a5,2
    8000455e:	c399                	beqz	a5,80004564 <flags2perm+0x16>
      perm |= PTE_W;
    80004560:	00456513          	ori	a0,a0,4
    return perm;
}
    80004564:	6422                	ld	s0,8(sp)
    80004566:	0141                	addi	sp,sp,16
    80004568:	8082                	ret

000000008000456a <exec>:

int
exec(char *path, char **argv)
{
    8000456a:	de010113          	addi	sp,sp,-544
    8000456e:	20113c23          	sd	ra,536(sp)
    80004572:	20813823          	sd	s0,528(sp)
    80004576:	20913423          	sd	s1,520(sp)
    8000457a:	21213023          	sd	s2,512(sp)
    8000457e:	ffce                	sd	s3,504(sp)
    80004580:	fbd2                	sd	s4,496(sp)
    80004582:	f7d6                	sd	s5,488(sp)
    80004584:	f3da                	sd	s6,480(sp)
    80004586:	efde                	sd	s7,472(sp)
    80004588:	ebe2                	sd	s8,464(sp)
    8000458a:	e7e6                	sd	s9,456(sp)
    8000458c:	e3ea                	sd	s10,448(sp)
    8000458e:	ff6e                	sd	s11,440(sp)
    80004590:	1400                	addi	s0,sp,544
    80004592:	892a                	mv	s2,a0
    80004594:	dea43423          	sd	a0,-536(s0)
    80004598:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    8000459c:	aeafd0ef          	jal	ra,80001886 <myproc>
    800045a0:	84aa                	mv	s1,a0

  begin_op();
    800045a2:	e0aff0ef          	jal	ra,80003bac <begin_op>

  if((ip = namei(path)) == 0){
    800045a6:	854a                	mv	a0,s2
    800045a8:	c28ff0ef          	jal	ra,800039d0 <namei>
    800045ac:	c13d                	beqz	a0,80004612 <exec+0xa8>
    800045ae:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800045b0:	d6ffe0ef          	jal	ra,8000331e <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800045b4:	04000713          	li	a4,64
    800045b8:	4681                	li	a3,0
    800045ba:	e5040613          	addi	a2,s0,-432
    800045be:	4581                	li	a1,0
    800045c0:	8556                	mv	a0,s5
    800045c2:	fadfe0ef          	jal	ra,8000356e <readi>
    800045c6:	04000793          	li	a5,64
    800045ca:	00f51a63          	bne	a0,a5,800045de <exec+0x74>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    800045ce:	e5042703          	lw	a4,-432(s0)
    800045d2:	464c47b7          	lui	a5,0x464c4
    800045d6:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    800045da:	04f70063          	beq	a4,a5,8000461a <exec+0xb0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    800045de:	8556                	mv	a0,s5
    800045e0:	f45fe0ef          	jal	ra,80003524 <iunlockput>
    end_op();
    800045e4:	e38ff0ef          	jal	ra,80003c1c <end_op>
  }
  return -1;
    800045e8:	557d                	li	a0,-1
}
    800045ea:	21813083          	ld	ra,536(sp)
    800045ee:	21013403          	ld	s0,528(sp)
    800045f2:	20813483          	ld	s1,520(sp)
    800045f6:	20013903          	ld	s2,512(sp)
    800045fa:	79fe                	ld	s3,504(sp)
    800045fc:	7a5e                	ld	s4,496(sp)
    800045fe:	7abe                	ld	s5,488(sp)
    80004600:	7b1e                	ld	s6,480(sp)
    80004602:	6bfe                	ld	s7,472(sp)
    80004604:	6c5e                	ld	s8,464(sp)
    80004606:	6cbe                	ld	s9,456(sp)
    80004608:	6d1e                	ld	s10,448(sp)
    8000460a:	7dfa                	ld	s11,440(sp)
    8000460c:	22010113          	addi	sp,sp,544
    80004610:	8082                	ret
    end_op();
    80004612:	e0aff0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80004616:	557d                	li	a0,-1
    80004618:	bfc9                	j	800045ea <exec+0x80>
  if((pagetable = proc_pagetable(p)) == 0)
    8000461a:	8526                	mv	a0,s1
    8000461c:	b70fd0ef          	jal	ra,8000198c <proc_pagetable>
    80004620:	8b2a                	mv	s6,a0
    80004622:	dd55                	beqz	a0,800045de <exec+0x74>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004624:	e7042783          	lw	a5,-400(s0)
    80004628:	e8845703          	lhu	a4,-376(s0)
    8000462c:	c325                	beqz	a4,8000468c <exec+0x122>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000462e:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004630:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80004634:	6a05                	lui	s4,0x1
    80004636:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    8000463a:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    8000463e:	6d85                	lui	s11,0x1
    80004640:	7d7d                	lui	s10,0xfffff
    80004642:	a411                	j	80004846 <exec+0x2dc>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004644:	00003517          	auipc	a0,0x3
    80004648:	1ac50513          	addi	a0,a0,428 # 800077f0 <syscall_names+0x280>
    8000464c:	91cfc0ef          	jal	ra,80000768 <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004650:	874a                	mv	a4,s2
    80004652:	009c86bb          	addw	a3,s9,s1
    80004656:	4581                	li	a1,0
    80004658:	8556                	mv	a0,s5
    8000465a:	f15fe0ef          	jal	ra,8000356e <readi>
    8000465e:	2501                	sext.w	a0,a0
    80004660:	18a91263          	bne	s2,a0,800047e4 <exec+0x27a>
  for(i = 0; i < sz; i += PGSIZE){
    80004664:	009d84bb          	addw	s1,s11,s1
    80004668:	013d09bb          	addw	s3,s10,s3
    8000466c:	1b74fd63          	bgeu	s1,s7,80004826 <exec+0x2bc>
    pa = walkaddr(pagetable, va + i);
    80004670:	02049593          	slli	a1,s1,0x20
    80004674:	9181                	srli	a1,a1,0x20
    80004676:	95e2                	add	a1,a1,s8
    80004678:	855a                	mv	a0,s6
    8000467a:	95ffc0ef          	jal	ra,80000fd8 <walkaddr>
    8000467e:	862a                	mv	a2,a0
    if(pa == 0)
    80004680:	d171                	beqz	a0,80004644 <exec+0xda>
      n = PGSIZE;
    80004682:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80004684:	fd49f6e3          	bgeu	s3,s4,80004650 <exec+0xe6>
      n = sz - i;
    80004688:	894e                	mv	s2,s3
    8000468a:	b7d9                	j	80004650 <exec+0xe6>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000468c:	4901                	li	s2,0
  iunlockput(ip);
    8000468e:	8556                	mv	a0,s5
    80004690:	e95fe0ef          	jal	ra,80003524 <iunlockput>
  end_op();
    80004694:	d88ff0ef          	jal	ra,80003c1c <end_op>
  p = myproc();
    80004698:	9eefd0ef          	jal	ra,80001886 <myproc>
    8000469c:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    8000469e:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    800046a2:	6785                	lui	a5,0x1
    800046a4:	17fd                	addi	a5,a5,-1
    800046a6:	993e                	add	s2,s2,a5
    800046a8:	77fd                	lui	a5,0xfffff
    800046aa:	00f977b3          	and	a5,s2,a5
    800046ae:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800046b2:	4691                	li	a3,4
    800046b4:	6609                	lui	a2,0x2
    800046b6:	963e                	add	a2,a2,a5
    800046b8:	85be                	mv	a1,a5
    800046ba:	855a                	mv	a0,s6
    800046bc:	be7fc0ef          	jal	ra,800012a2 <uvmalloc>
    800046c0:	8c2a                	mv	s8,a0
  ip = 0;
    800046c2:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800046c4:	12050063          	beqz	a0,800047e4 <exec+0x27a>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800046c8:	75f9                	lui	a1,0xffffe
    800046ca:	95aa                	add	a1,a1,a0
    800046cc:	855a                	mv	a0,s6
    800046ce:	d9bfc0ef          	jal	ra,80001468 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800046d2:	7afd                	lui	s5,0xfffff
    800046d4:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    800046d6:	df043783          	ld	a5,-528(s0)
    800046da:	6388                	ld	a0,0(a5)
    800046dc:	c135                	beqz	a0,80004740 <exec+0x1d6>
    800046de:	e9040993          	addi	s3,s0,-368
    800046e2:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    800046e6:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    800046e8:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    800046ea:	f50fc0ef          	jal	ra,80000e3a <strlen>
    800046ee:	0015079b          	addiw	a5,a0,1
    800046f2:	40f90933          	sub	s2,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    800046f6:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    800046fa:	11596a63          	bltu	s2,s5,8000480e <exec+0x2a4>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    800046fe:	df043d83          	ld	s11,-528(s0)
    80004702:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80004706:	8552                	mv	a0,s4
    80004708:	f32fc0ef          	jal	ra,80000e3a <strlen>
    8000470c:	0015069b          	addiw	a3,a0,1
    80004710:	8652                	mv	a2,s4
    80004712:	85ca                	mv	a1,s2
    80004714:	855a                	mv	a0,s6
    80004716:	ebffc0ef          	jal	ra,800015d4 <copyout>
    8000471a:	0e054e63          	bltz	a0,80004816 <exec+0x2ac>
    ustack[argc] = sp;
    8000471e:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004722:	0485                	addi	s1,s1,1
    80004724:	008d8793          	addi	a5,s11,8
    80004728:	def43823          	sd	a5,-528(s0)
    8000472c:	008db503          	ld	a0,8(s11)
    80004730:	c911                	beqz	a0,80004744 <exec+0x1da>
    if(argc >= MAXARG)
    80004732:	09a1                	addi	s3,s3,8
    80004734:	fb3c9be3          	bne	s9,s3,800046ea <exec+0x180>
  sz = sz1;
    80004738:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    8000473c:	4a81                	li	s5,0
    8000473e:	a05d                	j	800047e4 <exec+0x27a>
  sp = sz;
    80004740:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004742:	4481                	li	s1,0
  ustack[argc] = 0;
    80004744:	00349793          	slli	a5,s1,0x3
    80004748:	f9040713          	addi	a4,s0,-112
    8000474c:	97ba                	add	a5,a5,a4
    8000474e:	f007b023          	sd	zero,-256(a5) # ffffffffffffef00 <end+0xffffffff7ffd9428>
  sp -= (argc+1) * sizeof(uint64);
    80004752:	00148693          	addi	a3,s1,1
    80004756:	068e                	slli	a3,a3,0x3
    80004758:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    8000475c:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004760:	01597663          	bgeu	s2,s5,8000476c <exec+0x202>
  sz = sz1;
    80004764:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004768:	4a81                	li	s5,0
    8000476a:	a8ad                	j	800047e4 <exec+0x27a>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    8000476c:	e9040613          	addi	a2,s0,-368
    80004770:	85ca                	mv	a1,s2
    80004772:	855a                	mv	a0,s6
    80004774:	e61fc0ef          	jal	ra,800015d4 <copyout>
    80004778:	0a054363          	bltz	a0,8000481e <exec+0x2b4>
  p->trapframe->a1 = sp;
    8000477c:	058bb783          	ld	a5,88(s7) # 1058 <_entry-0x7fffefa8>
    80004780:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004784:	de843783          	ld	a5,-536(s0)
    80004788:	0007c703          	lbu	a4,0(a5)
    8000478c:	cf11                	beqz	a4,800047a8 <exec+0x23e>
    8000478e:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004790:	02f00693          	li	a3,47
    80004794:	a039                	j	800047a2 <exec+0x238>
      last = s+1;
    80004796:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    8000479a:	0785                	addi	a5,a5,1
    8000479c:	fff7c703          	lbu	a4,-1(a5)
    800047a0:	c701                	beqz	a4,800047a8 <exec+0x23e>
    if(*s == '/')
    800047a2:	fed71ce3          	bne	a4,a3,8000479a <exec+0x230>
    800047a6:	bfc5                	j	80004796 <exec+0x22c>
  safestrcpy(p->name, last, sizeof(p->name));
    800047a8:	4641                	li	a2,16
    800047aa:	de843583          	ld	a1,-536(s0)
    800047ae:	158b8513          	addi	a0,s7,344
    800047b2:	e56fc0ef          	jal	ra,80000e08 <safestrcpy>
  oldpagetable = p->pagetable;
    800047b6:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    800047ba:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    800047be:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    800047c2:	058bb783          	ld	a5,88(s7)
    800047c6:	e6843703          	ld	a4,-408(s0)
    800047ca:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800047cc:	058bb783          	ld	a5,88(s7)
    800047d0:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800047d4:	85ea                	mv	a1,s10
    800047d6:	a3afd0ef          	jal	ra,80001a10 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800047da:	0004851b          	sext.w	a0,s1
    800047de:	b531                	j	800045ea <exec+0x80>
    800047e0:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    800047e4:	df843583          	ld	a1,-520(s0)
    800047e8:	855a                	mv	a0,s6
    800047ea:	a26fd0ef          	jal	ra,80001a10 <proc_freepagetable>
  if(ip){
    800047ee:	de0a98e3          	bnez	s5,800045de <exec+0x74>
  return -1;
    800047f2:	557d                	li	a0,-1
    800047f4:	bbdd                	j	800045ea <exec+0x80>
    800047f6:	df243c23          	sd	s2,-520(s0)
    800047fa:	b7ed                	j	800047e4 <exec+0x27a>
    800047fc:	df243c23          	sd	s2,-520(s0)
    80004800:	b7d5                	j	800047e4 <exec+0x27a>
    80004802:	df243c23          	sd	s2,-520(s0)
    80004806:	bff9                	j	800047e4 <exec+0x27a>
    80004808:	df243c23          	sd	s2,-520(s0)
    8000480c:	bfe1                	j	800047e4 <exec+0x27a>
  sz = sz1;
    8000480e:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004812:	4a81                	li	s5,0
    80004814:	bfc1                	j	800047e4 <exec+0x27a>
  sz = sz1;
    80004816:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    8000481a:	4a81                	li	s5,0
    8000481c:	b7e1                	j	800047e4 <exec+0x27a>
  sz = sz1;
    8000481e:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004822:	4a81                	li	s5,0
    80004824:	b7c1                	j	800047e4 <exec+0x27a>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004826:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000482a:	e0843783          	ld	a5,-504(s0)
    8000482e:	0017869b          	addiw	a3,a5,1
    80004832:	e0d43423          	sd	a3,-504(s0)
    80004836:	e0043783          	ld	a5,-512(s0)
    8000483a:	0387879b          	addiw	a5,a5,56
    8000483e:	e8845703          	lhu	a4,-376(s0)
    80004842:	e4e6d6e3          	bge	a3,a4,8000468e <exec+0x124>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004846:	2781                	sext.w	a5,a5
    80004848:	e0f43023          	sd	a5,-512(s0)
    8000484c:	03800713          	li	a4,56
    80004850:	86be                	mv	a3,a5
    80004852:	e1840613          	addi	a2,s0,-488
    80004856:	4581                	li	a1,0
    80004858:	8556                	mv	a0,s5
    8000485a:	d15fe0ef          	jal	ra,8000356e <readi>
    8000485e:	03800793          	li	a5,56
    80004862:	f6f51fe3          	bne	a0,a5,800047e0 <exec+0x276>
    if(ph.type != ELF_PROG_LOAD)
    80004866:	e1842783          	lw	a5,-488(s0)
    8000486a:	4705                	li	a4,1
    8000486c:	fae79fe3          	bne	a5,a4,8000482a <exec+0x2c0>
    if(ph.memsz < ph.filesz)
    80004870:	e4043483          	ld	s1,-448(s0)
    80004874:	e3843783          	ld	a5,-456(s0)
    80004878:	f6f4efe3          	bltu	s1,a5,800047f6 <exec+0x28c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    8000487c:	e2843783          	ld	a5,-472(s0)
    80004880:	94be                	add	s1,s1,a5
    80004882:	f6f4ede3          	bltu	s1,a5,800047fc <exec+0x292>
    if(ph.vaddr % PGSIZE != 0)
    80004886:	de043703          	ld	a4,-544(s0)
    8000488a:	8ff9                	and	a5,a5,a4
    8000488c:	fbbd                	bnez	a5,80004802 <exec+0x298>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    8000488e:	e1c42503          	lw	a0,-484(s0)
    80004892:	cbdff0ef          	jal	ra,8000454e <flags2perm>
    80004896:	86aa                	mv	a3,a0
    80004898:	8626                	mv	a2,s1
    8000489a:	85ca                	mv	a1,s2
    8000489c:	855a                	mv	a0,s6
    8000489e:	a05fc0ef          	jal	ra,800012a2 <uvmalloc>
    800048a2:	dea43c23          	sd	a0,-520(s0)
    800048a6:	d12d                	beqz	a0,80004808 <exec+0x29e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800048a8:	e2843c03          	ld	s8,-472(s0)
    800048ac:	e2042c83          	lw	s9,-480(s0)
    800048b0:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    800048b4:	f60b89e3          	beqz	s7,80004826 <exec+0x2bc>
    800048b8:	89de                	mv	s3,s7
    800048ba:	4481                	li	s1,0
    800048bc:	bb55                	j	80004670 <exec+0x106>

00000000800048be <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    800048be:	7179                	addi	sp,sp,-48
    800048c0:	f406                	sd	ra,40(sp)
    800048c2:	f022                	sd	s0,32(sp)
    800048c4:	ec26                	sd	s1,24(sp)
    800048c6:	e84a                	sd	s2,16(sp)
    800048c8:	1800                	addi	s0,sp,48
    800048ca:	892e                	mv	s2,a1
    800048cc:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    800048ce:	fdc40593          	addi	a1,s0,-36
    800048d2:	f35fd0ef          	jal	ra,80002806 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    800048d6:	fdc42703          	lw	a4,-36(s0)
    800048da:	47bd                	li	a5,15
    800048dc:	02e7e963          	bltu	a5,a4,8000490e <argfd+0x50>
    800048e0:	fa7fc0ef          	jal	ra,80001886 <myproc>
    800048e4:	fdc42703          	lw	a4,-36(s0)
    800048e8:	01a70793          	addi	a5,a4,26
    800048ec:	078e                	slli	a5,a5,0x3
    800048ee:	953e                	add	a0,a0,a5
    800048f0:	611c                	ld	a5,0(a0)
    800048f2:	c385                	beqz	a5,80004912 <argfd+0x54>
    return -1;
  if(pfd)
    800048f4:	00090463          	beqz	s2,800048fc <argfd+0x3e>
    *pfd = fd;
    800048f8:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    800048fc:	4501                	li	a0,0
  if(pf)
    800048fe:	c091                	beqz	s1,80004902 <argfd+0x44>
    *pf = f;
    80004900:	e09c                	sd	a5,0(s1)
}
    80004902:	70a2                	ld	ra,40(sp)
    80004904:	7402                	ld	s0,32(sp)
    80004906:	64e2                	ld	s1,24(sp)
    80004908:	6942                	ld	s2,16(sp)
    8000490a:	6145                	addi	sp,sp,48
    8000490c:	8082                	ret
    return -1;
    8000490e:	557d                	li	a0,-1
    80004910:	bfcd                	j	80004902 <argfd+0x44>
    80004912:	557d                	li	a0,-1
    80004914:	b7fd                	j	80004902 <argfd+0x44>

0000000080004916 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004916:	1101                	addi	sp,sp,-32
    80004918:	ec06                	sd	ra,24(sp)
    8000491a:	e822                	sd	s0,16(sp)
    8000491c:	e426                	sd	s1,8(sp)
    8000491e:	1000                	addi	s0,sp,32
    80004920:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004922:	f65fc0ef          	jal	ra,80001886 <myproc>
    80004926:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004928:	0d050793          	addi	a5,a0,208
    8000492c:	4501                	li	a0,0
    8000492e:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004930:	6398                	ld	a4,0(a5)
    80004932:	cb19                	beqz	a4,80004948 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004934:	2505                	addiw	a0,a0,1
    80004936:	07a1                	addi	a5,a5,8
    80004938:	fed51ce3          	bne	a0,a3,80004930 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    8000493c:	557d                	li	a0,-1
}
    8000493e:	60e2                	ld	ra,24(sp)
    80004940:	6442                	ld	s0,16(sp)
    80004942:	64a2                	ld	s1,8(sp)
    80004944:	6105                	addi	sp,sp,32
    80004946:	8082                	ret
      p->ofile[fd] = f;
    80004948:	01a50793          	addi	a5,a0,26
    8000494c:	078e                	slli	a5,a5,0x3
    8000494e:	963e                	add	a2,a2,a5
    80004950:	e204                	sd	s1,0(a2)
      return fd;
    80004952:	b7f5                	j	8000493e <fdalloc+0x28>

0000000080004954 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004954:	715d                	addi	sp,sp,-80
    80004956:	e486                	sd	ra,72(sp)
    80004958:	e0a2                	sd	s0,64(sp)
    8000495a:	fc26                	sd	s1,56(sp)
    8000495c:	f84a                	sd	s2,48(sp)
    8000495e:	f44e                	sd	s3,40(sp)
    80004960:	f052                	sd	s4,32(sp)
    80004962:	ec56                	sd	s5,24(sp)
    80004964:	e85a                	sd	s6,16(sp)
    80004966:	0880                	addi	s0,sp,80
    80004968:	8b2e                	mv	s6,a1
    8000496a:	89b2                	mv	s3,a2
    8000496c:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    8000496e:	fb040593          	addi	a1,s0,-80
    80004972:	878ff0ef          	jal	ra,800039ea <nameiparent>
    80004976:	84aa                	mv	s1,a0
    80004978:	10050b63          	beqz	a0,80004a8e <create+0x13a>
    return 0;

  ilock(dp);
    8000497c:	9a3fe0ef          	jal	ra,8000331e <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004980:	4601                	li	a2,0
    80004982:	fb040593          	addi	a1,s0,-80
    80004986:	8526                	mv	a0,s1
    80004988:	de3fe0ef          	jal	ra,8000376a <dirlookup>
    8000498c:	8aaa                	mv	s5,a0
    8000498e:	c521                	beqz	a0,800049d6 <create+0x82>
    iunlockput(dp);
    80004990:	8526                	mv	a0,s1
    80004992:	b93fe0ef          	jal	ra,80003524 <iunlockput>
    ilock(ip);
    80004996:	8556                	mv	a0,s5
    80004998:	987fe0ef          	jal	ra,8000331e <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    8000499c:	000b059b          	sext.w	a1,s6
    800049a0:	4789                	li	a5,2
    800049a2:	02f59563          	bne	a1,a5,800049cc <create+0x78>
    800049a6:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffd956c>
    800049aa:	37f9                	addiw	a5,a5,-2
    800049ac:	17c2                	slli	a5,a5,0x30
    800049ae:	93c1                	srli	a5,a5,0x30
    800049b0:	4705                	li	a4,1
    800049b2:	00f76d63          	bltu	a4,a5,800049cc <create+0x78>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    800049b6:	8556                	mv	a0,s5
    800049b8:	60a6                	ld	ra,72(sp)
    800049ba:	6406                	ld	s0,64(sp)
    800049bc:	74e2                	ld	s1,56(sp)
    800049be:	7942                	ld	s2,48(sp)
    800049c0:	79a2                	ld	s3,40(sp)
    800049c2:	7a02                	ld	s4,32(sp)
    800049c4:	6ae2                	ld	s5,24(sp)
    800049c6:	6b42                	ld	s6,16(sp)
    800049c8:	6161                	addi	sp,sp,80
    800049ca:	8082                	ret
    iunlockput(ip);
    800049cc:	8556                	mv	a0,s5
    800049ce:	b57fe0ef          	jal	ra,80003524 <iunlockput>
    return 0;
    800049d2:	4a81                	li	s5,0
    800049d4:	b7cd                	j	800049b6 <create+0x62>
  if((ip = ialloc(dp->dev, type)) == 0){
    800049d6:	85da                	mv	a1,s6
    800049d8:	4088                	lw	a0,0(s1)
    800049da:	fdcfe0ef          	jal	ra,800031b6 <ialloc>
    800049de:	8a2a                	mv	s4,a0
    800049e0:	cd1d                	beqz	a0,80004a1e <create+0xca>
  ilock(ip);
    800049e2:	93dfe0ef          	jal	ra,8000331e <ilock>
  ip->major = major;
    800049e6:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    800049ea:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    800049ee:	4905                	li	s2,1
    800049f0:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    800049f4:	8552                	mv	a0,s4
    800049f6:	877fe0ef          	jal	ra,8000326c <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    800049fa:	000b059b          	sext.w	a1,s6
    800049fe:	03258563          	beq	a1,s2,80004a28 <create+0xd4>
  if(dirlink(dp, name, ip->inum) < 0)
    80004a02:	004a2603          	lw	a2,4(s4)
    80004a06:	fb040593          	addi	a1,s0,-80
    80004a0a:	8526                	mv	a0,s1
    80004a0c:	f2bfe0ef          	jal	ra,80003936 <dirlink>
    80004a10:	06054363          	bltz	a0,80004a76 <create+0x122>
  iunlockput(dp);
    80004a14:	8526                	mv	a0,s1
    80004a16:	b0ffe0ef          	jal	ra,80003524 <iunlockput>
  return ip;
    80004a1a:	8ad2                	mv	s5,s4
    80004a1c:	bf69                	j	800049b6 <create+0x62>
    iunlockput(dp);
    80004a1e:	8526                	mv	a0,s1
    80004a20:	b05fe0ef          	jal	ra,80003524 <iunlockput>
    return 0;
    80004a24:	8ad2                	mv	s5,s4
    80004a26:	bf41                	j	800049b6 <create+0x62>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004a28:	004a2603          	lw	a2,4(s4)
    80004a2c:	00003597          	auipc	a1,0x3
    80004a30:	de458593          	addi	a1,a1,-540 # 80007810 <syscall_names+0x2a0>
    80004a34:	8552                	mv	a0,s4
    80004a36:	f01fe0ef          	jal	ra,80003936 <dirlink>
    80004a3a:	02054e63          	bltz	a0,80004a76 <create+0x122>
    80004a3e:	40d0                	lw	a2,4(s1)
    80004a40:	00003597          	auipc	a1,0x3
    80004a44:	dd858593          	addi	a1,a1,-552 # 80007818 <syscall_names+0x2a8>
    80004a48:	8552                	mv	a0,s4
    80004a4a:	eedfe0ef          	jal	ra,80003936 <dirlink>
    80004a4e:	02054463          	bltz	a0,80004a76 <create+0x122>
  if(dirlink(dp, name, ip->inum) < 0)
    80004a52:	004a2603          	lw	a2,4(s4)
    80004a56:	fb040593          	addi	a1,s0,-80
    80004a5a:	8526                	mv	a0,s1
    80004a5c:	edbfe0ef          	jal	ra,80003936 <dirlink>
    80004a60:	00054b63          	bltz	a0,80004a76 <create+0x122>
    dp->nlink++;  // for ".."
    80004a64:	04a4d783          	lhu	a5,74(s1)
    80004a68:	2785                	addiw	a5,a5,1
    80004a6a:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004a6e:	8526                	mv	a0,s1
    80004a70:	ffcfe0ef          	jal	ra,8000326c <iupdate>
    80004a74:	b745                	j	80004a14 <create+0xc0>
  ip->nlink = 0;
    80004a76:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004a7a:	8552                	mv	a0,s4
    80004a7c:	ff0fe0ef          	jal	ra,8000326c <iupdate>
  iunlockput(ip);
    80004a80:	8552                	mv	a0,s4
    80004a82:	aa3fe0ef          	jal	ra,80003524 <iunlockput>
  iunlockput(dp);
    80004a86:	8526                	mv	a0,s1
    80004a88:	a9dfe0ef          	jal	ra,80003524 <iunlockput>
  return 0;
    80004a8c:	b72d                	j	800049b6 <create+0x62>
    return 0;
    80004a8e:	8aaa                	mv	s5,a0
    80004a90:	b71d                	j	800049b6 <create+0x62>

0000000080004a92 <sys_dup>:
{
    80004a92:	7179                	addi	sp,sp,-48
    80004a94:	f406                	sd	ra,40(sp)
    80004a96:	f022                	sd	s0,32(sp)
    80004a98:	ec26                	sd	s1,24(sp)
    80004a9a:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004a9c:	fd840613          	addi	a2,s0,-40
    80004aa0:	4581                	li	a1,0
    80004aa2:	4501                	li	a0,0
    80004aa4:	e1bff0ef          	jal	ra,800048be <argfd>
    return -1;
    80004aa8:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004aaa:	00054f63          	bltz	a0,80004ac8 <sys_dup+0x36>
  if((fd=fdalloc(f)) < 0)
    80004aae:	fd843503          	ld	a0,-40(s0)
    80004ab2:	e65ff0ef          	jal	ra,80004916 <fdalloc>
    80004ab6:	84aa                	mv	s1,a0
    return -1;
    80004ab8:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004aba:	00054763          	bltz	a0,80004ac8 <sys_dup+0x36>
  filedup(f);
    80004abe:	fd843503          	ld	a0,-40(s0)
    80004ac2:	cc0ff0ef          	jal	ra,80003f82 <filedup>
  return fd;
    80004ac6:	87a6                	mv	a5,s1
}
    80004ac8:	853e                	mv	a0,a5
    80004aca:	70a2                	ld	ra,40(sp)
    80004acc:	7402                	ld	s0,32(sp)
    80004ace:	64e2                	ld	s1,24(sp)
    80004ad0:	6145                	addi	sp,sp,48
    80004ad2:	8082                	ret

0000000080004ad4 <sys_read>:
{
    80004ad4:	7179                	addi	sp,sp,-48
    80004ad6:	f406                	sd	ra,40(sp)
    80004ad8:	f022                	sd	s0,32(sp)
    80004ada:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004adc:	fd840593          	addi	a1,s0,-40
    80004ae0:	4505                	li	a0,1
    80004ae2:	d41fd0ef          	jal	ra,80002822 <argaddr>
  argint(2, &n);
    80004ae6:	fe440593          	addi	a1,s0,-28
    80004aea:	4509                	li	a0,2
    80004aec:	d1bfd0ef          	jal	ra,80002806 <argint>
  if(argfd(0, 0, &f) < 0)
    80004af0:	fe840613          	addi	a2,s0,-24
    80004af4:	4581                	li	a1,0
    80004af6:	4501                	li	a0,0
    80004af8:	dc7ff0ef          	jal	ra,800048be <argfd>
    80004afc:	87aa                	mv	a5,a0
    return -1;
    80004afe:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004b00:	0007ca63          	bltz	a5,80004b14 <sys_read+0x40>
  return fileread(f, p, n);
    80004b04:	fe442603          	lw	a2,-28(s0)
    80004b08:	fd843583          	ld	a1,-40(s0)
    80004b0c:	fe843503          	ld	a0,-24(s0)
    80004b10:	dbeff0ef          	jal	ra,800040ce <fileread>
}
    80004b14:	70a2                	ld	ra,40(sp)
    80004b16:	7402                	ld	s0,32(sp)
    80004b18:	6145                	addi	sp,sp,48
    80004b1a:	8082                	ret

0000000080004b1c <sys_write>:
{
    80004b1c:	7179                	addi	sp,sp,-48
    80004b1e:	f406                	sd	ra,40(sp)
    80004b20:	f022                	sd	s0,32(sp)
    80004b22:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004b24:	fd840593          	addi	a1,s0,-40
    80004b28:	4505                	li	a0,1
    80004b2a:	cf9fd0ef          	jal	ra,80002822 <argaddr>
  argint(2, &n);
    80004b2e:	fe440593          	addi	a1,s0,-28
    80004b32:	4509                	li	a0,2
    80004b34:	cd3fd0ef          	jal	ra,80002806 <argint>
  if(argfd(0, 0, &f) < 0)
    80004b38:	fe840613          	addi	a2,s0,-24
    80004b3c:	4581                	li	a1,0
    80004b3e:	4501                	li	a0,0
    80004b40:	d7fff0ef          	jal	ra,800048be <argfd>
    80004b44:	87aa                	mv	a5,a0
    return -1;
    80004b46:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004b48:	0007ca63          	bltz	a5,80004b5c <sys_write+0x40>
  return filewrite(f, p, n);
    80004b4c:	fe442603          	lw	a2,-28(s0)
    80004b50:	fd843583          	ld	a1,-40(s0)
    80004b54:	fe843503          	ld	a0,-24(s0)
    80004b58:	e24ff0ef          	jal	ra,8000417c <filewrite>
}
    80004b5c:	70a2                	ld	ra,40(sp)
    80004b5e:	7402                	ld	s0,32(sp)
    80004b60:	6145                	addi	sp,sp,48
    80004b62:	8082                	ret

0000000080004b64 <sys_close>:
{
    80004b64:	1101                	addi	sp,sp,-32
    80004b66:	ec06                	sd	ra,24(sp)
    80004b68:	e822                	sd	s0,16(sp)
    80004b6a:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004b6c:	fe040613          	addi	a2,s0,-32
    80004b70:	fec40593          	addi	a1,s0,-20
    80004b74:	4501                	li	a0,0
    80004b76:	d49ff0ef          	jal	ra,800048be <argfd>
    return -1;
    80004b7a:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004b7c:	02054063          	bltz	a0,80004b9c <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004b80:	d07fc0ef          	jal	ra,80001886 <myproc>
    80004b84:	fec42783          	lw	a5,-20(s0)
    80004b88:	07e9                	addi	a5,a5,26
    80004b8a:	078e                	slli	a5,a5,0x3
    80004b8c:	97aa                	add	a5,a5,a0
    80004b8e:	0007b023          	sd	zero,0(a5)
  fileclose(f);
    80004b92:	fe043503          	ld	a0,-32(s0)
    80004b96:	c32ff0ef          	jal	ra,80003fc8 <fileclose>
  return 0;
    80004b9a:	4781                	li	a5,0
}
    80004b9c:	853e                	mv	a0,a5
    80004b9e:	60e2                	ld	ra,24(sp)
    80004ba0:	6442                	ld	s0,16(sp)
    80004ba2:	6105                	addi	sp,sp,32
    80004ba4:	8082                	ret

0000000080004ba6 <sys_fstat>:
{
    80004ba6:	1101                	addi	sp,sp,-32
    80004ba8:	ec06                	sd	ra,24(sp)
    80004baa:	e822                	sd	s0,16(sp)
    80004bac:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004bae:	fe040593          	addi	a1,s0,-32
    80004bb2:	4505                	li	a0,1
    80004bb4:	c6ffd0ef          	jal	ra,80002822 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004bb8:	fe840613          	addi	a2,s0,-24
    80004bbc:	4581                	li	a1,0
    80004bbe:	4501                	li	a0,0
    80004bc0:	cffff0ef          	jal	ra,800048be <argfd>
    80004bc4:	87aa                	mv	a5,a0
    return -1;
    80004bc6:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004bc8:	0007c863          	bltz	a5,80004bd8 <sys_fstat+0x32>
  return filestat(f, st);
    80004bcc:	fe043583          	ld	a1,-32(s0)
    80004bd0:	fe843503          	ld	a0,-24(s0)
    80004bd4:	c9cff0ef          	jal	ra,80004070 <filestat>
}
    80004bd8:	60e2                	ld	ra,24(sp)
    80004bda:	6442                	ld	s0,16(sp)
    80004bdc:	6105                	addi	sp,sp,32
    80004bde:	8082                	ret

0000000080004be0 <sys_link>:
{
    80004be0:	7169                	addi	sp,sp,-304
    80004be2:	f606                	sd	ra,296(sp)
    80004be4:	f222                	sd	s0,288(sp)
    80004be6:	ee26                	sd	s1,280(sp)
    80004be8:	ea4a                	sd	s2,272(sp)
    80004bea:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004bec:	08000613          	li	a2,128
    80004bf0:	ed040593          	addi	a1,s0,-304
    80004bf4:	4501                	li	a0,0
    80004bf6:	c49fd0ef          	jal	ra,8000283e <argstr>
    return -1;
    80004bfa:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004bfc:	0c054663          	bltz	a0,80004cc8 <sys_link+0xe8>
    80004c00:	08000613          	li	a2,128
    80004c04:	f5040593          	addi	a1,s0,-176
    80004c08:	4505                	li	a0,1
    80004c0a:	c35fd0ef          	jal	ra,8000283e <argstr>
    return -1;
    80004c0e:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004c10:	0a054c63          	bltz	a0,80004cc8 <sys_link+0xe8>
  begin_op();
    80004c14:	f99fe0ef          	jal	ra,80003bac <begin_op>
  if((ip = namei(old)) == 0){
    80004c18:	ed040513          	addi	a0,s0,-304
    80004c1c:	db5fe0ef          	jal	ra,800039d0 <namei>
    80004c20:	84aa                	mv	s1,a0
    80004c22:	c525                	beqz	a0,80004c8a <sys_link+0xaa>
  ilock(ip);
    80004c24:	efafe0ef          	jal	ra,8000331e <ilock>
  if(ip->type == T_DIR){
    80004c28:	04449703          	lh	a4,68(s1)
    80004c2c:	4785                	li	a5,1
    80004c2e:	06f70263          	beq	a4,a5,80004c92 <sys_link+0xb2>
  ip->nlink++;
    80004c32:	04a4d783          	lhu	a5,74(s1)
    80004c36:	2785                	addiw	a5,a5,1
    80004c38:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004c3c:	8526                	mv	a0,s1
    80004c3e:	e2efe0ef          	jal	ra,8000326c <iupdate>
  iunlock(ip);
    80004c42:	8526                	mv	a0,s1
    80004c44:	f84fe0ef          	jal	ra,800033c8 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004c48:	fd040593          	addi	a1,s0,-48
    80004c4c:	f5040513          	addi	a0,s0,-176
    80004c50:	d9bfe0ef          	jal	ra,800039ea <nameiparent>
    80004c54:	892a                	mv	s2,a0
    80004c56:	c921                	beqz	a0,80004ca6 <sys_link+0xc6>
  ilock(dp);
    80004c58:	ec6fe0ef          	jal	ra,8000331e <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004c5c:	00092703          	lw	a4,0(s2)
    80004c60:	409c                	lw	a5,0(s1)
    80004c62:	02f71f63          	bne	a4,a5,80004ca0 <sys_link+0xc0>
    80004c66:	40d0                	lw	a2,4(s1)
    80004c68:	fd040593          	addi	a1,s0,-48
    80004c6c:	854a                	mv	a0,s2
    80004c6e:	cc9fe0ef          	jal	ra,80003936 <dirlink>
    80004c72:	02054763          	bltz	a0,80004ca0 <sys_link+0xc0>
  iunlockput(dp);
    80004c76:	854a                	mv	a0,s2
    80004c78:	8adfe0ef          	jal	ra,80003524 <iunlockput>
  iput(ip);
    80004c7c:	8526                	mv	a0,s1
    80004c7e:	81ffe0ef          	jal	ra,8000349c <iput>
  end_op();
    80004c82:	f9bfe0ef          	jal	ra,80003c1c <end_op>
  return 0;
    80004c86:	4781                	li	a5,0
    80004c88:	a081                	j	80004cc8 <sys_link+0xe8>
    end_op();
    80004c8a:	f93fe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80004c8e:	57fd                	li	a5,-1
    80004c90:	a825                	j	80004cc8 <sys_link+0xe8>
    iunlockput(ip);
    80004c92:	8526                	mv	a0,s1
    80004c94:	891fe0ef          	jal	ra,80003524 <iunlockput>
    end_op();
    80004c98:	f85fe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80004c9c:	57fd                	li	a5,-1
    80004c9e:	a02d                	j	80004cc8 <sys_link+0xe8>
    iunlockput(dp);
    80004ca0:	854a                	mv	a0,s2
    80004ca2:	883fe0ef          	jal	ra,80003524 <iunlockput>
  ilock(ip);
    80004ca6:	8526                	mv	a0,s1
    80004ca8:	e76fe0ef          	jal	ra,8000331e <ilock>
  ip->nlink--;
    80004cac:	04a4d783          	lhu	a5,74(s1)
    80004cb0:	37fd                	addiw	a5,a5,-1
    80004cb2:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004cb6:	8526                	mv	a0,s1
    80004cb8:	db4fe0ef          	jal	ra,8000326c <iupdate>
  iunlockput(ip);
    80004cbc:	8526                	mv	a0,s1
    80004cbe:	867fe0ef          	jal	ra,80003524 <iunlockput>
  end_op();
    80004cc2:	f5bfe0ef          	jal	ra,80003c1c <end_op>
  return -1;
    80004cc6:	57fd                	li	a5,-1
}
    80004cc8:	853e                	mv	a0,a5
    80004cca:	70b2                	ld	ra,296(sp)
    80004ccc:	7412                	ld	s0,288(sp)
    80004cce:	64f2                	ld	s1,280(sp)
    80004cd0:	6952                	ld	s2,272(sp)
    80004cd2:	6155                	addi	sp,sp,304
    80004cd4:	8082                	ret

0000000080004cd6 <sys_unlink>:
{
    80004cd6:	7151                	addi	sp,sp,-240
    80004cd8:	f586                	sd	ra,232(sp)
    80004cda:	f1a2                	sd	s0,224(sp)
    80004cdc:	eda6                	sd	s1,216(sp)
    80004cde:	e9ca                	sd	s2,208(sp)
    80004ce0:	e5ce                	sd	s3,200(sp)
    80004ce2:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004ce4:	08000613          	li	a2,128
    80004ce8:	f3040593          	addi	a1,s0,-208
    80004cec:	4501                	li	a0,0
    80004cee:	b51fd0ef          	jal	ra,8000283e <argstr>
    80004cf2:	12054b63          	bltz	a0,80004e28 <sys_unlink+0x152>
  begin_op();
    80004cf6:	eb7fe0ef          	jal	ra,80003bac <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004cfa:	fb040593          	addi	a1,s0,-80
    80004cfe:	f3040513          	addi	a0,s0,-208
    80004d02:	ce9fe0ef          	jal	ra,800039ea <nameiparent>
    80004d06:	84aa                	mv	s1,a0
    80004d08:	c54d                	beqz	a0,80004db2 <sys_unlink+0xdc>
  ilock(dp);
    80004d0a:	e14fe0ef          	jal	ra,8000331e <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004d0e:	00003597          	auipc	a1,0x3
    80004d12:	b0258593          	addi	a1,a1,-1278 # 80007810 <syscall_names+0x2a0>
    80004d16:	fb040513          	addi	a0,s0,-80
    80004d1a:	a3bfe0ef          	jal	ra,80003754 <namecmp>
    80004d1e:	10050a63          	beqz	a0,80004e32 <sys_unlink+0x15c>
    80004d22:	00003597          	auipc	a1,0x3
    80004d26:	af658593          	addi	a1,a1,-1290 # 80007818 <syscall_names+0x2a8>
    80004d2a:	fb040513          	addi	a0,s0,-80
    80004d2e:	a27fe0ef          	jal	ra,80003754 <namecmp>
    80004d32:	10050063          	beqz	a0,80004e32 <sys_unlink+0x15c>
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004d36:	f2c40613          	addi	a2,s0,-212
    80004d3a:	fb040593          	addi	a1,s0,-80
    80004d3e:	8526                	mv	a0,s1
    80004d40:	a2bfe0ef          	jal	ra,8000376a <dirlookup>
    80004d44:	892a                	mv	s2,a0
    80004d46:	0e050663          	beqz	a0,80004e32 <sys_unlink+0x15c>
  ilock(ip);
    80004d4a:	dd4fe0ef          	jal	ra,8000331e <ilock>
  if(ip->nlink < 1)
    80004d4e:	04a91783          	lh	a5,74(s2)
    80004d52:	06f05463          	blez	a5,80004dba <sys_unlink+0xe4>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004d56:	04491703          	lh	a4,68(s2)
    80004d5a:	4785                	li	a5,1
    80004d5c:	06f70563          	beq	a4,a5,80004dc6 <sys_unlink+0xf0>
  memset(&de, 0, sizeof(de));
    80004d60:	4641                	li	a2,16
    80004d62:	4581                	li	a1,0
    80004d64:	fc040513          	addi	a0,s0,-64
    80004d68:	f5bfb0ef          	jal	ra,80000cc2 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004d6c:	4741                	li	a4,16
    80004d6e:	f2c42683          	lw	a3,-212(s0)
    80004d72:	fc040613          	addi	a2,s0,-64
    80004d76:	4581                	li	a1,0
    80004d78:	8526                	mv	a0,s1
    80004d7a:	8d9fe0ef          	jal	ra,80003652 <writei>
    80004d7e:	47c1                	li	a5,16
    80004d80:	08f51563          	bne	a0,a5,80004e0a <sys_unlink+0x134>
  if(ip->type == T_DIR){
    80004d84:	04491703          	lh	a4,68(s2)
    80004d88:	4785                	li	a5,1
    80004d8a:	08f70663          	beq	a4,a5,80004e16 <sys_unlink+0x140>
  iunlockput(dp);
    80004d8e:	8526                	mv	a0,s1
    80004d90:	f94fe0ef          	jal	ra,80003524 <iunlockput>
  ip->nlink--;
    80004d94:	04a95783          	lhu	a5,74(s2)
    80004d98:	37fd                	addiw	a5,a5,-1
    80004d9a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004d9e:	854a                	mv	a0,s2
    80004da0:	cccfe0ef          	jal	ra,8000326c <iupdate>
  iunlockput(ip);
    80004da4:	854a                	mv	a0,s2
    80004da6:	f7efe0ef          	jal	ra,80003524 <iunlockput>
  end_op();
    80004daa:	e73fe0ef          	jal	ra,80003c1c <end_op>
  return 0;
    80004dae:	4501                	li	a0,0
    80004db0:	a079                	j	80004e3e <sys_unlink+0x168>
    end_op();
    80004db2:	e6bfe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80004db6:	557d                	li	a0,-1
    80004db8:	a059                	j	80004e3e <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004dba:	00003517          	auipc	a0,0x3
    80004dbe:	a6650513          	addi	a0,a0,-1434 # 80007820 <syscall_names+0x2b0>
    80004dc2:	9a7fb0ef          	jal	ra,80000768 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004dc6:	04c92703          	lw	a4,76(s2)
    80004dca:	02000793          	li	a5,32
    80004dce:	f8e7f9e3          	bgeu	a5,a4,80004d60 <sys_unlink+0x8a>
    80004dd2:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004dd6:	4741                	li	a4,16
    80004dd8:	86ce                	mv	a3,s3
    80004dda:	f1840613          	addi	a2,s0,-232
    80004dde:	4581                	li	a1,0
    80004de0:	854a                	mv	a0,s2
    80004de2:	f8cfe0ef          	jal	ra,8000356e <readi>
    80004de6:	47c1                	li	a5,16
    80004de8:	00f51b63          	bne	a0,a5,80004dfe <sys_unlink+0x128>
    if(de.inum != 0)
    80004dec:	f1845783          	lhu	a5,-232(s0)
    80004df0:	ef95                	bnez	a5,80004e2c <sys_unlink+0x156>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004df2:	29c1                	addiw	s3,s3,16
    80004df4:	04c92783          	lw	a5,76(s2)
    80004df8:	fcf9efe3          	bltu	s3,a5,80004dd6 <sys_unlink+0x100>
    80004dfc:	b795                	j	80004d60 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004dfe:	00003517          	auipc	a0,0x3
    80004e02:	a3a50513          	addi	a0,a0,-1478 # 80007838 <syscall_names+0x2c8>
    80004e06:	963fb0ef          	jal	ra,80000768 <panic>
    panic("unlink: writei");
    80004e0a:	00003517          	auipc	a0,0x3
    80004e0e:	a4650513          	addi	a0,a0,-1466 # 80007850 <syscall_names+0x2e0>
    80004e12:	957fb0ef          	jal	ra,80000768 <panic>
    dp->nlink--;
    80004e16:	04a4d783          	lhu	a5,74(s1)
    80004e1a:	37fd                	addiw	a5,a5,-1
    80004e1c:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004e20:	8526                	mv	a0,s1
    80004e22:	c4afe0ef          	jal	ra,8000326c <iupdate>
    80004e26:	b7a5                	j	80004d8e <sys_unlink+0xb8>
    return -1;
    80004e28:	557d                	li	a0,-1
    80004e2a:	a811                	j	80004e3e <sys_unlink+0x168>
    iunlockput(ip);
    80004e2c:	854a                	mv	a0,s2
    80004e2e:	ef6fe0ef          	jal	ra,80003524 <iunlockput>
  iunlockput(dp);
    80004e32:	8526                	mv	a0,s1
    80004e34:	ef0fe0ef          	jal	ra,80003524 <iunlockput>
  end_op();
    80004e38:	de5fe0ef          	jal	ra,80003c1c <end_op>
  return -1;
    80004e3c:	557d                	li	a0,-1
}
    80004e3e:	70ae                	ld	ra,232(sp)
    80004e40:	740e                	ld	s0,224(sp)
    80004e42:	64ee                	ld	s1,216(sp)
    80004e44:	694e                	ld	s2,208(sp)
    80004e46:	69ae                	ld	s3,200(sp)
    80004e48:	616d                	addi	sp,sp,240
    80004e4a:	8082                	ret

0000000080004e4c <sys_open>:

uint64
sys_open(void)
{
    80004e4c:	7131                	addi	sp,sp,-192
    80004e4e:	fd06                	sd	ra,184(sp)
    80004e50:	f922                	sd	s0,176(sp)
    80004e52:	f526                	sd	s1,168(sp)
    80004e54:	f14a                	sd	s2,160(sp)
    80004e56:	ed4e                	sd	s3,152(sp)
    80004e58:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004e5a:	f4c40593          	addi	a1,s0,-180
    80004e5e:	4505                	li	a0,1
    80004e60:	9a7fd0ef          	jal	ra,80002806 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004e64:	08000613          	li	a2,128
    80004e68:	f5040593          	addi	a1,s0,-176
    80004e6c:	4501                	li	a0,0
    80004e6e:	9d1fd0ef          	jal	ra,8000283e <argstr>
    80004e72:	87aa                	mv	a5,a0
    return -1;
    80004e74:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004e76:	0807cd63          	bltz	a5,80004f10 <sys_open+0xc4>

  begin_op();
    80004e7a:	d33fe0ef          	jal	ra,80003bac <begin_op>

  if(omode & O_CREATE){
    80004e7e:	f4c42783          	lw	a5,-180(s0)
    80004e82:	2007f793          	andi	a5,a5,512
    80004e86:	c3c5                	beqz	a5,80004f26 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    80004e88:	4681                	li	a3,0
    80004e8a:	4601                	li	a2,0
    80004e8c:	4589                	li	a1,2
    80004e8e:	f5040513          	addi	a0,s0,-176
    80004e92:	ac3ff0ef          	jal	ra,80004954 <create>
    80004e96:	84aa                	mv	s1,a0
    if(ip == 0){
    80004e98:	c159                	beqz	a0,80004f1e <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004e9a:	04449703          	lh	a4,68(s1)
    80004e9e:	478d                	li	a5,3
    80004ea0:	00f71763          	bne	a4,a5,80004eae <sys_open+0x62>
    80004ea4:	0464d703          	lhu	a4,70(s1)
    80004ea8:	47a5                	li	a5,9
    80004eaa:	0ae7e963          	bltu	a5,a4,80004f5c <sys_open+0x110>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004eae:	876ff0ef          	jal	ra,80003f24 <filealloc>
    80004eb2:	89aa                	mv	s3,a0
    80004eb4:	0c050963          	beqz	a0,80004f86 <sys_open+0x13a>
    80004eb8:	a5fff0ef          	jal	ra,80004916 <fdalloc>
    80004ebc:	892a                	mv	s2,a0
    80004ebe:	0c054163          	bltz	a0,80004f80 <sys_open+0x134>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004ec2:	04449703          	lh	a4,68(s1)
    80004ec6:	478d                	li	a5,3
    80004ec8:	0af70163          	beq	a4,a5,80004f6a <sys_open+0x11e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004ecc:	4789                	li	a5,2
    80004ece:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80004ed2:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80004ed6:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80004eda:	f4c42783          	lw	a5,-180(s0)
    80004ede:	0017c713          	xori	a4,a5,1
    80004ee2:	8b05                	andi	a4,a4,1
    80004ee4:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004ee8:	0037f713          	andi	a4,a5,3
    80004eec:	00e03733          	snez	a4,a4
    80004ef0:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004ef4:	4007f793          	andi	a5,a5,1024
    80004ef8:	c791                	beqz	a5,80004f04 <sys_open+0xb8>
    80004efa:	04449703          	lh	a4,68(s1)
    80004efe:	4789                	li	a5,2
    80004f00:	06f70c63          	beq	a4,a5,80004f78 <sys_open+0x12c>
    itrunc(ip);
  }

  iunlock(ip);
    80004f04:	8526                	mv	a0,s1
    80004f06:	cc2fe0ef          	jal	ra,800033c8 <iunlock>
  end_op();
    80004f0a:	d13fe0ef          	jal	ra,80003c1c <end_op>

  return fd;
    80004f0e:	854a                	mv	a0,s2
}
    80004f10:	70ea                	ld	ra,184(sp)
    80004f12:	744a                	ld	s0,176(sp)
    80004f14:	74aa                	ld	s1,168(sp)
    80004f16:	790a                	ld	s2,160(sp)
    80004f18:	69ea                	ld	s3,152(sp)
    80004f1a:	6129                	addi	sp,sp,192
    80004f1c:	8082                	ret
      end_op();
    80004f1e:	cfffe0ef          	jal	ra,80003c1c <end_op>
      return -1;
    80004f22:	557d                	li	a0,-1
    80004f24:	b7f5                	j	80004f10 <sys_open+0xc4>
    if((ip = namei(path)) == 0){
    80004f26:	f5040513          	addi	a0,s0,-176
    80004f2a:	aa7fe0ef          	jal	ra,800039d0 <namei>
    80004f2e:	84aa                	mv	s1,a0
    80004f30:	c115                	beqz	a0,80004f54 <sys_open+0x108>
    ilock(ip);
    80004f32:	becfe0ef          	jal	ra,8000331e <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004f36:	04449703          	lh	a4,68(s1)
    80004f3a:	4785                	li	a5,1
    80004f3c:	f4f71fe3          	bne	a4,a5,80004e9a <sys_open+0x4e>
    80004f40:	f4c42783          	lw	a5,-180(s0)
    80004f44:	d7ad                	beqz	a5,80004eae <sys_open+0x62>
      iunlockput(ip);
    80004f46:	8526                	mv	a0,s1
    80004f48:	ddcfe0ef          	jal	ra,80003524 <iunlockput>
      end_op();
    80004f4c:	cd1fe0ef          	jal	ra,80003c1c <end_op>
      return -1;
    80004f50:	557d                	li	a0,-1
    80004f52:	bf7d                	j	80004f10 <sys_open+0xc4>
      end_op();
    80004f54:	cc9fe0ef          	jal	ra,80003c1c <end_op>
      return -1;
    80004f58:	557d                	li	a0,-1
    80004f5a:	bf5d                	j	80004f10 <sys_open+0xc4>
    iunlockput(ip);
    80004f5c:	8526                	mv	a0,s1
    80004f5e:	dc6fe0ef          	jal	ra,80003524 <iunlockput>
    end_op();
    80004f62:	cbbfe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80004f66:	557d                	li	a0,-1
    80004f68:	b765                	j	80004f10 <sys_open+0xc4>
    f->type = FD_DEVICE;
    80004f6a:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    80004f6e:	04649783          	lh	a5,70(s1)
    80004f72:	02f99223          	sh	a5,36(s3)
    80004f76:	b785                	j	80004ed6 <sys_open+0x8a>
    itrunc(ip);
    80004f78:	8526                	mv	a0,s1
    80004f7a:	c8efe0ef          	jal	ra,80003408 <itrunc>
    80004f7e:	b759                	j	80004f04 <sys_open+0xb8>
      fileclose(f);
    80004f80:	854e                	mv	a0,s3
    80004f82:	846ff0ef          	jal	ra,80003fc8 <fileclose>
    iunlockput(ip);
    80004f86:	8526                	mv	a0,s1
    80004f88:	d9cfe0ef          	jal	ra,80003524 <iunlockput>
    end_op();
    80004f8c:	c91fe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80004f90:	557d                	li	a0,-1
    80004f92:	bfbd                	j	80004f10 <sys_open+0xc4>

0000000080004f94 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004f94:	7175                	addi	sp,sp,-144
    80004f96:	e506                	sd	ra,136(sp)
    80004f98:	e122                	sd	s0,128(sp)
    80004f9a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004f9c:	c11fe0ef          	jal	ra,80003bac <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004fa0:	08000613          	li	a2,128
    80004fa4:	f7040593          	addi	a1,s0,-144
    80004fa8:	4501                	li	a0,0
    80004faa:	895fd0ef          	jal	ra,8000283e <argstr>
    80004fae:	02054363          	bltz	a0,80004fd4 <sys_mkdir+0x40>
    80004fb2:	4681                	li	a3,0
    80004fb4:	4601                	li	a2,0
    80004fb6:	4585                	li	a1,1
    80004fb8:	f7040513          	addi	a0,s0,-144
    80004fbc:	999ff0ef          	jal	ra,80004954 <create>
    80004fc0:	c911                	beqz	a0,80004fd4 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004fc2:	d62fe0ef          	jal	ra,80003524 <iunlockput>
  end_op();
    80004fc6:	c57fe0ef          	jal	ra,80003c1c <end_op>
  return 0;
    80004fca:	4501                	li	a0,0
}
    80004fcc:	60aa                	ld	ra,136(sp)
    80004fce:	640a                	ld	s0,128(sp)
    80004fd0:	6149                	addi	sp,sp,144
    80004fd2:	8082                	ret
    end_op();
    80004fd4:	c49fe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80004fd8:	557d                	li	a0,-1
    80004fda:	bfcd                	j	80004fcc <sys_mkdir+0x38>

0000000080004fdc <sys_mknod>:

uint64
sys_mknod(void)
{
    80004fdc:	7135                	addi	sp,sp,-160
    80004fde:	ed06                	sd	ra,152(sp)
    80004fe0:	e922                	sd	s0,144(sp)
    80004fe2:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004fe4:	bc9fe0ef          	jal	ra,80003bac <begin_op>
  argint(1, &major);
    80004fe8:	f6c40593          	addi	a1,s0,-148
    80004fec:	4505                	li	a0,1
    80004fee:	819fd0ef          	jal	ra,80002806 <argint>
  argint(2, &minor);
    80004ff2:	f6840593          	addi	a1,s0,-152
    80004ff6:	4509                	li	a0,2
    80004ff8:	80ffd0ef          	jal	ra,80002806 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004ffc:	08000613          	li	a2,128
    80005000:	f7040593          	addi	a1,s0,-144
    80005004:	4501                	li	a0,0
    80005006:	839fd0ef          	jal	ra,8000283e <argstr>
    8000500a:	02054563          	bltz	a0,80005034 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    8000500e:	f6841683          	lh	a3,-152(s0)
    80005012:	f6c41603          	lh	a2,-148(s0)
    80005016:	458d                	li	a1,3
    80005018:	f7040513          	addi	a0,s0,-144
    8000501c:	939ff0ef          	jal	ra,80004954 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005020:	c911                	beqz	a0,80005034 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005022:	d02fe0ef          	jal	ra,80003524 <iunlockput>
  end_op();
    80005026:	bf7fe0ef          	jal	ra,80003c1c <end_op>
  return 0;
    8000502a:	4501                	li	a0,0
}
    8000502c:	60ea                	ld	ra,152(sp)
    8000502e:	644a                	ld	s0,144(sp)
    80005030:	610d                	addi	sp,sp,160
    80005032:	8082                	ret
    end_op();
    80005034:	be9fe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    80005038:	557d                	li	a0,-1
    8000503a:	bfcd                	j	8000502c <sys_mknod+0x50>

000000008000503c <sys_chdir>:

uint64
sys_chdir(void)
{
    8000503c:	7135                	addi	sp,sp,-160
    8000503e:	ed06                	sd	ra,152(sp)
    80005040:	e922                	sd	s0,144(sp)
    80005042:	e526                	sd	s1,136(sp)
    80005044:	e14a                	sd	s2,128(sp)
    80005046:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005048:	83ffc0ef          	jal	ra,80001886 <myproc>
    8000504c:	892a                	mv	s2,a0
  
  begin_op();
    8000504e:	b5ffe0ef          	jal	ra,80003bac <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005052:	08000613          	li	a2,128
    80005056:	f6040593          	addi	a1,s0,-160
    8000505a:	4501                	li	a0,0
    8000505c:	fe2fd0ef          	jal	ra,8000283e <argstr>
    80005060:	04054163          	bltz	a0,800050a2 <sys_chdir+0x66>
    80005064:	f6040513          	addi	a0,s0,-160
    80005068:	969fe0ef          	jal	ra,800039d0 <namei>
    8000506c:	84aa                	mv	s1,a0
    8000506e:	c915                	beqz	a0,800050a2 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005070:	aaefe0ef          	jal	ra,8000331e <ilock>
  if(ip->type != T_DIR){
    80005074:	04449703          	lh	a4,68(s1)
    80005078:	4785                	li	a5,1
    8000507a:	02f71863          	bne	a4,a5,800050aa <sys_chdir+0x6e>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000507e:	8526                	mv	a0,s1
    80005080:	b48fe0ef          	jal	ra,800033c8 <iunlock>
  iput(p->cwd);
    80005084:	15093503          	ld	a0,336(s2)
    80005088:	c14fe0ef          	jal	ra,8000349c <iput>
  end_op();
    8000508c:	b91fe0ef          	jal	ra,80003c1c <end_op>
  p->cwd = ip;
    80005090:	14993823          	sd	s1,336(s2)
  return 0;
    80005094:	4501                	li	a0,0
}
    80005096:	60ea                	ld	ra,152(sp)
    80005098:	644a                	ld	s0,144(sp)
    8000509a:	64aa                	ld	s1,136(sp)
    8000509c:	690a                	ld	s2,128(sp)
    8000509e:	610d                	addi	sp,sp,160
    800050a0:	8082                	ret
    end_op();
    800050a2:	b7bfe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    800050a6:	557d                	li	a0,-1
    800050a8:	b7fd                	j	80005096 <sys_chdir+0x5a>
    iunlockput(ip);
    800050aa:	8526                	mv	a0,s1
    800050ac:	c78fe0ef          	jal	ra,80003524 <iunlockput>
    end_op();
    800050b0:	b6dfe0ef          	jal	ra,80003c1c <end_op>
    return -1;
    800050b4:	557d                	li	a0,-1
    800050b6:	b7c5                	j	80005096 <sys_chdir+0x5a>

00000000800050b8 <sys_exec>:

uint64
sys_exec(void)
{
    800050b8:	7145                	addi	sp,sp,-464
    800050ba:	e786                	sd	ra,456(sp)
    800050bc:	e3a2                	sd	s0,448(sp)
    800050be:	ff26                	sd	s1,440(sp)
    800050c0:	fb4a                	sd	s2,432(sp)
    800050c2:	f74e                	sd	s3,424(sp)
    800050c4:	f352                	sd	s4,416(sp)
    800050c6:	ef56                	sd	s5,408(sp)
    800050c8:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800050ca:	e3840593          	addi	a1,s0,-456
    800050ce:	4505                	li	a0,1
    800050d0:	f52fd0ef          	jal	ra,80002822 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    800050d4:	08000613          	li	a2,128
    800050d8:	f4040593          	addi	a1,s0,-192
    800050dc:	4501                	li	a0,0
    800050de:	f60fd0ef          	jal	ra,8000283e <argstr>
    800050e2:	87aa                	mv	a5,a0
    return -1;
    800050e4:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    800050e6:	0a07c463          	bltz	a5,8000518e <sys_exec+0xd6>
  }
  memset(argv, 0, sizeof(argv));
    800050ea:	10000613          	li	a2,256
    800050ee:	4581                	li	a1,0
    800050f0:	e4040513          	addi	a0,s0,-448
    800050f4:	bcffb0ef          	jal	ra,80000cc2 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800050f8:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    800050fc:	89a6                	mv	s3,s1
    800050fe:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005100:	02000a13          	li	s4,32
    80005104:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005108:	00391793          	slli	a5,s2,0x3
    8000510c:	e3040593          	addi	a1,s0,-464
    80005110:	e3843503          	ld	a0,-456(s0)
    80005114:	953e                	add	a0,a0,a5
    80005116:	e66fd0ef          	jal	ra,8000277c <fetchaddr>
    8000511a:	02054663          	bltz	a0,80005146 <sys_exec+0x8e>
      goto bad;
    }
    if(uarg == 0){
    8000511e:	e3043783          	ld	a5,-464(s0)
    80005122:	cf8d                	beqz	a5,8000515c <sys_exec+0xa4>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005124:	9fbfb0ef          	jal	ra,80000b1e <kalloc>
    80005128:	85aa                	mv	a1,a0
    8000512a:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000512e:	cd01                	beqz	a0,80005146 <sys_exec+0x8e>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005130:	6605                	lui	a2,0x1
    80005132:	e3043503          	ld	a0,-464(s0)
    80005136:	e90fd0ef          	jal	ra,800027c6 <fetchstr>
    8000513a:	00054663          	bltz	a0,80005146 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    8000513e:	0905                	addi	s2,s2,1
    80005140:	09a1                	addi	s3,s3,8
    80005142:	fd4911e3          	bne	s2,s4,80005104 <sys_exec+0x4c>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005146:	10048913          	addi	s2,s1,256
    8000514a:	6088                	ld	a0,0(s1)
    8000514c:	c121                	beqz	a0,8000518c <sys_exec+0xd4>
    kfree(argv[i]);
    8000514e:	8f1fb0ef          	jal	ra,80000a3e <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005152:	04a1                	addi	s1,s1,8
    80005154:	ff249be3          	bne	s1,s2,8000514a <sys_exec+0x92>
  return -1;
    80005158:	557d                	li	a0,-1
    8000515a:	a815                	j	8000518e <sys_exec+0xd6>
      argv[i] = 0;
    8000515c:	0a8e                	slli	s5,s5,0x3
    8000515e:	fc040793          	addi	a5,s0,-64
    80005162:	9abe                	add	s5,s5,a5
    80005164:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    80005168:	e4040593          	addi	a1,s0,-448
    8000516c:	f4040513          	addi	a0,s0,-192
    80005170:	bfaff0ef          	jal	ra,8000456a <exec>
    80005174:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005176:	10048993          	addi	s3,s1,256
    8000517a:	6088                	ld	a0,0(s1)
    8000517c:	c511                	beqz	a0,80005188 <sys_exec+0xd0>
    kfree(argv[i]);
    8000517e:	8c1fb0ef          	jal	ra,80000a3e <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005182:	04a1                	addi	s1,s1,8
    80005184:	ff349be3          	bne	s1,s3,8000517a <sys_exec+0xc2>
  return ret;
    80005188:	854a                	mv	a0,s2
    8000518a:	a011                	j	8000518e <sys_exec+0xd6>
  return -1;
    8000518c:	557d                	li	a0,-1
}
    8000518e:	60be                	ld	ra,456(sp)
    80005190:	641e                	ld	s0,448(sp)
    80005192:	74fa                	ld	s1,440(sp)
    80005194:	795a                	ld	s2,432(sp)
    80005196:	79ba                	ld	s3,424(sp)
    80005198:	7a1a                	ld	s4,416(sp)
    8000519a:	6afa                	ld	s5,408(sp)
    8000519c:	6179                	addi	sp,sp,464
    8000519e:	8082                	ret

00000000800051a0 <sys_pipe>:

uint64
sys_pipe(void)
{
    800051a0:	7139                	addi	sp,sp,-64
    800051a2:	fc06                	sd	ra,56(sp)
    800051a4:	f822                	sd	s0,48(sp)
    800051a6:	f426                	sd	s1,40(sp)
    800051a8:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800051aa:	edcfc0ef          	jal	ra,80001886 <myproc>
    800051ae:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800051b0:	fd840593          	addi	a1,s0,-40
    800051b4:	4501                	li	a0,0
    800051b6:	e6cfd0ef          	jal	ra,80002822 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    800051ba:	fc840593          	addi	a1,s0,-56
    800051be:	fd040513          	addi	a0,s0,-48
    800051c2:	8d2ff0ef          	jal	ra,80004294 <pipealloc>
    return -1;
    800051c6:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800051c8:	0a054463          	bltz	a0,80005270 <sys_pipe+0xd0>
  fd0 = -1;
    800051cc:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    800051d0:	fd043503          	ld	a0,-48(s0)
    800051d4:	f42ff0ef          	jal	ra,80004916 <fdalloc>
    800051d8:	fca42223          	sw	a0,-60(s0)
    800051dc:	08054163          	bltz	a0,8000525e <sys_pipe+0xbe>
    800051e0:	fc843503          	ld	a0,-56(s0)
    800051e4:	f32ff0ef          	jal	ra,80004916 <fdalloc>
    800051e8:	fca42023          	sw	a0,-64(s0)
    800051ec:	06054063          	bltz	a0,8000524c <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800051f0:	4691                	li	a3,4
    800051f2:	fc440613          	addi	a2,s0,-60
    800051f6:	fd843583          	ld	a1,-40(s0)
    800051fa:	68a8                	ld	a0,80(s1)
    800051fc:	bd8fc0ef          	jal	ra,800015d4 <copyout>
    80005200:	00054e63          	bltz	a0,8000521c <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005204:	4691                	li	a3,4
    80005206:	fc040613          	addi	a2,s0,-64
    8000520a:	fd843583          	ld	a1,-40(s0)
    8000520e:	0591                	addi	a1,a1,4
    80005210:	68a8                	ld	a0,80(s1)
    80005212:	bc2fc0ef          	jal	ra,800015d4 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005216:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005218:	04055c63          	bgez	a0,80005270 <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    8000521c:	fc442783          	lw	a5,-60(s0)
    80005220:	07e9                	addi	a5,a5,26
    80005222:	078e                	slli	a5,a5,0x3
    80005224:	97a6                	add	a5,a5,s1
    80005226:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    8000522a:	fc042503          	lw	a0,-64(s0)
    8000522e:	0569                	addi	a0,a0,26
    80005230:	050e                	slli	a0,a0,0x3
    80005232:	94aa                	add	s1,s1,a0
    80005234:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005238:	fd043503          	ld	a0,-48(s0)
    8000523c:	d8dfe0ef          	jal	ra,80003fc8 <fileclose>
    fileclose(wf);
    80005240:	fc843503          	ld	a0,-56(s0)
    80005244:	d85fe0ef          	jal	ra,80003fc8 <fileclose>
    return -1;
    80005248:	57fd                	li	a5,-1
    8000524a:	a01d                	j	80005270 <sys_pipe+0xd0>
    if(fd0 >= 0)
    8000524c:	fc442783          	lw	a5,-60(s0)
    80005250:	0007c763          	bltz	a5,8000525e <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    80005254:	07e9                	addi	a5,a5,26
    80005256:	078e                	slli	a5,a5,0x3
    80005258:	94be                	add	s1,s1,a5
    8000525a:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000525e:	fd043503          	ld	a0,-48(s0)
    80005262:	d67fe0ef          	jal	ra,80003fc8 <fileclose>
    fileclose(wf);
    80005266:	fc843503          	ld	a0,-56(s0)
    8000526a:	d5ffe0ef          	jal	ra,80003fc8 <fileclose>
    return -1;
    8000526e:	57fd                	li	a5,-1
}
    80005270:	853e                	mv	a0,a5
    80005272:	70e2                	ld	ra,56(sp)
    80005274:	7442                	ld	s0,48(sp)
    80005276:	74a2                	ld	s1,40(sp)
    80005278:	6121                	addi	sp,sp,64
    8000527a:	8082                	ret
    8000527c:	0000                	unimp
	...

0000000080005280 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005280:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005282:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005284:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005286:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005288:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000528a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000528c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000528e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005290:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005292:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005294:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005296:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005298:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000529a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000529c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000529e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    800052a0:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    800052a2:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    800052a4:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    800052a6:	be6fd0ef          	jal	ra,8000268c <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    800052aa:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    800052ac:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    800052ae:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800052b0:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800052b2:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800052b4:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800052b6:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800052b8:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800052ba:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800052bc:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800052be:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800052c0:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800052c2:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800052c4:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800052c6:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800052c8:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800052ca:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800052cc:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800052ce:	10200073          	sret
	...

00000000800052de <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800052de:	1141                	addi	sp,sp,-16
    800052e0:	e422                	sd	s0,8(sp)
    800052e2:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800052e4:	0c0007b7          	lui	a5,0xc000
    800052e8:	4705                	li	a4,1
    800052ea:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800052ec:	c3d8                	sw	a4,4(a5)
}
    800052ee:	6422                	ld	s0,8(sp)
    800052f0:	0141                	addi	sp,sp,16
    800052f2:	8082                	ret

00000000800052f4 <plicinithart>:

void
plicinithart(void)
{
    800052f4:	1141                	addi	sp,sp,-16
    800052f6:	e406                	sd	ra,8(sp)
    800052f8:	e022                	sd	s0,0(sp)
    800052fa:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800052fc:	d5efc0ef          	jal	ra,8000185a <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005300:	0085171b          	slliw	a4,a0,0x8
    80005304:	0c0027b7          	lui	a5,0xc002
    80005308:	97ba                	add	a5,a5,a4
    8000530a:	40200713          	li	a4,1026
    8000530e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005312:	00d5151b          	slliw	a0,a0,0xd
    80005316:	0c2017b7          	lui	a5,0xc201
    8000531a:	953e                	add	a0,a0,a5
    8000531c:	00052023          	sw	zero,0(a0)
}
    80005320:	60a2                	ld	ra,8(sp)
    80005322:	6402                	ld	s0,0(sp)
    80005324:	0141                	addi	sp,sp,16
    80005326:	8082                	ret

0000000080005328 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005328:	1141                	addi	sp,sp,-16
    8000532a:	e406                	sd	ra,8(sp)
    8000532c:	e022                	sd	s0,0(sp)
    8000532e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005330:	d2afc0ef          	jal	ra,8000185a <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005334:	00d5179b          	slliw	a5,a0,0xd
    80005338:	0c201537          	lui	a0,0xc201
    8000533c:	953e                	add	a0,a0,a5
  return irq;
}
    8000533e:	4148                	lw	a0,4(a0)
    80005340:	60a2                	ld	ra,8(sp)
    80005342:	6402                	ld	s0,0(sp)
    80005344:	0141                	addi	sp,sp,16
    80005346:	8082                	ret

0000000080005348 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005348:	1101                	addi	sp,sp,-32
    8000534a:	ec06                	sd	ra,24(sp)
    8000534c:	e822                	sd	s0,16(sp)
    8000534e:	e426                	sd	s1,8(sp)
    80005350:	1000                	addi	s0,sp,32
    80005352:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005354:	d06fc0ef          	jal	ra,8000185a <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005358:	00d5151b          	slliw	a0,a0,0xd
    8000535c:	0c2017b7          	lui	a5,0xc201
    80005360:	97aa                	add	a5,a5,a0
    80005362:	c3c4                	sw	s1,4(a5)
}
    80005364:	60e2                	ld	ra,24(sp)
    80005366:	6442                	ld	s0,16(sp)
    80005368:	64a2                	ld	s1,8(sp)
    8000536a:	6105                	addi	sp,sp,32
    8000536c:	8082                	ret

000000008000536e <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    8000536e:	1141                	addi	sp,sp,-16
    80005370:	e406                	sd	ra,8(sp)
    80005372:	e022                	sd	s0,0(sp)
    80005374:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80005376:	479d                	li	a5,7
    80005378:	04a7ca63          	blt	a5,a0,800053cc <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    8000537c:	00020797          	auipc	a5,0x20
    80005380:	61c78793          	addi	a5,a5,1564 # 80025998 <disk>
    80005384:	97aa                	add	a5,a5,a0
    80005386:	0187c783          	lbu	a5,24(a5)
    8000538a:	e7b9                	bnez	a5,800053d8 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    8000538c:	00451613          	slli	a2,a0,0x4
    80005390:	00020797          	auipc	a5,0x20
    80005394:	60878793          	addi	a5,a5,1544 # 80025998 <disk>
    80005398:	6394                	ld	a3,0(a5)
    8000539a:	96b2                	add	a3,a3,a2
    8000539c:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    800053a0:	6398                	ld	a4,0(a5)
    800053a2:	9732                	add	a4,a4,a2
    800053a4:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800053a8:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800053ac:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800053b0:	953e                	add	a0,a0,a5
    800053b2:	4785                	li	a5,1
    800053b4:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    800053b8:	00020517          	auipc	a0,0x20
    800053bc:	5f850513          	addi	a0,a0,1528 # 800259b0 <disk+0x18>
    800053c0:	b2ffc0ef          	jal	ra,80001eee <wakeup>
}
    800053c4:	60a2                	ld	ra,8(sp)
    800053c6:	6402                	ld	s0,0(sp)
    800053c8:	0141                	addi	sp,sp,16
    800053ca:	8082                	ret
    panic("free_desc 1");
    800053cc:	00002517          	auipc	a0,0x2
    800053d0:	49450513          	addi	a0,a0,1172 # 80007860 <syscall_names+0x2f0>
    800053d4:	b94fb0ef          	jal	ra,80000768 <panic>
    panic("free_desc 2");
    800053d8:	00002517          	auipc	a0,0x2
    800053dc:	49850513          	addi	a0,a0,1176 # 80007870 <syscall_names+0x300>
    800053e0:	b88fb0ef          	jal	ra,80000768 <panic>

00000000800053e4 <virtio_disk_init>:
{
    800053e4:	1101                	addi	sp,sp,-32
    800053e6:	ec06                	sd	ra,24(sp)
    800053e8:	e822                	sd	s0,16(sp)
    800053ea:	e426                	sd	s1,8(sp)
    800053ec:	e04a                	sd	s2,0(sp)
    800053ee:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800053f0:	00002597          	auipc	a1,0x2
    800053f4:	49058593          	addi	a1,a1,1168 # 80007880 <syscall_names+0x310>
    800053f8:	00020517          	auipc	a0,0x20
    800053fc:	6c850513          	addi	a0,a0,1736 # 80025ac0 <disk+0x128>
    80005400:	f6efb0ef          	jal	ra,80000b6e <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005404:	100017b7          	lui	a5,0x10001
    80005408:	4398                	lw	a4,0(a5)
    8000540a:	2701                	sext.w	a4,a4
    8000540c:	747277b7          	lui	a5,0x74727
    80005410:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005414:	14f71063          	bne	a4,a5,80005554 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005418:	100017b7          	lui	a5,0x10001
    8000541c:	43dc                	lw	a5,4(a5)
    8000541e:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005420:	4709                	li	a4,2
    80005422:	12e79963          	bne	a5,a4,80005554 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005426:	100017b7          	lui	a5,0x10001
    8000542a:	479c                	lw	a5,8(a5)
    8000542c:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000542e:	12e79363          	bne	a5,a4,80005554 <virtio_disk_init+0x170>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005432:	100017b7          	lui	a5,0x10001
    80005436:	47d8                	lw	a4,12(a5)
    80005438:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000543a:	554d47b7          	lui	a5,0x554d4
    8000543e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005442:	10f71963          	bne	a4,a5,80005554 <virtio_disk_init+0x170>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005446:	100017b7          	lui	a5,0x10001
    8000544a:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000544e:	4705                	li	a4,1
    80005450:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005452:	470d                	li	a4,3
    80005454:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005456:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005458:	c7ffe737          	lui	a4,0xc7ffe
    8000545c:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fd8c87>
    80005460:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005462:	2701                	sext.w	a4,a4
    80005464:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005466:	472d                	li	a4,11
    80005468:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    8000546a:	5bbc                	lw	a5,112(a5)
    8000546c:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005470:	8ba1                	andi	a5,a5,8
    80005472:	0e078763          	beqz	a5,80005560 <virtio_disk_init+0x17c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005476:	100017b7          	lui	a5,0x10001
    8000547a:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    8000547e:	43fc                	lw	a5,68(a5)
    80005480:	2781                	sext.w	a5,a5
    80005482:	0e079563          	bnez	a5,8000556c <virtio_disk_init+0x188>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005486:	100017b7          	lui	a5,0x10001
    8000548a:	5bdc                	lw	a5,52(a5)
    8000548c:	2781                	sext.w	a5,a5
  if(max == 0)
    8000548e:	0e078563          	beqz	a5,80005578 <virtio_disk_init+0x194>
  if(max < NUM)
    80005492:	471d                	li	a4,7
    80005494:	0ef77863          	bgeu	a4,a5,80005584 <virtio_disk_init+0x1a0>
  disk.desc = kalloc();
    80005498:	e86fb0ef          	jal	ra,80000b1e <kalloc>
    8000549c:	00020497          	auipc	s1,0x20
    800054a0:	4fc48493          	addi	s1,s1,1276 # 80025998 <disk>
    800054a4:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800054a6:	e78fb0ef          	jal	ra,80000b1e <kalloc>
    800054aa:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800054ac:	e72fb0ef          	jal	ra,80000b1e <kalloc>
    800054b0:	87aa                	mv	a5,a0
    800054b2:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800054b4:	6088                	ld	a0,0(s1)
    800054b6:	cd69                	beqz	a0,80005590 <virtio_disk_init+0x1ac>
    800054b8:	00020717          	auipc	a4,0x20
    800054bc:	4e873703          	ld	a4,1256(a4) # 800259a0 <disk+0x8>
    800054c0:	cb61                	beqz	a4,80005590 <virtio_disk_init+0x1ac>
    800054c2:	c7f9                	beqz	a5,80005590 <virtio_disk_init+0x1ac>
  memset(disk.desc, 0, PGSIZE);
    800054c4:	6605                	lui	a2,0x1
    800054c6:	4581                	li	a1,0
    800054c8:	ffafb0ef          	jal	ra,80000cc2 <memset>
  memset(disk.avail, 0, PGSIZE);
    800054cc:	00020497          	auipc	s1,0x20
    800054d0:	4cc48493          	addi	s1,s1,1228 # 80025998 <disk>
    800054d4:	6605                	lui	a2,0x1
    800054d6:	4581                	li	a1,0
    800054d8:	6488                	ld	a0,8(s1)
    800054da:	fe8fb0ef          	jal	ra,80000cc2 <memset>
  memset(disk.used, 0, PGSIZE);
    800054de:	6605                	lui	a2,0x1
    800054e0:	4581                	li	a1,0
    800054e2:	6888                	ld	a0,16(s1)
    800054e4:	fdefb0ef          	jal	ra,80000cc2 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800054e8:	100017b7          	lui	a5,0x10001
    800054ec:	4721                	li	a4,8
    800054ee:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800054f0:	4098                	lw	a4,0(s1)
    800054f2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800054f6:	40d8                	lw	a4,4(s1)
    800054f8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800054fc:	6498                	ld	a4,8(s1)
    800054fe:	0007069b          	sext.w	a3,a4
    80005502:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005506:	9701                	srai	a4,a4,0x20
    80005508:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    8000550c:	6898                	ld	a4,16(s1)
    8000550e:	0007069b          	sext.w	a3,a4
    80005512:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005516:	9701                	srai	a4,a4,0x20
    80005518:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    8000551c:	4705                	li	a4,1
    8000551e:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80005520:	00e48c23          	sb	a4,24(s1)
    80005524:	00e48ca3          	sb	a4,25(s1)
    80005528:	00e48d23          	sb	a4,26(s1)
    8000552c:	00e48da3          	sb	a4,27(s1)
    80005530:	00e48e23          	sb	a4,28(s1)
    80005534:	00e48ea3          	sb	a4,29(s1)
    80005538:	00e48f23          	sb	a4,30(s1)
    8000553c:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005540:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005544:	0727a823          	sw	s2,112(a5)
}
    80005548:	60e2                	ld	ra,24(sp)
    8000554a:	6442                	ld	s0,16(sp)
    8000554c:	64a2                	ld	s1,8(sp)
    8000554e:	6902                	ld	s2,0(sp)
    80005550:	6105                	addi	sp,sp,32
    80005552:	8082                	ret
    panic("could not find virtio disk");
    80005554:	00002517          	auipc	a0,0x2
    80005558:	33c50513          	addi	a0,a0,828 # 80007890 <syscall_names+0x320>
    8000555c:	a0cfb0ef          	jal	ra,80000768 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005560:	00002517          	auipc	a0,0x2
    80005564:	35050513          	addi	a0,a0,848 # 800078b0 <syscall_names+0x340>
    80005568:	a00fb0ef          	jal	ra,80000768 <panic>
    panic("virtio disk should not be ready");
    8000556c:	00002517          	auipc	a0,0x2
    80005570:	36450513          	addi	a0,a0,868 # 800078d0 <syscall_names+0x360>
    80005574:	9f4fb0ef          	jal	ra,80000768 <panic>
    panic("virtio disk has no queue 0");
    80005578:	00002517          	auipc	a0,0x2
    8000557c:	37850513          	addi	a0,a0,888 # 800078f0 <syscall_names+0x380>
    80005580:	9e8fb0ef          	jal	ra,80000768 <panic>
    panic("virtio disk max queue too short");
    80005584:	00002517          	auipc	a0,0x2
    80005588:	38c50513          	addi	a0,a0,908 # 80007910 <syscall_names+0x3a0>
    8000558c:	9dcfb0ef          	jal	ra,80000768 <panic>
    panic("virtio disk kalloc");
    80005590:	00002517          	auipc	a0,0x2
    80005594:	3a050513          	addi	a0,a0,928 # 80007930 <syscall_names+0x3c0>
    80005598:	9d0fb0ef          	jal	ra,80000768 <panic>

000000008000559c <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    8000559c:	7119                	addi	sp,sp,-128
    8000559e:	fc86                	sd	ra,120(sp)
    800055a0:	f8a2                	sd	s0,112(sp)
    800055a2:	f4a6                	sd	s1,104(sp)
    800055a4:	f0ca                	sd	s2,96(sp)
    800055a6:	ecce                	sd	s3,88(sp)
    800055a8:	e8d2                	sd	s4,80(sp)
    800055aa:	e4d6                	sd	s5,72(sp)
    800055ac:	e0da                	sd	s6,64(sp)
    800055ae:	fc5e                	sd	s7,56(sp)
    800055b0:	f862                	sd	s8,48(sp)
    800055b2:	f466                	sd	s9,40(sp)
    800055b4:	f06a                	sd	s10,32(sp)
    800055b6:	ec6e                	sd	s11,24(sp)
    800055b8:	0100                	addi	s0,sp,128
    800055ba:	8aaa                	mv	s5,a0
    800055bc:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800055be:	00c52d03          	lw	s10,12(a0)
    800055c2:	001d1d1b          	slliw	s10,s10,0x1
    800055c6:	1d02                	slli	s10,s10,0x20
    800055c8:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    800055cc:	00020517          	auipc	a0,0x20
    800055d0:	4f450513          	addi	a0,a0,1268 # 80025ac0 <disk+0x128>
    800055d4:	e1afb0ef          	jal	ra,80000bee <acquire>
  for(int i = 0; i < 3; i++){
    800055d8:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    800055da:	44a1                	li	s1,8
      disk.free[i] = 0;
    800055dc:	00020b97          	auipc	s7,0x20
    800055e0:	3bcb8b93          	addi	s7,s7,956 # 80025998 <disk>
  for(int i = 0; i < 3; i++){
    800055e4:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800055e6:	00020c97          	auipc	s9,0x20
    800055ea:	4dac8c93          	addi	s9,s9,1242 # 80025ac0 <disk+0x128>
    800055ee:	a8a9                	j	80005648 <virtio_disk_rw+0xac>
      disk.free[i] = 0;
    800055f0:	00fb8733          	add	a4,s7,a5
    800055f4:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800055f8:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800055fa:	0207c563          	bltz	a5,80005624 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    800055fe:	2905                	addiw	s2,s2,1
    80005600:	0611                	addi	a2,a2,4
    80005602:	05690863          	beq	s2,s6,80005652 <virtio_disk_rw+0xb6>
    idx[i] = alloc_desc();
    80005606:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005608:	00020717          	auipc	a4,0x20
    8000560c:	39070713          	addi	a4,a4,912 # 80025998 <disk>
    80005610:	87ce                	mv	a5,s3
    if(disk.free[i]){
    80005612:	01874683          	lbu	a3,24(a4)
    80005616:	fee9                	bnez	a3,800055f0 <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80005618:	2785                	addiw	a5,a5,1
    8000561a:	0705                	addi	a4,a4,1
    8000561c:	fe979be3          	bne	a5,s1,80005612 <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    80005620:	57fd                	li	a5,-1
    80005622:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    80005624:	01205b63          	blez	s2,8000563a <virtio_disk_rw+0x9e>
    80005628:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    8000562a:	000a2503          	lw	a0,0(s4)
    8000562e:	d41ff0ef          	jal	ra,8000536e <free_desc>
      for(int j = 0; j < i; j++)
    80005632:	2d85                	addiw	s11,s11,1
    80005634:	0a11                	addi	s4,s4,4
    80005636:	ffb91ae3          	bne	s2,s11,8000562a <virtio_disk_rw+0x8e>
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000563a:	85e6                	mv	a1,s9
    8000563c:	00020517          	auipc	a0,0x20
    80005640:	37450513          	addi	a0,a0,884 # 800259b0 <disk+0x18>
    80005644:	85ffc0ef          	jal	ra,80001ea2 <sleep>
  for(int i = 0; i < 3; i++){
    80005648:	f8040a13          	addi	s4,s0,-128
{
    8000564c:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    8000564e:	894e                	mv	s2,s3
    80005650:	bf5d                	j	80005606 <virtio_disk_rw+0x6a>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005652:	f8042583          	lw	a1,-128(s0)
    80005656:	00a58793          	addi	a5,a1,10
    8000565a:	0792                	slli	a5,a5,0x4

  if(write)
    8000565c:	00020617          	auipc	a2,0x20
    80005660:	33c60613          	addi	a2,a2,828 # 80025998 <disk>
    80005664:	00f60733          	add	a4,a2,a5
    80005668:	018036b3          	snez	a3,s8
    8000566c:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    8000566e:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005672:	01a73823          	sd	s10,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005676:	f6078693          	addi	a3,a5,-160
    8000567a:	6218                	ld	a4,0(a2)
    8000567c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000567e:	00878513          	addi	a0,a5,8
    80005682:	9532                	add	a0,a0,a2
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005684:	e308                	sd	a0,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005686:	6208                	ld	a0,0(a2)
    80005688:	96aa                	add	a3,a3,a0
    8000568a:	4741                	li	a4,16
    8000568c:	c698                	sw	a4,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    8000568e:	4705                	li	a4,1
    80005690:	00e69623          	sh	a4,12(a3)
  disk.desc[idx[0]].next = idx[1];
    80005694:	f8442703          	lw	a4,-124(s0)
    80005698:	00e69723          	sh	a4,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000569c:	0712                	slli	a4,a4,0x4
    8000569e:	953a                	add	a0,a0,a4
    800056a0:	058a8693          	addi	a3,s5,88
    800056a4:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    800056a6:	6208                	ld	a0,0(a2)
    800056a8:	972a                	add	a4,a4,a0
    800056aa:	40000693          	li	a3,1024
    800056ae:	c714                	sw	a3,8(a4)
  if(write)
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    800056b0:	001c3c13          	seqz	s8,s8
    800056b4:	0c06                	slli	s8,s8,0x1
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    800056b6:	001c6c13          	ori	s8,s8,1
    800056ba:	01871623          	sh	s8,12(a4)
  disk.desc[idx[1]].next = idx[2];
    800056be:	f8842603          	lw	a2,-120(s0)
    800056c2:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    800056c6:	00020697          	auipc	a3,0x20
    800056ca:	2d268693          	addi	a3,a3,722 # 80025998 <disk>
    800056ce:	00258713          	addi	a4,a1,2
    800056d2:	0712                	slli	a4,a4,0x4
    800056d4:	9736                	add	a4,a4,a3
    800056d6:	587d                	li	a6,-1
    800056d8:	01070823          	sb	a6,16(a4)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800056dc:	0612                	slli	a2,a2,0x4
    800056de:	9532                	add	a0,a0,a2
    800056e0:	f9078793          	addi	a5,a5,-112
    800056e4:	97b6                	add	a5,a5,a3
    800056e6:	e11c                	sd	a5,0(a0)
  disk.desc[idx[2]].len = 1;
    800056e8:	629c                	ld	a5,0(a3)
    800056ea:	97b2                	add	a5,a5,a2
    800056ec:	4605                	li	a2,1
    800056ee:	c790                	sw	a2,8(a5)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800056f0:	4509                	li	a0,2
    800056f2:	00a79623          	sh	a0,12(a5)
  disk.desc[idx[2]].next = 0;
    800056f6:	00079723          	sh	zero,14(a5)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    800056fa:	00caa223          	sw	a2,4(s5)
  disk.info[idx[0]].b = b;
    800056fe:	01573423          	sd	s5,8(a4)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005702:	6698                	ld	a4,8(a3)
    80005704:	00275783          	lhu	a5,2(a4)
    80005708:	8b9d                	andi	a5,a5,7
    8000570a:	0786                	slli	a5,a5,0x1
    8000570c:	97ba                	add	a5,a5,a4
    8000570e:	00b79223          	sh	a1,4(a5)

  __sync_synchronize();
    80005712:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005716:	6698                	ld	a4,8(a3)
    80005718:	00275783          	lhu	a5,2(a4)
    8000571c:	2785                	addiw	a5,a5,1
    8000571e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005722:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005726:	100017b7          	lui	a5,0x10001
    8000572a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    8000572e:	004aa783          	lw	a5,4(s5)
    80005732:	00c79f63          	bne	a5,a2,80005750 <virtio_disk_rw+0x1b4>
    sleep(b, &disk.vdisk_lock);
    80005736:	00020917          	auipc	s2,0x20
    8000573a:	38a90913          	addi	s2,s2,906 # 80025ac0 <disk+0x128>
  while(b->disk == 1) {
    8000573e:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80005740:	85ca                	mv	a1,s2
    80005742:	8556                	mv	a0,s5
    80005744:	f5efc0ef          	jal	ra,80001ea2 <sleep>
  while(b->disk == 1) {
    80005748:	004aa783          	lw	a5,4(s5)
    8000574c:	fe978ae3          	beq	a5,s1,80005740 <virtio_disk_rw+0x1a4>
  }

  disk.info[idx[0]].b = 0;
    80005750:	f8042903          	lw	s2,-128(s0)
    80005754:	00290793          	addi	a5,s2,2
    80005758:	00479713          	slli	a4,a5,0x4
    8000575c:	00020797          	auipc	a5,0x20
    80005760:	23c78793          	addi	a5,a5,572 # 80025998 <disk>
    80005764:	97ba                	add	a5,a5,a4
    80005766:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    8000576a:	00020997          	auipc	s3,0x20
    8000576e:	22e98993          	addi	s3,s3,558 # 80025998 <disk>
    80005772:	00491713          	slli	a4,s2,0x4
    80005776:	0009b783          	ld	a5,0(s3)
    8000577a:	97ba                	add	a5,a5,a4
    8000577c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005780:	854a                	mv	a0,s2
    80005782:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005786:	be9ff0ef          	jal	ra,8000536e <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    8000578a:	8885                	andi	s1,s1,1
    8000578c:	f0fd                	bnez	s1,80005772 <virtio_disk_rw+0x1d6>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000578e:	00020517          	auipc	a0,0x20
    80005792:	33250513          	addi	a0,a0,818 # 80025ac0 <disk+0x128>
    80005796:	cf0fb0ef          	jal	ra,80000c86 <release>
}
    8000579a:	70e6                	ld	ra,120(sp)
    8000579c:	7446                	ld	s0,112(sp)
    8000579e:	74a6                	ld	s1,104(sp)
    800057a0:	7906                	ld	s2,96(sp)
    800057a2:	69e6                	ld	s3,88(sp)
    800057a4:	6a46                	ld	s4,80(sp)
    800057a6:	6aa6                	ld	s5,72(sp)
    800057a8:	6b06                	ld	s6,64(sp)
    800057aa:	7be2                	ld	s7,56(sp)
    800057ac:	7c42                	ld	s8,48(sp)
    800057ae:	7ca2                	ld	s9,40(sp)
    800057b0:	7d02                	ld	s10,32(sp)
    800057b2:	6de2                	ld	s11,24(sp)
    800057b4:	6109                	addi	sp,sp,128
    800057b6:	8082                	ret

00000000800057b8 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    800057b8:	1101                	addi	sp,sp,-32
    800057ba:	ec06                	sd	ra,24(sp)
    800057bc:	e822                	sd	s0,16(sp)
    800057be:	e426                	sd	s1,8(sp)
    800057c0:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800057c2:	00020497          	auipc	s1,0x20
    800057c6:	1d648493          	addi	s1,s1,470 # 80025998 <disk>
    800057ca:	00020517          	auipc	a0,0x20
    800057ce:	2f650513          	addi	a0,a0,758 # 80025ac0 <disk+0x128>
    800057d2:	c1cfb0ef          	jal	ra,80000bee <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800057d6:	10001737          	lui	a4,0x10001
    800057da:	533c                	lw	a5,96(a4)
    800057dc:	8b8d                	andi	a5,a5,3
    800057de:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    800057e0:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    800057e4:	689c                	ld	a5,16(s1)
    800057e6:	0204d703          	lhu	a4,32(s1)
    800057ea:	0027d783          	lhu	a5,2(a5)
    800057ee:	04f70663          	beq	a4,a5,8000583a <virtio_disk_intr+0x82>
    __sync_synchronize();
    800057f2:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    800057f6:	6898                	ld	a4,16(s1)
    800057f8:	0204d783          	lhu	a5,32(s1)
    800057fc:	8b9d                	andi	a5,a5,7
    800057fe:	078e                	slli	a5,a5,0x3
    80005800:	97ba                	add	a5,a5,a4
    80005802:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005804:	00278713          	addi	a4,a5,2
    80005808:	0712                	slli	a4,a4,0x4
    8000580a:	9726                	add	a4,a4,s1
    8000580c:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80005810:	e321                	bnez	a4,80005850 <virtio_disk_intr+0x98>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005812:	0789                	addi	a5,a5,2
    80005814:	0792                	slli	a5,a5,0x4
    80005816:	97a6                	add	a5,a5,s1
    80005818:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    8000581a:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000581e:	ed0fc0ef          	jal	ra,80001eee <wakeup>

    disk.used_idx += 1;
    80005822:	0204d783          	lhu	a5,32(s1)
    80005826:	2785                	addiw	a5,a5,1
    80005828:	17c2                	slli	a5,a5,0x30
    8000582a:	93c1                	srli	a5,a5,0x30
    8000582c:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005830:	6898                	ld	a4,16(s1)
    80005832:	00275703          	lhu	a4,2(a4)
    80005836:	faf71ee3          	bne	a4,a5,800057f2 <virtio_disk_intr+0x3a>
  }

  release(&disk.vdisk_lock);
    8000583a:	00020517          	auipc	a0,0x20
    8000583e:	28650513          	addi	a0,a0,646 # 80025ac0 <disk+0x128>
    80005842:	c44fb0ef          	jal	ra,80000c86 <release>
}
    80005846:	60e2                	ld	ra,24(sp)
    80005848:	6442                	ld	s0,16(sp)
    8000584a:	64a2                	ld	s1,8(sp)
    8000584c:	6105                	addi	sp,sp,32
    8000584e:	8082                	ret
      panic("virtio_disk_intr status");
    80005850:	00002517          	auipc	a0,0x2
    80005854:	0f850513          	addi	a0,a0,248 # 80007948 <syscall_names+0x3d8>
    80005858:	f11fa0ef          	jal	ra,80000768 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
