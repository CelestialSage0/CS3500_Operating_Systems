
user/_bttest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
// user/bttest.c
#include "kernel/types.h"
#include "user/user.h"
int
main(int argc, char *argv[])
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
// Call sleep(1) so sys_sleep() runs in kernel and triggers
sleep(1);
   8:	4505                	li	a0,1
   a:	312000ef          	jal	ra,31c <sleep>
printf("bttest: returned from sleep\n");
   e:	00001517          	auipc	a0,0x1
  12:	86250513          	addi	a0,a0,-1950 # 870 <malloc+0xec>
  16:	6b4000ef          	jal	ra,6ca <printf>
exit(0);
  1a:	4501                	li	a0,0
  1c:	270000ef          	jal	ra,28c <exit>

0000000000000020 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  20:	1141                	addi	sp,sp,-16
  22:	e406                	sd	ra,8(sp)
  24:	e022                	sd	s0,0(sp)
  26:	0800                	addi	s0,sp,16
  extern int main();
  main();
  28:	fd9ff0ef          	jal	ra,0 <main>
  exit(0);
  2c:	4501                	li	a0,0
  2e:	25e000ef          	jal	ra,28c <exit>

0000000000000032 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  32:	1141                	addi	sp,sp,-16
  34:	e422                	sd	s0,8(sp)
  36:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  38:	87aa                	mv	a5,a0
  3a:	0585                	addi	a1,a1,1
  3c:	0785                	addi	a5,a5,1
  3e:	fff5c703          	lbu	a4,-1(a1)
  42:	fee78fa3          	sb	a4,-1(a5)
  46:	fb75                	bnez	a4,3a <strcpy+0x8>
    ;
  return os;
}
  48:	6422                	ld	s0,8(sp)
  4a:	0141                	addi	sp,sp,16
  4c:	8082                	ret

000000000000004e <strcmp>:

int
strcmp(const char *p, const char *q)
{
  4e:	1141                	addi	sp,sp,-16
  50:	e422                	sd	s0,8(sp)
  52:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  54:	00054783          	lbu	a5,0(a0)
  58:	cb91                	beqz	a5,6c <strcmp+0x1e>
  5a:	0005c703          	lbu	a4,0(a1)
  5e:	00f71763          	bne	a4,a5,6c <strcmp+0x1e>
    p++, q++;
  62:	0505                	addi	a0,a0,1
  64:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  66:	00054783          	lbu	a5,0(a0)
  6a:	fbe5                	bnez	a5,5a <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
  6c:	0005c503          	lbu	a0,0(a1)
}
  70:	40a7853b          	subw	a0,a5,a0
  74:	6422                	ld	s0,8(sp)
  76:	0141                	addi	sp,sp,16
  78:	8082                	ret

000000000000007a <strlen>:

uint
strlen(const char *s)
{
  7a:	1141                	addi	sp,sp,-16
  7c:	e422                	sd	s0,8(sp)
  7e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  80:	00054783          	lbu	a5,0(a0)
  84:	cf91                	beqz	a5,a0 <strlen+0x26>
  86:	0505                	addi	a0,a0,1
  88:	87aa                	mv	a5,a0
  8a:	4685                	li	a3,1
  8c:	9e89                	subw	a3,a3,a0
  8e:	00f6853b          	addw	a0,a3,a5
  92:	0785                	addi	a5,a5,1
  94:	fff7c703          	lbu	a4,-1(a5)
  98:	fb7d                	bnez	a4,8e <strlen+0x14>
    ;
  return n;
}
  9a:	6422                	ld	s0,8(sp)
  9c:	0141                	addi	sp,sp,16
  9e:	8082                	ret
  for(n = 0; s[n]; n++)
  a0:	4501                	li	a0,0
  a2:	bfe5                	j	9a <strlen+0x20>

00000000000000a4 <memset>:

void*
memset(void *dst, int c, uint n)
{
  a4:	1141                	addi	sp,sp,-16
  a6:	e422                	sd	s0,8(sp)
  a8:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  aa:	ca19                	beqz	a2,c0 <memset+0x1c>
  ac:	87aa                	mv	a5,a0
  ae:	1602                	slli	a2,a2,0x20
  b0:	9201                	srli	a2,a2,0x20
  b2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  b6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  ba:	0785                	addi	a5,a5,1
  bc:	fee79de3          	bne	a5,a4,b6 <memset+0x12>
  }
  return dst;
}
  c0:	6422                	ld	s0,8(sp)
  c2:	0141                	addi	sp,sp,16
  c4:	8082                	ret

00000000000000c6 <strchr>:

char*
strchr(const char *s, char c)
{
  c6:	1141                	addi	sp,sp,-16
  c8:	e422                	sd	s0,8(sp)
  ca:	0800                	addi	s0,sp,16
  for(; *s; s++)
  cc:	00054783          	lbu	a5,0(a0)
  d0:	cb99                	beqz	a5,e6 <strchr+0x20>
    if(*s == c)
  d2:	00f58763          	beq	a1,a5,e0 <strchr+0x1a>
  for(; *s; s++)
  d6:	0505                	addi	a0,a0,1
  d8:	00054783          	lbu	a5,0(a0)
  dc:	fbfd                	bnez	a5,d2 <strchr+0xc>
      return (char*)s;
  return 0;
  de:	4501                	li	a0,0
}
  e0:	6422                	ld	s0,8(sp)
  e2:	0141                	addi	sp,sp,16
  e4:	8082                	ret
  return 0;
  e6:	4501                	li	a0,0
  e8:	bfe5                	j	e0 <strchr+0x1a>

00000000000000ea <gets>:

char*
gets(char *buf, int max)
{
  ea:	711d                	addi	sp,sp,-96
  ec:	ec86                	sd	ra,88(sp)
  ee:	e8a2                	sd	s0,80(sp)
  f0:	e4a6                	sd	s1,72(sp)
  f2:	e0ca                	sd	s2,64(sp)
  f4:	fc4e                	sd	s3,56(sp)
  f6:	f852                	sd	s4,48(sp)
  f8:	f456                	sd	s5,40(sp)
  fa:	f05a                	sd	s6,32(sp)
  fc:	ec5e                	sd	s7,24(sp)
  fe:	1080                	addi	s0,sp,96
 100:	8baa                	mv	s7,a0
 102:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 104:	892a                	mv	s2,a0
 106:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 108:	4aa9                	li	s5,10
 10a:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 10c:	89a6                	mv	s3,s1
 10e:	2485                	addiw	s1,s1,1
 110:	0344d663          	bge	s1,s4,13c <gets+0x52>
    cc = read(0, &c, 1);
 114:	4605                	li	a2,1
 116:	faf40593          	addi	a1,s0,-81
 11a:	4501                	li	a0,0
 11c:	188000ef          	jal	ra,2a4 <read>
    if(cc < 1)
 120:	00a05e63          	blez	a0,13c <gets+0x52>
    buf[i++] = c;
 124:	faf44783          	lbu	a5,-81(s0)
 128:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 12c:	01578763          	beq	a5,s5,13a <gets+0x50>
 130:	0905                	addi	s2,s2,1
 132:	fd679de3          	bne	a5,s6,10c <gets+0x22>
  for(i=0; i+1 < max; ){
 136:	89a6                	mv	s3,s1
 138:	a011                	j	13c <gets+0x52>
 13a:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 13c:	99de                	add	s3,s3,s7
 13e:	00098023          	sb	zero,0(s3)
  return buf;
}
 142:	855e                	mv	a0,s7
 144:	60e6                	ld	ra,88(sp)
 146:	6446                	ld	s0,80(sp)
 148:	64a6                	ld	s1,72(sp)
 14a:	6906                	ld	s2,64(sp)
 14c:	79e2                	ld	s3,56(sp)
 14e:	7a42                	ld	s4,48(sp)
 150:	7aa2                	ld	s5,40(sp)
 152:	7b02                	ld	s6,32(sp)
 154:	6be2                	ld	s7,24(sp)
 156:	6125                	addi	sp,sp,96
 158:	8082                	ret

000000000000015a <stat>:

int
stat(const char *n, struct stat *st)
{
 15a:	1101                	addi	sp,sp,-32
 15c:	ec06                	sd	ra,24(sp)
 15e:	e822                	sd	s0,16(sp)
 160:	e426                	sd	s1,8(sp)
 162:	e04a                	sd	s2,0(sp)
 164:	1000                	addi	s0,sp,32
 166:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 168:	4581                	li	a1,0
 16a:	162000ef          	jal	ra,2cc <open>
  if(fd < 0)
 16e:	02054163          	bltz	a0,190 <stat+0x36>
 172:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 174:	85ca                	mv	a1,s2
 176:	16e000ef          	jal	ra,2e4 <fstat>
 17a:	892a                	mv	s2,a0
  close(fd);
 17c:	8526                	mv	a0,s1
 17e:	136000ef          	jal	ra,2b4 <close>
  return r;
}
 182:	854a                	mv	a0,s2
 184:	60e2                	ld	ra,24(sp)
 186:	6442                	ld	s0,16(sp)
 188:	64a2                	ld	s1,8(sp)
 18a:	6902                	ld	s2,0(sp)
 18c:	6105                	addi	sp,sp,32
 18e:	8082                	ret
    return -1;
 190:	597d                	li	s2,-1
 192:	bfc5                	j	182 <stat+0x28>

0000000000000194 <atoi>:

int
atoi(const char *s)
{
 194:	1141                	addi	sp,sp,-16
 196:	e422                	sd	s0,8(sp)
 198:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 19a:	00054603          	lbu	a2,0(a0)
 19e:	fd06079b          	addiw	a5,a2,-48
 1a2:	0ff7f793          	zext.b	a5,a5
 1a6:	4725                	li	a4,9
 1a8:	02f76963          	bltu	a4,a5,1da <atoi+0x46>
 1ac:	86aa                	mv	a3,a0
  n = 0;
 1ae:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 1b0:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 1b2:	0685                	addi	a3,a3,1
 1b4:	0025179b          	slliw	a5,a0,0x2
 1b8:	9fa9                	addw	a5,a5,a0
 1ba:	0017979b          	slliw	a5,a5,0x1
 1be:	9fb1                	addw	a5,a5,a2
 1c0:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1c4:	0006c603          	lbu	a2,0(a3)
 1c8:	fd06071b          	addiw	a4,a2,-48
 1cc:	0ff77713          	zext.b	a4,a4
 1d0:	fee5f1e3          	bgeu	a1,a4,1b2 <atoi+0x1e>
  return n;
}
 1d4:	6422                	ld	s0,8(sp)
 1d6:	0141                	addi	sp,sp,16
 1d8:	8082                	ret
  n = 0;
 1da:	4501                	li	a0,0
 1dc:	bfe5                	j	1d4 <atoi+0x40>

00000000000001de <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1de:	1141                	addi	sp,sp,-16
 1e0:	e422                	sd	s0,8(sp)
 1e2:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 1e4:	02b57463          	bgeu	a0,a1,20c <memmove+0x2e>
    while(n-- > 0)
 1e8:	00c05f63          	blez	a2,206 <memmove+0x28>
 1ec:	1602                	slli	a2,a2,0x20
 1ee:	9201                	srli	a2,a2,0x20
 1f0:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 1f4:	872a                	mv	a4,a0
      *dst++ = *src++;
 1f6:	0585                	addi	a1,a1,1
 1f8:	0705                	addi	a4,a4,1
 1fa:	fff5c683          	lbu	a3,-1(a1)
 1fe:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 202:	fee79ae3          	bne	a5,a4,1f6 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 206:	6422                	ld	s0,8(sp)
 208:	0141                	addi	sp,sp,16
 20a:	8082                	ret
    dst += n;
 20c:	00c50733          	add	a4,a0,a2
    src += n;
 210:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 212:	fec05ae3          	blez	a2,206 <memmove+0x28>
 216:	fff6079b          	addiw	a5,a2,-1
 21a:	1782                	slli	a5,a5,0x20
 21c:	9381                	srli	a5,a5,0x20
 21e:	fff7c793          	not	a5,a5
 222:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 224:	15fd                	addi	a1,a1,-1
 226:	177d                	addi	a4,a4,-1
 228:	0005c683          	lbu	a3,0(a1)
 22c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 230:	fee79ae3          	bne	a5,a4,224 <memmove+0x46>
 234:	bfc9                	j	206 <memmove+0x28>

0000000000000236 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 236:	1141                	addi	sp,sp,-16
 238:	e422                	sd	s0,8(sp)
 23a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 23c:	ca05                	beqz	a2,26c <memcmp+0x36>
 23e:	fff6069b          	addiw	a3,a2,-1
 242:	1682                	slli	a3,a3,0x20
 244:	9281                	srli	a3,a3,0x20
 246:	0685                	addi	a3,a3,1
 248:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 24a:	00054783          	lbu	a5,0(a0)
 24e:	0005c703          	lbu	a4,0(a1)
 252:	00e79863          	bne	a5,a4,262 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 256:	0505                	addi	a0,a0,1
    p2++;
 258:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 25a:	fed518e3          	bne	a0,a3,24a <memcmp+0x14>
  }
  return 0;
 25e:	4501                	li	a0,0
 260:	a019                	j	266 <memcmp+0x30>
      return *p1 - *p2;
 262:	40e7853b          	subw	a0,a5,a4
}
 266:	6422                	ld	s0,8(sp)
 268:	0141                	addi	sp,sp,16
 26a:	8082                	ret
  return 0;
 26c:	4501                	li	a0,0
 26e:	bfe5                	j	266 <memcmp+0x30>

0000000000000270 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 270:	1141                	addi	sp,sp,-16
 272:	e406                	sd	ra,8(sp)
 274:	e022                	sd	s0,0(sp)
 276:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 278:	f67ff0ef          	jal	ra,1de <memmove>
}
 27c:	60a2                	ld	ra,8(sp)
 27e:	6402                	ld	s0,0(sp)
 280:	0141                	addi	sp,sp,16
 282:	8082                	ret

0000000000000284 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 284:	4885                	li	a7,1
 ecall
 286:	00000073          	ecall
 ret
 28a:	8082                	ret

000000000000028c <exit>:
.global exit
exit:
 li a7, SYS_exit
 28c:	4889                	li	a7,2
 ecall
 28e:	00000073          	ecall
 ret
 292:	8082                	ret

0000000000000294 <wait>:
.global wait
wait:
 li a7, SYS_wait
 294:	488d                	li	a7,3
 ecall
 296:	00000073          	ecall
 ret
 29a:	8082                	ret

000000000000029c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 29c:	4891                	li	a7,4
 ecall
 29e:	00000073          	ecall
 ret
 2a2:	8082                	ret

00000000000002a4 <read>:
.global read
read:
 li a7, SYS_read
 2a4:	4895                	li	a7,5
 ecall
 2a6:	00000073          	ecall
 ret
 2aa:	8082                	ret

00000000000002ac <write>:
.global write
write:
 li a7, SYS_write
 2ac:	48c1                	li	a7,16
 ecall
 2ae:	00000073          	ecall
 ret
 2b2:	8082                	ret

00000000000002b4 <close>:
.global close
close:
 li a7, SYS_close
 2b4:	48d5                	li	a7,21
 ecall
 2b6:	00000073          	ecall
 ret
 2ba:	8082                	ret

00000000000002bc <kill>:
.global kill
kill:
 li a7, SYS_kill
 2bc:	4899                	li	a7,6
 ecall
 2be:	00000073          	ecall
 ret
 2c2:	8082                	ret

00000000000002c4 <exec>:
.global exec
exec:
 li a7, SYS_exec
 2c4:	489d                	li	a7,7
 ecall
 2c6:	00000073          	ecall
 ret
 2ca:	8082                	ret

00000000000002cc <open>:
.global open
open:
 li a7, SYS_open
 2cc:	48bd                	li	a7,15
 ecall
 2ce:	00000073          	ecall
 ret
 2d2:	8082                	ret

00000000000002d4 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 2d4:	48c5                	li	a7,17
 ecall
 2d6:	00000073          	ecall
 ret
 2da:	8082                	ret

00000000000002dc <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 2dc:	48c9                	li	a7,18
 ecall
 2de:	00000073          	ecall
 ret
 2e2:	8082                	ret

00000000000002e4 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 2e4:	48a1                	li	a7,8
 ecall
 2e6:	00000073          	ecall
 ret
 2ea:	8082                	ret

00000000000002ec <link>:
.global link
link:
 li a7, SYS_link
 2ec:	48cd                	li	a7,19
 ecall
 2ee:	00000073          	ecall
 ret
 2f2:	8082                	ret

00000000000002f4 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 2f4:	48d1                	li	a7,20
 ecall
 2f6:	00000073          	ecall
 ret
 2fa:	8082                	ret

00000000000002fc <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 2fc:	48a5                	li	a7,9
 ecall
 2fe:	00000073          	ecall
 ret
 302:	8082                	ret

0000000000000304 <dup>:
.global dup
dup:
 li a7, SYS_dup
 304:	48a9                	li	a7,10
 ecall
 306:	00000073          	ecall
 ret
 30a:	8082                	ret

000000000000030c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 30c:	48ad                	li	a7,11
 ecall
 30e:	00000073          	ecall
 ret
 312:	8082                	ret

0000000000000314 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 314:	48b1                	li	a7,12
 ecall
 316:	00000073          	ecall
 ret
 31a:	8082                	ret

000000000000031c <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 31c:	48b5                	li	a7,13
 ecall
 31e:	00000073          	ecall
 ret
 322:	8082                	ret

0000000000000324 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 324:	48b9                	li	a7,14
 ecall
 326:	00000073          	ecall
 ret
 32a:	8082                	ret

000000000000032c <trace>:
.global trace
trace:
 li a7, SYS_trace
 32c:	48d9                	li	a7,22
 ecall
 32e:	00000073          	ecall
 ret
 332:	8082                	ret

0000000000000334 <sigalarm>:
.global sigalarm
sigalarm:
 li a7, SYS_sigalarm
 334:	48dd                	li	a7,23
 ecall
 336:	00000073          	ecall
 ret
 33a:	8082                	ret

000000000000033c <sigreturn>:
.global sigreturn
sigreturn:
 li a7, SYS_sigreturn
 33c:	48e1                	li	a7,24
 ecall
 33e:	00000073          	ecall
 ret
 342:	8082                	ret

0000000000000344 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 344:	1101                	addi	sp,sp,-32
 346:	ec06                	sd	ra,24(sp)
 348:	e822                	sd	s0,16(sp)
 34a:	1000                	addi	s0,sp,32
 34c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 350:	4605                	li	a2,1
 352:	fef40593          	addi	a1,s0,-17
 356:	f57ff0ef          	jal	ra,2ac <write>
}
 35a:	60e2                	ld	ra,24(sp)
 35c:	6442                	ld	s0,16(sp)
 35e:	6105                	addi	sp,sp,32
 360:	8082                	ret

0000000000000362 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 362:	715d                	addi	sp,sp,-80
 364:	e486                	sd	ra,72(sp)
 366:	e0a2                	sd	s0,64(sp)
 368:	fc26                	sd	s1,56(sp)
 36a:	f84a                	sd	s2,48(sp)
 36c:	f44e                	sd	s3,40(sp)
 36e:	0880                	addi	s0,sp,80
 370:	84aa                	mv	s1,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 372:	c299                	beqz	a3,378 <printint+0x16>
 374:	0805c663          	bltz	a1,400 <printint+0x9e>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 378:	2581                	sext.w	a1,a1
  neg = 0;
 37a:	4881                	li	a7,0
 37c:	fb840693          	addi	a3,s0,-72
  }

  i = 0;
 380:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 382:	2601                	sext.w	a2,a2
 384:	00000517          	auipc	a0,0x0
 388:	51450513          	addi	a0,a0,1300 # 898 <digits>
 38c:	883a                	mv	a6,a4
 38e:	2705                	addiw	a4,a4,1
 390:	02c5f7bb          	remuw	a5,a1,a2
 394:	1782                	slli	a5,a5,0x20
 396:	9381                	srli	a5,a5,0x20
 398:	97aa                	add	a5,a5,a0
 39a:	0007c783          	lbu	a5,0(a5)
 39e:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 3a2:	0005879b          	sext.w	a5,a1
 3a6:	02c5d5bb          	divuw	a1,a1,a2
 3aa:	0685                	addi	a3,a3,1
 3ac:	fec7f0e3          	bgeu	a5,a2,38c <printint+0x2a>
  if(neg)
 3b0:	00088b63          	beqz	a7,3c6 <printint+0x64>
    buf[i++] = '-';
 3b4:	fd040793          	addi	a5,s0,-48
 3b8:	973e                	add	a4,a4,a5
 3ba:	02d00793          	li	a5,45
 3be:	fef70423          	sb	a5,-24(a4)
 3c2:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 3c6:	02e05663          	blez	a4,3f2 <printint+0x90>
 3ca:	fb840793          	addi	a5,s0,-72
 3ce:	00e78933          	add	s2,a5,a4
 3d2:	fff78993          	addi	s3,a5,-1
 3d6:	99ba                	add	s3,s3,a4
 3d8:	377d                	addiw	a4,a4,-1
 3da:	1702                	slli	a4,a4,0x20
 3dc:	9301                	srli	a4,a4,0x20
 3de:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 3e2:	fff94583          	lbu	a1,-1(s2)
 3e6:	8526                	mv	a0,s1
 3e8:	f5dff0ef          	jal	ra,344 <putc>
  while(--i >= 0)
 3ec:	197d                	addi	s2,s2,-1
 3ee:	ff391ae3          	bne	s2,s3,3e2 <printint+0x80>
}
 3f2:	60a6                	ld	ra,72(sp)
 3f4:	6406                	ld	s0,64(sp)
 3f6:	74e2                	ld	s1,56(sp)
 3f8:	7942                	ld	s2,48(sp)
 3fa:	79a2                	ld	s3,40(sp)
 3fc:	6161                	addi	sp,sp,80
 3fe:	8082                	ret
    x = -xx;
 400:	40b005bb          	negw	a1,a1
    neg = 1;
 404:	4885                	li	a7,1
    x = -xx;
 406:	bf9d                	j	37c <printint+0x1a>

0000000000000408 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 408:	7119                	addi	sp,sp,-128
 40a:	fc86                	sd	ra,120(sp)
 40c:	f8a2                	sd	s0,112(sp)
 40e:	f4a6                	sd	s1,104(sp)
 410:	f0ca                	sd	s2,96(sp)
 412:	ecce                	sd	s3,88(sp)
 414:	e8d2                	sd	s4,80(sp)
 416:	e4d6                	sd	s5,72(sp)
 418:	e0da                	sd	s6,64(sp)
 41a:	fc5e                	sd	s7,56(sp)
 41c:	f862                	sd	s8,48(sp)
 41e:	f466                	sd	s9,40(sp)
 420:	f06a                	sd	s10,32(sp)
 422:	ec6e                	sd	s11,24(sp)
 424:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 426:	0005c903          	lbu	s2,0(a1)
 42a:	24090c63          	beqz	s2,682 <vprintf+0x27a>
 42e:	8b2a                	mv	s6,a0
 430:	8a2e                	mv	s4,a1
 432:	8bb2                	mv	s7,a2
  state = 0;
 434:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 436:	4481                	li	s1,0
 438:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 43a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 43e:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 442:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 446:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 44a:	00000c97          	auipc	s9,0x0
 44e:	44ec8c93          	addi	s9,s9,1102 # 898 <digits>
 452:	a005                	j	472 <vprintf+0x6a>
        putc(fd, c0);
 454:	85ca                	mv	a1,s2
 456:	855a                	mv	a0,s6
 458:	eedff0ef          	jal	ra,344 <putc>
 45c:	a019                	j	462 <vprintf+0x5a>
    } else if(state == '%'){
 45e:	03598263          	beq	s3,s5,482 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 462:	2485                	addiw	s1,s1,1
 464:	8726                	mv	a4,s1
 466:	009a07b3          	add	a5,s4,s1
 46a:	0007c903          	lbu	s2,0(a5)
 46e:	20090a63          	beqz	s2,682 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 472:	0009079b          	sext.w	a5,s2
    if(state == 0){
 476:	fe0994e3          	bnez	s3,45e <vprintf+0x56>
      if(c0 == '%'){
 47a:	fd579de3          	bne	a5,s5,454 <vprintf+0x4c>
        state = '%';
 47e:	89be                	mv	s3,a5
 480:	b7cd                	j	462 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 482:	c3c1                	beqz	a5,502 <vprintf+0xfa>
 484:	00ea06b3          	add	a3,s4,a4
 488:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 48c:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 48e:	c681                	beqz	a3,496 <vprintf+0x8e>
 490:	9752                	add	a4,a4,s4
 492:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 496:	03878e63          	beq	a5,s8,4d2 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 49a:	05a78863          	beq	a5,s10,4ea <vprintf+0xe2>
      } else if(c0 == 'u'){
 49e:	0db78b63          	beq	a5,s11,574 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 4a2:	07800713          	li	a4,120
 4a6:	10e78d63          	beq	a5,a4,5c0 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 4aa:	07000713          	li	a4,112
 4ae:	14e78263          	beq	a5,a4,5f2 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 4b2:	06300713          	li	a4,99
 4b6:	16e78f63          	beq	a5,a4,634 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 4ba:	07300713          	li	a4,115
 4be:	18e78563          	beq	a5,a4,648 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 4c2:	05579063          	bne	a5,s5,502 <vprintf+0xfa>
        putc(fd, '%');
 4c6:	85d6                	mv	a1,s5
 4c8:	855a                	mv	a0,s6
 4ca:	e7bff0ef          	jal	ra,344 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 4ce:	4981                	li	s3,0
 4d0:	bf49                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 4d2:	008b8913          	addi	s2,s7,8
 4d6:	4685                	li	a3,1
 4d8:	4629                	li	a2,10
 4da:	000ba583          	lw	a1,0(s7)
 4de:	855a                	mv	a0,s6
 4e0:	e83ff0ef          	jal	ra,362 <printint>
 4e4:	8bca                	mv	s7,s2
      state = 0;
 4e6:	4981                	li	s3,0
 4e8:	bfad                	j	462 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 4ea:	03868663          	beq	a3,s8,516 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4ee:	05a68163          	beq	a3,s10,530 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 4f2:	09b68d63          	beq	a3,s11,58c <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 4f6:	03a68f63          	beq	a3,s10,534 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 4fa:	07800793          	li	a5,120
 4fe:	0cf68d63          	beq	a3,a5,5d8 <vprintf+0x1d0>
        putc(fd, '%');
 502:	85d6                	mv	a1,s5
 504:	855a                	mv	a0,s6
 506:	e3fff0ef          	jal	ra,344 <putc>
        putc(fd, c0);
 50a:	85ca                	mv	a1,s2
 50c:	855a                	mv	a0,s6
 50e:	e37ff0ef          	jal	ra,344 <putc>
      state = 0;
 512:	4981                	li	s3,0
 514:	b7b9                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 516:	008b8913          	addi	s2,s7,8
 51a:	4685                	li	a3,1
 51c:	4629                	li	a2,10
 51e:	000bb583          	ld	a1,0(s7)
 522:	855a                	mv	a0,s6
 524:	e3fff0ef          	jal	ra,362 <printint>
        i += 1;
 528:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 52a:	8bca                	mv	s7,s2
      state = 0;
 52c:	4981                	li	s3,0
        i += 1;
 52e:	bf15                	j	462 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 530:	03860563          	beq	a2,s8,55a <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 534:	07b60963          	beq	a2,s11,5a6 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 538:	07800793          	li	a5,120
 53c:	fcf613e3          	bne	a2,a5,502 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 540:	008b8913          	addi	s2,s7,8
 544:	4681                	li	a3,0
 546:	4641                	li	a2,16
 548:	000bb583          	ld	a1,0(s7)
 54c:	855a                	mv	a0,s6
 54e:	e15ff0ef          	jal	ra,362 <printint>
        i += 2;
 552:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 554:	8bca                	mv	s7,s2
      state = 0;
 556:	4981                	li	s3,0
        i += 2;
 558:	b729                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 55a:	008b8913          	addi	s2,s7,8
 55e:	4685                	li	a3,1
 560:	4629                	li	a2,10
 562:	000bb583          	ld	a1,0(s7)
 566:	855a                	mv	a0,s6
 568:	dfbff0ef          	jal	ra,362 <printint>
        i += 2;
 56c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 56e:	8bca                	mv	s7,s2
      state = 0;
 570:	4981                	li	s3,0
        i += 2;
 572:	bdc5                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 574:	008b8913          	addi	s2,s7,8
 578:	4681                	li	a3,0
 57a:	4629                	li	a2,10
 57c:	000be583          	lwu	a1,0(s7)
 580:	855a                	mv	a0,s6
 582:	de1ff0ef          	jal	ra,362 <printint>
 586:	8bca                	mv	s7,s2
      state = 0;
 588:	4981                	li	s3,0
 58a:	bde1                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 58c:	008b8913          	addi	s2,s7,8
 590:	4681                	li	a3,0
 592:	4629                	li	a2,10
 594:	000bb583          	ld	a1,0(s7)
 598:	855a                	mv	a0,s6
 59a:	dc9ff0ef          	jal	ra,362 <printint>
        i += 1;
 59e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5a0:	8bca                	mv	s7,s2
      state = 0;
 5a2:	4981                	li	s3,0
        i += 1;
 5a4:	bd7d                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5a6:	008b8913          	addi	s2,s7,8
 5aa:	4681                	li	a3,0
 5ac:	4629                	li	a2,10
 5ae:	000bb583          	ld	a1,0(s7)
 5b2:	855a                	mv	a0,s6
 5b4:	dafff0ef          	jal	ra,362 <printint>
        i += 2;
 5b8:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5ba:	8bca                	mv	s7,s2
      state = 0;
 5bc:	4981                	li	s3,0
        i += 2;
 5be:	b555                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 5c0:	008b8913          	addi	s2,s7,8
 5c4:	4681                	li	a3,0
 5c6:	4641                	li	a2,16
 5c8:	000be583          	lwu	a1,0(s7)
 5cc:	855a                	mv	a0,s6
 5ce:	d95ff0ef          	jal	ra,362 <printint>
 5d2:	8bca                	mv	s7,s2
      state = 0;
 5d4:	4981                	li	s3,0
 5d6:	b571                	j	462 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5d8:	008b8913          	addi	s2,s7,8
 5dc:	4681                	li	a3,0
 5de:	4641                	li	a2,16
 5e0:	000bb583          	ld	a1,0(s7)
 5e4:	855a                	mv	a0,s6
 5e6:	d7dff0ef          	jal	ra,362 <printint>
        i += 1;
 5ea:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5ec:	8bca                	mv	s7,s2
      state = 0;
 5ee:	4981                	li	s3,0
        i += 1;
 5f0:	bd8d                	j	462 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 5f2:	008b8793          	addi	a5,s7,8
 5f6:	f8f43423          	sd	a5,-120(s0)
 5fa:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5fe:	03000593          	li	a1,48
 602:	855a                	mv	a0,s6
 604:	d41ff0ef          	jal	ra,344 <putc>
  putc(fd, 'x');
 608:	07800593          	li	a1,120
 60c:	855a                	mv	a0,s6
 60e:	d37ff0ef          	jal	ra,344 <putc>
 612:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 614:	03c9d793          	srli	a5,s3,0x3c
 618:	97e6                	add	a5,a5,s9
 61a:	0007c583          	lbu	a1,0(a5)
 61e:	855a                	mv	a0,s6
 620:	d25ff0ef          	jal	ra,344 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 624:	0992                	slli	s3,s3,0x4
 626:	397d                	addiw	s2,s2,-1
 628:	fe0916e3          	bnez	s2,614 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 62c:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 630:	4981                	li	s3,0
 632:	bd05                	j	462 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 634:	008b8913          	addi	s2,s7,8
 638:	000bc583          	lbu	a1,0(s7)
 63c:	855a                	mv	a0,s6
 63e:	d07ff0ef          	jal	ra,344 <putc>
 642:	8bca                	mv	s7,s2
      state = 0;
 644:	4981                	li	s3,0
 646:	bd31                	j	462 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 648:	008b8993          	addi	s3,s7,8
 64c:	000bb903          	ld	s2,0(s7)
 650:	00090f63          	beqz	s2,66e <vprintf+0x266>
        for(; *s; s++)
 654:	00094583          	lbu	a1,0(s2)
 658:	c195                	beqz	a1,67c <vprintf+0x274>
          putc(fd, *s);
 65a:	855a                	mv	a0,s6
 65c:	ce9ff0ef          	jal	ra,344 <putc>
        for(; *s; s++)
 660:	0905                	addi	s2,s2,1
 662:	00094583          	lbu	a1,0(s2)
 666:	f9f5                	bnez	a1,65a <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 668:	8bce                	mv	s7,s3
      state = 0;
 66a:	4981                	li	s3,0
 66c:	bbdd                	j	462 <vprintf+0x5a>
          s = "(null)";
 66e:	00000917          	auipc	s2,0x0
 672:	22290913          	addi	s2,s2,546 # 890 <malloc+0x10c>
        for(; *s; s++)
 676:	02800593          	li	a1,40
 67a:	b7c5                	j	65a <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 67c:	8bce                	mv	s7,s3
      state = 0;
 67e:	4981                	li	s3,0
 680:	b3cd                	j	462 <vprintf+0x5a>
    }
  }
}
 682:	70e6                	ld	ra,120(sp)
 684:	7446                	ld	s0,112(sp)
 686:	74a6                	ld	s1,104(sp)
 688:	7906                	ld	s2,96(sp)
 68a:	69e6                	ld	s3,88(sp)
 68c:	6a46                	ld	s4,80(sp)
 68e:	6aa6                	ld	s5,72(sp)
 690:	6b06                	ld	s6,64(sp)
 692:	7be2                	ld	s7,56(sp)
 694:	7c42                	ld	s8,48(sp)
 696:	7ca2                	ld	s9,40(sp)
 698:	7d02                	ld	s10,32(sp)
 69a:	6de2                	ld	s11,24(sp)
 69c:	6109                	addi	sp,sp,128
 69e:	8082                	ret

00000000000006a0 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6a0:	715d                	addi	sp,sp,-80
 6a2:	ec06                	sd	ra,24(sp)
 6a4:	e822                	sd	s0,16(sp)
 6a6:	1000                	addi	s0,sp,32
 6a8:	e010                	sd	a2,0(s0)
 6aa:	e414                	sd	a3,8(s0)
 6ac:	e818                	sd	a4,16(s0)
 6ae:	ec1c                	sd	a5,24(s0)
 6b0:	03043023          	sd	a6,32(s0)
 6b4:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6b8:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6bc:	8622                	mv	a2,s0
 6be:	d4bff0ef          	jal	ra,408 <vprintf>
}
 6c2:	60e2                	ld	ra,24(sp)
 6c4:	6442                	ld	s0,16(sp)
 6c6:	6161                	addi	sp,sp,80
 6c8:	8082                	ret

00000000000006ca <printf>:

void
printf(const char *fmt, ...)
{
 6ca:	711d                	addi	sp,sp,-96
 6cc:	ec06                	sd	ra,24(sp)
 6ce:	e822                	sd	s0,16(sp)
 6d0:	1000                	addi	s0,sp,32
 6d2:	e40c                	sd	a1,8(s0)
 6d4:	e810                	sd	a2,16(s0)
 6d6:	ec14                	sd	a3,24(s0)
 6d8:	f018                	sd	a4,32(s0)
 6da:	f41c                	sd	a5,40(s0)
 6dc:	03043823          	sd	a6,48(s0)
 6e0:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 6e4:	00840613          	addi	a2,s0,8
 6e8:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 6ec:	85aa                	mv	a1,a0
 6ee:	4505                	li	a0,1
 6f0:	d19ff0ef          	jal	ra,408 <vprintf>
}
 6f4:	60e2                	ld	ra,24(sp)
 6f6:	6442                	ld	s0,16(sp)
 6f8:	6125                	addi	sp,sp,96
 6fa:	8082                	ret

00000000000006fc <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 6fc:	1141                	addi	sp,sp,-16
 6fe:	e422                	sd	s0,8(sp)
 700:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 702:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 706:	00001797          	auipc	a5,0x1
 70a:	8fa7b783          	ld	a5,-1798(a5) # 1000 <freep>
 70e:	a805                	j	73e <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 710:	4618                	lw	a4,8(a2)
 712:	9db9                	addw	a1,a1,a4
 714:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 718:	6398                	ld	a4,0(a5)
 71a:	6318                	ld	a4,0(a4)
 71c:	fee53823          	sd	a4,-16(a0)
 720:	a091                	j	764 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 722:	ff852703          	lw	a4,-8(a0)
 726:	9e39                	addw	a2,a2,a4
 728:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 72a:	ff053703          	ld	a4,-16(a0)
 72e:	e398                	sd	a4,0(a5)
 730:	a099                	j	776 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 732:	6398                	ld	a4,0(a5)
 734:	00e7e463          	bltu	a5,a4,73c <free+0x40>
 738:	00e6ea63          	bltu	a3,a4,74c <free+0x50>
{
 73c:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 73e:	fed7fae3          	bgeu	a5,a3,732 <free+0x36>
 742:	6398                	ld	a4,0(a5)
 744:	00e6e463          	bltu	a3,a4,74c <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 748:	fee7eae3          	bltu	a5,a4,73c <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 74c:	ff852583          	lw	a1,-8(a0)
 750:	6390                	ld	a2,0(a5)
 752:	02059813          	slli	a6,a1,0x20
 756:	01c85713          	srli	a4,a6,0x1c
 75a:	9736                	add	a4,a4,a3
 75c:	fae60ae3          	beq	a2,a4,710 <free+0x14>
    bp->s.ptr = p->s.ptr;
 760:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 764:	4790                	lw	a2,8(a5)
 766:	02061593          	slli	a1,a2,0x20
 76a:	01c5d713          	srli	a4,a1,0x1c
 76e:	973e                	add	a4,a4,a5
 770:	fae689e3          	beq	a3,a4,722 <free+0x26>
  } else
    p->s.ptr = bp;
 774:	e394                	sd	a3,0(a5)
  freep = p;
 776:	00001717          	auipc	a4,0x1
 77a:	88f73523          	sd	a5,-1910(a4) # 1000 <freep>
}
 77e:	6422                	ld	s0,8(sp)
 780:	0141                	addi	sp,sp,16
 782:	8082                	ret

0000000000000784 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 784:	7139                	addi	sp,sp,-64
 786:	fc06                	sd	ra,56(sp)
 788:	f822                	sd	s0,48(sp)
 78a:	f426                	sd	s1,40(sp)
 78c:	f04a                	sd	s2,32(sp)
 78e:	ec4e                	sd	s3,24(sp)
 790:	e852                	sd	s4,16(sp)
 792:	e456                	sd	s5,8(sp)
 794:	e05a                	sd	s6,0(sp)
 796:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 798:	02051493          	slli	s1,a0,0x20
 79c:	9081                	srli	s1,s1,0x20
 79e:	04bd                	addi	s1,s1,15
 7a0:	8091                	srli	s1,s1,0x4
 7a2:	0014899b          	addiw	s3,s1,1
 7a6:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 7a8:	00001517          	auipc	a0,0x1
 7ac:	85853503          	ld	a0,-1960(a0) # 1000 <freep>
 7b0:	c515                	beqz	a0,7dc <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7b2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7b4:	4798                	lw	a4,8(a5)
 7b6:	02977f63          	bgeu	a4,s1,7f4 <malloc+0x70>
 7ba:	8a4e                	mv	s4,s3
 7bc:	0009871b          	sext.w	a4,s3
 7c0:	6685                	lui	a3,0x1
 7c2:	00d77363          	bgeu	a4,a3,7c8 <malloc+0x44>
 7c6:	6a05                	lui	s4,0x1
 7c8:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 7cc:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7d0:	00001917          	auipc	s2,0x1
 7d4:	83090913          	addi	s2,s2,-2000 # 1000 <freep>
  if(p == (char*)-1)
 7d8:	5afd                	li	s5,-1
 7da:	a885                	j	84a <malloc+0xc6>
    base.s.ptr = freep = prevp = &base;
 7dc:	00001797          	auipc	a5,0x1
 7e0:	83478793          	addi	a5,a5,-1996 # 1010 <base>
 7e4:	00001717          	auipc	a4,0x1
 7e8:	80f73e23          	sd	a5,-2020(a4) # 1000 <freep>
 7ec:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 7ee:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 7f2:	b7e1                	j	7ba <malloc+0x36>
      if(p->s.size == nunits)
 7f4:	02e48c63          	beq	s1,a4,82c <malloc+0xa8>
        p->s.size -= nunits;
 7f8:	4137073b          	subw	a4,a4,s3
 7fc:	c798                	sw	a4,8(a5)
        p += p->s.size;
 7fe:	02071693          	slli	a3,a4,0x20
 802:	01c6d713          	srli	a4,a3,0x1c
 806:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 808:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 80c:	00000717          	auipc	a4,0x0
 810:	7ea73a23          	sd	a0,2036(a4) # 1000 <freep>
      return (void*)(p + 1);
 814:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 818:	70e2                	ld	ra,56(sp)
 81a:	7442                	ld	s0,48(sp)
 81c:	74a2                	ld	s1,40(sp)
 81e:	7902                	ld	s2,32(sp)
 820:	69e2                	ld	s3,24(sp)
 822:	6a42                	ld	s4,16(sp)
 824:	6aa2                	ld	s5,8(sp)
 826:	6b02                	ld	s6,0(sp)
 828:	6121                	addi	sp,sp,64
 82a:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 82c:	6398                	ld	a4,0(a5)
 82e:	e118                	sd	a4,0(a0)
 830:	bff1                	j	80c <malloc+0x88>
  hp->s.size = nu;
 832:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 836:	0541                	addi	a0,a0,16
 838:	ec5ff0ef          	jal	ra,6fc <free>
  return freep;
 83c:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 840:	dd61                	beqz	a0,818 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 842:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 844:	4798                	lw	a4,8(a5)
 846:	fa9777e3          	bgeu	a4,s1,7f4 <malloc+0x70>
    if(p == freep)
 84a:	00093703          	ld	a4,0(s2)
 84e:	853e                	mv	a0,a5
 850:	fef719e3          	bne	a4,a5,842 <malloc+0xbe>
  p = sbrk(nu * sizeof(Header));
 854:	8552                	mv	a0,s4
 856:	abfff0ef          	jal	ra,314 <sbrk>
  if(p == (char*)-1)
 85a:	fd551ce3          	bne	a0,s5,832 <malloc+0xae>
        return 0;
 85e:	4501                	li	a0,0
 860:	bf65                	j	818 <malloc+0x94>
